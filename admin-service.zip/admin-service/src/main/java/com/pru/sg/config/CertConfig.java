package com.pru.sg.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CertConfig {

    @Value("${dp.keystorelocation.sit}")
    private String keyStoreLocationSIT;

    @Value("${dp.keystorelocation.uat}")
    private String keyStoreLocationUAT;

    @Value("${dp.keystorelocation.prd}")
    private String keyStoreLocationPRD;

    @Value("${dp.keystorepassword.sit}")
    private String keyStorePasswordSIT;

    @Value("${dp.keystorepassword.uat}")
    private String keyStorePasswordUAT;

    @Value("${dp.keystorepassword.prd}")
    private String keyStorePasswordPRD;

    @Value("${dp.protocol}")
    private String protocol;

    public String getKeyStoreLocationSIT() {
        return keyStoreLocationSIT;
    }

    public void setKeyStoreLocationSIT(String keyStoreLocationSIT) {
        this.keyStoreLocationSIT = keyStoreLocationSIT;
    }

    public String getKeyStoreLocationUAT() {
        return keyStoreLocationUAT;
    }

    public void setKeyStoreLocationUAT(String keyStoreLocationUAT) {
        this.keyStoreLocationUAT = keyStoreLocationUAT;
    }

    public String getKeyStoreLocationPRD() {
        return keyStoreLocationPRD;
    }

    public void setKeyStoreLocationPRD(String keyStoreLocationPRD) {
        this.keyStoreLocationPRD = keyStoreLocationPRD;
    }

    public String getKeyStorePasswordSIT() {
        return keyStorePasswordSIT;
    }

    public void setKeyStorePasswordSIT(String keyStorePasswordSIT) {
        this.keyStorePasswordSIT = keyStorePasswordSIT;
    }

    public String getKeyStorePasswordUAT() {
        return keyStorePasswordUAT;
    }

    public void setKeyStorePasswordUAT(String keyStorePasswordUAT) {
        this.keyStorePasswordUAT = keyStorePasswordUAT;
    }

    public String getKeyStorePasswordPRD() {
        return keyStorePasswordPRD;
    }

    public void setKeyStorePasswordPRD(String keyStorePasswordPRD) {
        this.keyStorePasswordPRD = keyStorePasswordPRD;
    }

    public String getProtocol() {
        return protocol;
    }

    public void setProtocol(String protocol) {
        this.protocol = protocol;
    }
}
