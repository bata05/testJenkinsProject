package com.pru.sg.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import java.util.Properties;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(entityManagerFactoryRef = "pruserviceEntityManagerFactory",
        transactionManagerRef = "pruserviceTransactionManager",
        basePackages = "com.pru.sg.repository.oracle")
public class DataSourceConfig {

    private static final Logger LOGGER = LoggerFactory.getLogger(DataSourceConfig.class);

    /*
    @Value("${jdbc.driverClassName}")
    private String jdbcDriverClass;

    @Value("${jdbc.url}")
    private String jdbcUrl;

    @Value("${jdbc.username}")
    private String jdbcUsername;

    @Value("${jdbc.password}")
    private String jdbcPassword;

    @Value("${hibernate.dialect}")
    private String hibernateDialect;

    @Value("${hibernate.default.schema}")
    private String hibernateDefaultSchema;

    @Value("${connection.jndiName}")
    private String jndiName;

    @Value("${jdbc.jndi.enable}")
    private boolean jndiEnable;

    */

    @Value("${dp.jpa.hibernate.show-sql}")
    private boolean hibernateShowSql;

    @Bean(name = "pruserviceEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(pruserviceDataSource());
        em.setPersistenceUnitName("oracle");
        em.setPackagesToScan(new String[]{"com.pru.sg.entity.oracle"});
        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        vendorAdapter.setShowSql(hibernateShowSql);
        em.setJpaVendorAdapter(vendorAdapter);
        em.setJpaProperties(additionalProperties());
        LOGGER.info("PRUSERVICE JDBC LocalContainerEntityManagerFactoryBean ======> created");
        return em;
    }

    @Primary
    @Bean
    @ConfigurationProperties("dp.datasource")
    public DataSource pruserviceDataSource() {

        return DataSourceBuilder.create().build();

        /*
        LOGGER.info("Is JNDI enable ======> {}", jndiEnable);
        if (jndiEnable) {
            LOGGER.info("Connection via JNDI name ======> {}", jndiName);
            JndiDataSourceLookup lookup = new JndiDataSourceLookup();
            return lookup.getDataSource(jndiName);
        } else {
            LOGGER.info("PRUSERVICE JDBC connection ======> using manual DB connection");
            DriverManagerDataSource dataSource = new DriverManagerDataSource();
            dataSource.setDriverClass(jdbcDriverClass);
            dataSource.setJdbcUrl(jdbcUrl);
            dataSource.setUser(jdbcUsername);
            dataSource.setPassword(jdbcPassword);
            return dataSource;
        }

        */
    }

    @Bean(name = "pruserviceTransactionManager")
    public PlatformTransactionManager transactionManager(@Qualifier("pruserviceEntityManagerFactory") EntityManagerFactory emf) {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(emf);
        return transactionManager;
    }

    @Bean
    public PersistenceExceptionTranslationPostProcessor exceptionTranslation() {
        return new PersistenceExceptionTranslationPostProcessor();
    }

    @Bean
    @ConfigurationProperties("dp.jpa")
    Properties additionalProperties() {
        Properties properties = new Properties();
        //properties.setProperty("hibernate.dialect", hibernateDialect);
        //properties.setProperty("hibernate.default_schema", hibernateDefaultSchema);
        //disable hibernate/jpa logging to improve performance.
        //properties.setProperty("hibernate.generate_statistics", "false");
        return properties;
    }
}