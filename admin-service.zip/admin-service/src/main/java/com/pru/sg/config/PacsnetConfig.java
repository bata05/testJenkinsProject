package com.pru.sg.config;

import com.mchange.v2.c3p0.DriverManagerDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import java.util.Properties;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
        entityManagerFactoryRef = "pacsnetEntityManagerFactory",
        transactionManagerRef = "pacsnetTransactionManager",
        basePackages = { "com.pru.sg.repository.db2" }
)
public class PacsnetConfig {

    private static final Logger LOGGER = LoggerFactory.getLogger(PacsnetConfig.class);

    @Value("${pacsnet.datasource.driver-class-name}")
    private String jdbcDriverClass;

    @Value("${pacsnet.datasource.jdbc-url}")
    private String jdbcUrl;

    @Value("${pacsnet.datasource.username}")
    private String jdbcUsername;

    @Value("${pacsnet.datasource.password}")
    private String jdbcPassword;

    @Value("${pacsnet.jpa.hibernate.dialect}")
    private String hibernateDialect;

    @Value("${pacsnet.jpa.hibernate.show-sql}")
    private boolean hibernateShowSql;

    @Bean(name = "pacsnetEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(pacsnetDataSource());
        em.setPersistenceUnitName("db2");
        em.setPackagesToScan(new String[] { "com.pru.sg.entity.db2"});
        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        vendorAdapter.setShowSql(hibernateShowSql);
        em.setJpaVendorAdapter(vendorAdapter);
        em.setJpaProperties(additionalProperties());
        LOGGER.info("PACSNET JDBC LocalContainerEntityManagerFactoryBean ======> created");
        return em;
    }

    @Bean
    public DataSource pacsnetDataSource() {
        LOGGER.info("PACSNET JDBC connection ======> using manual DB connection");
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClass(jdbcDriverClass);
        dataSource.setJdbcUrl(jdbcUrl);
        dataSource.setUser(jdbcUsername);
        dataSource.setPassword(jdbcPassword);
        return dataSource;
    }

    @Bean(name = "pacsnetTransactionManager")
    public PlatformTransactionManager transactionManager(@Qualifier("pacsnetEntityManagerFactory") EntityManagerFactory emf) {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(emf);
        return transactionManager;
    }

    @Bean
    public PersistenceExceptionTranslationPostProcessor exceptionTranslation() {
        return new PersistenceExceptionTranslationPostProcessor();
    }

    Properties additionalProperties() {
        Properties properties = new Properties();
        properties.setProperty("hibernate.dialect", hibernateDialect);
        //disable hibernate/jpa logging to improve performance.
        //properties.setProperty("hibernate.generate_statistics", "false");
        return properties;
    }
}