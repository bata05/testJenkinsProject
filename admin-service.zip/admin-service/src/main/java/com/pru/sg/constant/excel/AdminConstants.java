package com.pru.sg.constant.excel;

import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;

public class AdminConstants {

    public static final String FILE_SEPARATOR = "/";
    public static final String FILENAME_CONCATENATOR = "_";
    //public static final String[] EXCEL_EXTENSIONS = {"XLS","XLSX"};
    public static final String[] EXCEL_EXTENSIONS = {"XLSX"};

    public static final int agentPoolOffsetHeaderIndex = 1;
    public static final int FIRST_SHEET = 0;
    public static final int STATUS_ACTIVE = 1;
    public static final int ADPOOL_EXCEL_TOTAL_COLUMNS = 2;

    public static final SimpleDateFormat EXCEL_DATE_VALUE = new SimpleDateFormat("dd-MM-yyyy");
    public static final DateTimeFormatter MAPPER_FORMATTER = DateTimeFormatter.ofPattern("dd-MM-yyyy");

    public static final SimpleDateFormat currentDateTimeformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SS");//'2022-02-11'
    

    public static final String ERROR_FILE_TOO_LARGE = "Uploaded file is too large";
    public static final String ERROR_GENERIC_MESSAGE = "Unexpected error has occurred in the system.";
    public static final String ERROR_INVALID_EXCEL_HEADER = "One of the expected column header has a wrong value.";
    public static final String ERROR_INVALID_EXCEL_DATA = "Invalid excel data was detected.";
    public static final String ERROR_INVALID_EMPTY_EXCEL = "The uploaded excel file is empty.";
    public static final String ERROR_INVALID_EMPTY_ROW = "The uploaded excel file contains empty row: ";
    public static final String ERROR_INVALID_EMPTY_VALUE = "The uploaded excel file contains empty value: ";
    public static final String ERROR_INVALID_SESSION = "Session verification failed. Not a valid session.";
    public static final String ERROR_INVALID_EXCEL_FORMAT="Invalid excel format was detected: ";

    public static final String SUCCESS_UPLOAD = "File was uploaded successfully.";
    public static final String SUCCESS_VERIFICATION = "success";

    public static final String EXCEL_CONTENT_TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    public static final String EXCEL_FILE_MAPPER = "excelmapper/AD_AFFILIATION_POOL.json";

    public static final String AUTH_HEADER = "Authorization";
    public static final String AUTH_BEAR = "Bearer ";
    
    public static final String SUCCESS_PROMO_CREATION = "Successfully created a promotion discount";
}
