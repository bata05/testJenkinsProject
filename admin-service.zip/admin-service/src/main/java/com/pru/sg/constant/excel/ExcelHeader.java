package com.pru.sg.constant.excel;

public enum ExcelHeader {

    PARTNER("Partner", 0),
    AGENTCODE("Agent_Code", 1);

    private String headerName;
    private int index;

    private ExcelHeader(String headerName, int index) {
        this.headerName = headerName;
        this.index = index;
    }
    public String getHeaderName() {
        return headerName;
    }
    public int getIndex() {
        return index;
    }
}
