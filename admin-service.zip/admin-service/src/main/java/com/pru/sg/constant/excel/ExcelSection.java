package com.pru.sg.constant.excel;

public enum ExcelSection {

    AD_AFFILIATION_POOL("AdAffiliationPool");

    private String groupName;

    private ExcelSection(String headerName) {
        this.groupName = headerName;
    }

    public String getGroupName() {
        return groupName;
    }

}
