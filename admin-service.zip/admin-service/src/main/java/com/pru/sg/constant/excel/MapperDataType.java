package com.pru.sg.constant.excel;

public enum MapperDataType {

    DOUBLE("Double"),
    INTEGER("Integer"),
    STRING("String"),
    DATE("Date");

    final String typeValue;

    private MapperDataType(final String typeValue) {
        this.typeValue = typeValue;
    }

    public String getTypeValue() {
        return typeValue;
    }

    @Override
    public String toString() {
        return name();
    }
}
