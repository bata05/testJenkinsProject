package com.pru.sg.constant.excel;

import org.apache.poi.ss.usermodel.CellType;

public enum ModifiedHeaderType {

    AGENT_CODE("Agent_Code", CellType.STRING);

    private String headerName;
    private CellType cellType;

    private ModifiedHeaderType(String headerName, CellType cellType){
        this.headerName = headerName;
        this.cellType = cellType;
    }

    public String headerName(){
        return headerName;
    }

    public CellType cellType(){
        return cellType;
    }
}
