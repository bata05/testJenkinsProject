package com.pru.sg.controller;

import com.pru.sg.constant.excel.AdminConstants;
import com.pru.sg.dto.request.ProxyAccessRequest;
import com.pru.sg.dto.response.AdminResponse;
import com.pru.sg.entity.oracle.AgentPoolHistory;
import com.pru.sg.security.AuthenticationManager;
import com.pru.sg.service.upload.AgentPoolService;
import com.pru.sg.service.upload.PacsnetService;
import com.pru.sg.service.upload.UploadService;
import com.pru.sg.validator.ExcelValidator;
import io.swagger.annotations.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@CrossOrigin(maxAge = 3600)
@RestController
@Api(value = "Upload", description = "Digital Platform Admin module")
@RequestMapping("/agentpool")
public class AgentPoolUploadController {

    private static final Logger LOGGER = LoggerFactory.getLogger(AgentPoolUploadController.class);

    @Value("${SPRING_PROFILES_ACTIVE}")
    private String activeProfile;

    @Autowired
    private UploadService uploadService;

    @Autowired
    private PacsnetService pacsnetService;

    @Autowired
    private AgentPoolService agentPoolService;

    @Autowired
    private AuthenticationManager authenticationManager;

    @PostMapping(value = "/upload", produces = MediaType.APPLICATION_JSON_UTF8_VALUE, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ApiOperation(value = "Make a POST request to upload the file",
            produces = "application/json", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "upload POST call was successful"),
            @ApiResponse(code = 500, message = "upload POST call failed"),
            @ApiResponse(code = 400, message = "upload POST call has wrong request data, e.g.")
    })
    public ResponseEntity<AdminResponse> agentPoolUploadFile(
            @ApiParam(name = "empid", value = "Employee Id", required = true)
            @RequestParam("empid") String empid,
            @ApiParam(name = "empName", value = "Employee Name", required = true)
            @RequestParam("empName") String empName,
            @ApiParam(name = "file", value = "Select a file to Upload", required = true)
            @RequestPart("file") MultipartFile file) throws Exception {
        LOGGER.info("Original uploaded file name: {}, file size: {}, content type: {}", file.getOriginalFilename(), file.getSize(), file.getContentType());
        LOGGER.info("Employee request info=> employee id:{}, employee name:{}", empid, empName);
        ExcelValidator.validateFile(file);

        ProxyAccessRequest proxyAccessRequest = new ProxyAccessRequest(null, empid, empName);
        uploadService.processADPoolFile(file, proxyAccessRequest);

        LOGGER.info("File {} was successfully uploaded.", file.getOriginalFilename());
        AdminResponse response = AdminResponse.builder().message(AdminConstants.SUCCESS_UPLOAD).fileName(file.getOriginalFilename()).build();
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping(value = "/verifysession", produces = MediaType.APPLICATION_JSON_UTF8_VALUE, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ApiOperation(value = "Make a POST request to validate PACSNET session",
            produces = "application/json", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "verifysession POST call was successful"),
            @ApiResponse(code = 500, message = "verifysession POST call failed"),
            @ApiResponse(code = 400, message = "verifysession POST call has wrong request data, e.g.")
    })
    public ResponseEntity<AdminResponse> verifyPacsnetSession(
            @ApiParam(name = "sessionid", value = "Pacsnet session Id", required = true)
            @RequestBody ProxyAccessRequest proxyAccessRequest){
        LOGGER.info("Start - [To verify Pacsnet proxyAccessRequest] - {}", proxyAccessRequest.toString());

        boolean isValidSession = pacsnetService.isValidSession(proxyAccessRequest) || "local".equalsIgnoreCase(activeProfile);

        String jwtToken = null;

        if(isValidSession) {
            jwtToken = authenticationManager.authenticate(proxyAccessRequest);

        }

        String message = (isValidSession) ? AdminConstants.SUCCESS_VERIFICATION : AdminConstants.ERROR_INVALID_SESSION;
        AdminResponse response = AdminResponse.builder().jwtAuthToken(jwtToken).message(message).build();
        LOGGER.info("End - [Verifying Pacsnet request sessionid] - {}, employeeid: {}, result: {}",
                proxyAccessRequest.getSessionid(), proxyAccessRequest.getEmpid(), message);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(value = "/agentPoolTransHistories", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ApiOperation(value = "Make a GET request to fetch all Agent Pool History transactions",
            produces = "application/json", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "agentPoolTransHistories GET call was successful"),
            @ApiResponse(code = 500, message = "agentPoolTransHistories GET call failed")
    })
    public ResponseEntity getAgentPoolTransHistory() {
        Page<AgentPoolHistory> agentPoolHistories = agentPoolService.fetchAllAgentPoolHistory();
        AdminResponse response = AdminResponse.builder().agentPoolHistories(agentPoolHistories.getContent()).message(AdminConstants.SUCCESS_VERIFICATION).build();
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
