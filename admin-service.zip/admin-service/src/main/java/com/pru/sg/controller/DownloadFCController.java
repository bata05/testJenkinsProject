package com.pru.sg.controller;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

import com.pru.sg.service.upload.DownloadFCService;
import org.apache.commons.io.IOUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@CrossOrigin(maxAge = 3600)
@RestController
@Api(value = "Download", description = "Digital Platform FC Download modules")
@RequestMapping("/downloadfc")
public class DownloadFCController {

    private static final Logger LOGGER = LoggerFactory.getLogger(LeadGenerationController.class);

    @Autowired
    private DownloadFCService downloadFCService;

    @PostMapping(value = "/eligible")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "eligiblefcs POST call was successful"),
            @ApiResponse(code = 500, message = "eligiblefcs POST call failed"),
            @ApiResponse(code = 400, message = "eligiblefcs POST call has wrong request data, e.g.")
    })
    public ResponseEntity<byte[]> agentPoolUploadFile(
            @ApiParam(name = "empid", value = "Employee Id", required = true)
            @RequestParam("empid") String empid,
            @ApiParam(name = "empName", value = "Employee Name", required = true)
            @RequestParam("empName") String empName) throws Exception {
        LOGGER.info("Starting download of eligible FCs");

        InputStream resource = new ByteArrayInputStream(downloadFCService.generateEligibleFCFile());
        String fileName = "eligibleFCs";
        byte[] result = IOUtils.toByteArray(resource);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fileName)
                .header(HttpHeaders.CONTENT_TYPE, "application/vnd.ms-excel")
                .contentLength(result.length)
                .body(result);
    }
}
