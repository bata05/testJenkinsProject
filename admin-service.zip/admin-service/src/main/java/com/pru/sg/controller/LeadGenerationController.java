package com.pru.sg.controller;


import com.pru.sg.service.upload.LeadgenService;
import com.pru.sg.validator.ExcelValidator;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;

@CrossOrigin(maxAge = 3600)
@RestController
@Api(value = "Upload", description = "Digital Platform Lead generation")
@RequestMapping("/leadgeneration")
public class LeadGenerationController {

    private static final Logger LOGGER = LoggerFactory.getLogger(LeadGenerationController.class);

    @Autowired
    private LeadgenService leadgenService;

    @PostMapping(value = "/upload")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "upload POST call was successful"),
            @ApiResponse(code = 500, message = "upload POST call failed"),
            @ApiResponse(code = 400, message = "upload POST call has wrong request data, e.g.")
    })
    public ResponseEntity<byte[]> agentPoolUploadFile(
            @ApiParam(name = "empid", value = "Employee Id", required = true)
            @RequestParam("empid") String empid,
            @ApiParam(name = "empName", value = "Employee Name", required = true)
            @RequestParam("empName") String empName,
            @ApiParam(name = "file", value = "Select a file to Upload", required = true)
            @RequestPart("file") MultipartFile file) throws Exception {
        LOGGER.info("Leadgen file uploaded file name: {}, file size: {}, content type: {}", file.getOriginalFilename(), file.getSize(), file.getContentType());
        ExcelValidator.validateFile(file);
        InputStream resource = leadgenService.processLeadgen(file);
        String fileName = file.getOriginalFilename() + "_result";
        String contentType = file.getContentType();
        byte[] result = IOUtils.toByteArray(resource);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + fileName)
                .header(HttpHeaders.CONTENT_TYPE, contentType)
                .contentLength(result.length)
                .body(result);
    }
}
