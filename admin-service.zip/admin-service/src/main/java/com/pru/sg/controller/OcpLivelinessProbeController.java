package com.pru.sg.controller;

import com.pru.sg.constant.excel.AdminConstants;
import com.pru.sg.dto.response.OcpLivelinessProbeResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.sql.Timestamp;
import java.util.Date;

@RestController
@Api(value = "Check status", description = "OCP status check")
public class OcpLivelinessProbeController {

    @GetMapping(value = "/checkStatus", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ApiOperation(value = "Make a GET request to fetch all Agent Pool History transactions",
            produces = MediaType.APPLICATION_JSON_UTF8_VALUE, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Ocp checkStatus GET call was successful"),
            @ApiResponse(code = 500, message = "Ocp checkStatus GET call failed")
    })
    public ResponseEntity getAgentPoolTransHistory() {
        OcpLivelinessProbeResponse response = new OcpLivelinessProbeResponse();
        response.setMessage(AdminConstants.SUCCESS_VERIFICATION);
        response.setCurrentTime(AdminConstants.currentDateTimeformat.format(new Timestamp((new Date()).getTime())));
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
