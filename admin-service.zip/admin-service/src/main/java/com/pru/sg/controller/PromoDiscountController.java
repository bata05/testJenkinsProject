package com.pru.sg.controller;

import com.pru.sg.constant.excel.AdminConstants;
import com.pru.sg.dto.request.ProxyAccessRequest;
import com.pru.sg.dto.response.AdminResponse;
import com.pru.sg.entity.oracle.AgentPoolHistory;
import com.pru.sg.entity.oracle.ProductPromotion;
import com.pru.sg.entity.oracle.Products;
import com.pru.sg.security.AuthenticationManager;
import com.pru.sg.service.promo.ProductPromotionDetailsService;
import com.pru.sg.service.promo.ProductPromotionService;
import com.pru.sg.service.promo.ProductsService;
import com.pru.sg.service.promo.impl.PromotionDiscountService;
import com.pru.sg.service.upload.AgentPoolService;
import com.pru.sg.service.upload.PacsnetService;
import com.pru.sg.service.upload.UploadService;
import com.pru.sg.validator.ExcelValidator;
import io.swagger.annotations.*;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@CrossOrigin(maxAge = 3600)
@RestController
@Api(value = "Discounts", description = "Digital Platform Admin module")
@RequestMapping("/promodiscount")
public class PromoDiscountController {

    private static final Logger LOGGER = LoggerFactory.getLogger(PromoDiscountController.class);

    @Autowired
    private PromotionDiscountService promotionDiscountService;
    
    @Autowired
    private ProductPromotionService productPromotionService;

    @Autowired
    private AuthenticationManager authenticationManager;
    
    @PostMapping(value = "/delete")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "upload POST call was successful"),
            @ApiResponse(code = 500, message = "upload POST call failed"),
            @ApiResponse(code = 400, message = "upload POST call has wrong request data, e.g.")
    })
    public ResponseEntity<AdminResponse> deleteProductPromotion(
    		@ApiParam(name = "empid", value = "Employee Id", required = true)
    		@RequestParam("empid") String empid,
    		@ApiParam(name = "empName", value = "Employee Name", required = true)
    		@RequestParam("empName") String empName,
    		@ApiParam(name = "promotionIds", value = "One or more promotion ids", required = true)
    		@RequestParam("promotionIds") String[] promotionIds) throws Exception {
    	String successMessage = "Successfully deleted ("+promotionIds.length+") entrie/s: ";
    	int count = 0;
    	for(String promoId : promotionIds)
    	{
    		Optional<ProductPromotion> productPromoOption = productPromotionService.findById(Long.valueOf(promoId));
    		ProductPromotion productPromo = productPromoOption.get();
    		productPromotionService.deleteEntry(productPromo);
    		if(count == 0)
    		{
    			successMessage+="Promotion Id: "+productPromo.getPromotionId()+" Promo Code: "+productPromo.getProductCode()+" Channel Code: "
    		                  +productPromo.getChannelCode()
    		                  +" Discount Percentage: "+productPromo.getDiscountPercentage();
    		} else {
    			successMessage+="\nPromotion Id: "+productPromo.getPromotionId()+" Promo Code: "+productPromo.getProductCode()+" Channel Code: "
		                  +productPromo.getChannelCode()
		                  +" Discount Percentage: "+productPromo.getDiscountPercentage();
    		}
    		count++;
    	}
    	AdminResponse response = AdminResponse.builder().message(AdminConstants.SUCCESS_PROMO_CREATION).promotionDiscountMessage(successMessage).build();
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
    @PostMapping(value = "/setInactive")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "upload POST call was successful"),
            @ApiResponse(code = 500, message = "upload POST call failed"),
            @ApiResponse(code = 400, message = "upload POST call has wrong request data, e.g.")
    })
    public ResponseEntity<AdminResponse> setInactiveProductPromotion(
    		@ApiParam(name = "empid", value = "Employee Id", required = true)
    		@RequestParam("empid") String empid,
    		@ApiParam(name = "empName", value = "Employee Name", required = true)
    		@RequestParam("empName") String empName,
    		@ApiParam(name = "promotionIds", value = "One or more promotion ids", required = true)
    		@RequestParam("promotionIds") String[] promotionIds) throws Exception {
    	String successMessage = "Successfully set to In-Active for ("+promotionIds.length+") entrie/s: ";
    	int count = 0;
    	for(String promoId : promotionIds)
    	{
    		Optional<ProductPromotion> productPromoOption = productPromotionService.findById(Long.valueOf(promoId));
    		ProductPromotion productPromo = productPromoOption.get();
    		LocalDate ldate = LocalDate.now().minusDays(2);
    		Date date = Date.from(ldate.atStartOfDay(ZoneId.systemDefault()).toInstant());
    		productPromo.setFromValidityDate(date);
    		productPromo.setToValidityDate(date);
    		productPromotionService.save(productPromo);
    		if(count == 0)
    		{
    			successMessage+="Promotion Id: "+productPromo.getPromotionId()+" Promo Code: "+productPromo.getProductCode()+" Channel Code: "
    		                  +productPromo.getChannelCode()
    		                  +" Discount Percentage: "+productPromo.getDiscountPercentage();
    		} else {
    			successMessage+="\nPromotion Id: "+productPromo.getPromotionId()+" Promo Code: "+productPromo.getProductCode()+" Channel Code: "
		                  +productPromo.getChannelCode()
		                  +" Discount Percentage: "+productPromo.getDiscountPercentage();
    		}
    		count++;
    	}
    	AdminResponse response = AdminResponse.builder().message(AdminConstants.SUCCESS_PROMO_CREATION).promotionDiscountMessage(successMessage).build();
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
    @PostMapping(value = "/createNew", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ApiOperation(value = "Make a POST request to upload the file",
            produces = "application/json")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "promotion discount creation was successful"),
            @ApiResponse(code = 500, message = "promotion discount creation failed"),
            @ApiResponse(code = 400, message = "promotion discount creation has wrong request data, e.g.")
    })
    public ResponseEntity<AdminResponse> saveProductPromotion(
    		@ApiParam(name = "empid", value = "Employee Id", required = true)
            @RequestParam("empid") String empid,
            @ApiParam(name = "empName", value = "Employee Name", required = true)
            @RequestParam("empName") String empName,
            @ApiParam(name = "productCode", value = "Promotion Product Code", required = true)
            @RequestParam("productCode") String productCode,
            @ApiParam(name = "channelCode", value = "Promotion Channel Code", required = true)
            @RequestParam("channelCode") String channelCode,
            @ApiParam(name = "discPercentage", value = "Promotion Discount Percentage", required = true)
            @RequestParam("discPercentage") Float discPercentage,
            @ApiParam(name = "fromValidDate", value = "Promotion From Validity Date", required = true)
            @RequestParam("fromValidDate") String fromValidDate,
            @ApiParam(name = "toValidDate", value = "Promotion To Validity Date", required = true)
            @RequestParam("toValidDate") String toValidDate,
            @ApiParam(name = "promoMsg", value = "Promotion Message", required = true)
            @RequestParam("promoMsg") String promoMsg) throws Exception {
        LOGGER.info("Employee request info=> employee id:{}, employee name:{}", empid, empName);
        SimpleDateFormat dateConverter = new SimpleDateFormat("yyyy-MM-dd");//'2022-02-11'
        ProxyAccessRequest proxyAccessRequest = new ProxyAccessRequest(null, empid, empName);
        ProductPromotion productPromo = new ProductPromotion();
        productPromo.setProductCode(productCode);
        productPromo.setChannelCode(channelCode);
        productPromo.setDiscountPercentage(discPercentage);
        productPromo.setFromValidityDate(dateConverter.parse(fromValidDate));
        productPromo.setToValidityDate(dateConverter.parse(toValidDate));
        productPromo.setPromoMsg(promoMsg);
        productPromo.setCreatedBy(proxyAccessRequest.getEmpid());
        productPromotionService.save(productPromo);
        String successMessage = "Successfully created promotion discount with Product Code: "+productCode+", Channel Code: "+channelCode+", Discount Percentag: "+discPercentage;
        LOGGER.info(successMessage);
        AdminResponse response = AdminResponse.builder().message(AdminConstants.SUCCESS_PROMO_CREATION).promotionDiscountMessage(successMessage).build();
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
    @PostMapping(value = "/update", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ApiOperation(value = "Make a POST request to upload the file",
            produces = "application/json")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "promotion discount creation was successful"),
            @ApiResponse(code = 500, message = "promotion discount creation failed"),
            @ApiResponse(code = 400, message = "promotion discount creation has wrong request data, e.g.")
    })
    public ResponseEntity<AdminResponse> updateProductPromotion(
    		@ApiParam(name = "empid", value = "Employee Id", required = true)
            @RequestParam("empid") String empid,
            @ApiParam(name = "empName", value = "Employee Name", required = true)
            @RequestParam("empName") String empName,
            @ApiParam(name = "promoId", value = "Promotion Id", required = true)
            @RequestParam("promoId") Long promoId,
            @ApiParam(name = "productCode", value = "Promotion Product Code", required = true)
            @RequestParam("productCode") String productCode,
            @ApiParam(name = "channelCode", value = "Promotion Channel Code", required = true)
            @RequestParam("channelCode") String channelCode,
            @ApiParam(name = "discPercentage", value = "Promotion Discount Percentage", required = true)
            @RequestParam("discPercentage") Float discPercentage,
            @ApiParam(name = "fromValidDate", value = "Promotion From Validity Date", required = true)
            @RequestParam("fromValidDate") String fromValidDate,
            @ApiParam(name = "toValidDate", value = "Promotion To Validity Date", required = true)
            @RequestParam("toValidDate") String toValidDate,
            @ApiParam(name = "promoMsg", value = "Promotion Message", required = true)
            @RequestParam("promoMsg") String promoMsg) throws Exception {
        LOGGER.info("Employee request info=> employee id:{}, employee name:{}", empid, empName);
        SimpleDateFormat dateConverter = new SimpleDateFormat("yyyy-MM-dd");//'2022-02-11'
        ProxyAccessRequest proxyAccessRequest = new ProxyAccessRequest(null, empid, empName);
        Optional<ProductPromotion> productPromoOption = productPromotionService.findById(promoId);
		ProductPromotion productPromo = productPromoOption.get();
        productPromo.setProductCode(productCode);
        productPromo.setChannelCode(channelCode);
        productPromo.setDiscountPercentage(discPercentage);
        productPromo.setFromValidityDate(dateConverter.parse(fromValidDate));
        productPromo.setToValidityDate(dateConverter.parse(toValidDate));
        productPromo.setPromoMsg(promoMsg);
        productPromo.setCreatedBy(proxyAccessRequest.getEmpid());
        productPromotionService.updateEntry(productPromo);
        String successMessage = "Successfully updated promotion discount with Product Code: "+productCode+", Channel Code: "+channelCode+", Discount Percentag: "+discPercentage;
        LOGGER.info(successMessage);
        AdminResponse response = AdminResponse.builder().message(AdminConstants.SUCCESS_PROMO_CREATION).promotionDiscountMessage(successMessage).build();
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
    @GetMapping(value = "/inactiveDiscounts", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ApiOperation(value = "Make a GET request to fetch all Agent Pool History transactions",
            produces = "application/json", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "agentPoolTransHistories GET call was successful"),
            @ApiResponse(code = 500, message = "agentPoolTransHistories GET call failed")
    })
    public ResponseEntity getInActiveProductPromotionEntries() {
    	//List<Products> products = productsService.fetchAllRecords();
        AdminResponse response = AdminResponse.builder().productPromotions(productPromotionService.fetchAllInActiveRecords()).message(AdminConstants.SUCCESS_UPLOAD).build();
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(value = "/activeDiscounts", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ApiOperation(value = "Make a GET request to fetch all Agent Pool History transactions",
            produces = "application/json", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "agentPoolTransHistories GET call was successful"),
            @ApiResponse(code = 500, message = "agentPoolTransHistories GET call failed")
    })
    public ResponseEntity getActiveProductPromotionEntries() {
    	//List<Products> products = productsService.fetchAllRecords();
        AdminResponse response = AdminResponse.builder().productPromotions(productPromotionService.fetchAllActiveRecords()).message(AdminConstants.SUCCESS_UPLOAD).build();
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
        
    @GetMapping(value = "/allDiscounts", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ApiOperation(value = "Make a GET request to fetch all Agent Pool History transactions",
            produces = "application/json", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "agentPoolTransHistories GET call was successful"),
            @ApiResponse(code = 500, message = "agentPoolTransHistories GET call failed")
    })
    public ResponseEntity getProductPromotionEntries() {
    	//List<Products> products = productsService.fetchAllRecords();
        AdminResponse response = AdminResponse.builder().productPromotions(productPromotionService.fetchAllRecords()).message(AdminConstants.SUCCESS_UPLOAD).build();
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
}
