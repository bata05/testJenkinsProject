package com.pru.sg.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ProxyAccessRequest {

    private String sessionid;
    private String empid;
    private String empName;
}
