package com.pru.sg.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.pru.sg.entity.json.PromotionDiscount;
import com.pru.sg.entity.oracle.AgentPoolHistory;
import com.pru.sg.entity.oracle.ProductPromotion;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Value;
import java.util.List;

@Value
@Builder
@ApiModel(description = "Admin module response object")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AdminResponse {
    @ApiModelProperty(value = "Information about the transaction", required = true, dataType = "string")
    private String message;
    @ApiModelProperty(value = "Uploaded file name", required = true, dataType = "string")
    private String fileName;
    private int paginationSize = 0;
    private int currentPageCount = 0;
    
    private String promotionDiscountMessage;
    private List<AgentPoolHistory> agentPoolHistories;
    private List<PromotionDiscount> promotionDiscountList;
    private List<ProductPromotion> productPromotions;
    @ApiModelProperty(value = "Information about the error of the transaction")
    private ErrorResponse error;
    @ApiModelProperty(value = "JWT Security Token[Optional]", required = false, dataType = "string")
    private String jwtAuthToken;

}
