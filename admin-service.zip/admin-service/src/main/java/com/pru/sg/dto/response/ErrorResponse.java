package com.pru.sg.dto.response;

import com.pru.sg.constant.excel.AdminConstants;
import lombok.AllArgsConstructor;
import lombok.Value;
import org.springframework.http.HttpStatus;

import java.time.LocalDateTime;


@Value
@AllArgsConstructor
public class ErrorResponse {

    private final HttpStatus status;
    private LocalDateTime timestamp;
    private String message;

    public ErrorResponse(HttpStatus status) {
        this(status, LocalDateTime.now(), AdminConstants.ERROR_GENERIC_MESSAGE);
    }

    public ErrorResponse(HttpStatus status, String message) {
        this(status, LocalDateTime.now(), message);
    }

}