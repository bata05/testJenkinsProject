package com.pru.sg.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.annotations.ApiModel;
import lombok.Data;

@Data
@ApiModel(description = "Admin module Ocp Liveliness Probe object")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OcpLivelinessProbeResponse {
    private String message;
    private String currentTime;
}
