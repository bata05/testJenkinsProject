package com.pru.sg.entity.db2;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import java.util.Date;

@Data
@NoArgsConstructor
@Entity
@Table(schema = "INFO", name = "PROXY_ACCESS")
@AllArgsConstructor
public class ProxyAccess {

    @EmbeddedId
    private ProxyAccessIdentity proxyAccessIdentity;

    @CreationTimestamp
    @Column(name = "DATE_TIME_STAMP")
    private Date createdDate;

}
