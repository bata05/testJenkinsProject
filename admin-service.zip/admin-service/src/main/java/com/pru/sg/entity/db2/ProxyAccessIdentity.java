package com.pru.sg.entity.db2;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Data
@NoArgsConstructor
@Embeddable
public class ProxyAccessIdentity implements Serializable {

    @Column(name = "U_SID")
    private String sessionId;

    @Column(name = "LOGIN_ID")
    private String employeeId;

}
