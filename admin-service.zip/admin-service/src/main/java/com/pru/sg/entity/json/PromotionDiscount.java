package com.pru.sg.entity.json;

import java.util.Date;

import javax.persistence.Entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pru.sg.constant.excel.AdminConstants;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class PromotionDiscount {

  @JsonProperty("productId")	
  private Long productId;	
	
  @JsonProperty("promoId")	
  private Long promotionId;
  
  @JsonProperty("prodName")
  private String productName;
  
  @JsonProperty("prodCode")
  private String productCode;
  
  @JsonProperty("fromValidDate")
  private Date fromValidityDate;
  
  @JsonProperty("toValidDate")
  private Date toValidityDate;
  
  @JsonProperty("promoMsg")
  private String promoMessage;
  
  @JsonProperty("channelCode")
  private String channelCode;
  
  @JsonProperty("discPercentage")
  private Float discountPercentage;
  
  @JsonProperty("createdDate")
  private Date createdDate;
  
  @JsonProperty("createdBy")
  private String createdBy;
  
  public String getFormattedFromValidDate(){
      return AdminConstants.currentDateTimeformat.format(this.fromValidityDate);
  }
  
  public String getFormattedToValidDate(){
      return AdminConstants.currentDateTimeformat.format(this.toValidityDate);
  }
}
