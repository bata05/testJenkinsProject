package com.pru.sg.entity.oracle;

import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(schema = "PRUSERVICE", name = "AGENT_POOL_LOOKUP")
@SequenceGenerator(name = "AGENT_POOL_LOOKUP_SEQ", sequenceName = "AGENT_POOL_LOOKUP_SEQ", allocationSize = 1)
public class AgentPool {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "AGENT_POOL_LOOKUP_SEQ")
    @Column(name = "ID")
    private Long id;

    @Column(name = "AGENT_CODE")
    private String agentCode;

    @Column(name = "ENTRY_TYPE")
    private String entryType;

    @Column(name = "STATUS")
    private Integer status;

    @UpdateTimestamp
    @Column(name = "DATE_UPDATED")
    private Date lastModifiedDate;

    @CreationTimestamp
    @Column(name = "DATE_CREATED")
    private Date createdDate;

}
