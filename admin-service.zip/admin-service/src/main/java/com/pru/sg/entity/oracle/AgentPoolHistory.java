package com.pru.sg.entity.oracle;

import com.pru.sg.constant.excel.AdminConstants;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(schema = "PRUSERVICE", name = "AGENT_POOL_LOOKUP_HISTORY")
@SequenceGenerator(name = "AGENT_POOL_LOOKUP_HISTORY_SEQ", sequenceName = "AGENT_POOL_LOOKUP_HISTORY_SEQ", allocationSize = 1)
public class AgentPoolHistory {

    public enum AgentPoolUploadStatus {
        INIT,
        SUCCESS,
        FAILED
    }

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "AGENT_POOL_LOOKUP_HISTORY_SEQ")
    @Column(name = "ID")
    private Long id;

    @Column(name = "USER_ID")
    private String userId;

    @Column(name = "USER_NAME")
    private String userName;

    @Column(name = "FILE_NAME")
    private String fileName;

    @Column(name = "AGENT_UPLOADED_COUNT")
    private long agentTotalCount;

    @Enumerated
    @Column(name = "STATUS")
    private AgentPoolUploadStatus status;

    @CreationTimestamp
    @Column(name = "DATE_CREATED")
    private Date createdDate;

    public String getFormattedCreatedDate(){
        return AdminConstants.currentDateTimeformat.format(this.createdDate);
    }

}
