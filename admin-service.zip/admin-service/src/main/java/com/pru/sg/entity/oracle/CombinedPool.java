package com.pru.sg.entity.oracle;

import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(schema = "PRUSERVICE", name = "COMBINED_AGENT_POOL")
public class CombinedPool {

    @Id
    @Column(name = "ROWID")
    private String id;

    @Column(name = "U_ADVISER_KEY")
    private Long uAdviserKey;

    @Column(name = "AGENT_CODE")
    private String agentCode;

    @Column(name = "AGENT_BUSINESS_NAME")
    private String agentBusinessName;

    @Column(name = "ADVISER_TYPE_CODE")
    private String adviserTypeCode;

    @Column(name = "EMAIL_ADDRESS")
    private String email;

    @Column(name = "MOBILE_NUMBER")
    private String mobile;

    @Column(name = "MAS_REPRESENTATIVE_NO")
    private String masRepNo;

    @Column(name = "ADVISER_STATUS_CODE")
    private String adviserStatusCode;

    @Column(name = "CHANNEL_CODE")
    private String channelCode;

    @Column(name = "ENTRY_TYPE")
    private String entryType;

    @Column(name = "APPOINTMENT_DATE")
    private String appointmentDate;

    @CreationTimestamp
    @Column(name = "CREATED_DATE")
    private Date createdDate;

    public String getAgentCode(){
        return agentCode;
    }

    public String getEntryType(){
        return entryType;
    }

}
