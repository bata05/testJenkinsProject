package com.pru.sg.entity.oracle;

import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.pru.sg.constant.excel.AdminConstants;

import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(schema = "SGD2C", name = "PRODUCT_PROMOTION")
@SequenceGenerator(name = "PRODUCT_PROMOTION_LOOKUP_SEQ", sequenceName = "PRODUCT_PROMOTION_LOOKUP_SEQ", allocationSize = 1)
public class ProductPromotion {
	
	//PROMOTION_ID, PRODUCT_CODE, FROM_VALIDITY_DATE, TO_VALIDITY_DATE, DISCOUNT_PERCENTAGE, CREATED_DATE, CREATED_BY, MODIFIED_DATE, MODIFIED_BY, START_AGE, END_AGE, PROMO_MSG, CHANNEL_CODE
	
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PRODUCT_PROMOTION_LOOKUP_SEQ")
    @Column(name = "PROMOTION_ID")
    private Long promotionId;

    @Column(name = "PRODUCT_CODE")
    private String productCode;

    @Column(name = "FROM_VALIDITY_DATE")
    private Date fromValidityDate;
    
    @Column(name = "TO_VALIDITY_DATE")
    private Date toValidityDate;

    @Column(name = "DISCOUNT_PERCENTAGE")
    private Float discountPercentage;

    @Column(name = "START_AGE")
    private Integer startAge;
    
    @Column(name = "END_AGE")
    private Integer endAge;
    
    @Column(name = "PROMO_MSG")
    private String promoMsg;
    
    @Column(name = "CHANNEL_CODE")
    private String channelCode;
    
    @CreationTimestamp
    @Column(name = "CREATED_DATE")
    private Date createdDate;
    
    @UpdateTimestamp
    @Column(name = "MODIFIED_DATE")
    private Date modifiedDate;

    @Column(name = "CREATED_BY")
    private String createdBy;
    
    @Column(name = "MODIFIED_BY")
    private String modifiedBy;

    public String getFormattedFromValidDate(){
        return AdminConstants.currentDateTimeformat.format(this.fromValidityDate);
    }
    
    public String getFormattedToValidDate(){
        return AdminConstants.currentDateTimeformat.format(this.toValidityDate);
    }
}
