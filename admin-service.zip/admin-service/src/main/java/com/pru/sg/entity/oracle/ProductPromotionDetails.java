package com.pru.sg.entity.oracle;

import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(schema = "SGD2C", name = "PRODUCT_PROMOTION_DETAILS")
@SequenceGenerator(name = "PRODPROMO_DETAILS_LOOKUP_SEQ", sequenceName = "PRODPROMO_DETAILS_LOOKUP_SEQ", allocationSize = 1)
public class ProductPromotionDetails extends ProductsCommon {
    //DETAILS_ID, PRODUCT_CODE, COMPONENT_CODE, DISCOUNT_PERCENTAGE, CREATED_DATE, CREATED_BY, MODIFIED_DATE, MODIFIED_BY
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PRODPROMO_DETAILS_LOOKUP_SEQ")
    @Column(name = "DETAILS_ID")
    private Long detailsId;

    @Column(name = "PRODUCT_CODE")
    private String productCode;

    @Column(name = "COMPONENT_CODE")
    private String componentCode;

    @Column(name = "DISCOUNT_PERCENTAGE")
    private Integer discountPercentage;

}
