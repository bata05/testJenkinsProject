package com.pru.sg.entity.oracle;

import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(schema = "SGD2C", name = "PRODUCTS")
@SequenceGenerator(name = "PRODUCTS_LOOKUP_SEQ", sequenceName = "PRODUCTS_LOOKUP_SEQ", allocationSize = 1)
public class Products extends ProductsCommon {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PRODUCTS_LOOKUP_SEQ")
    @Column(name = "PRODUCT_ID")
    private Long productId;
    
    //PRODUCT_ID, PRODUCT_NAME, PRODUCT_CODE, CREATED_DATE, CREATED_BY, MODIFIED_DATE, MODIFIED_BY

    @Column(name = "PRODUCT_NAME")
    private String productName;

    @Column(name = "PRODUCT_CODE")
    private String productCode;
}
