package com.pru.sg.entity.oracle;

import java.util.Date;

import javax.persistence.Column;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class ProductsCommon {
	@CreationTimestamp
    @Column(name = "CREATED_DATE")
    private Date createdDate;
    
    @UpdateTimestamp
    @Column(name = "MODIFIED_DATE")
    private Date modifiedDate;

    @Column(name = "CREATED_BY")
    private String createdBy;
    
    @Column(name = "MODIFIED_BY")
    private String modifiedBy;
}
