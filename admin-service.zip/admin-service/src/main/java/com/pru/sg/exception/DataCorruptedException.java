package com.pru.sg.exception;

public class DataCorruptedException extends RuntimeException {
    public DataCorruptedException(Throwable thr) {
        super(thr);
    }
}
