package com.pru.sg.exception;

public class ExcelException extends RuntimeException {
    public ExcelException(String message) {
        super(message);
    }
}
