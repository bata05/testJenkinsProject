package com.pru.sg.exception;

public class FileException extends RuntimeException {
    public FileException(String message) {
        super(message);
    }
}
