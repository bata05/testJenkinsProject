package com.pru.sg.exception;

public class PacsnetAccessException extends RuntimeException {
    public PacsnetAccessException(String message) {
        super(message);
    }
}
