package com.pru.sg.exception;

import com.pru.sg.constant.excel.AdminConstants;
import com.pru.sg.dto.response.AdminResponse;
import com.pru.sg.dto.response.ErrorResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.multipart.MaxUploadSizeExceededException;

import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;

@Order(Ordered.HIGHEST_PRECEDENCE)
@RestControllerAdvice
public class RestExceptionHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(RestExceptionHandler.class);

    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public ResponseEntity<Object> fileTooLargeHandler(MaxUploadSizeExceededException e) {
        LOGGER.error("Error detected in fileTooLargeHandler: ", e);
        ErrorResponse error = new ErrorResponse(BAD_REQUEST, AdminConstants.ERROR_FILE_TOO_LARGE);
        return buildResponseEntity(buildResponse(AdminConstants.ERROR_GENERIC_MESSAGE, error));
    }

    @ExceptionHandler(ExcelException.class)
    public ResponseEntity<Object> excelErrorHandler(ExcelException e) {
        LOGGER.error("Error detected in excel: ", e);
        ErrorResponse error = new ErrorResponse(BAD_REQUEST, e.getMessage());
        return buildResponseEntity(buildResponse(e.getMessage(), error));
    }

    @ExceptionHandler(FileException.class)
    public ResponseEntity<Object> fileErrorHandler(FileException e) {
        LOGGER.error("Error detected in file: ", e);
        ErrorResponse error = new ErrorResponse(BAD_REQUEST, e.getMessage());
        return buildResponseEntity(buildResponse(e.getMessage(), error));
    }


    @ExceptionHandler(PacsnetAccessException.class)
    public ResponseEntity<Object> excelErrorHandler(PacsnetAccessException e) {
        LOGGER.error("Error detected while verifying Pacsnet session: ", e);
        ErrorResponse error = new ErrorResponse(BAD_REQUEST, e.getMessage());
        return buildResponseEntity(buildResponse(e.getMessage(), error));
    }

    @ExceptionHandler(value = Exception.class)
    public ResponseEntity<Object> defaultErrorHandler(Exception e) {
        LOGGER.error("Error detected in defaultErrorHandler: ", e);
        ErrorResponse error = new ErrorResponse(INTERNAL_SERVER_ERROR);
        return buildResponseEntity(buildResponse(AdminConstants.ERROR_GENERIC_MESSAGE, error));
    }


    private ResponseEntity<Object> buildResponseEntity(AdminResponse response) {
        return new ResponseEntity<>(response, response.getError().getStatus());
    }

    private AdminResponse buildResponse(String message, ErrorResponse error){
        return AdminResponse.builder().message(message).error(error).build();
    }

}