package com.pru.sg.file.excel;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class AdAffiliationPool {

    private String partner;
    private String agentCode;

}
