package com.pru.sg.file.excel;

import com.pru.sg.config.ExcelConfig;
import com.pru.sg.constant.excel.AdminConstants;
import com.pru.sg.constant.excel.MapperDataType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ExcelObjectMapper {

    private static final Logger LOGGER = LoggerFactory.getLogger(ExcelObjectMapper.class);

    public static <T> List<T> getObject(List<ExcelConfig[]> excelValueConfigs, Class<T> clazz) throws Exception {
        List<T> list = new ArrayList<>();

        for(ExcelConfig[] evc: excelValueConfigs) {
            T t = null;
            try {
                t = clazz.getConstructor().newInstance();
            } catch (Exception e) {
                LOGGER.error("Error in ExcelObjectMapper.getObject()_1: ", e);
                throw e;
            }
            Class<? extends Object> classz = t.getClass();
            for (int i = 0; i < evc.length; i++) {
                for (Field field : classz.getDeclaredFields()) {
                    field.setAccessible(true);
                    if (evc[i].getPojoAttribute().equalsIgnoreCase(field.getName())) {
                        try {
                            if (MapperDataType.STRING.getTypeValue().equalsIgnoreCase(evc[i].getExcelColType())) {
                                field.set(t, evc[i].getExcelValue());
                            } else if (MapperDataType.DOUBLE.getTypeValue().equalsIgnoreCase(evc[i].getExcelColType())) {
                                field.set(t, Double.valueOf(evc[i].getExcelValue()));
                            } else if (MapperDataType.INTEGER.getTypeValue().equalsIgnoreCase(evc[i].getExcelColType())) {
                                field.set(t, Double.valueOf(evc[i].getExcelValue()).intValue());
                            } else if (MapperDataType.DATE.getTypeValue().equalsIgnoreCase(evc[i].getExcelColType())) {
                                field.set(t, LocalDate.parse(evc[i].getExcelValue(), AdminConstants.MAPPER_FORMATTER));
                            }
                        } catch (Exception e) {
                            LOGGER.error("Error in ExcelObjectMapper.getObject()_2: ", e);
                            throw e;
                        }
                        break;
                    }
                }
            }
            list.add(t);
        }
        excelValueConfigs.forEach(evc -> {

        });
        return list;
    }
}
