package com.pru.sg.file.excel;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.io.ByteStreams;
import com.pru.sg.config.ExcelConfig;
import com.pru.sg.constant.excel.AdminConstants;
import com.pru.sg.constant.excel.MapperDataType;
import com.pru.sg.exception.ExcelException;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ExcelReader {

    private static final Logger LOGGER = LoggerFactory.getLogger(ExcelReader.class);

    public static Workbook readExcel(File file) throws ExcelException {
        Workbook wb = null;
        try {
            wb = WorkbookFactory.create(file);
        } catch (Exception e) {
            LOGGER.error("Error in ExcelReader.readExcel(): ", e);
            throw new ExcelException(e.getMessage());
        }
        return wb;
    }

    public static Map<String, List<ExcelConfig[]>> getExcelRowValues(Map<String, ExcelConfig[]> excelSectionHeaders,
                                                                     final Sheet sheet, int lastValidRowIndex) {
        Map<String, List<ExcelConfig[]>> excelMap = new HashMap<>();
        excelSectionHeaders.forEach((section, ExcelConfigs) -> {
            List<ExcelConfig[]> ExcelConfigList = new ArrayList<>();
            for (int i = 1; i <= lastValidRowIndex; i++) {
                Row row = sheet.getRow(i);
                ExcelConfig[] ExcelConfigArr = new ExcelConfig[ExcelConfigs.length];
                int k = 0;
                for (ExcelConfig ehc : ExcelConfigs) {
                    int cellIndex = ehc.getExcelIndex();
                    String cellType = ehc.getExcelColType();
                    Cell cell = row.getCell(cellIndex);
                    ExcelConfig config = new ExcelConfig();
                    config.setExcelColType(ehc.getExcelColType());
                    config.setExcelHeader(ehc.getExcelHeader());
                    config.setExcelIndex(ehc.getExcelIndex());
                    config.setPojoAttribute(ehc.getPojoAttribute());
                    if (MapperDataType.STRING.getTypeValue().equalsIgnoreCase(cellType)) {
                        config.setExcelValue(cell.getStringCellValue());
                    } else if (MapperDataType.DOUBLE.getTypeValue().equalsIgnoreCase(cellType)
                            || MapperDataType.INTEGER.getTypeValue().equalsIgnoreCase(cellType)) {
                        config.setExcelValue(String.valueOf(cell.getNumericCellValue()));
                    } else if (HSSFDateUtil.isCellDateFormatted(cell)) {
                        config.setExcelValue(String.valueOf(AdminConstants.EXCEL_DATE_VALUE.format(cell.getDateCellValue())));
                    }
                    ExcelConfigArr[k++] = config;
                }
                ExcelConfigList.add(ExcelConfigArr);
            }
            LOGGER.info("Excel mapped config size: " + ExcelConfigList.size());
            excelMap.put(section, ExcelConfigList);
        });
        return excelMap;
    }

    public static Map<String, ExcelConfig[]> getExcelHeaderSections() {
        List<Map<String, List<ExcelConfig>>> jsonConfigMap = getExcelHeaderConfigSections();
        Map<String, ExcelConfig[]> jsonMap = new HashMap<>();
        jsonConfigMap.forEach(jps -> {
            jps.forEach((section, values) -> {
                ExcelConfig[] ExcelConfigs = new ExcelConfig[values.size()];
                jsonMap.put(section, values.toArray(ExcelConfigs));
            });
        });
        return jsonMap;
    }

    public static List<Map<String, List<ExcelConfig>>> getExcelHeaderConfigSections() {
        List<Map<String, List<ExcelConfig>>> jsonMap = null;
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            ClassPathResource resource = new ClassPathResource(AdminConstants.EXCEL_FILE_MAPPER);
            String jsonConfig = new String(ByteStreams.toByteArray(resource.getInputStream()));
            jsonMap = objectMapper.readValue(jsonConfig,
                    new TypeReference<List<Map<String, List<ExcelConfig>>>>() {
                    });
        } catch (IOException e) {
            LOGGER.error("Error in ExcelReader.getExcelHeaderConfigSections(): ", e);
            throw new ExcelException(e.getMessage());
        }
        return jsonMap;
    }
}
