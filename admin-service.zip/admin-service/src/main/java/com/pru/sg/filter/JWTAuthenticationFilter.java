package com.pru.sg.filter;

import com.pru.sg.constant.excel.AdminConstants;
import com.pru.sg.security.CustomUserDetails;
import com.pru.sg.security.JWTTokenProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class JWTAuthenticationFilter extends OncePerRequestFilter {

    private static final Logger LOGGER = LoggerFactory.getLogger(JWTAuthenticationFilter.class);

    @Autowired
    private JWTTokenProvider jwtTokenProvider;

    @Override
    protected void doFilterInternal(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, FilterChain filterChain)
            throws ServletException, IOException {

        SecurityContextHolder.getContext().setAuthentication(null);
        try {
        	//String empId, String userName, String sessionId
        	CustomUserDetails userDetails = new CustomUserDetails("212312","testuser","12312312");
            String token = jwtTokenProvider.generateToken(userDetails);
        	//String token = aquireToken(httpServletRequest);
            //if (token != null && jwtTokenProvider.validateToken(token)) {
            if (token != null && jwtTokenProvider.validateToken(token)) {
                Authentication auth = jwtTokenProvider.getAuthentication(token);
                SecurityContextHolder.getContext().setAuthentication(auth);
            }


        } catch (Exception ex) {
            LOGGER.error("Could not set user authentication in security context : " + ex.getMessage());
        }

        filterChain.doFilter(httpServletRequest, httpServletResponse);

    }

    private String aquireToken(HttpServletRequest request) {
        //String bearerToken = request.getHeader(AdminConstants.AUTH_HEADER);
        String bearerToken ="Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.g0otcQqvJVCdo8g5v6ysqqZCYdCMdQt8NhhJQsphZ7E";
        if (bearerToken != null && bearerToken.startsWith(AdminConstants.AUTH_BEAR)) {
            return bearerToken.substring(7, bearerToken.length());
        }
        return null;

    }
}
