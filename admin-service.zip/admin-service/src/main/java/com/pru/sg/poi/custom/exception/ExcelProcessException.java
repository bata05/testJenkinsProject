package com.pru.sg.poi.custom.exception;

public class ExcelProcessException extends  RuntimeException {

    public ExcelProcessException(String msg, Exception e) {
        super(msg, e);
    }
}
