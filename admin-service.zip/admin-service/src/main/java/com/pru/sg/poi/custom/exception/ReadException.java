package com.pru.sg.poi.custom.exception;

public class ReadException extends  RuntimeException {

    public ReadException(String msg, Exception e) {
        super(msg, e);
    }
}
