package com.pru.sg.poi.custom.service;


import com.pru.sg.poi.custom.util.ParseExcelFile;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

public class XLSXServiceImpl implements XLSXService {

    private ParseExcelFile parsedFile;

    public XLSXServiceImpl(File file, int colsToProcess) throws InvalidFormatException {
        OPCPackage opcPackage = OPCPackage.open(file);
        parsedFile = new ParseExcelFile(opcPackage,colsToProcess);
    }

    public <T1, T2> SXSSFWorkbook processDataAndGenerateFileWithAppending(Function<T1, T2> businessFunction)
            throws OpenXML4JException,
            ParserConfigurationException,
            SAXException,
            IOException {

        SXSSFWorkbook outWorkbook = parsedFile.processFirstSheet(businessFunction);

        return outWorkbook;
    }

    public <T1> List<List<T1>> collectDataWithValidation(Predicate<List<T1>> bussinesValidator,Predicate<List<T1>> headerValidator,Predicate<List<T1>> adPoolColumnValidator) throws OpenXML4JException,
            ParserConfigurationException,
            SAXException,
            IOException {

        return parsedFile.processFirstSheet(bussinesValidator,headerValidator,adPoolColumnValidator);

    }
}
