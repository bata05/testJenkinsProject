package com.pru.sg.poi.custom.util;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.util.CellAddress;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler;
import org.apache.poi.xssf.usermodel.XSSFComment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

public abstract class AbstractXSSFSheetEventHandler implements XSSFSheetXMLHandler.SheetContentsHandler {// DefaultHandler {{

    protected final Logger LOGGER = LoggerFactory.getLogger(getClass());

    /**
     * Number of columns to read starting with leftmost
     */
    protected final int minColumnCount;

    protected final DataFormatter formatter;
    protected List<Object> cellValues = new ArrayList<>();
    protected int currColumnNo = -1;
    protected int currRowNo = -1;


    public AbstractXSSFSheetEventHandler(int cols) {
        this.minColumnCount = cols;
        this.formatter = new DataFormatter();
    }

    @Override
    public void startRow(int rowNum) {
        LOGGER.debug("Start Row   ===>>> " + rowNum);
        cellValues = new ArrayList<>();
        currRowNo = rowNum;
        currColumnNo = -1;
    }

    @Override
    public void cell(String cellReference, String formattedValue, XSSFComment comment) {

        // handle missing CellRef here in a similar way as XSSFCell does
        if (cellReference == null) {
            cellReference = new CellAddress(currRowNo, currColumnNo).formatAsString();

        }

        // Missed Cells
        int thisCol = (new CellReference(cellReference)).getCol();
        int missedCols = thisCol - currColumnNo - 1;
        for (int i = 0; i < missedCols; i++) {
            cellValues.add(++currColumnNo, "");
        }
        currColumnNo = thisCol;
        LOGGER.debug("Value   ===>>> row : " + currRowNo + "  Col : " + currColumnNo + formattedValue);

        cellValues.add(currColumnNo, formattedValue);

    }

    @Override
    public void endRow(int rowNum) {
        LOGGER.debug("End Row   ===>>> " + rowNum);
        for (int i = currColumnNo; i < (minColumnCount - 1); i++) {
            cellValues.add(++currColumnNo, "");
        }
        applyBusinessFunction(rowNum);
    }

    protected abstract void applyBusinessFunction(int rowNum);
}
