package com.pru.sg.poi.custom.util;

import org.apache.poi.ooxml.util.SAXHelper;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.eventusermodel.ReadOnlySharedStringsTable;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler;
import org.apache.poi.xssf.model.StylesTable;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

public class ParseExcelFile {

    private static final Logger LOGGER = LoggerFactory.getLogger(ParseExcelFile.class);

    private OPCPackage xlsxPackage;
    private int minColumns;
    private SXSSFWorkbook outWorkbook;
    private List outData;

    /**
     * @param pkg        The XLSX package to process
     * @param minColumns The minimum number of columns to output, or -1 for no minimum
     */
    public ParseExcelFile(OPCPackage pkg, int minColumns) {
        this.xlsxPackage = pkg;
        this.minColumns = minColumns;
        this.outWorkbook = new SXSSFWorkbook(10);
        this.outData = new ArrayList();
        this.outWorkbook.setCompressTempFiles(true);
    }


    /**
     * @throws IOException
     * @throws OpenXML4JException
     * @throws ParserConfigurationException
     * @throws SAXException
     */
    public <T1, T2> SXSSFWorkbook processFirstSheet(Function<T1, T2> businessFunction)
            throws IOException,
            OpenXML4JException,
            ParserConfigurationException,
            SAXException {

        ReadOnlySharedStringsTable strings = new ReadOnlySharedStringsTable(this.xlsxPackage);
        XSSFReader xssfReader = new XSSFReader(this.xlsxPackage);

        StylesTable styles = xssfReader.getStylesTable();
        XSSFReader.SheetIterator iter = (XSSFReader.SheetIterator) xssfReader.getSheetsData();

        if (iter.hasNext()) {
            long startTime = System.currentTimeMillis();
            InputStream stream = iter.next();
            String sheetName = iter.getSheetName();
            LOGGER.info("Processing Sheet : " + sheetName);
            InputSource sheetSource = new InputSource(stream);

            XMLReader xmlParser = SAXHelper.newXMLReader();
            ContentHandler handler = new XSSFSheetXMLHandler(styles, null, strings, new XSSFSheetContentProcessHandler(this.minColumns, outWorkbook.createSheet(sheetName), businessFunction), new DataFormatter(), false);
            LOGGER.info("Starting to process [Sheet] : " + sheetName);
            xmlParser.setContentHandler(handler);
            xmlParser.parse(sheetSource);
            stream.close();
            LOGGER.info("Time to process sheet [In Seconds] : " + sheetName + " => " + (System.currentTimeMillis() - startTime) / 1000);
        }
        return outWorkbook;
    }

    /**
     * @throws IOException
     * @throws OpenXML4JException
     * @throws ParserConfigurationException
     * @throws SAXException
     */
    public <T> List<List<T>> processFirstSheet(Predicate<List<T>> businessValidator,Predicate<List<T>> headerValidator, Predicate<List<T>> adPoolColumnValidator)
            throws IOException,
            OpenXML4JException,
            ParserConfigurationException,
            SAXException {

        ReadOnlySharedStringsTable strings = new ReadOnlySharedStringsTable(this.xlsxPackage);
        XSSFReader xssfReader = new XSSFReader(this.xlsxPackage);

        StylesTable styles = xssfReader.getStylesTable();

        ContentHandler handler = new XSSFSheetXMLHandler(styles, null, strings, new XSSFSheetContentCollectHandler(this.minColumns, businessValidator, outData,headerValidator,adPoolColumnValidator), new DataFormatter(), false);
        processFirstSheet(xssfReader, handler);
        return outData;
    }


    private void processFirstSheet(XSSFReader xssfReader, ContentHandler handler)
            throws IOException,
            InvalidFormatException,
            ParserConfigurationException,
            SAXException {

        XSSFReader.SheetIterator iter = (XSSFReader.SheetIterator) xssfReader.getSheetsData();
        if (iter.hasNext()) {
            long startTime = System.currentTimeMillis();
            InputStream stream = iter.next();
            String sheetName = iter.getSheetName();
            LOGGER.info("Processing Sheet : " + sheetName);
            InputSource sheetSource = new InputSource(stream);

            XMLReader xmlParser = SAXHelper.newXMLReader();
            LOGGER.info("Starting to process [Sheet] : " + sheetName);
            xmlParser.setContentHandler(handler);
            xmlParser.parse(sheetSource);
            stream.close();
            LOGGER.info("Time to process sheet [In Seconds] : " + sheetName + " => " + (System.currentTimeMillis() - startTime) / 1000);
        }


    }

    // TODO: Need to complete the implementation for MultipleSheets + Multiple Business Functions

    /**
     *
     * @throws IOException
     * @throws OpenXML4JException
     * @throws ParserConfigurationException
     * @throws SAXException
     */

    /*
    public <T1, T2> SXSSFWorkbook processAllSheets(List<Function<T1, T2>> businessFunctions)
            throws IOException,
            OpenXML4JException,
            ParserConfigurationException,
            SAXException {

        ReadOnlySharedStringsTable strings = new ReadOnlySharedStringsTable(this.xlsxPackage);
        XSSFReader xssfReader = new XSSFReader(this.xlsxPackage);

        StylesTable styles = xssfReader.getStylesTable();
        XSSFReader.SheetIterator iter = (XSSFReader.SheetIterator) xssfReader
                .getSheetsData();
        while (iter.hasNext()) {
            InputStream stream = iter.next();
            String sheetName = iter.getSheetName();
            LOGGER.info("Processing Sheet : "+sheetName);
            processSheet(styles, strings, sheetName, stream, null);
            stream.close();
        }
        return outWorkbook;
    }

    */
}
