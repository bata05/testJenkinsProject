package com.pru.sg.poi.custom.util;

import com.pru.sg.constant.excel.AdminConstants;
import com.pru.sg.exception.ExcelException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.function.Predicate;

public class XSSFSheetContentCollectHandler extends AbstractXSSFSheetEventHandler {// DefaultHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(XSSFSheetContentProcessHandler.class);
    private Predicate businessvalidator;
    private List outData;
    private Predicate headerValidator;
    private Predicate adPoolColumnValidator;


    /**
     * Accepts objects needed while parsing.
     *
     * @param cols         Minimum number of columns to show
     * @param busValidator Predicate to validate rowData
     * @param outData      List to collect validated File[row] data
     */
    public XSSFSheetContentCollectHandler(int cols, Predicate busValidator, List outData,Predicate headerValidator, Predicate adPoolColumnValidator) {
        super(cols);
        this.businessvalidator = busValidator;
        this.outData = outData;
        this.headerValidator = headerValidator;
        this.adPoolColumnValidator =adPoolColumnValidator;
    }

    @Override
    protected void applyBusinessFunction(int rowNum) {
        if (!adPoolColumnValidator.test(cellValues)){
            throw new ExcelException(AdminConstants.ERROR_INVALID_EXCEL_FORMAT +"Total columns found > "+AdminConstants.ADPOOL_EXCEL_TOTAL_COLUMNS);
        }

        if(rowNum == 0){
            if (!headerValidator.test(cellValues)){
                throw new ExcelException(AdminConstants.ERROR_INVALID_EXCEL_FORMAT +AdminConstants.ERROR_INVALID_EXCEL_HEADER);
            }
        }

        if (rowNum > 0) {
            if (businessvalidator.test(cellValues)) {
                outData.add(cellValues);
            }else {
                throw new ExcelException(AdminConstants.ERROR_INVALID_EMPTY_VALUE+" at Row "+(currRowNo+1));
            }

        }

    }



}
