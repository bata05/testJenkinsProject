package com.pru.sg.poi.custom.util;


import org.apache.poi.ss.usermodel.CellType;

import org.apache.poi.ss.util.CellAddress;
import org.apache.poi.ss.util.CellReference;

import org.apache.poi.xssf.streaming.SXSSFCell;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;

import org.apache.poi.xssf.usermodel.XSSFComment;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.function.Function;

class XSSFSheetContentProcessHandler<T, R> extends AbstractXSSFSheetEventHandler {// DefaultHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(XSSFSheetContentProcessHandler.class);

    private SXSSFSheet currentSheet;
    private Function businessFunction;


    /**
     * Accepts objects needed while parsing.
     *
     * @param cols Minimum number of columns to show
     */
    public XSSFSheetContentProcessHandler(int cols, SXSSFSheet currentSheet, Function<T, R> bussFunc) {
        super(cols);
        this.currentSheet = currentSheet;
        this.businessFunction = bussFunc;
    }

    @Override
    public void startRow(int rowNum) {

        LOGGER.debug("Start Row   ===>>> " + rowNum);
        currentSheet.createRow(rowNum);
        cellValues.clear();
        currRowNo = rowNum;
        currColumnNo = -1;
    }

    @Override
    public void endRow(int rowNum) {

        LOGGER.debug("End Row   ===>>> " + rowNum);
        SXSSFRow row = currentSheet.getRow(rowNum);

        for (int i = currColumnNo; i < minColumnCount; i++) {
            row.createCell((row.getLastCellNum() < 0 ? 0 : row.getLastCellNum()), CellType.BLANK);
            cellValues.add(++currColumnNo, "");
        }

        if (rowNum > 0) {

            try {
                R processedValues = (R) businessFunction.apply(cellValues);
                if (processedValues instanceof List) {
                    List<Object> values = (List) processedValues;
                    for (Object entry : values) {
                        SXSSFCell newCell = row.createCell((row.getLastCellNum() < 0 ? 0 : row.getLastCellNum()), CellType.STRING);
                        newCell.setCellValue(entry.toString());
                    }
                }
            } catch (Exception ex) {
                row.createCell((row.getLastCellNum() < 0 ? 0 : row.getLastCellNum()), CellType.BLANK);
                LOGGER.error("Error Generating Lead Gen Url for row no " + currRowNo + " " + ex.getMessage());
            }
        }
    }


    @Override
    public void cell(String cellReference, String formattedValue, XSSFComment comment) {


        SXSSFRow row = currentSheet.getRow(currRowNo);
        SXSSFCell cell;

        // handle missing CellRef here in a similar way as XSSFCell does
        if (cellReference == null) {
            cellReference = new CellAddress(currRowNo, currColumnNo).formatAsString();

        }

        // Missed Cells
        int thisCol = (new CellReference(cellReference)).getCol();
        int missedCols = thisCol - currColumnNo - 1;
        for (int i = 0; i < missedCols; i++) {
            row.createCell((row.getLastCellNum() < 0 ? 0 : row.getLastCellNum()), CellType.BLANK);
            cellValues.add(++currColumnNo, "");
        }
        currColumnNo = thisCol;
        LOGGER.debug("Value   ===>>> row : " + currRowNo + "  Col : " + currColumnNo + formattedValue);


        //Write cell as String by default to prevent missing prefix '0' in agent code
        cell = row.createCell((row.getLastCellNum() < 0 ? 0 : row.getLastCellNum()), CellType.STRING);
        cell.setCellValue(formattedValue);

        cellValues.add(currColumnNo, formattedValue);

    }


    @Override
    protected void applyBusinessFunction(int rowNum) {
    }
}
