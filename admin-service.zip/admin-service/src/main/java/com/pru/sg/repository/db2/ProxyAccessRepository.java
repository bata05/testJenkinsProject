package com.pru.sg.repository.db2;

import com.pru.sg.entity.db2.ProxyAccess;
import com.pru.sg.entity.db2.ProxyAccessIdentity;
import org.springframework.stereotype.Repository;

@Repository
public interface ProxyAccessRepository extends Db2GenericRepository<ProxyAccess, ProxyAccessIdentity> {}
