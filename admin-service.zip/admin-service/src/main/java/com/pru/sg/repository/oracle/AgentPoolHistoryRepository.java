package com.pru.sg.repository.oracle;

import com.pru.sg.entity.oracle.AgentPoolHistory;
import org.springframework.stereotype.Repository;

@Repository
public interface AgentPoolHistoryRepository extends GenericRepository<AgentPoolHistory, Long> {}
