package com.pru.sg.repository.oracle;

import com.pru.sg.entity.oracle.AgentPool;
import com.pru.sg.repository.oracle.custom.AgentPoolRepositoryCustom;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface AgentPoolRepository extends GenericRepository<AgentPool, Long>, AgentPoolRepositoryCustom {
}
