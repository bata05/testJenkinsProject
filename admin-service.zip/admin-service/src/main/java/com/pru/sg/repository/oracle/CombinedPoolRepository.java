package com.pru.sg.repository.oracle;

import com.pru.sg.entity.oracle.CombinedPool;
import com.pru.sg.repository.oracle.custom.AgentPoolRepositoryCustom;
import org.springframework.stereotype.Repository;

@Repository
public interface CombinedPoolRepository extends GenericRepository<CombinedPool, Long>, AgentPoolRepositoryCustom {
}
