package com.pru.sg.repository.oracle;

import com.pru.sg.entity.oracle.ProductPromotionDetails;

public interface ProductPromotionDetailsRepository extends GenericRepository<ProductPromotionDetails, Long> {

}
