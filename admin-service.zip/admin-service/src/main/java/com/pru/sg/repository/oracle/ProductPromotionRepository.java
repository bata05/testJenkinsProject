package com.pru.sg.repository.oracle;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.pru.sg.entity.oracle.ProductPromotion;

@Repository
public interface ProductPromotionRepository extends GenericRepository<ProductPromotion, Long> {
    
	@Query(value="SELECT \n"
			+ " pp.PROMOTION_ID, pp.PRODUCT_CODE, pp.DISCOUNT_PERCENTAGE, pp.CHANNEL_CODE, pp.PROMO_MSG,\n"
			+ " pp.FROM_VALIDITY_DATE, pp.TO_VALIDITY_DATE, pp.CREATED_BY, pp.MODIFIED_BY, \n"
			+ " pp.MODIFIED_DATE, pp.CREATED_DATE, pp.START_AGE, pp.END_AGE\n"
			+ "FROM product_promotion PP\n"
			+ "WHERE\n"
			+ "  sysdate BETWEEN pp.FROM_VALIDITY_DATE and pp.TO_VALIDITY_DATE order by pp.CREATED_DATE DESC", nativeQuery = true)
	public List<ProductPromotion> getAllActiveProductPromotions();
	
	@Query(value="SELECT \n"
			+ " pp.PROMOTION_ID, pp.PRODUCT_CODE, pp.DISCOUNT_PERCENTAGE, pp.CHANNEL_CODE, pp.PROMO_MSG,\n"
			+ " pp.FROM_VALIDITY_DATE, pp.TO_VALIDITY_DATE, pp.CREATED_BY, pp.MODIFIED_BY, \n"
			+ " pp.MODIFIED_DATE, pp.CREATED_DATE, pp.START_AGE, pp.END_AGE\n"
			+ "FROM product_promotion PP\n"
			+ "WHERE\n"
			+ "  pp.PROMOTION_ID NOT IN (SELECT pi.PROMOTION_ID FROM SGD2C.product_promotion pi WHERE "
			+ "SYSTIMESTAMP between pi.FROM_VALIDITY_DATE and pi.TO_VALIDITY_DATE)", nativeQuery = true)
	public List<ProductPromotion> getAllInActiveProductPromotions();
}
