package com.pru.sg.repository.oracle;

import com.pru.sg.entity.oracle.Products;

public interface ProductsRepository extends GenericRepository<Products, Long> {

}
