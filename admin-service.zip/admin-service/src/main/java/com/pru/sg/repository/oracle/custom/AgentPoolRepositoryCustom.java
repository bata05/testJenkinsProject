package com.pru.sg.repository.oracle.custom;

import java.util.List;

public interface AgentPoolRepositoryCustom {

    void batchInsertADPoolEntries(List<List<String>> entries);
}
