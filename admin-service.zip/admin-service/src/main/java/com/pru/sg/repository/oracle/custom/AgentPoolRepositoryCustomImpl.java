package com.pru.sg.repository.oracle.custom;

import com.pru.sg.constant.excel.AdminConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ParameterizedPreparedStatementSetter;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

@Repository
@Transactional(value = "pruserviceTransactionManager", propagation = Propagation.MANDATORY, rollbackFor = {Exception.class})
public class AgentPoolRepositoryCustomImpl implements AgentPoolRepositoryCustom {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public void batchInsertADPoolEntries(List<List<String>> entries) {

        String sql = "INSERT INTO PRUSERVICE.AGENT_POOL_LOOKUP (ID, AGENT_CODE, ENTRY_TYPE, STATUS, DATE_UPDATED, DATE_CREATED)" +
                " VALUES (PRUSERVICE.AGENT_POOL_LOOKUP_SEQ.NEXTVAL, ?, ?, ?, sysdate, sysdate )";
        jdbcTemplate.batchUpdate(
                sql,
                entries,
                1000,
                new ParameterizedPreparedStatementSetter<List<String>>() {

                    public void setValues(PreparedStatement ps, List<String> entry)
                            throws SQLException {
                        ps.setString(1, entry.get(1));
                        ps.setString(2, entry.get(0));
                        ps.setInt(3, AdminConstants.STATUS_ACTIVE);
                    }
                }
        );
    }
}
