package com.pru.sg.security;

import com.pru.sg.controller.AgentPoolUploadController;
import com.pru.sg.dto.request.ProxyAccessRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;


@Component
public class AuthenticationManager {

    private static final Logger LOGGER = LoggerFactory.getLogger(AgentPoolUploadController.class);

    @Autowired
    private JWTTokenProvider jwtTokenProvider;

    public String authenticate(ProxyAccessRequest proxyAccessRequest) {
        LOGGER.info("Authenticating -> {} " + proxyAccessRequest.toString());
        String token = null;
        if (proxyAccessRequest != null
                && !StringUtils.isEmpty(proxyAccessRequest.getEmpid())
                && !StringUtils.isEmpty(proxyAccessRequest.getEmpName())) {
            try {
                token = jwtTokenProvider.generateToken(new CustomUserDetails(proxyAccessRequest.getEmpid(), proxyAccessRequest.getEmpName(), proxyAccessRequest.getSessionid()));
                LOGGER.info("Authentication Success -> {} " + proxyAccessRequest.toString());
            } catch (Exception ex) {
                LOGGER.error("Authentication Failure -> {} " + proxyAccessRequest.toString() + " " + ex.getMessage());
            }
        } else {
            LOGGER.error("Authentication Failure -> {} " + proxyAccessRequest.toString() + "  INVALID Credentials");
        }

        return token;
    }
}
