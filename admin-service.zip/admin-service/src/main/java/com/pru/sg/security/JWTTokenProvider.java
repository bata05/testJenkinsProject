package com.pru.sg.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.SignatureException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;
import java.security.Key;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Component
public class JWTTokenProvider {

    private static final Logger LOGGER = LoggerFactory.getLogger(JWTTokenProvider.class);

    @Value("${security.jwt.secret}")
    private String jwtSecret;

    @Value("${security.jwt.expireInMs}")
    private long jwtExpireInMs;

    private final SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;

    public String generateToken(CustomUserDetails userDetails) {

        ZonedDateTime now = ZonedDateTime.now();
        Date issuedAt = Date.from(now.toInstant());

        byte[] apiKeySecretBytes = DatatypeConverter.parseBase64Binary(jwtSecret);
        Key signingKey = new SecretKeySpec(apiKeySecretBytes, signatureAlgorithm.getJcaName());

        final Map<String, Object> tokenData = new HashMap<>();
        tokenData.put("sessionId", userDetails.getUsername());


        final JwtBuilder jwtBuilder = Jwts.builder()
                .setSubject(userDetails.getUsername())
                .setId(userDetails.getEmpId())
                .setIssuedAt(issuedAt)
                .setClaims(tokenData)
                .signWith(signingKey, signatureAlgorithm);

        if (jwtExpireInMs >= 0) {
            ZonedDateTime expirationDateTime = now.plus(this.jwtExpireInMs, ChronoUnit.MILLIS);
            Date expirationDate = Date.from(expirationDateTime.toInstant());
            jwtBuilder.setExpiration(expirationDate);
        }

        return jwtBuilder.compact();
    }


    public Authentication getAuthentication(String token) {

        Claims claims = Jwts.parser().setSigningKey(this.jwtSecret).parseClaimsJws(token).getBody();

        CustomUserDetails userDetails = new CustomUserDetails(claims.getId(), claims.getSubject(), Optional.of(claims.get("sessionId")).orElse("").toString());
        return new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
    }

    public boolean validateToken(String token) {

        try {
            Jwts.parser().setSigningKey((DatatypeConverter.parseBase64Binary(jwtSecret))).parseClaimsJws(token);
            return true;
        } catch (SignatureException sEx) {
            LOGGER.error("Invalid JWT Signature");
        } catch (MalformedJwtException mEx) {
            LOGGER.error("Invalid JWT Token");
        } catch (ExpiredJwtException eEx) {
            LOGGER.error("Expired JWT Token");
        } catch (UnsupportedJwtException uEx) {
            LOGGER.error("Unsupported JWT Token");
        } catch (IllegalArgumentException iEx) {
            LOGGER.error("JWT claims string is empty");
        } catch (Exception ex) {
            LOGGER.error("JWT validation error " + ex.getMessage());
        }
        return false;
    }
}
