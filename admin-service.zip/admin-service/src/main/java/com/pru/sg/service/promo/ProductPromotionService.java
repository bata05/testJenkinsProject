package com.pru.sg.service.promo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;

import com.pru.sg.dto.request.ProxyAccessRequest;
import com.pru.sg.entity.oracle.ProductPromotion;

public interface ProductPromotionService {
	
	Page<ProductPromotion> fetchAllRecordsByPagination();
	
	List<ProductPromotion> fetchAllRecords();
	
	List<ProductPromotion> fetchAllActiveRecords();
	
	List<ProductPromotion> fetchAllInActiveRecords();
	
	void save(ProductPromotion prodPromo); 

	Optional<ProductPromotion> findById(Long promotionId);
	
	void deleteEntry(ProductPromotion prodPromo);
	
	void updateEntry(ProductPromotion prodPromo);
}
