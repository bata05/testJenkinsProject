package com.pru.sg.service.promo;

import java.util.List;

import org.springframework.data.domain.Page;
import com.pru.sg.entity.oracle.Products;

public interface ProductsService {
	Page<Products> fetchAllRecordsByPagination();
    
	List<Products> fetchAllRecords();
	
	Products getProductByProductCode(String productCode);
}
