package com.pru.sg.service.promo.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.pru.sg.entity.oracle.ProductPromotionDetails;
import com.pru.sg.repository.oracle.ProductPromotionDetailsRepository;
import com.pru.sg.service.promo.ProductPromotionDetailsService;

@Service
@Transactional(value = "pruserviceTransactionManager", rollbackFor = Exception.class)
public class ProductPromotionDetailsServiceImpl implements ProductPromotionDetailsService {

	@Autowired
	ProductPromotionDetailsRepository productPromotionDetailsRepository;
	
	@Override
	public Page<ProductPromotionDetails> fetchAllRecordsByPagination() {
		return productPromotionDetailsRepository.findAll(PageRequest.of(0,20, Sort.by("createdDate").descending()));
	}

	@Override
	public List<ProductPromotionDetails> fetchAllRecords() {
		return productPromotionDetailsRepository.findAll();
	}

}
