package com.pru.sg.service.promo.impl;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.pru.sg.entity.oracle.AgentPoolHistory;
import com.pru.sg.entity.oracle.ProductPromotion;
import com.pru.sg.repository.oracle.ProductPromotionRepository;
import com.pru.sg.service.promo.ProductPromotionService;

@Service
@Transactional(value = "pruserviceTransactionManager", rollbackFor = Exception.class)
public class ProductPromotionServiceImpl implements ProductPromotionService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ProductsServiceImpl.class);
	
	@Autowired
	ProductPromotionRepository productPromotionRepository;

	public Page<ProductPromotion> fetchAllRecordsByPagination() {
		return productPromotionRepository.findAll(PageRequest.of(0,20, Sort.by("createdDate").descending()));
	}

	public List<ProductPromotion> fetchAllRecords() {
		return productPromotionRepository.findAll();
	}
	
	@Transactional(propagation = Propagation.REQUIRES_NEW, value = "pruserviceTransactionManager", rollbackFor = Exception.class)
    public void save(ProductPromotion prodPromo) {
        productPromotionRepository.save(prodPromo);
        LOGGER.info("prodPromoDiscount creation save ");
    }

	public Optional<ProductPromotion> findById(Long promotionId) {
		return productPromotionRepository.findById(promotionId);
	}

	public void updateEntry(ProductPromotion prodPromo) {
		productPromotionRepository.save(prodPromo);		
	}
	
	public void deleteEntry(ProductPromotion prodPromo) {
		productPromotionRepository.delete(prodPromo);		
	}

	public List<ProductPromotion> fetchAllActiveRecords() {
		return productPromotionRepository.getAllActiveProductPromotions();
	}

	public List<ProductPromotion> fetchAllInActiveRecords() {
		return productPromotionRepository.getAllInActiveProductPromotions();
	}

}
