package com.pru.sg.service.promo.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.pru.sg.entity.oracle.Products;
import com.pru.sg.repository.oracle.ProductsRepository;
import com.pru.sg.service.promo.ProductsService;

@Service
@Transactional(value = "pruserviceTransactionManager", rollbackFor = Exception.class)
public class ProductsServiceImpl implements ProductsService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ProductsServiceImpl.class);
	
	@Autowired
	ProductsRepository productsRepository;
	
	public Page<Products> fetchAllRecordsByPagination() {
		return productsRepository.findAll(PageRequest.of(0,20, Sort.by("createdDate").descending()));
	}

	public List<Products> fetchAllRecords() {
		return productsRepository.findAll();
	}
	
    public Products getProductByProductCode(String productCode)
    {
    	List<Products> products = fetchAllRecords();
    	for(Products product : products) {
    		if(productCode.equals(product.getProductCode()))
    		{
    			return product;
    		}
    	}
    	return null; 
    }

}
