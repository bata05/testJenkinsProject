package com.pru.sg.service.promo.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pru.sg.entity.json.PromotionDiscount;
import com.pru.sg.entity.oracle.ProductPromotion;
import com.pru.sg.entity.oracle.ProductPromotionDetails;
import com.pru.sg.entity.oracle.Products;
import com.pru.sg.service.promo.ProductPromotionDetailsService;
import com.pru.sg.service.promo.ProductPromotionService;
import com.pru.sg.service.promo.ProductsService;

@Service
@Transactional(value = "pruserviceTransactionManager", rollbackFor = Exception.class)
public class PromotionDiscountService {
	
	@Autowired
    private ProductPromotionDetailsService productPromotionDetailsService;

    @Autowired
    private ProductPromotionService productPromotionService;

    @Autowired
    private ProductsService productsService;
    
	public List<PromotionDiscount> getAllPromotions() {
    	List<PromotionDiscount> promoDiscountList = new ArrayList<PromotionDiscount>();
    	List<ProductPromotion> productPromotions = productPromotionService.fetchAllRecords();
    	for(ProductPromotion prodPromo : productPromotions)
    	{
    		PromotionDiscount promoDiscount = new PromotionDiscount();
    		//Products product = productsService.getProductByProductCode(prodPromo.getProductCode());
    		promoDiscount.setPromotionId(prodPromo.getPromotionId());
    		promoDiscount.setProductCode(prodPromo.getProductCode());
//    		romoDiscount.setProductId(product.getProductId());//    		promoDiscount.setProductName(product.getProductName());
    		promoDiscount.setDiscountPercentage(prodPromo.getDiscountPercentage());
    		promoDiscount.setCreatedDate(prodPromo.getCreatedDate());
    		promoDiscount.setCreatedBy(promoDiscount.getCreatedBy());
    		promoDiscount.setPromoMessage(prodPromo.getPromoMsg());
    		promoDiscount.setFromValidityDate(prodPromo.getFromValidityDate());
    		promoDiscount.setToValidityDate(prodPromo.getToValidityDate());
    		promoDiscount.setChannelCode(prodPromo.getChannelCode());
    		promoDiscountList.add(promoDiscount);
    	}
//    	List<Products> products = productsService.fetchAllRecords();
//    	for(Products product : products)
//    	{
//    		PromotionDiscount promoDiscount = new PromotionDiscount();
//    		promoDiscount.setProductId(product.getProductId());
//    		promoDiscount.setProductCode(product.getProductCode());
//    		//promoDiscount.set
//    	}
    	return promoDiscountList;
	}
}
