package com.pru.sg.service.upload;

import com.pru.sg.dto.request.ProxyAccessRequest;
import com.pru.sg.entity.oracle.AgentPoolHistory;
import org.springframework.data.domain.Page;

import java.io.File;
import java.nio.file.Path;
import java.util.List;

public interface AgentPoolService {

    boolean processAgentPoolManipulation(List<List<String>> uploadedAgents);

    Page<AgentPoolHistory> fetchAllAgentPoolHistory();

    AgentPoolHistory initiateUploadHistory(ProxyAccessRequest proxyAccessRequest, String fileName);

    void updateAgentPoolUpdateStatus(AgentPoolHistory history, AgentPoolHistory.AgentPoolUploadStatus updatedStatus);

    void moveTempADPoolFileAsync(File file, Path destination);
}
