package com.pru.sg.service.upload;

import com.pru.sg.entity.oracle.CombinedPool;

import java.util.List;

public interface CombinedPoolService {

    List<CombinedPool> fetchAllCurrentAgents();
}
