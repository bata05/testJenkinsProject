package com.pru.sg.service.upload;

import com.pru.sg.entity.oracle.CombinedPool;
import com.pru.sg.util.ExcelUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.ArrayList;
import java.util.List;
import java.io.InputStream;

@Service
public class DownloadFCService {
    private static final Logger LOGGER = LoggerFactory.getLogger(LinkgenService.class);

    @Autowired
    private CombinedPoolService combinedPoolService;

    public byte[] generateEligibleFCFile() {
        String[] columns = {"Entry", "FC Code"};

        ArrayList<List<String>> fileData = new ArrayList<>();

        List<CombinedPool> agents = combinedPoolService.fetchAllCurrentAgents();
        for(CombinedPool agent : agents) {
            List<String> data = new ArrayList<>();
            data.add(agent.getEntryType());
            data.add(agent.getAgentCode());
            fileData.add(data);
        }

        return ExcelUtil.generateExcelByteStream(columns, fileData, null);
    }
}
