package com.pru.sg.service.upload;

public interface FileStoreService {

    /*void processAgentUpload(ProxyAccessRequest proxyAccessRequest, String fileName, Path uploadedFile,
                            Path successPath, List<AdAffiliationPool> uploadedAgents) throws Exception;*/
}
