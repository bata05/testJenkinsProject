package com.pru.sg.service.upload;

import com.pru.sg.poi.custom.exception.ExcelProcessException;
import com.pru.sg.poi.custom.exception.ReadException;
import com.pru.sg.poi.custom.service.XLSXServiceImpl;
import com.pru.sg.util.FileUtil;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import com.pru.sg.util.EncryptDecryptUtil;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.*;
import java.net.URLEncoder;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.function.Function;

@Service
public class LeadgenService {

    private static final Logger LOGGER = LoggerFactory.getLogger(LeadgenService.class);

    @Value("${SPRING_PROFILES_ACTIVE}")
    private String activeProfile;

    public InputStream processLeadgen(MultipartFile file) throws EncryptedDocumentException, IOException {

        InputStream in = new BufferedInputStream(file.getInputStream());
        ByteArrayOutputStream outStream = new ByteArrayOutputStream();

        processLeadGenInformation(in).write(outStream);
        byte[] inputByteArr = outStream.toByteArray();
        in.close();
        outStream.close();
        return new ByteArrayInputStream(inputByteArr);
    }

    private void generateLeadGenUrl(Sheet sheet) throws UnsupportedEncodingException {
        if (sheet != null) {
            String prodCode = "";
            String campaignId = "";
            String genericName = "";
            String leadGenFlag = "Y";
            String clientId = "";
            String policyNumber = "";

            Iterator<Row> iterator = sheet.iterator();

            while (iterator.hasNext()) {
                Row currentRow = iterator.next();
                if (currentRow.getRowNum() == 0) {
                    continue;
                }

                Iterator<Cell> cellIterator = currentRow.iterator();
                while (cellIterator.hasNext()) {

                    Cell currentCell = cellIterator.next();
                    int columnIndex = currentCell.getColumnIndex();

                    switch (columnIndex) {
                        case 0:
                            prodCode = currentCell.getStringCellValue();
                            break;
                        case 1:
                            campaignId = currentCell.getStringCellValue();
                            break;
                        case 2:
                            genericName = currentCell.getStringCellValue();
                            break;
                        case 3:
                            leadGenFlag = currentCell.getStringCellValue();
                            break;
                        case 4:
                            if (currentCell.getCellTypeEnum() == CellType.NUMERIC) {
                                clientId = String.valueOf((int) currentCell.getNumericCellValue());
                            } else {
                                clientId = currentCell.getStringCellValue();
                            }
                            break;
                        case 5:
                            if (currentCell.getCellTypeEnum() == CellType.NUMERIC) {
                                policyNumber = String.valueOf((int) currentCell.getNumericCellValue());
                            } else {
                                policyNumber = currentCell.getStringCellValue();
                            }
                            break;
                    }

                }
                String parameters = prodCode
                        + "#" + campaignId
                        + "#" + genericName
                        + "#" + leadGenFlag
                        + "#" + clientId
                        + "#" + policyNumber;

                if (!genericName.isEmpty() && (!clientId.isEmpty() || !policyNumber.isEmpty())) {
                    String encryptedLeadUrl = getEncryptedLeadUrl(parameters);
                    currentRow.createCell(6).setCellValue(encryptedLeadUrl);
                }

            }
        }
    }

    private String generateLeadGenUrl(List<String> entries) {

        String prodCode = "";
        String campaignId = "";
        String genericName = "";
        String leadGenFlag = "Y";
        String clientId = "";
        String policyNumber = "";
        String leadGenUrl = "";


        if (!CollectionUtils.isEmpty(entries)) {

            for (int i = 0; i < entries.size(); i++) {
                String value = entries.get(i);
                value = !StringUtils.isEmpty(value) ? value : "";
                switch (i) {
                    case 0:
                        prodCode = value;
                        break;
                    case 1:
                        campaignId = value;
                        break;
                    case 2:
                        genericName = value;
                        break;
                    case 3:
                        leadGenFlag = value;
                        break;
                    case 4:
                        clientId = value;
                        break;
                    case 5:
                        policyNumber = value;
                        break;
                }
            }
        }


        String parameters = prodCode
                + "#" + campaignId
                + "#" + genericName
                + "#" + leadGenFlag
                + "#" + clientId
                + "#" + policyNumber;

        if (!StringUtils.isEmpty(genericName) && (!StringUtils.isEmpty(clientId) || !StringUtils.isEmpty(policyNumber))) {
            try {
                leadGenUrl = getEncryptedLeadUrl(parameters);
            } catch (UnsupportedEncodingException ex) {
                LOGGER.error("Encoding Error for data : " + parameters);
                ex.printStackTrace();
            }
        }
        return leadGenUrl;
    }

    private String getEncryptedLeadUrl(String original) throws UnsupportedEncodingException {
        LOGGER.debug("Input Leadgen URL" + original);
        String hashValue = EncryptDecryptUtil.sha512EncryptWithSalt(original, "UAT_PACS_SALT");
        String xorString = EncryptDecryptUtil.xorEncryptDecrypt(original, "UAT_PACS_KEY");
        String encryptedString = EncryptDecryptUtil.encodeBase64(xorString);
        String URLString = URLEncoder.encode(encryptedString, "UTF-8");

        String envURL;
        if ("prod".equalsIgnoreCase(activeProfile) || "prd".equalsIgnoreCase(activeProfile)) {
            envURL = "https://buy";
        } else {
            envURL = "https://buy-pact";
        }
        return envURL + ".prudential.com.sg/d2c/otpRequest?param1="
                + URLString
                + "&param2="
                + hashValue;
    }

    private SXSSFWorkbook processLeadGenInformation(InputStream in) {
        File f = null;
        try {
            f = FileUtil.writeInputStreamToFile(in);
            Function<List<String>, List<String>> funcEmpToString = (entries) -> {
                return Arrays.asList(generateLeadGenUrl(entries));
            };
            return new XLSXServiceImpl(f, 6).processDataAndGenerateFileWithAppending(funcEmpToString);
        } catch (IOException e) {
            throw new ReadException("Unable to read input stream", e);
        } catch (RuntimeException e) {

            throw e;
        } catch (SAXException | ParserConfigurationException | OpenXML4JException e) {
            e.printStackTrace();
            throw new ExcelProcessException("Error Processing File", e);
        } finally {
            if (f != null) {
                try {
                    f.delete();
                    LOGGER.info("Deleted temp file[LeadGenUpload] " + f.getName());
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
    }
}
