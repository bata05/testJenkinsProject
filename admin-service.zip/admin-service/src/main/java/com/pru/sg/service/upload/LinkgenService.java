package com.pru.sg.service.upload;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.pru.sg.config.CertConfig;
import com.pru.sg.dto.request.FCLinkRequest;
import com.pru.sg.dto.response.GenericResponse;
import com.pru.sg.entity.json.LinkGen;
import com.pru.sg.poi.custom.exception.ExcelProcessException;
import com.pru.sg.poi.custom.exception.ReadException;
import com.pru.sg.poi.custom.service.XLSXServiceImpl;
import com.pru.sg.util.*;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.*;
import java.util.function.Function;

import org.apache.http.client.HttpClient;

@Service
public class LinkgenService {
    private static final Logger LOGGER = LoggerFactory.getLogger(LinkgenService.class);

    @Value("${SPRING_PROFILES_ACTIVE}")
    private String activeProfile;

    private static final String CHANNEL_CODE="RFRS";

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private CertConfig certConfig;


    @Autowired
    private JasyptUtil util;

    private boolean sendEmail=false;

    public boolean isSendEmail() {
        return sendEmail;
    }

    public void setSendEmail(boolean sendEmail) {
        this.sendEmail = sendEmail;
    }

    public InputStream processLinkgen(MultipartFile file) throws EncryptedDocumentException, IOException {

        InputStream in = new BufferedInputStream(file.getInputStream());
        ByteArrayOutputStream outStream = new ByteArrayOutputStream();

        processLinkGenInformation(in).write(outStream);
        byte[] inputByteArr = outStream.toByteArray();
        in.close();
        outStream.close();
        return new ByteArrayInputStream(inputByteArr);
    }


    private String generateLinkGenUrl(List<String> entries){

        String prodCode = "";
        String agentCode = "";

        String linkGenUrl = "";


        if (!CollectionUtils.isEmpty(entries)) {

            for (int i = 0; i < entries.size(); i++) {
                String value = entries.get(i);
                value = !StringUtils.isEmpty(value) ? value : "";
                switch (i) {
                    case 0:
                        prodCode = value;
                        break;
                    case 1:
                        agentCode = value;
                        break;

                }
            }
        }

        if (!StringUtils.isEmpty(prodCode) && (!StringUtils.isEmpty(agentCode))) {
            try {
                LinkGen linkGen = new LinkGen();
                linkGen.setAgentCode(agentCode);

               linkGenUrl = getEncryptedLinkUrl(linkGen,prodCode,agentCode);
            } catch (UnsupportedEncodingException ex) {
                LOGGER.error("Encoding Error for data : prodCode={},agentCode={}",prodCode,agentCode);
                ex.printStackTrace();
            } catch (JsonProcessingException e) {
                LOGGER.error("JsonUtil.generateJsonString() has failed, error message={}",e.getMessage());
                e.printStackTrace();
            }
        }
        return linkGenUrl;
    }

    private String generateLinkGenEmail(List<String> entries) {

        String prodCode = "";
        String agentCode = "";

        String responseMessage = "";


        if (!CollectionUtils.isEmpty(entries)) {

            for (int i = 0; i < entries.size(); i++) {
                String value = entries.get(i);
                value = !StringUtils.isEmpty(value) ? value : "";
                switch (i) {
                    case 0:
                        prodCode = value;
                        break;
                    case 1:
                        agentCode = value;
                        break;

                }
            }
        }

        if (!StringUtils.isEmpty(prodCode) && (!StringUtils.isEmpty(agentCode))) {
            try {
                LinkGen linkGen = new LinkGen();
                linkGen.setAgentCode(agentCode);

                responseMessage = getSendEmailResponse(linkGen,prodCode,agentCode);
            } catch (UnsupportedEncodingException ex) {
                LOGGER.error("Encoding Error for data : prodCode={},agentCode={}",prodCode,agentCode);
                ex.printStackTrace();
            }
        }
        return responseMessage;
    }

    public String getEncryptedLinkUrl(LinkGen linkGen, String prodCode, String agentCode) throws UnsupportedEncodingException, JsonProcessingException {
        boolean isInputValid=validateAgentCodeAndProdCode(agentCode,prodCode);
        GenericResponse response=null;

        LOGGER.debug("isValidProdCode={}",isInputValid);
        if(!isInputValid){
            return "Agent Code/Product Code is blank";
        }

        try {
            response = validateFCLink(agentCode,prodCode);

        } catch (Exception e) {
            LOGGER.error("Encoding Error for data : prodCode={},agentCode={}",prodCode,agentCode);
            LOGGER.error("Error Message={}",e.getMessage());
            e.printStackTrace();
            return "Error message: "+e.getMessage();
        }

        LOGGER.info("agentCode={}, prodCode={}, message={}",agentCode,prodCode,response.getMessage());


        //return the response message if not valid
        if(!response.getMessage().equalsIgnoreCase("valid")){
            return response.getMessage();
        }

        String jsonString = JsonUtil.generateJsonString(linkGen);
        String encrypted = Base64.getUrlEncoder().withoutPadding().encodeToString(jsonString.getBytes());

        return EnvironmentUtil.getEnvironment(activeProfile) + ".prudential.com.sg/d2c/"+prodCode.toLowerCase()+"_entry"+"?token="+encrypted;

    }

    private String getSendEmailResponse(LinkGen linkGen, String prodCode, String agentCode) throws UnsupportedEncodingException{
        LOGGER.info("Inside getSendEmailResponse()");
        boolean isInputValid=validateAgentCodeAndProdCode(agentCode,prodCode);
        GenericResponse response=null;

        LOGGER.info("isValidProdCode={}",isInputValid);
        if(!isInputValid){
            return "Agent Code/Product Code is blank";
        }

        try {
            response = validateFCLink(agentCode,prodCode);

        } catch (Exception e) {
            LOGGER.error("Encoding Error for data : prodCode={},agentCode={}",prodCode,agentCode);
            LOGGER.error("Error Message={}",e.getMessage());
            e.printStackTrace();
            return "Error message: "+e.getMessage();
        }
        LOGGER.info("agentCode={}, prodCode={}, message={}",agentCode,prodCode,response.getMessage());

        return response.getMessage();

    }

    private boolean validateAgentCodeAndProdCode(String agentCode, String prodCode){
       return (!StringUtils.isEmpty(agentCode) && !StringUtils.isEmpty(prodCode));
    }

    public GenericResponse validateFCLink(String agentCode, String prodCode)throws IOException, NoSuchAlgorithmException, KeyManagementException, KeyStoreException, CertificateException{

        FCLinkRequest request = new FCLinkRequest();
        HttpClient httpClient;
        HttpHeaders headers = HttpHeadersUtil.getHeaders();
        HttpEntity<FCLinkRequest> entityReq = new HttpEntity<FCLinkRequest>(request, headers);

        request.setAgentCode(agentCode);
        request.setProdCode(prodCode);
        request.setSendEmail(isSendEmail());

        LOGGER.info("activeProfile={}",activeProfile);

        if ("prod".equalsIgnoreCase(activeProfile) || "prd".equalsIgnoreCase(activeProfile)) {
            httpClient = KeyStoreUtil.createHttpClient(new ClassPathResource(certConfig.getKeyStoreLocationPRD()).getInputStream(),certConfig.getKeyStorePasswordPRD(),certConfig.getProtocol());
        } else if("uat".equalsIgnoreCase(activeProfile)){
            httpClient = KeyStoreUtil.createHttpClient(new ClassPathResource(certConfig.getKeyStoreLocationUAT()).getInputStream(),certConfig.getKeyStorePasswordUAT(),certConfig.getProtocol());
        }else{
            httpClient = KeyStoreUtil.createHttpClient(new ClassPathResource(certConfig.getKeyStoreLocationSIT()).getInputStream(),certConfig.getKeyStorePasswordSIT(),certConfig.getProtocol());
        }

        ClientHttpRequestFactory requestFactory =
                new HttpComponentsClientHttpRequestFactory(httpClient);

        restTemplate.setRequestFactory(requestFactory);


        String postURL = EnvironmentUtil.getEnvironment(activeProfile)+ ".prudential.com.sg/d2c-service/validateFCLink";

        LOGGER.info("postURL={}",postURL);

        GenericResponse response = restTemplate.postForObject(postURL,entityReq, GenericResponse.class);

        LOGGER.info("response.getMessage()={}, status={}",response.getMessage(),response.getStatus());

        return response;
    }

    @Bean
    public RestTemplate restTemplate(RestTemplateBuilder builder) {
        // Do any additional configuration here
        return builder.build();
    }

    private SXSSFWorkbook processLinkGenInformation(InputStream in) {
        File f = null;
        try {
            f = FileUtil.writeInputStreamToFile(in);
            Function<List<String>, List<String>> funcEmpToString = (entries) -> {
                if(!isSendEmail())
                  return Arrays.asList(generateLinkGenUrl(entries));
                else
                  //TO DO: implement generateLinkGenEmail
                  return Arrays.asList(generateLinkGenEmail(entries));
            };

            return new XLSXServiceImpl(f, 2).processDataAndGenerateFileWithAppending(funcEmpToString);
        } catch (IOException e) {
            throw new ReadException("Unable to read input stream", e);
        } catch (RuntimeException e) {

            throw e;
        } catch (SAXException | ParserConfigurationException | OpenXML4JException e) {
            e.printStackTrace();
            throw new ExcelProcessException("Error Processing File", e);
        } finally {
            if (f != null) {
                try {
                    f.delete();
                    LOGGER.info("Deleted temp file[LinkGenUpload] " + f.getName());
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
    }


}
