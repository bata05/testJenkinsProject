package com.pru.sg.service.upload;

import com.pru.sg.dto.request.ProxyAccessRequest;
import com.pru.sg.entity.db2.ProxyAccess;
import com.pru.sg.entity.db2.ProxyAccessIdentity;

public interface PacsnetService {

    boolean isValidSession(ProxyAccessRequest proxyAccessRequest);
    ProxyAccess getSessionByIdAndEmpId(ProxyAccessIdentity identity);
    void deleteSession(ProxyAccess access);
}
