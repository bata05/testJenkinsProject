package com.pru.sg.service.upload;

import com.pru.sg.poi.custom.exception.ExcelProcessException;
import com.pru.sg.poi.custom.exception.ReadException;
import com.pru.sg.poi.custom.service.XLSXServiceImpl;
import com.pru.sg.util.EncryptDecryptUtil;
import com.pru.sg.util.FileUtil;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.*;
import java.net.URLEncoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.function.Function;

@Service
public class SIOLinkGenService {
    private static final Logger LOGGER = LoggerFactory.getLogger(SIOLinkGenService.class);

    @Value("${SPRING_PROFILES_ACTIVE}")
    private String activeProfile;

    private static final String EXPIRY_DATE_FORMAT="dd/MM/yyyy";

    public InputStream processLinkgen(MultipartFile file) throws EncryptedDocumentException, IOException {

        InputStream in = new BufferedInputStream(file.getInputStream());
        ByteArrayOutputStream outStream = new ByteArrayOutputStream();

        processSIOLinkGenInformation(in).write(outStream);
        byte[] inputByteArr = outStream.toByteArray();
        in.close();
        outStream.close();
        return new ByteArrayInputStream(inputByteArr);
    }

    private SXSSFWorkbook processSIOLinkGenInformation(InputStream in) {
        File f = null;
        try {
            f = FileUtil.writeInputStreamToFile(in);
            Function<List<String>, List<String>> funcEmpToString = (entries) -> {
                return Arrays.asList(generateLinkGenUrl(entries));
            };
            return new XLSXServiceImpl(f, 4).processDataAndGenerateFileWithAppending(funcEmpToString);
        } catch (IOException e) {
            throw new ReadException("Unable to read input stream", e);
        } catch (RuntimeException e) {

            throw e;
        } catch (SAXException | ParserConfigurationException | OpenXML4JException e) {
            e.printStackTrace();
            throw new ExcelProcessException("Error Processing File", e);
        } finally {
            if (f != null) {
                try {
                    f.delete();
                    LOGGER.info("Deleted temp file[LeadGenUpload] " + f.getName());
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
    }

    private String generateLinkGenUrl(List<String> entries) {

        String prodCode = "";
        String campaignId = "";
        String clientId = "";

        String expiryDate ="";

        String linkGenUrl = "";


        if (!CollectionUtils.isEmpty(entries)) {

            for (int i = 0; i < entries.size(); i++) {
                String value = entries.get(i);
                value = !StringUtils.isEmpty(value) ? value : "";
                switch (i) {
                    case 0: {
                        prodCode = value;
                        break;
                    }
                    case 1: {
                        campaignId = value;
                        break;
                    }
                    case 2: {
                        clientId = value;
                        break;
                    }
                    case 3: {
                        expiryDate = value;
                        break;
                    }
                    default: {
                        break;
                    }
                }
            }
        }

        String parameters = campaignId
                + "#" + clientId
                + "#" + prodCode
                + "#" + expiryDate;

        if (!StringUtils.isEmpty(prodCode) && !StringUtils.isEmpty(campaignId) && !StringUtils.isEmpty(clientId) && !StringUtils.isEmpty(expiryDate) && validateDate(expiryDate)) {
            try {
                linkGenUrl = getEncryptedLeadUrl(parameters);
            } catch (UnsupportedEncodingException ex) {
                LOGGER.error("Encoding Error for data : " + parameters);
                linkGenUrl = "Encoding Error for data : " + parameters;
                ex.printStackTrace();
            }
        }else{
            linkGenUrl = "Encoding Error for data : " + parameters;
        }
        return linkGenUrl;
    }

    private boolean validateDate(String inputDate){
        Date n = null;
        boolean result=false;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(EXPIRY_DATE_FORMAT);
            sdf.setLenient(false);
            n = sdf.parse(inputDate);
            result=true;
        }
        catch (ParseException e) {
            LOGGER.error("validateDate", e);
        }finally {
            return result;
        }
    }

    private String getEncryptedLeadUrl(String original) throws UnsupportedEncodingException {
        LOGGER.debug("Input LinkGen URL" + original);
        String hashValue = EncryptDecryptUtil.sha512EncryptWithSalt(original, "UAT_PACS_SALT");
        String xorString = EncryptDecryptUtil.xorEncryptDecrypt(original, "UAT_PACS_KEY");
        String encryptedString = EncryptDecryptUtil.encodeBase64(xorString);
        String URLString = URLEncoder.encode(encryptedString, "UTF-8");

        String envURL;
        if ("prod".equalsIgnoreCase(activeProfile) || "prd".equalsIgnoreCase(activeProfile)) {
            envURL = "https://buy";
        }  else if("uat".equalsIgnoreCase(activeProfile)) {
            envURL = "https://buy-pact";
        }else{
            envURL = "https://buy-sit";
        }
        return envURL + ".prudential.com.sg/d2c/edmSIO?param1="
                + URLString
                + "&param2="
                + hashValue;
    }
}
