package com.pru.sg.service.upload;

import com.pru.sg.dto.request.ProxyAccessRequest;
import org.springframework.web.multipart.MultipartFile;

public interface UploadService {

    void processUploadingOfFile(MultipartFile file, ProxyAccessRequest proxyAccessRequest) throws Exception;

    void processADPoolFile(MultipartFile file, ProxyAccessRequest proxyAccessRequest) throws Exception;
}
