package com.pru.sg.service.upload.impl;

import com.pru.sg.dto.request.ProxyAccessRequest;
import com.pru.sg.entity.oracle.AgentPool;
import com.pru.sg.entity.oracle.AgentPoolHistory;
import com.pru.sg.repository.oracle.AgentPoolHistoryRepository;
import com.pru.sg.repository.oracle.AgentPoolRepository;
import com.pru.sg.service.upload.AgentPoolService;
import com.pru.sg.util.FileUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.nio.file.Path;
import java.util.List;

@Service
@Transactional(value = "pruserviceTransactionManager", rollbackFor = Exception.class)
public class AgentPoolServiceImpl implements AgentPoolService {

    private static final Logger LOGGER = LoggerFactory.getLogger(AgentPoolServiceImpl.class);

    @Autowired
    AgentPoolRepository agentPoolRepository;
    @Autowired
    AgentPoolHistoryRepository agentPoolHistoryRepository;

    public List<AgentPool> fetchAllCurrentAgents(){
        return agentPoolRepository.findAll();
    }

    private long fetchAllCurrentAgentsCount(){
        return agentPoolRepository.count();
    }

    private void deleteAllCurrentAgents(){
        agentPoolRepository.deleteAllInBatch();
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW, value = "pruserviceTransactionManager", rollbackFor = Exception.class)
    public boolean processAgentPoolManipulation(List<List<String>> uploadedAgents){
        long start1 = System.currentTimeMillis();

        long currentAgentPoolCount = fetchAllCurrentAgentsCount();
        LOGGER.info("Loading CUrrent Agent Pool SIze took: {}", System.currentTimeMillis()-start1);
        LOGGER.info("Current Agent Pool size: {}", currentAgentPoolCount);

        long start3 = System.currentTimeMillis();
        deleteAllCurrentAgents();
        LOGGER.info("Agent Pool table truncate took: {}", System.currentTimeMillis()-start3);

        long start4 = System.currentTimeMillis();
        agentPoolRepository.batchInsertADPoolEntries(uploadedAgents);
        LOGGER.info("New set of Agent Pool  loading took: {}", System.currentTimeMillis()-start4);
        return true;
    }

    private AgentPoolHistory buildAgentPoolHistory(ProxyAccessRequest proxyAccessRequest, String fileName, long uploadedAgentCnt) {
        AgentPoolHistory agentPoolHistory = new AgentPoolHistory();
        agentPoolHistory.setUserId(proxyAccessRequest.getEmpid());
        agentPoolHistory.setUserName(proxyAccessRequest.getEmpName());
        agentPoolHistory.setFileName(fileName);
        agentPoolHistory.setAgentTotalCount(uploadedAgentCnt);
        return agentPoolHistory;
    }

    public Page<AgentPoolHistory> fetchAllAgentPoolHistory(){
        return agentPoolHistoryRepository.findAll(PageRequest.of(0,20, Sort.by("createdDate").descending()));
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW, value = "pruserviceTransactionManager", rollbackFor = Exception.class)
    public AgentPoolHistory initiateUploadHistory(ProxyAccessRequest proxyAccessRequest, String fileName) {
        AgentPoolHistory history = buildAgentPoolHistory(proxyAccessRequest, fileName, 0);
        history.setStatus(AgentPoolHistory.AgentPoolUploadStatus.INIT);
        return agentPoolHistoryRepository.save(history);
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW, value = "pruserviceTransactionManager", rollbackFor = Exception.class)
    public void updateAgentPoolUpdateStatus(AgentPoolHistory history, AgentPoolHistory.AgentPoolUploadStatus updatedStatus) {
        history.setStatus(updatedStatus);
        agentPoolHistoryRepository.save(history);
        LOGGER.info("Updated ADPoolUploadHistory Status " + updatedStatus.name());
    }

    @Async
    @Override
    public void moveTempADPoolFileAsync(File file, Path destination) {
        if (file != null && destination != null) {
            FileUtil.moveFile(file.toPath(), destination);
            LOGGER.info("Temp file {} moved ", file.getName());
        }
    }

}
