package com.pru.sg.service.upload.impl;

import com.pru.sg.entity.oracle.CombinedPool;
import com.pru.sg.repository.oracle.CombinedPoolRepository;
import com.pru.sg.service.upload.AgentPoolService;
import com.pru.sg.service.upload.CombinedPoolService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.nio.file.Path;
import java.util.List;

@Service
@Transactional(value = "pruserviceTransactionManager", rollbackFor = Exception.class)
public class CombinedPoolServiceImpl implements CombinedPoolService {

    private static final Logger LOGGER = LoggerFactory.getLogger(CombinedPoolServiceImpl.class);

    @Autowired
    CombinedPoolRepository combinedPoolRepository;

    public List<CombinedPool> fetchAllCurrentAgents(){
        return combinedPoolRepository.findAll();
    }

}
