package com.pru.sg.service.upload.impl;


import com.pru.sg.service.upload.FileStoreService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;


@Service
public class FileStoreServiceImpl implements FileStoreService {

    private static final Logger LOGGER = LoggerFactory.getLogger(FileStoreServiceImpl.class);

    /*@Autowired
    private AgentPoolService agentPoolService;

    public void processAgentUpload(ProxyAccessRequest proxyAccessRequest, String fileName, Path uploadedFile, Path successsPath,
                                   List<AdAffiliationPool> uploadedAgents) throws Exception{
        try {
            LOGGER.info("[Start] - Processing processAgentUpload of userid {}, userName {}, with fileName {}",
                    proxyAccessRequest.getEmpid(), proxyAccessRequest.getEmpName(), fileName);
            long start = System.currentTimeMillis();
            if(agentPoolService.processAgentPoolManipulation(proxyAccessRequest, fileName, uploadedAgents))
            FileUtil.moveFile(uploadedFile, successsPath);
            LOGGER.info("Overall time Processing processAgentUpload in {}", System.currentTimeMillis()-start);
            LOGGER.info("[End] - Processing processAgentUpload of userid {}, userName {}, with fileName {}",
                    proxyAccessRequest.getEmpid(), proxyAccessRequest.getEmpName(), fileName);
        } catch (Exception e) {
            LOGGER.error("Error in FileStoreServiceImpl.processAgentUpload(): ", e);
            throw new FileException(e.getMessage());
        }
    }*/
}
