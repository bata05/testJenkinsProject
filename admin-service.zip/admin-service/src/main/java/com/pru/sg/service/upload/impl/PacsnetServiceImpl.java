package com.pru.sg.service.upload.impl;

import com.pru.sg.dto.request.ProxyAccessRequest;
import com.pru.sg.entity.db2.ProxyAccess;
import com.pru.sg.entity.db2.ProxyAccessIdentity;
import com.pru.sg.exception.PacsnetAccessException;
import com.pru.sg.exception.SessionNotFoundException;
import com.pru.sg.repository.db2.ProxyAccessRepository;
import com.pru.sg.service.upload.PacsnetService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@org.springframework.transaction.annotation.Transactional(value = "pacsnetTransactionManager")
public class PacsnetServiceImpl implements PacsnetService {

    private static final Logger LOGGER = LoggerFactory.getLogger(PacsnetServiceImpl.class);

    @Autowired
    private ProxyAccessRepository proxyAccessRepository;

    public boolean isValidSession(ProxyAccessRequest proxyAccessRequest){
        LOGGER.info("Start isValidSession sessionid of: {}", proxyAccessRequest.toString());
        try {
            ProxyAccess access = getSessionByIdAndEmpId(buildProxyAccessIdentity(proxyAccessRequest));
            deleteSession(access);
        } catch(SessionNotFoundException e){
            LOGGER.error("Session sessionid of: {}, or empid of: {} not found",
                    proxyAccessRequest.getSessionid(), proxyAccessRequest.getEmpid());
            return false;
        } catch(Exception e){
            LOGGER.error("Session sessionid of: {}, and empid of: {}, encountered an error: {}",
                    proxyAccessRequest.getSessionid(), proxyAccessRequest.getEmpid(), e.getMessage());
            throw new PacsnetAccessException(e.getMessage());
        }
        LOGGER.info("End isValidSession sessionid of: {}", proxyAccessRequest.toString());
        return true;
    }

    private ProxyAccessIdentity buildProxyAccessIdentity(ProxyAccessRequest proxyAccessRequest){
        ProxyAccessIdentity identity = new ProxyAccessIdentity();
        identity.setSessionId(proxyAccessRequest.getSessionid());
        identity.setEmployeeId(proxyAccessRequest.getEmpid());
        return identity;
    }

    public ProxyAccess getSessionByIdAndEmpId(ProxyAccessIdentity identity){
        return  proxyAccessRepository.findById(identity)
                .orElseThrow(() -> new SessionNotFoundException("Access not found for sessionid: " + identity.getSessionId() +
                        " employeeid: " + identity.getEmployeeId()));
    }

    public void deleteSession(ProxyAccess access){
        proxyAccessRepository.delete(access);
    }
}
