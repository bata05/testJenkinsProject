package com.pru.sg.service.upload.impl;

import com.pru.sg.config.ExcelConfig;
import com.pru.sg.constant.excel.AdminConstants;
import com.pru.sg.constant.excel.ExcelSection;
import com.pru.sg.constant.excel.ModifiedHeaderType;
import com.pru.sg.dto.request.ProxyAccessRequest;
import com.pru.sg.entity.oracle.AgentPoolHistory;
import com.pru.sg.exception.ExcelException;
import com.pru.sg.file.excel.AdAffiliationPool;
import com.pru.sg.file.excel.ExcelObjectMapper;
import com.pru.sg.file.excel.ExcelReader;
import com.pru.sg.poi.custom.exception.ExcelProcessException;
import com.pru.sg.poi.custom.exception.ReadException;
import com.pru.sg.poi.custom.service.XLSXServiceImpl;
import com.pru.sg.service.upload.AgentPoolService;
import com.pru.sg.service.upload.FileStoreService;
import com.pru.sg.service.upload.UploadService;
import com.pru.sg.util.ExcelUtil;
import com.pru.sg.util.FileUtil;
import lombok.Getter;
import lombok.Setter;
import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.poi.ss.usermodel.Sheet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;
import org.xml.sax.SAXException;

import javax.annotation.PostConstruct;
import javax.xml.parsers.ParserConfigurationException;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

@Service
public class UploadServiceImpl implements UploadService {

    private static final Logger LOGGER = LoggerFactory.getLogger(UploadServiceImpl.class);

    @Value("${file.root.directory}")
    private String rootConfig;
    @Value("${file.directory.temp}")
    private String tempConfig;
    @Value("${file.directory.success}")
    private String successConfig;
    @Value("${file.directory.failed}")
    private String failedConfig;

    @Getter
    @Setter
    private Path tempFolder;
    @Getter
    @Setter
    private Path successFolder;
    @Getter
    @Setter
    private Path failedFolder;

    @Autowired
    private FileStoreService fileStoreService;

    @Autowired
    private AgentPoolService agentPoolService;

    @PostConstruct
    private void createDirectories() throws IOException {
        Path tempPath = Paths.get(rootConfig, tempConfig);
        Path successPath = Paths.get(rootConfig, successConfig);
        Path failedPath = Paths.get(rootConfig, failedConfig);
        if (!Files.exists(tempPath)) Files.createDirectories(tempPath);
        if (!Files.exists(successPath)) Files.createDirectories(successPath);
        if (!Files.exists(failedPath)) Files.createDirectories(failedPath);
        this.tempFolder = tempPath;
        this.successFolder = successPath;
        this.failedFolder = failedPath;
    }

    public synchronized void processUploadingOfFile(MultipartFile file, ProxyAccessRequest proxyAccessRequest) throws Exception {
        /*File uploadedFile = writefileFromRequest(file, proxyAccessRequest);
        try {
            Workbook wb = ExcelReader.readExcel(uploadedFile);
            Sheet sheet = wb.getSheetAt(AdminConstants.FIRST_SHEET);
            LOGGER.info("File was successfully save to the temp folder");
            Map<String, ExcelConfig[]> excelSectionHeaders = ExcelReader.getExcelHeaderSections();
            int lastValidRowIndex = ExcelUtil.getValidRowIndex(sheet);
            LOGGER.info("No of rows detected: {}", lastValidRowIndex);

            if (ExcelUtil.areAllHeadersValid(excelSectionHeaders, sheet)) {
                modifyColumnHeaderDataType(sheet, lastValidRowIndex);
                List<AdAffiliationPool> uploadedAgents = extractUploadedAgent(excelSectionHeaders, sheet, lastValidRowIndex);
                if (!CollectionUtils.isEmpty(uploadedAgents)) {
                    Path successPath = Paths.get(successFolder.toString() + AdminConstants.FILE_SEPARATOR + uploadedFile.getName());
                    fileStoreService.processAgentUpload(proxyAccessRequest, uploadedFile.getName(), Paths.get(uploadedFile.getPath()), successPath, uploadedAgents);
                }
                LOGGER.info("Upload service transaction was completed.");
            }
        } catch (Exception e) {
            FileUtil.moveFile(Paths.get(uploadedFile.getPath()), Paths.get(failedFolder.toString() + AdminConstants.FILE_SEPARATOR + uploadedFile.getName()));
            throw new FileException(e.getMessage());
        }*/
    }

    @Override
    public synchronized void processADPoolFile(MultipartFile file, ProxyAccessRequest proxyAccessRequest) throws Exception {

        InputStream in = null;
        File f = null;
        boolean success = false;
        AgentPoolHistory historyEntry = null;
        try {
            historyEntry = agentPoolService.initiateUploadHistory(proxyAccessRequest, file.getOriginalFilename());
            in = new BufferedInputStream(file.getInputStream());
            f = writefileFromRequest(file, proxyAccessRequest);
            Predicate<List<String>> predicateADEntryValidator = (entries) -> {
                return valdateADPoolFileEntry(entries);
            };

            Predicate<List<String>> predicateHeaderValidator = (entries) -> {
                return validateADPoolHeader(entries);
            };

            Predicate<List<String>> predicateADPoolColumnValidator = (entries) -> {
                return validateADPoolColumn(entries);
            };

            List<List<String>> adPoolFileData = new XLSXServiceImpl(f, 2).collectDataWithValidation(predicateADEntryValidator,predicateHeaderValidator, predicateADPoolColumnValidator);

            if (!CollectionUtils.isEmpty(adPoolFileData)) {
                LOGGER.info("Collected File Data successfully. Number of new Entries : " + adPoolFileData.size());
                if (agentPoolService.processAgentPoolManipulation(adPoolFileData)) {
                    success = true;
                    historyEntry.setAgentTotalCount(adPoolFileData.size());
                    //FileUtil.moveFile(f, successFolder);
                }
            }
            //excel is empty
            else{
                throw new ExcelException(AdminConstants.ERROR_INVALID_EMPTY_EXCEL);
            }

        } catch (IOException e) {
            throw new ReadException("Unable to read input stream", e);
        } catch (RuntimeException e) {
            throw e;
        } catch (SAXException | ParserConfigurationException | OpenXML4JException e) {
            e.printStackTrace();
            throw new ExcelProcessException("Error Processing File", e);
        } finally {
            if (historyEntry != null) {
                try {
                    agentPoolService.updateAgentPoolUpdateStatus(historyEntry, success ? AgentPoolHistory.AgentPoolUploadStatus.SUCCESS : AgentPoolHistory.AgentPoolUploadStatus.FAILED);
                } catch (Exception ex) {
                    LOGGER.error("Error Updating AgentPoolHistory.AgentPoolUploadStatus");
                    ex.printStackTrace();
                }
            }

            if (in != null) {
                try {
                    in.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }

            //Move the processed temp file to relavant success / fail folder
            if (f != null) {
                try {
                    agentPoolService.moveTempADPoolFileAsync(f, Paths.get((success ? successFolder.toString() : failedFolder.toString()) + AdminConstants.FILE_SEPARATOR + f.getName()));
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }

        }

    }

    private File writefileFromRequest(MultipartFile file, ProxyAccessRequest proxyAccessRequest) {
        String fileName = FileUtil.generateFileName(proxyAccessRequest.getEmpid(), file.getOriginalFilename());
        LOGGER.info("userId: {}, fileName: {}, uploaded file: {}", proxyAccessRequest.getEmpid(), fileName, tempFolder + AdminConstants.FILE_SEPARATOR + fileName);
        return FileUtil.writeFile(fileName, tempFolder.toString(), FileUtil.extractContent(file));
    }

    private List<AdAffiliationPool> extractUploadedAgent(Map<String, ExcelConfig[]> excelSectionHeaders, Sheet sheet, int lastValidRowIndex) throws Exception {
        Map<String, List<ExcelConfig[]>> excelRowValuesMap = ExcelReader.getExcelRowValues(excelSectionHeaders, sheet, lastValidRowIndex);
        List<AdAffiliationPool> uploadedAgents = ExcelObjectMapper.getObject(excelRowValuesMap.get(ExcelSection.AD_AFFILIATION_POOL.getGroupName()), AdAffiliationPool.class);
        LOGGER.info("No of Agents to be uploaded: {}", uploadedAgents.size());
        return uploadedAgents;
    }

    private void modifyColumnHeaderDataType(Sheet sheet, int lastValidRowIndex) {
        for (ModifiedHeaderType header : ModifiedHeaderType.values()) {
            int colIndex = ExcelUtil.getColHeaderIndex(sheet, header.headerName());
            LOGGER.info("Column header cell data type to be modified : {}, to new data type: {}", header.headerName(), header.cellType().toString());
            ExcelUtil.updateCellTypePerColumnHeader(sheet, AdminConstants.agentPoolOffsetHeaderIndex, lastValidRowIndex, colIndex, header.cellType());
        }
    }

    private boolean valdateADPoolFileEntry(List<String> adPoolFileEntry) {
        return (!CollectionUtils.isEmpty(adPoolFileEntry)
                && adPoolFileEntry.stream().noneMatch(entry -> StringUtils.isEmpty(entry)) && validateData(adPoolFileEntry));

    }

    private boolean validateADPoolColumn(List<String> adPoolFileEntry) {

        int totalColumnsFound = adPoolFileEntry.size();
        LOGGER.info("totalColumnsFound={}",totalColumnsFound);

        if(totalColumnsFound > AdminConstants.ADPOOL_EXCEL_TOTAL_COLUMNS)
            return false;

        return true;
    }

    private boolean validateADPoolHeader(List<String> adPoolFileEntry) {

        Map<String, ExcelConfig[]> excelSectionHeaders = ExcelReader.getExcelHeaderSections();

        Iterator<String> iter = excelSectionHeaders.keySet().iterator();

        while(iter.hasNext()){
            String key = iter.next();
            ExcelConfig[] excelConfigs = excelSectionHeaders.get(key);

            for(int i=0; i<excelConfigs.length; i++) {
                int cellIndex = excelConfigs[i].getExcelIndex();
                String colName = excelConfigs[i].getExcelHeader();
                String cellValue = adPoolFileEntry.get(cellIndex).toString();

                if (cellValue == null || cellValue.isEmpty() || !colName.equals(cellValue)) {
                    return false;
                }
            }

        }

        return true;
    }



    private boolean validateData(List cellValues){
        int size = cellValues.size();

        for(int j=0;j<size;j++){
            String value = cellValues.get(j).toString();
            if(value==null||value.isEmpty()){
                return false;
            }
        }
        return true;
    }
}
