package com.pru.sg.util;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class EncryptDecryptUtil {

    private EncryptDecryptUtil() {
    }

    private static Logger LOGGER = LoggerFactory.getLogger(EncryptDecryptUtil.class);

    public static String xorEncryptDecrypt(String inputStr, String key) {
        StringBuilder outputStr = new StringBuilder();
        for (int i = 0; i < inputStr.length(); i++) {
            outputStr.append((char) (inputStr.charAt(i) ^ key.charAt(i % key.length())));
        }
        return new String(outputStr);
    }

    public static String encodeBase64(String str) {
        return new String(Base64.encodeBase64URLSafe(str.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    }

    public static String sha512EncryptWithSalt(String original, String salt) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-512");
            md.update(salt.getBytes());
            byte[] digestRes = md.digest(original.getBytes(StandardCharsets.UTF_8));
            return getDigestStr(digestRes);
        } catch (NoSuchAlgorithmException e) {
            LOGGER.error("Error in Leadgen sha512EncryptWithSalt"+ e.getMessage());
            return null;
        }
    }

    private static String getDigestStr(byte[] origBytes) {
        String tempStr;
        StringBuilder stb = new StringBuilder();
        for (byte origByte : origBytes) {
            tempStr = Integer.toHexString(origByte & 0xff);
            if (tempStr.length() == 1) {
                stb.append("0");
            }
            stb.append(tempStr);
        }
        return stb.toString();
    }

}
