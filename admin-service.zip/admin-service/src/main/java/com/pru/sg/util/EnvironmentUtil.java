package com.pru.sg.util;

public class EnvironmentUtil {

    public static String getEnvironment(String activeProfile){
        if ("prod".equalsIgnoreCase(activeProfile) || "prd".equalsIgnoreCase(activeProfile)) {
            return "https://buy";
        } else if("uat".equalsIgnoreCase(activeProfile)){
            return "https://buy-pact";
        }

        return "https://buy-sit";
    }
}
