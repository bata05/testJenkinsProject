package com.pru.sg.util;

import com.pru.sg.config.ExcelConfig;
import com.pru.sg.constant.excel.AdminConstants;
import com.pru.sg.exception.ExcelException;
import java.io.*;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import static java.util.Arrays.asList;
import static org.apache.poi.util.IOUtils.closeQuietly;
import static org.springframework.util.StringUtils.isEmpty;

import java.util.Map;

public class ExcelUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(ExcelUtil.class);

    public static boolean areAllHeadersValid(Map<String, ExcelConfig[]> excelSectionHeaders, final Sheet sheet){
        Row headerRow = sheet.getRow(0);
        excelSectionHeaders.forEach((section, excelConfigs) -> {
            for(int i=0; i<excelConfigs.length; i++) {
                int cellIndex = excelConfigs[i].getExcelIndex();
                String colName = excelConfigs[i].getExcelHeader();
                Cell cell = headerRow.getCell(cellIndex);
                if (cell == null || cell.getCellType() == CellType.BLANK || !colName.equals(cell.getStringCellValue())) {
                    throw new ExcelException(AdminConstants.ERROR_INVALID_EXCEL_HEADER);
                }
            }
        });
        return true;
    }

    public static String setDefaultIfEmpty(String value) {
        return (StringUtils.isEmpty(value) ? "" : value);
    }

    public static byte[] generateExcelByteStream(String[] headers, List<List<String>> data, String sheetName) throws ExcelException{
        Workbook workbook = new XSSFWorkbook();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try {
            LOGGER.info("generate byte stream for excel (.xlsx) attachment in email");
            populateWorkbook(workbook, headers, data, sheetName);
            workbook.write(baos);
        }catch(Exception e) {
            LOGGER.error("Exception occurred during generation of excel (.xlsx) byte stream: {}", e);
            throw new ExcelException("Excel attachment for email cannot be generated");
        } finally{
            closeQuietly(workbook);
            closeQuietly(baos);
        }
        return baos.toByteArray();
    }

    private static void populateWorkbook(Workbook workbook, String[] headers, List<List<String>> data, String sheetName) {
        LOGGER.info("Building excel (.xlsx) attachment workbook with headers: {}, and no. of records: {}", asList(headers), data.size());
        if (isEmpty(headers) || data.size() < 1 || data.stream().anyMatch( rowData -> (rowData == null || headers.length != rowData.size()))) {
            LOGGER.warn("Invalid headers for excel workbook creation.");
            throw new ExcelException("Excel workbook (.xlsx) cannot be created. invalid parameters !!");
        }
        Sheet sheet = workbook.createSheet(StringUtils.isNotBlank(sheetName) ? sheetName : "sheet1");

        // Create a header row of sheet with style
        Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerFont.setFontHeightInPoints((short) 14);
        Row headerRow = sheet.createRow(0);
        CellStyle headerCellStyle = workbook.createCellStyle();
        headerCellStyle.setFont(headerFont);

        for (int i = 0; i < headers.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers[i]);
            cell.setCellStyle(headerCellStyle);
        }

        // Create Other rows and cells with data
        AtomicInteger rowNum = new AtomicInteger(1);
        for(List<String> rowData : data) {
            Row row = sheet.createRow(rowNum.getAndIncrement());
            for (int i = 0; i < rowData.size(); i++) {
                row.createCell(i).setCellValue(rowData.get(i));
            }
        }

        for (int i = 0; i < headers.length; i++) {
            sheet.autoSizeColumn(i);
        }
    }

    public static int getColHeaderIndex(Sheet sheet, String colName) {
        int colIndex = -1;
        Row row = sheet.getRow(0);
        for (int i = 0; i <= row.getLastCellNum(); i++) {
            Cell c = row.getCell(i);
            if (c == null || c.getCellType() == CellType.BLANK) {
                continue;
            }
            if (c.getCellType() == CellType.STRING) {
                String text = c.getStringCellValue();
                if (colName.equals(text)) {
                    colIndex = i;
                    break;
                }
            }
        }
        if (colIndex == -1) {
            throw new ExcelException("The header column " + colName + " does not exist.");
        }
        return colIndex;
    }

    public static int getValidRowIndex(Sheet sheet) {
        int rowIndex = -1;
        for(int i=0; i<sheet.getPhysicalNumberOfRows(); i++){
            //Check the first row of header
            if(i==0 && validateEmptyRows(sheet, i)) throw new ExcelException(AdminConstants.ERROR_INVALID_EXCEL_HEADER);
            //Check the second row of the first data entry
            if(i==1 && validateEmptyRows(sheet, i)){
                throw new ExcelException(AdminConstants.ERROR_INVALID_EXCEL_DATA);//First data entry was empty or set to blank)
            }
            if(validateEmptyRows(sheet, i)) break;//Ignore remaining null/empty row
            rowIndex = i;
        }
        if (rowIndex == -1) {
            throw new ExcelException(AdminConstants.ERROR_INVALID_EMPTY_EXCEL);
        }
        return rowIndex;
    }

    private static boolean validateEmptyRows(Sheet sheet, int i) {
        if(ExcelUtil.isEmptyRow(sheet.getRow(i))) return true;
        Cell partner = sheet.getRow(i).getCell(0);
        Cell agentCode = sheet.getRow(i).getCell(1);
        if(partner == null || partner.getCellType() == CellType.BLANK ||
                agentCode == null || agentCode.getCellType() == CellType.BLANK){
            return true;
        }
        return false;
    }

    public static void updateCellTypePerColumnHeader(Sheet sheet, int offsetHeaderIndex, int rowIndex, int colIndex, CellType cellType) {
        for (int i = sheet.getFirstRowNum() + offsetHeaderIndex; i <= rowIndex; i++) {
            sheet.getRow(i).getCell(colIndex).setCellType(cellType);
        }
    }

    public static boolean isEmptyRow(Row row){
        return null == row || row.getLastCellNum() <= 0;
    }
}
