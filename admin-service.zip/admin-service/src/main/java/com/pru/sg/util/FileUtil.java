package com.pru.sg.util;

import com.pru.sg.constant.excel.AdminConstants;
import com.pru.sg.exception.DataCorruptedException;
import com.pru.sg.exception.FileException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.Date;

public class FileUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(FileUtil.class);

    public static final String FILE_TIMESTAMP = "yyyyMMdd_HHmmssSSS";

    private static int bufferSize = 1024;

    public static Path verifyAndCreatePath(Path path) throws IOException {
        if (Files.exists(path) && Files.isDirectory(path)) {
            return path;
        } else {
            return Files.createDirectories(path);
        }
    }

    public static String generateFileName(String userId, String origName){
        String timeStamp = new SimpleDateFormat(FILE_TIMESTAMP).format(new Date());
        return userId + AdminConstants.FILENAME_CONCATENATOR + timeStamp + AdminConstants.FILENAME_CONCATENATOR + origName;
    }


    public static byte[] extractContent(MultipartFile file) throws DataCorruptedException {
        try {
            return file.getBytes();
        } catch (Exception e) {
            throw new DataCorruptedException(e);
        }
    }


    public static File writeFile(String fileName, String path, byte[] content) {
        Path temp = null;
        try {
            Path saveFolder = FileUtil.verifyAndCreatePath(Paths.get(path));
            temp = Files.write(saveFolder.resolve(fileName), content);
        } catch (IOException e) {
            LOGGER.error("Could not save the file into the empFolder: ", e);
            throw new FileException(e.getMessage());
        }
        return temp.toFile();
    }

    public static Path moveFile(Path origin, Path destination) {
        try{
            return Files.move(origin, destination, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            LOGGER.error("Could not moved the file FROM: {}, TO: {}", origin, destination);
            throw new FileException(e.getMessage());
        }
    }

    public static File writeInputStreamToFile(InputStream is) throws IOException {
        File f = Files.createTempFile("tmp-", ".xlsx").toFile();
        try(FileOutputStream fos = new FileOutputStream(f)) {
            int read;
            byte[] bytes = new byte[bufferSize];
            while((read = is.read(bytes)) != -1) {
                fos.write(bytes, 0, read);
            }
            return f;
        } finally {
            is.close();
        }
    }

    public static String readFromInputStream(InputStream inputStream)
            throws IOException {
        StringBuilder resultStringBuilder = new StringBuilder();
        try (BufferedReader br
                     = new BufferedReader(new InputStreamReader(inputStream))) {
            String line;
            while ((line = br.readLine()) != null) {
                resultStringBuilder.append(line).append("\n");
            }
        }
        return resultStringBuilder.toString();
    }

}
