package com.pru.sg.util;

import java.util.Arrays;
import java.util.Date;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

public class HttpHeadersUtil {

    private HttpHeadersUtil() {
    }

    public static HttpHeaders getHeaders() {
        HttpHeaders	headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON ));
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setContentLength(1034);
        headers.setDate(new Date().getTime());
        return headers;
    }
}
