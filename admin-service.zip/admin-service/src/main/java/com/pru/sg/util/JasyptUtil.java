package com.pru.sg.util;

import com.pru.sg.config.JasyptConfig;
import org.jasypt.encryption.StringEncryptor;
import org.jasypt.encryption.pbe.PooledPBEStringEncryptor;
import org.jasypt.encryption.pbe.config.SimpleStringPBEConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class JasyptUtil {
    @Autowired
    private JasyptConfig config;


    public String encryptString(String src){
        return config.stringEncryptor().encrypt(src);
    }

    public String decryptString(String encrypted){
        return config.stringEncryptor().decrypt(encrypted);
    }


}
