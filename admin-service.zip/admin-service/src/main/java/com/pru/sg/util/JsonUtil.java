package com.pru.sg.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;

public class JsonUtil {

    public static String generateJsonString(Object object) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();

        return new ObjectMapper().writeValueAsString(object);
    }

    public static <T> T generateObjectFromJsonString(String jsonString, Class<T> returnClass) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();

        return objectMapper.readValue(jsonString,returnClass);
    }
}
