package com.pru.sg.util;
import org.apache.commons.codec.binary.Base64;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.LaxRedirectStrategy;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.client.HttpClient;
import org.apache.http.ssl.TrustStrategy;

import javax.net.ssl.SSLContext;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;


public class KeyStoreUtil {
    public static HttpClient createHttpClient(String certLocation, String password, String protocol) throws IOException, NoSuchAlgorithmException, KeyManagementException, KeyStoreException, CertificateException {
        SSLContext sslContext = SSLContextBuilder.create()
                .loadTrustMaterial(
                        new File(certLocation),
                        password.toCharArray()
                )
                .setProtocol(protocol)
                .build();

        return HttpClientBuilder.create()
                .setSSLContext(sslContext)
                .build();
    }

    public static HttpClient createHttpClient(InputStream is, String password, String protocol) throws IOException, NoSuchAlgorithmException, KeyManagementException, KeyStoreException, CertificateException {

        TrustStrategy acceptingTrustStrategy = (X509Certificate[] chain, String authType) -> true;

        SSLContext sslContext = org.apache.http.ssl.SSLContexts.custom().loadTrustMaterial(null, acceptingTrustStrategy)
                .build();

        SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(sslContext);


        return  HttpClientBuilder.create()
                .setSSLSocketFactory(csf)
                .setRedirectStrategy(new LaxRedirectStrategy())
                .build();
    }
}
