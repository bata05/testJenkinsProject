package com.pru.sg.validator;

import com.pru.sg.constant.excel.AdminConstants;
import com.pru.sg.exception.FileException;
import org.springframework.web.multipart.MultipartFile;

import java.util.Arrays;

public class ExcelValidator {

    public static void validateFile(MultipartFile file){
        if(!AdminConstants.EXCEL_CONTENT_TYPE.equals(file.getContentType())){
            throw new FileException(file.getOriginalFilename() + " has an invalid file type.");
        }
        String extn = file.getOriginalFilename();
        extn = extn.substring(extn.lastIndexOf(".")+1);
        if(!Arrays.asList(AdminConstants.EXCEL_EXTENSIONS).contains(extn.toUpperCase())){
            throw new FileException(file.getOriginalFilename() + " has an invalid file extension.");
        }
        if(file.getSize() == 0){
            throw new FileException(file.getOriginalFilename() + " is empty.");
        }
    }
}
