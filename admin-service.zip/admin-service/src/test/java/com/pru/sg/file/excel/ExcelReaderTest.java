package com.pru.sg.file.excel;

import com.pru.sg.config.ExcelConfig;
import com.pru.sg.constant.excel.ExcelHeader;
import com.pru.sg.constant.excel.ExcelSection;
import com.pru.sg.exception.ExcelException;
import com.pru.sg.service.upload.impl.UploadServiceImplTest;
import org.apache.poi.ss.usermodel.Workbook;
import org.junit.*;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.notNullValue;

@RunWith(MockitoJUnitRunner.class)
public class ExcelReaderTest {

    @Mock
    private Workbook workbook;

    @Rule
    public ExpectedException exception = ExpectedException.none();

    private String fileName;
    private int validRowsNum = 2;
    private Map<String, ExcelConfig[]> excelMap = new HashMap<>();

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        fileName = "AD_POOL_data_2_rows.xlsx";
        Path path = Paths.get("src","test","resources", "temp", fileName);
        workbook = ExcelReader.readExcel(path.toFile());
        excelMap = ExcelReader.getExcelHeaderSections();
    }

    @AfterClass
    public static void cleanup() throws IOException {
        UploadServiceImplTest.processCleanup();
    }


    @Test
    public void readExcel_success() {
        Path path = Paths.get("src","test","resources", "temp", fileName);
        Assert.assertTrue(ExcelReader.readExcel(path.toFile()) instanceof Workbook);

    }

    @Test
    public void readExcel_error_non_excel_file() {
        Path path = Paths.get("src","test","resources", "temp", "file.txt");
        exception.expect(notNullValue());
        exception.expect(ExcelException.class);
        ExcelReader.readExcel(path.toFile());
    }

    @Test
    public void getExcelRowValues() {
        Map<String, List<ExcelConfig[]>> map = ExcelReader.getExcelRowValues(excelMap, workbook.getSheetAt(0), validRowsNum);
        List<ExcelConfig[]> configs = map.get(ExcelSection.AD_AFFILIATION_POOL.getGroupName());

        Assert.assertEquals(configs.get(0).length, validRowsNum);
        Assert.assertEquals(configs.get(0)[0].getExcelIndex(), ExcelHeader.PARTNER.getIndex());
        Assert.assertEquals(configs.get(0)[0].getExcelHeader(), ExcelHeader.PARTNER.getHeaderName());

        Assert.assertEquals(configs.get(0)[1].getExcelIndex(), ExcelHeader.AGENTCODE.getIndex());
        Assert.assertEquals(configs.get(0)[1].getExcelHeader(), ExcelHeader.AGENTCODE.getHeaderName());
    }

    @Test
    public void getExcelHeaderSections() {
        List<Map<String, List<ExcelConfig>>> list = ExcelReader.getExcelHeaderConfigSections();
        Assert.assertTrue(list.size() > 0);
        Map mapConfig = list.get(0);
        List<ExcelConfig> configs = (List)mapConfig.get(ExcelSection.AD_AFFILIATION_POOL.getGroupName());

        Assert.assertEquals(configs.size(), validRowsNum);
        Assert.assertEquals(configs.get(0).getExcelIndex(), ExcelHeader.PARTNER.getIndex());
        Assert.assertEquals(configs.get(0).getExcelHeader(), ExcelHeader.PARTNER.getHeaderName());

        Assert.assertEquals(configs.get(1).getExcelIndex(), ExcelHeader.AGENTCODE.getIndex());
        Assert.assertEquals(configs.get(1).getExcelHeader(), ExcelHeader.AGENTCODE.getHeaderName());
    }
}