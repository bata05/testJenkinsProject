package com.pru.sg.jwt;

import com.pru.sg.security.CustomUserDetails;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;
import java.security.Key;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class JWTKeyGen {
    public static void main(String[] args) {
        CustomUserDetails userDetails = new CustomUserDetails("test123", "user123", "session123");
        String token=generateToken(userDetails);
        System.out.println("token="+token);
    }

    public static String generateToken(CustomUserDetails userDetails) {
        String jwtSecret="1CFMW9unuJ88b5H6KWSPDoVEHiu/e1MIpiV2GCtcwPk=";
        long jwtExpireInMs=14400000;
        final SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;

        ZonedDateTime now = ZonedDateTime.now();
        Date issuedAt = Date.from(now.toInstant());

        byte[] apiKeySecretBytes = DatatypeConverter.parseBase64Binary(jwtSecret);
        Key signingKey = new SecretKeySpec(apiKeySecretBytes, signatureAlgorithm.getJcaName());

        final Map<String, Object> tokenData = new HashMap<>();
        tokenData.put("sessionId", userDetails.getUsername());


        final JwtBuilder jwtBuilder = Jwts.builder()
                .setSubject(userDetails.getUsername())
                .setId(userDetails.getEmpId())
                .setIssuedAt(issuedAt)
                .setClaims(tokenData)
                .signWith(signingKey, signatureAlgorithm);

        if (jwtExpireInMs >= 0) {
            ZonedDateTime expirationDateTime = now.plus(jwtExpireInMs, ChronoUnit.MILLIS);
            Date expirationDate = Date.from(expirationDateTime.toInstant());
            jwtBuilder.setExpiration(expirationDate);
        }

        return jwtBuilder.compact();
    }
}
