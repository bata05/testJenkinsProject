package com.pru.sg.service.upload.impl;

import com.pru.sg.dto.request.ProxyAccessRequest;
import com.pru.sg.entity.oracle.AgentPool;
import com.pru.sg.entity.oracle.AgentPoolHistory;
import com.pru.sg.file.excel.AdAffiliationPool;
import com.pru.sg.repository.oracle.AgentPoolHistoryRepository;
import com.pru.sg.repository.oracle.AgentPoolRepository;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.Matchers.is;
import static org.mockito.Matchers.any;

@RunWith(MockitoJUnitRunner.class)
public class AgentPoolServiceImplTest {

    @Mock
    AgentPoolRepository agentPoolRepository;
    @Mock
    AgentPoolHistoryRepository agentPoolHistoryRepository;

    @InjectMocks
    AgentPoolServiceImpl agentPoolService;

    private List<AgentPool> agentPool = new ArrayList<>();
    private List<AgentPoolHistory> agentHist = new ArrayList<>();
    private List<AdAffiliationPool> uploadedAgents = new ArrayList<>();
    private ProxyAccessRequest proxyAccessRequest = null;

    @Before
    public void setup(){
        MockitoAnnotations.initMocks(this);
        AgentPool agentPool1 = new AgentPool();
        agentPool1.setAgentCode("00001");
        agentPool1.setEntryType("DIA");
        AgentPool agentPool2 = new AgentPool();
        agentPool2.setAgentCode("00100");
        agentPool2.setEntryType("KPL");
        agentPool.add(agentPool1);
        agentPool.add(agentPool2);

        AgentPoolHistory agentHist1 = new AgentPoolHistory();
        agentHist1.setUserId("Admin");
        agentHist.add(agentHist1);

        AdAffiliationPool uploaded = new AdAffiliationPool();
        uploaded.setAgentCode("111111");
        uploaded.setPartner("DIA");
        uploadedAgents.add(uploaded);

        proxyAccessRequest = new ProxyAccessRequest(PacsnetServiceImplTest.TEST_SESSION_ID,
                PacsnetServiceImplTest.TEST_EMP_ID, PacsnetServiceImplTest.TEST_SESSION_ID);
    }
    @Test
    public void fetchAllCurrentAgents() {
        Mockito.when(agentPoolRepository.findAll()).thenReturn(agentPool);
        List<AgentPool> agents = agentPoolService.fetchAllCurrentAgents();
        Assert.assertNotNull(agents);
        Assert.assertThat(agents.size(), is(2));
    }

/*
    @Test
    public void storeAgentsToHistoryPool() {
        Mockito.when(agentPoolHistoryRepository.save(any())).thenReturn(agentHist.get(0));
        AgentPoolHistory agent = agentPoolService.storeAgentsToHistoryPool(proxyAccessRequest, "", 0);
        Assert.assertNotNull(agent);
    }
*/

    @Test
    public void deleteAllCurrentAgents() {
        agentPoolRepository.deleteAll();
        Mockito.verify(agentPoolRepository, Mockito.times(1)).deleteAll();
    }

}