package com.pru.sg.service.upload.impl;

import com.pru.sg.dto.request.ProxyAccessRequest;
import com.pru.sg.entity.oracle.AgentPoolHistory;
import com.pru.sg.file.excel.AdAffiliationPool;
import com.pru.sg.util.FileUtil;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Matchers.anyList;
import static org.mockito.Matchers.anyString;

public class FileStoreServiceImplTest {

    @Mock
    AgentPoolServiceImpl agentPoolService;
    @InjectMocks
    FileStoreServiceImpl fileStoreService;

    //private List<AdAffiliationPool> uploadedAgents = new ArrayList<>();
    private List<List<String>> uploadedAgents = new ArrayList<>();
    private static String fileName = "AD_POOL_data_2_rows.xlsx";
    private static Path uploadedFile = Paths.get("src","test","resources", "temp", fileName);
    private static Path successPath = Paths.get("src","test","resources", "success", fileName);
    private ProxyAccessRequest proxyAccessRequest = null;
    private AgentPoolHistory historyEntry = null;

    @Before
    public void setup(){
        MockitoAnnotations.initMocks(this);
        //AdAffiliationPool uploaded = new AdAffiliationPool();
        List<String> entry = new ArrayList<>();
        entry.add("111111");
        entry.add("DIA");
        uploadedAgents.add(entry);

        proxyAccessRequest = new ProxyAccessRequest(PacsnetServiceImplTest.TEST_SESSION_ID,
                PacsnetServiceImplTest.TEST_EMP_ID, PacsnetServiceImplTest.TEST_SESSION_ID);
        historyEntry = new AgentPoolHistory();
        historyEntry.setId(1000L);
        historyEntry.setStatus(AgentPoolHistory.AgentPoolUploadStatus.INIT);
    }

    @AfterClass
    public static void cleanup() throws IOException {
        //move back the file
        FileUtil.moveFile(successPath, uploadedFile);
        //cleanup
        UploadServiceImplTest.processCleanup();
    }
    @Test
    public void processAgentUpload() throws Exception {
        Mockito.when(agentPoolService.processAgentPoolManipulation(anyList())).thenReturn(true);

        boolean result = agentPoolService.processAgentPoolManipulation(uploadedAgents);
        Assert.assertTrue(result);
        Mockito.verify(agentPoolService, Mockito.times(1)).
                processAgentPoolManipulation(uploadedAgents);

        Path uploadedFile = Paths.get("src","test","resources", "temp", fileName);
        Path successPath = Paths.get("src","test","resources", "success", fileName);
        //fileStoreService.processAgentUpload(proxyAccessRequest, fileName, uploadedFile, successPath, uploadedAgents);

    }
}