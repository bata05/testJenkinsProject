package com.pru.sg.service.upload.impl;

import com.pru.sg.dto.request.ProxyAccessRequest;
import com.pru.sg.entity.db2.ProxyAccess;
import com.pru.sg.entity.db2.ProxyAccessIdentity;
import com.pru.sg.exception.PacsnetAccessException;
import com.pru.sg.repository.db2.ProxyAccessRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Date;
import java.util.Optional;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class PacsnetServiceImplTest {

    public static final String TEST_SESSION_ID = "TEST-SESSION-ID";
    public static final String TEST_EMP_ID = "TEST-EMP-ID";
    public static final String TEST_EMP_NAME = "TEST-EMP-NAME";
    @Mock
    private ProxyAccessRepository proxyAccessRepository;

    @InjectMocks
    private PacsnetServiceImpl pacsnetService;

    @Captor
    private ArgumentCaptor<ProxyAccess> proxyAccessArgumentCaptor;

    @Test
    public void validateSession_NoAccessFoundInDB() {
        when(proxyAccessRepository.findById(any(ProxyAccessIdentity.class))).thenReturn(Optional.ofNullable(null));
        assertFalse(pacsnetService.isValidSession(createTestRequest()));
        verify(proxyAccessRepository, never()).delete(any());
    }

    @Test(expected = PacsnetAccessException.class)
    public void validateSession_inCaseOfDbErrorSystemShouldThrowPacsnetAccessException() {
        when(proxyAccessRepository.findById(any(ProxyAccessIdentity.class))).thenThrow(new RuntimeException());
        pacsnetService.isValidSession(createTestRequest());
        verify(proxyAccessRepository, never()).delete(any());
    }

    @Test
    public void validateSession_clearSessionWhenFoundInDb() {
        when(proxyAccessRepository.findById(any(ProxyAccessIdentity.class))).thenReturn(Optional.of(createProxyAccess()));
        assertTrue(pacsnetService.isValidSession(createTestRequest()));
        verify(proxyAccessRepository, times(1)).delete(proxyAccessArgumentCaptor.capture());

        assert("TEST-SESSION-ID".equals(proxyAccessArgumentCaptor.getValue().getProxyAccessIdentity().getSessionId()));
        assert("TEST-EMP-ID".equals(proxyAccessArgumentCaptor.getValue().getProxyAccessIdentity().getEmployeeId()));
    }

    private ProxyAccessRequest createTestRequest() {
        return new ProxyAccessRequest(TEST_SESSION_ID, TEST_EMP_ID, TEST_EMP_NAME);
    }

    private ProxyAccess createProxyAccess() {
        ProxyAccessIdentity proxyAccessIdentity = new ProxyAccessIdentity();
        proxyAccessIdentity.setSessionId(TEST_SESSION_ID);
        proxyAccessIdentity.setEmployeeId(TEST_EMP_ID);
        return new ProxyAccess(proxyAccessIdentity, new Date());
    }

    @Test
    public void deleteSession() {
        proxyAccessRepository.delete(Matchers.any());
        Mockito.verify(proxyAccessRepository, Mockito.times(1)).delete(Matchers.any());
    }

}