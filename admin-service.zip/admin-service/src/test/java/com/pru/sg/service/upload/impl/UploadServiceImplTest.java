package com.pru.sg.service.upload.impl;

import com.pru.sg.constant.excel.AdminConstants;
import com.pru.sg.dto.request.ProxyAccessRequest;
import com.pru.sg.exception.FileException;
import com.pru.sg.file.excel.AdAffiliationPool;
import org.hamcrest.CoreMatchers;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

@RunWith(MockitoJUnitRunner.class)
public class UploadServiceImplTest {

    private static final Logger LOGGER = LoggerFactory.getLogger(UploadServiceImplTest.class);

    @Mock
    private FileStoreServiceImpl fileStoreService;
    @InjectMocks
    private UploadServiceImpl uploadService;

    private static String fileName;
    private String fileName_invalid_header;
    private String fileName_empty_excel;
    private List<AdAffiliationPool> uploadedAgents = new ArrayList<>();
    private ProxyAccessRequest proxyAccessRequest = null;

    @Rule
    public ExpectedException exception = ExpectedException.none();

    @Before
    public void setup() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        MockitoAnnotations.initMocks(this);

        Path uploadedPath = Paths.get("src","test","resources");
        ReflectionTestUtils.setField(uploadService, "rootConfig", uploadedPath.toAbsolutePath().toString());
        ReflectionTestUtils.setField(uploadService, "tempConfig", "temp");
        ReflectionTestUtils.setField(uploadService, "failedConfig","failed");
        ReflectionTestUtils.setField(uploadService, "successConfig","success");

        Method postConstruct =  UploadServiceImpl.class.getDeclaredMethod("createDirectories",null); // methodName,parameters
        postConstruct.setAccessible(true);
        postConstruct.invoke(uploadService);

        AdAffiliationPool uploaded1 = new AdAffiliationPool();
        uploaded1.setAgentCode("16875");
        uploaded1.setPartner("DIA");
        AdAffiliationPool uploaded2 = new AdAffiliationPool();
        uploaded2.setAgentCode("111111");
        uploaded2.setPartner("DIA");
        uploadedAgents.add(uploaded1);
        uploadedAgents.add(uploaded2);
        fileName = "AD_POOL_data_2_rows.xlsx";
        fileName_invalid_header = "AD_POOL_InvalidHeader.xlsx";
        fileName_empty_excel = "AD_POOL_empty_excel.xlsx";

        proxyAccessRequest = new ProxyAccessRequest(PacsnetServiceImplTest.TEST_SESSION_ID,
                PacsnetServiceImplTest.TEST_EMP_ID, PacsnetServiceImplTest.TEST_SESSION_ID);
    }

    @AfterClass
    public static void cleanup() throws IOException {
        processCleanup();
    }

    public static void processCleanup() throws IOException {
        Path temps = Paths.get("src","test","resources", "temp");
        Path success = Paths.get("src","test","resources", "success");
        Path failed = Paths.get("src","test","resources", "failed");
        deleteFile(temps);
        deleteFile(success);
        deleteFile(failed);
    }


    private static void deleteFile(Path path) throws IOException{
        Stream<Path> list = Files.list(path);
        list.forEach(p -> {
            if(p.getFileName().toString().startsWith("TEST-EMP-ID")){
                try {
                    Files.delete(p);
                } catch (IOException e) {
                    LOGGER.error("Error occurred while deleting file",
                            path);
                }
            }

        });
    }

    @Test
    public void processUploadingOfFile_success() throws Exception {
        Path uploadedFile = Paths.get("src","test","resources", "temp", fileName);
        MockMultipartFile file = new MockMultipartFile("file", fileName, AdminConstants.EXCEL_CONTENT_TYPE, Files.readAllBytes(uploadedFile));
        uploadService.processUploadingOfFile(file, proxyAccessRequest);
        //Mockito.verify(fileStoreService, Mockito.times(1))
          //      .processAgentUpload(Mockito.any(), Mockito.anyString(), Mockito.anyObject(), Mockito.anyObject(), Mockito.anyList());
    }

    @Test
    public void processUploadingOfFile_invalid_excel_header_value() throws Exception {
        Path uploadedFile = Paths.get("src","test","resources", "temp", fileName_invalid_header);
        MockMultipartFile file = new MockMultipartFile("file", fileName, AdminConstants.EXCEL_CONTENT_TYPE, Files.readAllBytes(uploadedFile));
        exception.expect(CoreMatchers.notNullValue());
        exception.expect(FileException.class);
        exception.expectMessage(CoreMatchers.is(AdminConstants.ERROR_INVALID_EXCEL_HEADER));
        uploadService.processUploadingOfFile(file, proxyAccessRequest);
    }
}