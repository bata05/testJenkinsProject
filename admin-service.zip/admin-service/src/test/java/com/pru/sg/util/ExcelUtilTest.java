package com.pru.sg.util;

import com.pru.sg.config.ExcelConfig;
import com.pru.sg.constant.excel.AdminConstants;
import com.pru.sg.exception.ExcelException;
import com.pru.sg.file.excel.ExcelReader;
import com.pru.sg.service.upload.impl.UploadServiceImplTest;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.hamcrest.CoreMatchers;
import org.junit.*;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ExcelUtilTest {

    @Mock
    private Workbook workbook;
    private Workbook workbook_invalid_header;
    private Workbook workbook_empty_excel;
    @Mock
    private Sheet sheet;
    @Mock
    private Row row;

    @Rule
    public ExpectedException exception = ExpectedException.none();

    private String fileName;
    private String fileName_invalid_header;
    private String fileName_empty_excel;
    private String VALID_PARTNER_HEADER = "Partner";
    private String INVALID_PARTNER_HEADER = "Partner_@(s)";
    private String VALID_AGENT_CODE_HEADER = "Agent_Code";
    private String INVALID_AGENT_CODE_HEADER = "Agent_Code_@(s)";

    @Before
    public void init() throws IOException, InvalidFormatException {
        MockitoAnnotations.initMocks(this);
        fileName = "AD_POOL_data_2_rows.xlsx";
        fileName_invalid_header = "AD_POOL_InvalidHeader.xlsx";
        fileName_empty_excel = "AD_POOL_empty_excel.xlsx";

        Path path = Paths.get("src","test","resources", "temp", fileName);
        Path path_invalid_header = Paths.get("src","test","resources", "temp", fileName_invalid_header);
        Path path_empty_excel = Paths.get("src","test","resources", "temp", fileName_empty_excel);

        workbook = ExcelReader.readExcel(path.toFile());
        workbook_invalid_header = ExcelReader.readExcel(path_invalid_header.toFile());
        workbook_empty_excel = ExcelReader.readExcel(path_empty_excel.toFile());
    }

    @AfterClass
    public static void cleanup() throws IOException {
        UploadServiceImplTest.processCleanup();
    }

    @Test
    public void areAllHeadersValid_success() {
        Map<String, ExcelConfig[]> map = buildConfig(VALID_PARTNER_HEADER);
        boolean areHeadersValid = ExcelUtil.areAllHeadersValid(map, workbook.getSheetAt(0));
        Assert.assertNotNull(workbook);
        Assert.assertTrue(areHeadersValid);
    }

    @Test
    public void areAllHeadersValid_failed() {
        Map<String, ExcelConfig[]> configMaps = buildConfig(INVALID_PARTNER_HEADER);
        exception.expect(CoreMatchers.notNullValue());
        exception.expect(ExcelException.class);
        exception.expectMessage(CoreMatchers.is("One of the expected column header has a wrong value."));
        ExcelUtil.areAllHeadersValid(configMaps, workbook.getSheetAt(AdminConstants.FIRST_SHEET));
    }

    private Map<String, ExcelConfig[]> buildConfig(String header){
        Map<String, ExcelConfig[]> configMaps = new HashMap<>();
        ExcelConfig config1 = new ExcelConfig();
        config1.setExcelHeader(header);
        config1.setExcelIndex(0);

        ExcelConfig config2 = new ExcelConfig();
        config2.setExcelHeader(VALID_AGENT_CODE_HEADER);
        config2.setExcelIndex(1);

        ExcelConfig[] arr = new ExcelConfig[2];
        arr[0] = config1;
        arr[1] = config2;
        configMaps.put("AdAffiliationPool", arr);
        return  configMaps;
    }

    @Test
    public void getColHeaderIndex_Partner() {
        Map<String, ExcelConfig[]> map = buildConfig(VALID_PARTNER_HEADER);
        int agentCodeIndex = ExcelUtil.getColHeaderIndex(workbook.getSheetAt(AdminConstants.FIRST_SHEET), VALID_PARTNER_HEADER);
        Assert.assertEquals(map.get("AdAffiliationPool")[0].getExcelIndex(), agentCodeIndex);
        Assert.assertNotEquals(-1, agentCodeIndex);
    }

    @Test
    public void getColHeaderIndex_Agent_Code() {
        Map<String, ExcelConfig[]> map = buildConfig(VALID_AGENT_CODE_HEADER);
        int agentCodeIndex = ExcelUtil.getColHeaderIndex(workbook.getSheetAt(AdminConstants.FIRST_SHEET), VALID_AGENT_CODE_HEADER);
        Assert.assertEquals(map.get("AdAffiliationPool")[1].getExcelIndex(), agentCodeIndex);
        Assert.assertNotEquals(-1, agentCodeIndex);
    }

    @Test
    public void getColHeaderIndex_Invalid_Agent_code_Header_Value() {
        exception.expect(CoreMatchers. notNullValue());
        exception.expect(ExcelException.class);
        exception.expectMessage(CoreMatchers.is("The header column " + INVALID_AGENT_CODE_HEADER + " does not exist."));
        ExcelUtil.getColHeaderIndex(workbook.getSheetAt(AdminConstants.FIRST_SHEET), INVALID_AGENT_CODE_HEADER);
    }

    @Test
    public void getColHeaderIndex_Invalid_Partner_code_Header_Value() {
        exception.expect(CoreMatchers.notNullValue());
        exception.expect(ExcelException.class);
        exception.expectMessage(CoreMatchers.is("The header column " + INVALID_PARTNER_HEADER + " does not exist."));
        ExcelUtil.getColHeaderIndex(workbook.getSheetAt(AdminConstants.FIRST_SHEET), INVALID_PARTNER_HEADER);
    }

    @Test
    public void getValidRowIndex_Invalid_Header_Row_Empty() {
        exception.expect(CoreMatchers.notNullValue());
        exception.expect(ExcelException.class);
        exception.expectMessage(CoreMatchers.is(AdminConstants.ERROR_INVALID_EXCEL_HEADER));
        ExcelUtil.getValidRowIndex(workbook_invalid_header.getSheetAt(AdminConstants.FIRST_SHEET));
    }

    @Test
    public void getValidRowIndex_Empty_Excel() {
        exception.expect(CoreMatchers.notNullValue());
        exception.expect(ExcelException.class);
        exception.expectMessage(CoreMatchers.is(AdminConstants.ERROR_INVALID_EMPTY_EXCEL));
        ExcelUtil.getValidRowIndex(workbook_empty_excel.getSheetAt(AdminConstants.FIRST_SHEET));
    }

//    @Test
//    public void isEmptyRow() {
//        when(sheet.createRow(anyInt())).thenReturn(row);
//        Assert.assertNotNull(ExcelUtil.isEmptyRow(row));
//    }

}