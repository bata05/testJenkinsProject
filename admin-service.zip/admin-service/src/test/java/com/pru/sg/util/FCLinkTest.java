package com.pru.sg.util;

import com.pru.sg.dto.request.FCLinkRequest;
import com.pru.sg.dto.response.GenericResponse;
import com.pru.sg.entity.json.LinkGen;
import com.pru.sg.service.upload.LinkgenService;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.IOException;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;


@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(MockitoJUnitRunner.class)
public class FCLinkTest {
    @Mock
    private LinkgenService linkgenService;

    @Test
    public void test() throws IOException {
        String agentCode="00071";
        String prodCode="PAS";
        LinkGen linkGen = new LinkGen();
        linkGen.setAgentCode("12345");

        String encryptedURL=getEncryptedUrl();

        Mockito.lenient().when(linkgenService.getEncryptedLinkUrl(linkGen, prodCode, agentCode)).thenReturn(encryptedURL);

        Assert.assertEquals("https://buy-sit.prudential.com.sg/d2c/pas_entry?token=eyJhQ29kZSI6IjAwMDcxIn0",encryptedURL);

    }

    @Test
    public void testValidateFCLink() throws IOException,NoSuchAlgorithmException, KeyManagementException, KeyStoreException, CertificateException {
        String agentCode="00071";
        String prodCode="PAS";

        GenericResponse response = createResponse(false);
        Mockito.lenient().when(linkgenService.validateFCLink(agentCode, prodCode)).thenReturn(response);

        Assert.assertEquals("valid", response.getMessage());
        Assert.assertEquals("success", response.getStatus());
    }

    @Test
    public void testValidateFCLinkEmail() throws IOException,NoSuchAlgorithmException, KeyManagementException, KeyStoreException, CertificateException {
        String agentCode="00071";
        String prodCode="PA";

        GenericResponse response = createResponse(true);
        Mockito.lenient().when(linkgenService.validateFCLink(agentCode, prodCode)).thenReturn(response);

        Assert.assertEquals("Email sent", response.getMessage());
        Assert.assertEquals("success", response.getStatus().toLowerCase());
    }

    private String getEncryptedUrl(){
        return "https://buy-sit.prudential.com.sg/d2c/pas_entry?token=eyJhQ29kZSI6IjAwMDcxIn0";
    }

    private GenericResponse createResponse(boolean email){
        if(!email)
          return new GenericResponse("success","valid");
        else return new GenericResponse("success","Email sent");
    }
}
