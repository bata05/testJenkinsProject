package com.pru.sg.util;

import com.pru.sg.service.upload.impl.UploadServiceImplTest;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;

@RunWith(MockitoJUnitRunner.class)
public class FileUtilTest {

    private Path pathToDelete;
    private Path origin;
    private Path destination;
    private String FILE_TIMESTAMP = "yyyyMMdd_HHmmssSSS";

    @Rule
    public ExpectedException exception = ExpectedException.none();

    @AfterClass
    public static void cleanup() throws IOException {
        UploadServiceImplTest.processCleanup();
    }

    @Test
    public void getPath_Existing_Directory() throws IOException {
        Path directoryPath = Paths.get("src","test","resources", "temp");
        Assert.assertTrue(Files.isDirectory(directoryPath));
        Path path = FileUtil.verifyAndCreatePath(directoryPath);
        Assert.assertNotNull(path);
    }

    @Test
    public void getPath_Create_Non_Existing_Directory() throws IOException {
        String timeStamp = new SimpleDateFormat(FILE_TIMESTAMP).format(new Date());
        Path directoryPath = Paths.get("src","test","resources", "temp", timeStamp);

        pathToDelete = FileUtil.verifyAndCreatePath(directoryPath);

        Assert.assertTrue(Files.exists(pathToDelete));
        Assert.assertTrue(Files.isDirectory(pathToDelete));
        Files.delete(pathToDelete);
    }

    @Test
    public void generateFileName() {
        String fileName = FileUtil.generateFileName("System", "filename.xlsx");
        Assert.assertTrue(fileName.contains("System"));
        Assert.assertTrue(fileName.contains("filename.xlsx"));
    }

    @Test
    public void moveFile_temp_to_success() throws URISyntaxException, IOException {
        origin = Paths.get("src","test","resources", "temp", "AD_POOL_data_2_rows.xlsx");
        destination = Paths.get("src","test","resources", "success", "AD_POOL_data_2_rows.xlsx");
        Assert.assertTrue(!Files.exists(destination));
        Path path = FileUtil.moveFile(origin, destination);
        Assert.assertTrue(!Files.exists(origin));
        Assert.assertTrue(Files.exists(destination));

        //move back the file
        FileUtil.moveFile(destination, origin);
    }
}