package com.pru.sg.util;

import com.pru.sg.DpAdminApplication;
import com.pru.sg.config.JasyptConfig;
import com.pru.sg.config.PacsnetConfig;
import org.jasypt.encryption.StringEncryptor;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = DpAdminApplication.class)

@TestPropertySource(locations = "classpath:application.properties")
public class JasyptTest {

    @Autowired
    private JasyptConfig config;
    @Autowired
    private JasyptUtil util;

    @Test
    public void test(){
        String text="Hello1234";
        //String encrypted = config.stringEncryptor().encrypt(text);
        String encrypted= util.encryptString(text);
        System.out.println("encrypted="+encrypted);

        String decrypted= util.decryptString(encrypted);

        Assert.assertEquals(text,decrypted);

       // System.out.println("decrypted="+decrypted);
    }


}
