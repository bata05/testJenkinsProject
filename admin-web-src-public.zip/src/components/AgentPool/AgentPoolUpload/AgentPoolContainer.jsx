import React, { Component } from "react";
import "./AgentPoolContainer.css";
import Upload from "./upload/Upload";

export default class AgentPoolContainer extends Component {
    constructor(props){
        super(props);
        this.state = {
            percentage: 0
        }
    }
    handleUploadPercertageVal = (percentage) => {
        this.setState({ percentage: percentage});
        this.props.dashUploadPercentage(percentage);
    };
    render () {
        return (
            <div className="App">
                <div className="Card">
                    <Upload {...this.props} uploadPercentage={this.handleUploadPercertageVal} />
                </div>
            </div>
        );
    }
}