import React, { Component } from "react";
import "./Dropzone.css";
import upload_icon from "assets/image/upload_icon.svg";

export default class Dropzone extends Component {
    constructor(props) {
        super(props);
        this.state = {
            highlight: false
        };
        this.fileInputRef = React.createRef();
    }

    openFileDialog = () => {
        if (this.props.disabled) return;
        this.fileInputRef.current.click();
    };

    addFile = event => {
        if (this.props.disabled) return;
        const files = event.target.files;
        if (this.props.onFilesAdded && files.length > 0) {
            let maxSize = 10000000; //10MB
            if (files[0].size > maxSize) {
                this.props.dropzoneProps({
                message: "Max allowable size is 10MB only.",
                visible: true,
                alertType: "danger"
                });
            } else {
                this.props.onFilesAdded(files[0]);
            }
            //Set target to null to allow uploading with the same filename
            event.target.value = null;
        }
    };

    onDragOver = event => {
        event.preventDefault();
        if (this.props.disabled) return;
        this.setState({ highlight: true });
    };

    onDragLeave = () => {
        this.setState({ highlight: false });
    };

    onDrop = event => {
        this.setState({ highlight: false});
        event.preventDefault();
        if (this.props.disabled) return;
        const files = event.dataTransfer.files;
        if (files.length > 1) {
            this.props.dropzoneProps({
                message: "Please upload one file at a time.",
                visible: true,
                alertType: "danger"
            });
            return;
        }
        this.props.onFilesAdded(files[0]);
    };

    render() {
        return (
            <div className={`Dropzone ${this.state.highlight ? "Highlight" : ""}`}
                onDragOver={this.onDragOver}
                onDragLeave={this.onDragLeave}
                onDrop={this.onDrop}
                onClick={this.openFileDialog}
                style={{ cursor: this.props.disabled ? "default" : "pointer" }}
                >
            <input
                ref={this.fileInputRef}
                className="FileInput"
                type="file"
                accept=".xls,.xlsx"
                onChange={this.addFile}
                />
            <img alt="upload" className="Icon" src={upload_icon} />
            <span>Click or Drop files to upload</span>
            </div>
        );
    }

}