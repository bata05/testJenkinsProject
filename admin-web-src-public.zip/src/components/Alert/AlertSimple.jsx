import React, { Component } from "react";
import { Alert } from "reactstrap";
import "./AlertSimple.css";

export default class AlertSimple extends Component {
    constructor(props) {
        super(props);
        this.state = {
        localProps: this.props.alertProps
        };
    }

    onDismiss = () => {
        let prop = { ...this.state.localProps};
        prop.visible = false;
        this.setState({ localProps: prop });
        this.props.onAlertDismiss();
    };

  render() {
    const { localProps } = this.state;
    return (
      <Alert
        color={localProps.alertType}
        isOpen={localProps.visible}
        toggle={this.onDismiss}
      >
          <h5 className="alert-heading">{localProps.alertType === "danger" ? "Error!" : "Success"}</h5>
          <span className="messageSize">{localProps.message}</span>
      </Alert>
    );
  }
}
