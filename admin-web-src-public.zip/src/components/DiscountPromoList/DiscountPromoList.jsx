import React, { Component, useEffect } from "react";
import { Card, 
         CardHeader, 
         CardFooter,
         CardTitle,
         CardSubtitle,
         CardText,
         Form,
         FormGroup,
         Input,
         Pagination,
         PaginationItem,
         PaginationLink,
         Label,
         Col,
         Row,
         CardBody, 
         Table, 
         Button, 
         Modal,
         ModalHeader,
         ModalBody,
         ModalFooter} from "reactstrap";
import Checkbox from "@mui/material/Checkbox"
import axios from "axios";
import GenericError from "../Error/GenericError";
import EllipsisText from "react-ellipsis-text";


export default class DiscountPromoList extends Component {
    constructor(props){
        super(props);
        this.state = {
            promoDiscountList: [],
            uniqueProductCode: [],
            uniqueChannelCode: [],
            promotionIdToDelete: [],
            createdEntry: {
                promoId: 0,
                productCode: "",
                isProdCodeNew: false,
                channelCode: "",
                discountPercentage: 0,
                isChanlCodeNew: false,
                fromValidDate: "",
                toValidDate: "",
                promoMsg: "",
            },
            editedEntry: {
                promoId: 0,
                productCode: "",
                isProdCodeNew: false,
                channelCode: "",
                discountPercentage: 0,
                isChanlCodeNew: false,
                fromValidDateObj: new Date(),
                fromValidDate: "",
                toValidDate: "",
                toValidDateObj: new Date(),
                promoMsg: "",
            },
            isEditMode: false,
            isInAcMode: false,
            modalPopupMsg: "",
            modalValidationMsg: "",
            modalDeleteMsg: "",
            isCreatingNew: false,
            error: null,
            showTxnResultModal: false,
            showCreatePromoModal: false,
            showValidationModal: false,
            showDeleteMsgModal: false,
            disableDeleteButton: true,
            disableSetInActButton: true,
            filterSelected: 'Active',
            pageSize: 20,
            pageCount: 1,
            disableCopyButton: true,
            isNewProdCode: false,
            isNewChanCode: false
        };
        //this.state={showCreatePromoModal: false}
    }

    componentDidMount(){
        const configMapping = window.ConfigMapping;
        const finalUrl = configMapping.REACT_APP_ADMIN_SERVICE_URL + process.env.REACT_APP_FETCH_ACTIVE_DISCOUNT_PROMOTION_LIST;
        axios.get(finalUrl)
            .then(response => {
                this.constructTable(response.data.productPromotions)
            }).catch((error) => {
            this.setState({
                error: error
            });
        });
    }

    constructTable = (tableEntries) => {
        const  prodPromoJson = tableEntries;
        /*Product Code Dropdown*/
        const uniqueProdCode = ["Select One"];
        const filteredProdPromo = prodPromoJson.map(promoDiscount => promoDiscount.productCode)
                                                .filter((value, index, self) => self.indexOf(value) === index)
        filteredProdPromo.map((code, index) => {
            uniqueProdCode.push(code);
        });
        uniqueProdCode.push("Create New Product Code");
        /*Channel Code Dropdown*/
        const uniqueChnnlCode = ["Select One"];
        const filteredChannelCode = prodPromoJson.map(promoDiscount => promoDiscount.channelCode)
                                                .filter((value, index, self) => self.indexOf(value) === index)
        filteredChannelCode.map((code, index) => {
            uniqueChnnlCode.push(code);
        });
        uniqueChnnlCode.push("Create New Channel Code");
        this.setState({
            uniqueChannelCode: uniqueChnnlCode
        });
        this.setState({
            uniqueProductCode: uniqueProdCode
        });
        this.setState({
            promoDiscountList: prodPromoJson
        });
    }

    hasFailedValidation = (newData) => {
        var errorMsg = "The following required inputs are missing: ";
        var errorCount = 0;
        if(newData.productCode == "" || newData.productCode == "Select One")
        {   
            errorMsg+="Product Code";
            errorCount++;
        } 
        if(newData.channelCode == "" || newData.channelCode == "Select One") {
            if(errorCount > 0)errorMsg+=", "
            errorMsg+="Channel Code";
            errorCount++;
        } 
        if(newData.discountPercentage == 0) {
            if(errorCount > 0)errorMsg+=", "
            errorMsg+="Discount Percentage ";
            errorCount++;
        } 
        if(newData.fromValidDate == "") {
            if(errorCount > 0)errorMsg+=", "
            errorMsg+="From Valid Date ";
            errorCount++;
        } 
        if(newData.toValidDate == "") {
            if(errorCount > 0)errorMsg+=", "
            errorMsg+="To Valid Date ";
            errorCount++;
        } 
        if(newData.promoMsg == "") {
            if(errorCount > 0)errorMsg+=", "
            errorMsg+="Promotional Message ";
            errorCount++;
        }

        if(errorMsg == "The following required inputs are missing: ")
        {
            return false;
        } else{
            this.modalValidationMsg = errorMsg;
            this.setState({showValidationModal: true})
            return true;
        }        
    }

    handleFilter = (event) => {
        const configMapping = window.ConfigMapping;
        var filterUrl = process.env.REACT_APP_FETCH_ACTIVE_DISCOUNT_PROMOTION_LIST;
        if(event.target.value === 'All')
        {
            filterUrl = process.env.REACT_APP_FETCH_ALL_DISCOUNT_PROMOTION_LIST;
        } else if(event.target.value === 'InActive') {
            filterUrl = process.env.REACT_APP_FETCH_INACTIVE_DISCOUNT_PROMOTION_LIST;
        }
        const finalUrl = configMapping.REACT_APP_ADMIN_SERVICE_URL + filterUrl;
        axios.get(finalUrl)
            .then(response => {
                this.constructTable(response.data.productPromotions)
            }).catch((error) => {
            this.setState({
                error: error
            });
        });
    }

    handleMainModalCancelButton = (e) => {
        if(this.state.isEditMode){
            this.setState({ isEditMode: false })
        }
        this.setState({showCreatePromoModal: false})
    }

    handleCreateNewDiscount = (e) => {
        this.setState({ isCreatingNew: true })
        e.preventDefault(); // Stop form submit
        let dataToProcess = this.state.createdEntry;
        if(this.state.isEditMode){
            dataToProcess = this.state.editedEntry;
        }

        if(this.hasFailedValidation(dataToProcess) == false)
        {
            this.performCreatePromo(dataToProcess).then((response)=>{
                //
                this.modalPopupMsg = response.data.promotionDiscountMessage;
                this.setState({showTxnResultModal: true})
            }).catch((error) => {
                if(error.response){
                    this.modalPopupMsg = error.response.data.message;
                } else {
                    this.modalPopupMsg = "Unexpected server error was encountered";
                }
                this.setState({showTxnResultModal: true})
            });
        }
        
    }

    performCreatePromo = (newData) => {
        if(newData.productCode != '')
        {
            const configMapping = window.ConfigMapping;
            let finalUrl = configMapping.REACT_APP_ADMIN_SERVICE_URL + process.env.REACT_APP_CREATENEW_DISCOUNT_PROMOTION;

            const formData = new FormData();  
            const { session } = this.props;
            if(this.state.isEditMode){
                formData.append('promoId',newData.promoId);
                finalUrl = configMapping.REACT_APP_ADMIN_SERVICE_URL + process.env.REACT_APP_UPDATE_DISCOUNT_PROMOTION;
            }
            formData.append('productCode',newData.productCode);
            formData.append('channelCode',newData.channelCode);
            formData.append('discPercentage',newData.discountPercentage);
            formData.append('fromValidDate',newData.fromValidDate);
            formData.append('toValidDate',newData.toValidDate);
            formData.append('promoMsg',newData.promoMsg);
            formData.append('empid','2321');
            formData.append('empName','TestUser');
            //formData.append('empid',session.empid);
            //formData.append('empName',session.empName);
            return axios.post(finalUrl, formData);
        }
    }

    handleSetInactivePromoDiscount = (e) => {
        this.setState({isInAcMode:true})
        e.preventDefault(); 
        let newData = this.state.promotionIdToDelete
        if(newData.length > 0)
        {
            const configMapping = window.ConfigMapping;
            let finalUrl = configMapping.REACT_APP_ADMIN_SERVICE_URL + process.env.REACT_APP_SETINACTIVE_PROMO_DISCOUNT_PROMOTION; 
            const formData = new FormData();  
            const { session } = this.props;
            formData.append('promotionIds',newData);
            formData.append('empid','2321');
            formData.append('empName','TestUser');
            //formData.append('empid',session.empid);
            //formData.append('empName',session.empName);
            axios.post(finalUrl, formData).then((response)=>{
                //
                this.modalDeleteMsg = response.data.promotionDiscountMessage;
                this.setState({showDeleteMsgModal: true})
            }).catch((error) => {
                if(error.response){
                    this.modalDeleteMsg = error.response.data.message;
                } else {
                    this.modalDeleteMsg = "Unexpected server error was encountered";
                }
                this.setState({showDeleteMsgModal: true})
            });
        }
    }

    handleDeletePromoDiscount = (e) => {
        this.setState({ isCreatingNew: true })
        e.preventDefault(); // Stop form submit

        this.performDeletePromo(this.state.promotionIdToDelete).then((response)=>{
            //
            this.modalDeleteMsg = response.data.promotionDiscountMessage;
            this.setState({showDeleteMsgModal: true})
        }).catch((error) => {
            if(error.response){
                this.modalDeleteMsg = error.response.data.message;
            } else {
                this.modalDeleteMsg = "Unexpected server error was encountered";
            }
            this.setState({showDeleteMsgModal: true})
        });
    }

    performDeletePromo = (newData) => {
        if(newData.length > 0)
        {
            const configMapping = window.ConfigMapping;
            let finalUrl = configMapping.REACT_APP_ADMIN_SERVICE_URL + process.env.REACT_APP_DELETE_PROMO_DISCOUNT_PROMOTION;
            if(this.state.isInAcMode)
            {
                finalUrl = configMapping.REACT_APP_ADMIN_SERVICE_URL + process.env.REACT_APP_SETINACTIVE_PROMO_DISCOUNT_PROMOTION; 
            }
            const formData = new FormData();  
            const { session } = this.props;
            formData.append('promotionIds',newData);
            formData.append('empid','2321');
            formData.append('empName','TestUser');
            //formData.append('empid',session.empid);
            //formData.append('empName',session.empName);
            return axios.post(finalUrl, formData);
        }
    }

    render(){
        
        const headers = process.env.REACT_APP_PROMO_DISCOUNT_HEADERS.split(",");
        const { promotionIdToDelete, promoDiscountList, uniqueProductCode, 
                createdEntry, editedEntry, uniqueChannelCode, error} = this.state;
        
        const openModal = (event) => {
            this.setState({showCreatePromoModal: true})
            this.setState({
                createdEntry: {
                    productCode: "",
                    isProdCodeNew: false,
                    channelCode: "",
                    discountPercentage: 0,
                    isChanlCodeNew: false,
                    fromValidDate: "",
                    toValidDate: "",
                    promoMsg: "",
                }
            })
        }; 

        const closeDeleteModal = (event) => {
            this.setState({showDeleteMsgModal: true})
            window.location.reload();
        };
        
        const populateNewPromoEntry = e => {
            let value = e.target.value;
            if('prodCodeSelect' === e.target.id || 'prodCodeSelectNew' === e.target.id)
            {
                if(value === 'Create New Product Code')
                {
                    createdEntry.isProdCodeNew = true;
                    this.setState({isNewProdCode: true});
                } else {
                    createdEntry.isChanlCodeNew = false;
                }
                if(this.state.isEditMode){                   
                    this.setState(prevState => ({
                        editedEntry: {                   
                            ...prevState.editedEntry,    
                            productCode: value       
                        }
                    }))
                } else {
                    createdEntry.productCode = e.target.value;
                }
                
            } else if('chanCodeSelect' === e.target.id || 'chanCodeSelectNew' === e.target.id) {
                if(value === 'Create New Channel Code')
                {
                    createdEntry.isChanlCodeNew = true;
                    this.setState({isNewChanCode: true});
                } else {
                    createdEntry.isChanlCodeNew = false;
                }
                if(this.state.isEditMode){  
                    this.setState(prevState => ({
                        editedEntry: {                   
                            ...prevState.editedEntry,    
                            channelCode: value       
                        }
                    }))
                 } else {
                     createdEntry.channelCode = e.target.value;
                 }
            } else if('discPercentage' === e.target.id) {
                if(this.state.isEditMode){  
                    this.setState(prevState => ({
                        editedEntry: {                   
                            ...prevState.editedEntry,    
                            discountPercentage: value       
                        }
                    }))
                } else {
                     createdEntry.discountPercentage = e.target.value;
                }
            } else if('fromValidDate' === e.target.id) {
                if(this.state.isEditMode){  
                    let dateObj = new Date(value);
                    this.setState(prevState => ({
                        editedEntry: {                   
                            ...prevState.editedEntry,    
                            fromValidDateObj: dateObj,
                            fromValidDate: value       
                        }
                    }))
                } else {
                    createdEntry.fromValidDate = e.target.value;
                }
            }  else if('toValidDate' === e.target.id) {
                if(this.state.isEditMode){  
                    let dateObj = new Date(value);
                    this.setState(prevState => ({
                        editedEntry: {                   
                            ...prevState.editedEntry,    
                            toValidDateObj: dateObj,
                            toValidDate: value       
                        }
                    })) 
                } else {
                    createdEntry.toValidDate = e.target.value;
                }
            } else if('promoMsg' === e.target.id) {
                if(this.state.isEditMode){  
                    this.setState(prevState => ({
                        editedEntry: {                   
                            ...prevState.editedEntry,    
                            promoMsg: value       
                        }
                    })) 
                } else {
                    createdEntry.promoMsg = e.target.value;
                }
            }
        }

        const closeAllModal = e => {
            this.setState({showTxnResultModal: false})
            this.setState({showCreatePromoModal: false})
            window.location.reload();
        }

        const handleSelect = (event) => {
            const position = event.target.value;
            console.log('event.target.value'+event.target.value)
            const updatedCheckedState = promoDiscountList.map((item, index) =>
                index === parseInt(position) ? item : !item
            );
            const promotionId = updatedCheckedState.reduce(
                (promotionId, dataEntry, index) => {
                    if (dataEntry != false) {
                        return dataEntry.promotionId;
                    }
                    return promotionId;
                },
                0
            );
            console.log('updatedCheckedState='+updatedCheckedState);
            
            if (event.target.checked) {              
              this.setState({disableDeleteButton: false});
              this.setState({disableCopyButton: false});
              this.setState({disableSetInActButton: false}); 
              promotionIdToDelete.push(promotionId);
            } else {
              const index = promotionIdToDelete.indexOf(promotionId);
              promotionIdToDelete.splice(index, 1) ;
            }
            if(promotionIdToDelete.length > 1)
            {
              this.setState({disableCopyButton: true}); 
            } else {
              this.setState({disableCopyButton: false});                
            }
        };

        const uniquePromoCodeDropDown = uniqueProductCode.map((code, key) => {
            console.log('uniqueChannelCode:'+key)
            return <option value={code} key={key}>{code}</option>;
        });

        const uniqueChannelCodeDropDown = uniqueChannelCode.map((code, key) => {
            console.log('uniqueChannelCode:'+key)
            return <option value={code} key={key}>{code}</option>;
        });

        const tableBody = promoDiscountList.map((promoDiscount,key) => {

            return <tr key={key}>
                 <td>
                    <Checkbox
                     value={key}
                     onChange={handleSelect}
                     inputProps={{ 'aria-label': 'select all desserts' }}
                    />
                </td>
                <td> 
                    <a href="#" onClick={(e) => {editEntry(e, key)}}>
                      {promoDiscount.promotionId}
                    </a>
                </td>
                <td>{promoDiscount.productCode}</td>
                <td>{promoDiscount.discountPercentage}</td>
                <td>{promoDiscount.channelCode}</td>
                <td>{promoDiscount.promoMsg === null ? promoDiscount.promoMsg :<EllipsisText text={promoDiscount.promoMsg} length={60} tooltip={promoDiscount.promoMsg} />}</td>
                <td>{promoDiscount.formattedFromValidDate}</td>
                <td>{promoDiscount.formattedToValidDate}</td>
                <td>{promoDiscount.createdBy}</td>
            </tr>;
        });

        const editEntry = (event, position) => {
            event.preventDefault();
            const updatedCheckedState = promoDiscountList.map((item, index) =>
                index === parseInt(position) ? item : !item
            );
            const selectedEntry = updatedCheckedState.reduce(
                (promotionId, dataEntry, index) => {
                    if (dataEntry != false) {
                        return dataEntry;
                    }
                    return promotionId;
                },
                0
            );
    
            this.setState({isEditMode: true})
            console.log(this.state.isEditMode);
            this.setState({showCreatePromoModal: true})
            var fromDate = new Date(selectedEntry.fromValidityDate);
            var toDate = new Date(selectedEntry.toValidityDate);
            this.setState({
                editedEntry: {
                    promoId: selectedEntry.promotionId,
                    productCode: selectedEntry.productCode,
                    channelCode: selectedEntry.channelCode,
                    fromValidDateObj: fromDate,
                    toValidDateObj: toDate,
                    discountPercentage: selectedEntry.discountPercentage,
                    fromValidDate: selectedEntry.fromValidityDate,
                    toValidDate: selectedEntry.toValidityDate,
                    promoMsg: selectedEntry.promoMsg,
                }
            })
        };

        const tablePagination = (dataEntries) => {
            if(promoDiscountList.length>0)
            {
               let paginationTag = 
               (
                <Pagination>
                     <PaginationItem disabled>
                        <PaginationLink
                        first
                        href="#"
                        />
                    </PaginationItem>
                    <PaginationItem disabled>
                        <PaginationLink
                        href="#"
                        previous
                        />
                    </PaginationItem>
                    <PaginationItem>
                        <PaginationLink href="#">
                            2
                        </PaginationLink>
                    </PaginationItem>
                    <PaginationItem>
                        <PaginationLink href="#">
                            3
                        </PaginationLink>
                    </PaginationItem>
                    <PaginationItem>
                        <PaginationLink next href="#" />
                    </PaginationItem>
                    <PaginationItem>
                        <PaginationLink last href="#" />
                    </PaginationItem>
                </Pagination>);
                return paginationTag;
            }
        }

        return(
            <Card>
                <CardHeader>
                    <h5 className="title">Promotional Discount</h5>
                    <div>
                        <Row>
                            <Col xs="2" style={{paddingTop:"15px"}}>
                                <Input
                                    id="exampleSelect"
                                    name="select"
                                    type="select"
                                    bsSize="sm"
                                    onChange={this.handleFilter}
                                >
                                    <option value="active">
                                    Active
                                    </option>
                                    <option value="InActive">
                                    In-Active
                                    </option>
                                    <option  value="All">
                                    All
                                    </option>
                                </Input>
                            </Col>
                            <Modal isOpen={this.state.showDeleteMsgModal} >
                                <ModalBody>
                                    {this.modalDeleteMsg}
                                </ModalBody>
                                <ModalFooter>
                                    <Button
                                        color="danger"
                                        onClick={closeDeleteModal}
                                    >
                                        Close
                                    </Button>
                                </ModalFooter>
                            </Modal>
                            <Col xs="6">
                                <Button
                                    color="danger"
                                    onClick={openModal}
                                >
                                    Create New
                                </Button>
                                <Button
                                    color="danger"
                                    onClick={this.handleSetInactivePromoDiscount}
                                    disabled={this.state.disableSetInActButton}
                                >
                                    Set InActive
                                </Button>
                                <Button
                                    color="danger"
                                    disabled={this.state.disableDeleteButton}
                                    onClick={this.handleDeletePromoDiscount}
                                >
                                    Delete
                                </Button>
                                {/* <Button
                                    color="danger"
                                    disabled={this.state.disableCopyButton}
                                >
                                    Copy
                                </Button>                         */}
                                <Modal isOpen={this.state.showCreatePromoModal} size="xl" toggle={() => this.setState({showCreatePromoModal: false})}>
                                    {this.state.isEditMode && (
                                    <ModalHeader toggle={() => this.setState({showCreatePromoModal: false})}>Update Promotional Discount</ModalHeader>
                                    )}
                                    {!this.state.isEditMode && (
                                    <ModalHeader toggle={() => this.setState({showCreatePromoModal: false})}>Create New Promotional Discount</ModalHeader>
                                    )}
                                    <ModalBody> 
                                            <Form>
                                                <FormGroup row>
                                                    <Label
                                                    for="productCodeSelect"
                                                    sm={2}
                                                    >
                                                    Product Code
                                                    </Label>
                                                    <Col sm={3}>
                                                    {this.state.isEditMode && (
                                                        <Input
                                                            id="prodCodeSelect"
                                                            name="prodCodeSelect"
                                                            type="select"
                                                            onChange={populateNewPromoEntry}
                                                            value={this.state.editedEntry.productCode}
                                                        >
                                                            {uniquePromoCodeDropDown}
                                                        </Input>
                                                    )}
                                                    {!this.state.isEditMode && (
                                                        <Input
                                                            id="prodCodeSelect"
                                                            name="prodCodeSelect"
                                                            type="select"
                                                            onChange={populateNewPromoEntry}
                                                        >
                                                            {uniquePromoCodeDropDown}
                                                        </Input>
                                                    )}
                                                    </Col>
                                                    <Col sm={2}>
                                                    {this.state.isNewProdCode && (
                                                        <Input
                                                          bsSize="sm"
                                                          id="prodCodeSelectNew"
                                                            name="prodCodeSelectNew"
                                                          onChange={populateNewPromoEntry}
                                                        />
                                                    )}
                                                    </Col>
                                                </FormGroup>
                                                <FormGroup row>
                                                    <Label
                                                    for="channelCodeSelect"
                                                    sm={2}
                                                    >
                                                    Channel Code
                                                    </Label>
                                                    <Col sm={3}>
                                                    {this.state.isEditMode && (
                                                        <Input
                                                            id="chanCodeSelect"
                                                            name="chanCodeSelect"
                                                            type="select" 
                                                            onChange={populateNewPromoEntry}
                                                            value={this.state.editedEntry.channelCode}                                           
                                                        >
                                                            {uniqueChannelCodeDropDown}
                                                        </Input>
                                                    )}
                                                    {!this.state.isEditMode && (
                                                        <Input
                                                            id="chanCodeSelect"
                                                            name="chanCodeSelect"
                                                            type="select" 
                                                            onChange={populateNewPromoEntry}
                                                        >
                                                            {uniqueChannelCodeDropDown}
                                                        </Input>
                                                    )}
                                                    </Col>
                                                    <Col sm={2}>
                                                    {this.state.isNewChanCode && (
                                                        <Input
                                                          id="chanCodeSelectNew"
                                                          name="chanCodeSelectNew"
                                                          bsSize="sm"
                                                          onChange={populateNewPromoEntry}
                                                        />
                                                    )}
                                                    </Col>
                                                </FormGroup>
                                                <FormGroup row>
                                                    <Label
                                                    for="promoDiscPercentage"
                                                    sm={2}
                                                    >
                                                    Discount Percentage
                                                    </Label>
                                                    <Col sm={2}>
                                                    {this.state.isEditMode && (
                                                        <Input
                                                            id="discPercentage"
                                                            name="discPercentage"
                                                            bsSize="sm"
                                                            type="number"
                                                            value={this.state.editedEntry.discountPercentage}
                                                            onChange={populateNewPromoEntry}  
                                                        />
                                                    )}
                                                    {!this.state.isEditMode && (
                                                        <Input
                                                            id="discPercentage"
                                                            name="discPercentage"
                                                            bsSize="sm"
                                                            type="number"
                                                            onChange={populateNewPromoEntry}  
                                                        />
                                                    )}
                                                    </Col>
                                                </FormGroup>
                                                
                                                <FormGroup row>
                                                    <Label
                                                    for="fromDate"
                                                    sm={2}
                                                    >
                                                    From Validity Date
                                                    </Label>
                                                    <Col sm={3}>
                                                    {this.state.isEditMode && (
                                                        <Input
                                                            bsSize="sm"
                                                            type="date"
                                                            id="fromValidDate"
                                                            name="fromValidDate"
                                                            value={this.state.editedEntry.fromValidDateObj.toLocaleDateString('en-CA')} 
                                                            onChange={populateNewPromoEntry}
                                                        />
                                                    )}
                                                    {!this.state.isEditMode && (
                                                        <Input
                                                            bsSize="sm"
                                                            type="date"
                                                            id="fromValidDate"
                                                            name="fromValidDate"
                                                            onChange={populateNewPromoEntry}
                                                        />
                                                    )}
                                                    </Col>
                                                    <Label
                                                    for="fromDate"
                                                    sm={2}
                                                    >
                                                    To Validity Date
                                                    </Label>
                                                    <Col sm={3}>
                                                    {this.state.isEditMode && (
                                                        <Input
                                                            bsSize="sm"
                                                            type="date"
                                                            id="toValidDate"
                                                            name="toValidDate"
                                                            value={this.state.editedEntry.toValidDateObj.toLocaleDateString('en-CA')}
                                                            onChange={populateNewPromoEntry}
                                                        />
                                                    )}
                                                    {!this.state.isEditMode && (
                                                        <Input
                                                            bsSize="sm"
                                                            type="date"
                                                            id="toValidDate"
                                                            name="toValidDate"
                                                            onChange={populateNewPromoEntry}
                                                        />
                                                    )}
                                                    </Col>
                                                </FormGroup>
                                                <FormGroup row>
                                                    <Label
                                                    for="promoMessage"
                                                    sm={2}
                                                    >
                                                    Promotional Discount Message
                                                    </Label>
                                                    <Col sm={8}>
                                                    {this.state.isEditMode && (
                                                        <Input
                                                            id="promoMsg"
                                                            name="promoMsg"
                                                            type="textarea"
                                                            value={this.state.editedEntry.promoMsg}
                                                            onChange={populateNewPromoEntry}
                                                        />
                                                    )}
                                                    {!this.state.isEditMode && (
                                                        <Input
                                                            id="promoMsg"
                                                            name="promoMsg"
                                                            type="textarea"
                                                            onChange={populateNewPromoEntry}
                                                        />
                                                    )}
                                                    </Col>
                                                </FormGroup>
                                            </Form>
                                        {/* <Button
                                            color="danger"
                                            onClick={() => this.setState({showTxnResultModal: true})}
                                        >
                                        Open inner
                                        </Button> */}
                                        <Modal isOpen={this.state.showTxnResultModal} >
                                            <ModalBody>
                                                {this.modalPopupMsg}
                                            </ModalBody>
                                            <ModalFooter>
                                                <Button
                                                    color="danger"
                                                    onClick={closeAllModal}
                                                >
                                                    Close
                                                </Button>
                                            </ModalFooter>
                                        </Modal>
                                        <Modal isOpen={this.state.showValidationModal} >
                                            <ModalBody>
                                                {this.modalValidationMsg}
                                            </ModalBody>
                                            <ModalFooter>
                                                <Button
                                                    color="danger"
                                                    onClick={() => this.setState({showValidationModal: false})}
                                                >
                                                    Close
                                                </Button>
                                            </ModalFooter>
                                        </Modal>
                                    </ModalBody>
                                    <ModalFooter>
                                    {this.state.isEditMode && (
                                       <Button 
                                       color="danger"
                                       onClick={this.handleCreateNewDiscount}
                                       >
                                           Update
                                       </Button>
                                    )}
                                    {!this.state.isEditMode && (
                                       <Button 
                                       color="danger"
                                       onClick={this.handleCreateNewDiscount}
                                       >
                                           Save
                                       </Button>
                                    )}
                                        <Button 
                                        color="danger"
                                        onClick={this.handleMainModalCancelButton}
                                        >
                                            Cancel
                                        </Button>
                                    </ModalFooter>
                                </Modal>
                            </Col>
                        </Row>
                    </div>
                </CardHeader>
                <CardBody>
                    {error === null ?
                        <Table hover>
                            <thead className="text-primary">
                            <tr>
                                <th>
                                   &nbsp;
                                </th>
                                {headers.map((header, key) => {
                                    return <th key={key}>{header}</th>;
                                })}
                            </tr>
                            </thead>
                            <tbody>
                            {tableBody}
                            </tbody>
                        </Table> 
                        : <GenericError/>
                    }
                </CardBody>
                <CardFooter className="text-muted">
                    {/* {tablePagination(this.state.promoDiscountList)} */}
                </CardFooter>
            </Card>
        );
    }
}