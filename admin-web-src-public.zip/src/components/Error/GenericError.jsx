import React, { Component } from "react";
import "./PageNotFound.css";

export default class GenericError extends Component {

    render() {
        return (
            <div className="main">
                    <h2 className="title">Sorry, an error was encountered.</h2>
                <div>Please contact Digital Platform support.</div>
            </div>
        );
    }
}