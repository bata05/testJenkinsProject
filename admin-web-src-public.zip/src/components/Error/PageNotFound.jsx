import React, { Component } from "react";
import pagenotfound from "assets/image/404_img3.jpg";

import "./PageNotFound.css";

export default class PageNotFound extends Component {

    render() {
        return (
            <div className="main">
                <div className="header">
                    <h3 className="title">Sorry, we couldn't find that page</h3>
                </div>
                <div>
                    <img className="img" src={pagenotfound} alt="Page not found" />
                </div>
            </div>
        );
    }
}