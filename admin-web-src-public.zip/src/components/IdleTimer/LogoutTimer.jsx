import React, { Component } from "react";
import IdleTimer from "react-idle-timer";

export default class LogoutTimer extends Component {
    constructor(props){
        super(props);
        this.idleTimer = null;
        this.state = {
            totalIdleTimeInMinute: 30,//30/2=15 minutes
            tempIdle: 0,
            timeoutEveryHalfMinute: 1,//every 30 seconds
            redirect: false
        }
    }

    onIdle = (e) => {
        const { tempIdle, timeoutEveryHalfMinute } = this.state;
        this.setState({
            tempIdle: tempIdle + timeoutEveryHalfMinute
        });
        if(this.props.percentage > 0 && this.props.percentage < 100){
            this.setState({
                tempIdle: 0
            });
        } else if(this.state.tempIdle >= this.state.totalIdleTimeInMinute){
            window.location.href = "/timeout";
        }
        this.idleTimer.reset();
    };
    onAction = (e) => {
        this.setState({
            tempIdle: 0
        });
    };
    onActive = (e) => {};

    render() {
        const { timeoutEveryHalfMinute } = this.state;
        return (
                <IdleTimer
                    ref={ref => { this.idleTimer = ref }}
                    element={document}
                    onActive={this.onActive}
                    onIdle={this.onIdle}
                    onAction={this.onAction}
                    debounce={250}
                    timeout={1000 * 30 * timeoutEveryHalfMinute} />)
    }
}