import React, { Component } from "react";
import "./LinkGeneration.css";
import UploadLinkgen from "./uploadLinkgen/UploadLinkgen";

export default class LinkGeneration extends Component {
    constructor(props){
        super(props);
        this.state = {
            percentage: 0
        }
    }
    handleUploadPercertageVal = (percentage) => {
        this.setState({ percentage: percentage});
        this.props.dashUploadPercentage(percentage);
    };
    render () {
        return (
            <div className="App">
                <div className="Card">
                    <UploadLinkgen {...this.props} uploadPercentage={this.handleUploadPercertageVal} />
                </div>
            </div>
        );
    }
}