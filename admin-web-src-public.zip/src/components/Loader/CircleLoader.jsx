import React, { Component } from "react";
import Loader from "react-loader-spinner";
import "./CircleLoader.css";

export default class CircleLoader extends Component {
    render() {
        return(
            <div>
                <div className="header">
                    <h3 className="title">Redirecting to DP Web Admin module</h3>
                </div>
                <div className="loader">
                    <Loader
                        type="Circles"
                        color="#00BFFF"
                        height="200"
                        width="200"
                    />
                </div>
            </div>
        );
    }
}