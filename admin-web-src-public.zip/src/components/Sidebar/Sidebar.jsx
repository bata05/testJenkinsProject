import React from "react";
import { NavLink } from "react-router-dom";
import { Nav } from "reactstrap";
import PerfectScrollbar from "perfect-scrollbar";

import logo from "assets/image/pru_logo_sidebar.png";

var ps;
var role;

export default class Sidebar extends React.Component {
  constructor(props) {
    super(props);
    this.activeRoute.bind(this);
  }
  // verifies if routeName is the one active (in browser input)
  activeRoute(routeName) {
    return this.props.location.pathname.indexOf(routeName) > -1 ? "active" : "";
  }
  componentDidMount() {
    if (navigator.platform.indexOf("Win") > -1) {
      ps = new PerfectScrollbar(this.refs.sidebar, {
        suppressScrollX: true,
        suppressScrollY: false
      });
    }
  }
  componentWillUnmount() {
    if (navigator.platform.indexOf("Win") > -1) {
      ps.destroy();
    }
  }
  render() {
    //retrieve role from sessionStorage
    //role = sessionStorage.getItem("role");
    //role = "DP_ADMIN_CUSTOMER"
    role  = "DP_ADMIN_AD";
    return (
      <div className="sidebar" data-color="red">
        <div className="logo" style={{ backgroundColor: "white" }}>
          <div className="logo-img">
            <img src={logo} alt="" />
          </div>
        </div>
        <div className="sidebar-wrapper" ref="sidebar">
          <Nav>
            {this.props.routes.filter(function(route) {
               if (role === "DP_ADMIN_AD") {
                  if (route.name === "Agent Pool Upload" || route.name === "Agent Pool Upload Summary" || route.name === "Download Eligible FCs" || route.name === "Discount Promo List")
                      return true;
               }else if (role === "DP_ADMIN_CUSTOMER") {
                  if (route.name === "Lead Generation" || route.name === "FC Link Generation" || route.name === "SIO Link Generation" )
                      return true;
               }
               return false;
             }).map((prop, key) => {
              if (prop.redirect) return null;

              return (
                <li
                  className={
                    this.activeRoute(prop.path) +
                    (prop.pro ? " active active-pro" : "")
                  }
                  key={key}
                >
                  <NavLink
                    to={prop.path}
                    className="nav-link"
                    activeClassName="active"
                  >
                    <i className={"now-ui-icons " + prop.icon} />
                    <p>{prop.name}</p>
                  </NavLink>
                </li>
              );
            })}
          </Nav>
        </div>
      </div>
    );
  }
}