import React from "react";
import ReactDOM from "react-dom";
import PacsnetValidator from "./PacsnetValidator";

ReactDOM.render(<PacsnetValidator />, document.getElementById('root'));
