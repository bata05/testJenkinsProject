import React, { Component } from "react";
import PerfectScrollbar from "perfect-scrollbar";
import { Route, Switch } from "react-router";

import Header from "components/Header/Header";
import Sidebar from "components/Sidebar/Sidebar";
import Footer from "components/Footer/Footer";
import routes from "routes/routes";

var ps;

export default class Dashboard extends Component {
    constructor(props){
        super(props);
        this.state = {
            percentage: 0
        }
    }
  componentDidMount() {
    if (navigator.platform.indexOf("Win") > -1) {
      ps = new PerfectScrollbar(this.refs.mainPanel);
      document.body.classList.toggle("perfect-scrollbar-on");
    }
  }
  componentWillUnmount() {
    if (navigator.platform.indexOf("Win") > -1) {
      ps.destroy();
      document.body.classList.toggle("perfect-scrollbar-on");
    }
  }
  componentDidUpdate(e) {
    if (e.history.action === "PUSH") {
      this.refs.mainPanel.scrollTop = 0;
      document.scrollingElement.scrollTop = 0;
    }
  }
    handleUploadPercertageVal = (percentage) => {
        this.setState({ percentage: percentage});
        this.props.appUploadPercentage(percentage);
    };
  render() {
    return (
      <div className="wrapper">
        <Sidebar {...this.props} routes={routes} />
        <div className="main-panel" ref="mainPanel">
          <Header {...this.props} />
          <Switch>
            {routes.map((prop, key) => {
              return (
                  <Route path={prop.path} key={key} render={(props) => <prop.component {...this.props} dashUploadPercentage={this.handleUploadPercertageVal} /> }  />
              );
            })}
          </Switch>
          <Footer fluid />
        </div>
      </div>
    );
  }
}