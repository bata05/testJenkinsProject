import React, { Component } from "react";
import PanelHeader from "components/PanelHeader/PanelHeader";
import AgentPoolSummary from "../../../components/AgentPool/AgentPoolSummary/AgentPoolSummary";


export default class AgentPoolUploadSummaryModule extends Component {
  render() {
    return (
      <div>
          <PanelHeader size="sm" />
        <div className="content">
              <AgentPoolSummary/>
        </div>
      </div>
    );
  }
}