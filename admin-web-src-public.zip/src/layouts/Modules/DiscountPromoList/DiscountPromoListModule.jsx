import React, { Component } from "react";
import { Card, CardHeader, CardBody } from "reactstrap";
import PanelHeader from "components/PanelHeader/PanelHeader";
import DiscountPromoList from "../../../components/DiscountPromoList/DiscountPromoList";


export default class DiscountPromoListModule extends Component {
    render() {
        return (
          <div>
          <PanelHeader size="sm" />
          <div className="content">
                <DiscountPromoList/>
          </div>
        </div>
        );
      }
}