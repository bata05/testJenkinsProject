import React, { Component } from "react";
import { Card, CardHeader, CardBody } from "reactstrap";
import PanelHeader from "components/PanelHeader/PanelHeader";
import LinkGeneration from "../../../components/LinkGen/LinkGeneration";


export default class LinkGenerationModule extends Component {
    render() {
        return (
          <div>
            <PanelHeader size="sm" />
            <div className="content">
              <Card>
                <CardHeader>
                  <h5 className="title">Link Generation</h5>
                </CardHeader>
                <CardBody>
                  <LinkGeneration {...this.props} fileType="FCLink" />
                </CardBody>
              </Card>
            </div>
          </div>
        );
      }
}