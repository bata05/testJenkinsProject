import AgentPoolUploadModule from "layouts/Modules/AgentUpload/AgentPoolUploadModule";
import AgentPoolUploadSummaryModule from "layouts/Modules/AgentUploadSummary/AgentPoolUploadSummaryModule";
import DownloadEligibleFCsModule from "layouts/Modules/DownloadEligibleFCs/DownloadEligibleFCsModule";
import LeadGenerationModule from "layouts/Modules/LeadGeneration/LeadGenerationModule";
import LinkGenerationModule from "layouts/Modules/LinkGeneration/LinkGenerationModule";
import SIOLinkGenerationModule from "layouts/Modules/SIOLinkGeneration/SIOLinkGenerationModule";
import DiscountPromoListModule from "layouts/Modules/DiscountPromoList/DiscountPromoListModule";

var routes = [
    {
        path: "/loginAD",
        name: "Agent Pool Upload",
        icon: "arrows-1_cloud-upload-94",
        component: AgentPoolUploadModule
    },
    {
        path: "/agentPoolSummary",
        name: "Agent Pool Upload Summary",
        icon: "design_bullet-list-67",
        component: AgentPoolUploadSummaryModule
    },
    {
        path: "/downloadEligibleFCs",
        name: "Download Eligible FCs",
        icon: "arrows-1_cloud-download-93",
        component: DownloadEligibleFCsModule
    },
    {
        path: "/loginCus",
        name: "Lead Generation",
        icon: "arrows-1_cloud-upload-94",
        component: LeadGenerationModule
    },
    {
        path: "/linkgen",
        name: "FC Link Generation",
        icon: "arrows-1_cloud-upload-94",
        component: LinkGenerationModule
    },
    {
        path: "/sioLinkgen",
        name: "SIO Link Generation",
        icon: "arrows-1_cloud-upload-94",
        component: SIOLinkGenerationModule
    },
    {
        path: "/promoList",
        name: "Discount Promo List",
        icon: "design_bullet-list-67",
        component: DiscountPromoListModule
    }
    
];
export default routes;