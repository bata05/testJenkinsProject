import React from 'react';
import { UserContext } from './UserContext';

const withUserContext = (WrappedComponent, ...props) => {
    class WithUserContext extends React.Component {
        render() {
            return (
                <div>
                    <UserContext.Consumer>
                        {authToken  => 
                            <WrappedComponent authToken={authToken} {...this.props}  />
                        }
                    </UserContext.Consumer>
                </div>
            );
        }
    }

    return WithUserContext;
};

export default withUserContext
