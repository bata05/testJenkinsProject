#!/bin/sh

# copy file to its proper location
# .tmp/config_mapping.js is cmap mounted
cp .tmp/config_mapping.js public/config/config_mapping.js
cp .tmp/config_mapping.js build/config/config_mapping.js

# run
serve -s build -l 3000