const ADMIN_SERVICE_URL = {
    REACT_APP_ADMIN_SERVICE_URL: "http://localhost:8080/admin-service"
};
window.ConfigMapping = ADMIN_SERVICE_URL;