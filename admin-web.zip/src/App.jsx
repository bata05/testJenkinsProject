import React, { Component } from "react";
import { createBrowserHistory } from "history";
import { Router, Route, Switch } from "react-router-dom";

import Dashboard from "./layouts/Dashboard/Dashboard";
import PageNotFound from "./components/Error/PageNotFound";
import LogoutTimer from "./components/IdleTimer/LogoutTimer";
import SessionTimeout from "./components/Error/SessionTimeout";
import Unauthorized from "./components/Error/Unauthorized";
import axios from "axios";

const hist = createBrowserHistory();
const UNAUTH_CODE = 401;
class App extends Component {
    constructor(props){
        super(props);
        
        this.state = {
            percentage: 0,
            secToken : null

        }
    }
    componentDidMount() {
        this.setInterceptors(this.props.authToken);
        window.onpopstate = () => {
        // @listens back and forward browser buttons
            window.location.href = "/timeout";
        }
    }
    handleUploadPercertageVal = (percentage) => {
        this.setState({ percentage: percentage});
    };

    setInterceptors(authToken) {
        authToken = authToken || '';
        axios.interceptors.request.use(function (config) {
            config.headers["Authorization"] = `Bearer ${authToken}`;

            return config;
        });

        axios.interceptors.response.use(function (response) {
            // Any status code that lie within the range of 2xx cause this function to trigger
            // Do something with response data
            return response;
        }, function (error) {
            const { status } = error.response;
            if (status === UNAUTH_CODE) {
                window.location.href = "/unauthorized";
            }
            return Promise.reject(error);
        });
    }
    render(){
        const { session, authToken } = this.props;     
        return (
            <div>
                <Router history={hist}>
                    <Switch>
                        <Route path={"/timeout"} component={SessionTimeout} />
                        <Route path={"/unauthorized"} component={Unauthorized} />
                        {session.message === "success" && authToken ?
                            <Route path="/" render={(props) => <Dashboard {...props} session={session} appUploadPercentage={this.handleUploadPercertageVal} />} />
                            : session.message === "success" && !authToken ?
                                <Route path={"*"} component={Unauthorized} />
                                : <Route path={"*"} component={PageNotFound} />
                        }
                    </Switch>
                </Router>
                {session.message === "success" ?
                    <div>
                        <LogoutTimer history={hist} {...this.props} {...this.state}/>
                    </div>
                    : null
                }
            </div>
        );
    }
}

export default App;