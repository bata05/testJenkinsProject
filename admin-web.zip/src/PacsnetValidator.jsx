import React, { Component } from "react";
import axios from "axios";
import queryString from "query-string";

import "bootstrap/dist/css/bootstrap.css";
import "./assets/scss/admin-ui.css";
import CircleLoader from "./components/Loader/CircleLoader";
import App from "./App";
import { UserContext } from './utils/UserContext';
import withUserContext from './utils/withUserContext'
export default class PacsnetValidator extends Component {

    constructor(props) {
        super(props);
        this.state = {
            session: {
                empid: null,
                empName: null,
                role: null,
                sid: null,
                message : null,
                dashboard: null 
            },
            authToken: null
        }
    }

    componentDidMount() {
        let { session } = this.state;
        setTimeout(() => {
            if(this.isValidParams()){
                // this.setEmpId(empid);
                this.validSessionId(session.sid);
            } else {
                let session = this.state.session;
                session.message = "error";
                this.setStateVal(session);
            }
        }, 1000);
    }

    isValidParams(){
        const urlParams = window.location.search;
        const action = window.location.pathname;
        if(urlParams === "" || (action !== "/loginAD" && action !== "/loginCus")){
            return false;
        }
        const locSearch = queryString.parse(urlParams);
        const role = locSearch.param1;
        sessionStorage.setItem("role", role);
        const empid = locSearch.param2;
        const empName = locSearch.param4;
        const sid = locSearch.param3;
        if(!empid && !sid && !empName){
            return false;
        }
        let session = this.state.session;
        session.empid = empid;
        session.sid = sid;
        session.empName = empName;
        this.setStateVal(session);
        return true;
    }

    setStateVal(session){
        this.setState({
            session: session
        });
    }

    validSessionId = () => {
        let session = this.state.session;

        this.verifySessionId().then((response)=>{
            session.message = response.data.message;
            let authToken = response.data.jwtAuthToken;
            this.setState({
                session: session,
                authToken: authToken
            });
        }).catch((error) => {
            session.message = error.data;
            this.setState({
                session: session,
                authToken: null
            });
        });
    }

    verifySessionId() {
        const configMapping = window.ConfigMapping;
        const finalUrl = configMapping.REACT_APP_ADMIN_SERVICE_URL + process.env.REACT_APP_VERIFY_SESSION;
        const { session } = this.state;
        const request = {
            "sessionid": session.sid,
            "empid": session.empid,
            "empName": session.empName
        };
        const config = {
            headers: {
                'content-type': 'application/json'
            }
        };
        return  axios.post(finalUrl, request, config)
    };

    render() {
        const { session } = this.state;
        const NewComp = withUserContext(App, this.props);
        return  (
            <UserContext.Provider value={this.state.authToken}>
                <div>
                    {session.message !== null ? 
                        <NewComp session={session} /> 
                        : <CircleLoader />}
                    </div>
            </UserContext.Provider>
        );
    }
}