import React, { Component } from "react";
import { Card, CardHeader, CardBody, Table } from "reactstrap";
import axios from "axios";
import GenericError from "../../Error/GenericError";

export default class AgentPoolSummary extends Component {
    constructor(props){
        super(props);
        this.state = {
            agentPoolHistories: [],
            error: null
        };
    }

    componentDidMount(){
        const configMapping = window.ConfigMapping;
        const finalUrl = configMapping.REACT_APP_ADMIN_SERVICE_URL + process.env.REACT_APP_FETCH_AGENT_POOL_HISTORIES;
        axios.get(finalUrl)
            .then(response => {
                this.setState({
                    agentPoolHistories: response.data.agentPoolHistories
                });
            }).catch((error) => {
            this.setState({
                error: error
            });
        });
    }

    render(){
        const headers = process.env.REACT_APP_AGENT_POOL_HEADERS.split(",");
        const { agentPoolHistories, error } = this.state;
        const tableBody = agentPoolHistories.map((agentPoolHist,key) => {
            return <tr key={key}>
                <td>{agentPoolHist.userId}</td>
                <td>{agentPoolHist.userName}</td>
                <td>{agentPoolHist.fileName}</td>
                <td>{agentPoolHist.agentTotalCount}</td>
                <td>{agentPoolHist.formattedCreatedDate}</td>
            </tr>;
        });
        return(
            <Card>
                <CardHeader>
                    <h5 className="title">Agent Pool Upload Summary</h5>
                    <div>*Up to last 20 transactions</div>
                </CardHeader>
                <CardBody>
                    {error === null ?
                        <Table responsive>
                            <thead className="text-primary">
                            <tr>
                                {headers.map((header, key) => {
                                    return <th key={key}>{header}</th>;
                                })}
                            </tr>
                            </thead>
                            <tbody>
                            {tableBody}
                            </tbody>
                        </Table>
                        : <GenericError/>
                    }
                </CardBody>
            </Card>
        );
    }
}