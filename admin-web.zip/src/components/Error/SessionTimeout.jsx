import React, { Component } from "react";
import "./PageNotFound.css";

export default class SessionTimeout extends Component {

    render() {
        return (
            <div className="main">
                    <h2 className="title">Your session has timeout.</h2>
                <div>Kindly login via PACSNET to resume your session.</div>
            </div>
        );
    }
}