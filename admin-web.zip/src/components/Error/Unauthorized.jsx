import React, { Component } from "react";
import "./PageNotFound.css";

export default class Unauthorized extends Component {

    render() {
        return (
            <div className="main">
                    <h2 className="title">Unauthorized access</h2>
                <div>Kindly login with your credentials via PACSNET.</div>
            </div>
        );
    }
}