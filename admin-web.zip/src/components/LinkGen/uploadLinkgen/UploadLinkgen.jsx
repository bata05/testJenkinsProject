import React, { Component } from "react";
import { Progress } from "reactstrap";
import axios from "axios";
import { downloadDynamicFile } from "../../../utils/utils";

import Dropzone from "../../AgentPool/AgentPoolUpload/dropzone/Dropzone";
import AlertSimple from "../../Alert/AlertSimple";
import "./UploadLinkgen.css";


export default class UploadLinkgen extends Component {
    constructor(props) {
        super(props);
        this._isMounted = false;
        this.state = {
            file: null,
            percentage: 0,
            isUploading: false,
            alertProps: {},
            progressType: "animated"
        };
    }

    componentDidMount(){
        this._isMounted = true;
    }

    componentWillUnmount(){
        this._isMounted = false;
    }

    handleFileUpload = (e) => {
      this.setState({ isUploading: true});
        e.preventDefault(); // Stop form submit
        this.fileUpload(this.state.file).then((response)=>{
            if(this.props.fileType ==="FCLink") {
                downloadDynamicFile(new Blob([response.data]), 'FC_referral_link_result.xlsx');
            } else {
                downloadDynamicFile(new Blob([response.data]), 'SIO_link_result.xlsx');
            }
            this.setState({
                percentage: 100,
                alertProps: {
                    message: response.data.message,
                    visible: true,
                    alertType: "success",
                    progressType: "striped"
                }
            });
            this.props.uploadPercentage(100);
        }).catch((error) => {
            let dropzoneProp = {...this.state.alertProps};
            dropzoneProp.visible = true;
            dropzoneProp.alertType = "danger";
            dropzoneProp.progressType = "striped";
            if(error.response){
                dropzoneProp.message = error.response.data.message;
            } else {
                dropzoneProp.message = "Unexpected server error was encountered";
            }
            this.setState({
                percentage: 0,
                alertProps: dropzoneProp,
                file: null
            });
        });
    };

    fileUpload = (file) => {
        if(file != null){
            const configMapping = window.ConfigMapping;
            const uploadType = this.props.fileType;

            const finalUrl = configMapping.REACT_APP_ADMIN_SERVICE_URL + (uploadType === "FCLink" ? process.env.REACT_APP_LINK_GENERATION : process.env.REACT_APP_LINK_SIO_GENERATION) ;

            const formData = new FormData();
            const { session } = this.props;

            formData.append('empid',session.empid);
            formData.append('empName',session.empName);
            formData.append('file',file,file.name);

            this.setPercentage();
            return  axios({method: 'post',url:finalUrl,data:formData,responseType:'blob'});
        }
    };

    handleFileUploadEmail = (e) => {
          this.setState({ isUploading: true});
            e.preventDefault(); // Stop form submit
            this.fileUploadEmail(this.state.file).then((response)=>{
                downloadDynamicFile(new Blob([response.data]), 'FC_referral_link_email_result.xlsx');
                this.setState({
                    percentage: 100,
                    alertProps: {
                        message: response.data.message,
                        visible: true,
                        alertType: "success",
                        progressType: "striped"
                    }
                });
                this.props.uploadPercentage(100);
            }).catch((error) => {
                let dropzoneProp = {...this.state.alertProps};
                dropzoneProp.visible = true;
                dropzoneProp.alertType = "danger";
                dropzoneProp.progressType = "striped";
                if(error.response){
                    dropzoneProp.message = error.response.data.message;
                } else {
                    dropzoneProp.message = "Unexpected server error was encountered";
                }
                this.setState({
                    percentage: 0,
                    alertProps: dropzoneProp,
                    file: null
                });
            });
        };

        fileUploadEmail = (file) => {
            if(file != null){
                const configMapping = window.ConfigMapping;
                const uploadType = this.props.fileType;

                const finalUrl = configMapping.REACT_APP_ADMIN_SERVICE_URL + process.env.REACT_APP_LINK_GENERATION_EMAIL;

                const formData = new FormData();
                const { session } = this.props;

                formData.append('empid',session.empid);
                formData.append('empName',session.empName);
                formData.append('file',file,file.name);

                this.setPercentage();
                return  axios({method: 'post',url:finalUrl,data:formData,responseType:'blob'});
            }
        };

    setPercentage = () => {
        let timer = 1; // 1 is to 5 percent ratio
        let percent = 1;
        this.setState({percentage: percent});
        this.props.uploadPercentage(percent);
        const interval1 = setInterval(function(){
            if (timer > 39) {
                clearInterval(interval1);
            } else {
                const interval2 = setInterval(function () {
                    if ((this.state.percentage === 0 || this.state.percentage === 100)
                            //the user refresh the page during while upload is on progress
                            || (!this._isMounted && this.state.percentage > 0 && this.state.percentage < 100)) {
                        clearInterval(interval1);
                        clearInterval(interval2);
                    }
                    percent += 0.125;
                    if(this._isMounted && this.state.percentage > 0 && this.state.percentage < 100){
                        this.setState({percentage: percent});
                        this.props.uploadPercentage(percent);
                    }
                    if (percent % 2.5 === 0) {
                        clearInterval(interval2);
                    }
                    // console.log("millisecond interval", new Date(), timer, percent, this.state.percentage);
                }.bind(this), 50);
            }
            // console.log("below minuteinterval", new Date(), timer, percent, this.state.percentage);
            timer++;
        }.bind(this), 1000);
    };

    handleOnFilesAdded = (file) => {
        this.setState({ file: file});
    };

    retrieveDropZoneProps = props => {
        this.setState({ alertProps: props });
        if (props.visible) {
          this.setState({ file: null });
        }
    };

    handleAlertDismiss = () => {
        let prop = {...this.state.alertProps};
        prop.visible = false;
        this.setState({
            alertProps : prop,
            file: null,
            percentage: 0,
            isUploading: false
        });
    };

    renderFileandProgress = () => {
        const { file, percentage } = this.state;
        const animated = <Progress animated value={percentage}/>;
        const striped = <Progress striped value={percentage}/>;
        if(file != null) {
            return (
                <div className="row padProgress">
                    <div className="col">
                        <span className="fileName">{file.name}</span>
                        {percentage === 100 ? striped : animated}
                    </div>
                </div>
            );
        } else {
            return (
                <div className="row padDefaultHeight" />
            );
        }
    };

    renderButton = () => {
        const uploadType = this.props.fileType;
        const { file, isUploading } = this.state;

        if(uploadType === "FCLink") {
           return (
             <div>
                <button disabled={file === null || isUploading} onClick={this.handleFileUpload}>Generate</button>&nbsp;&nbsp;
                <button disabled={file === null || isUploading} onClick={this.handleFileUploadEmail}>Generate and email link to FC</button>
             </div>
           );
        }else{
           return (
               <button disabled={file === null || isUploading} onClick={this.handleFileUpload}>Generate</button>
           );
        }

    };

    render() {
        const alert = this.state.alertProps.visible ?
            (
                <div className="Alert">
                    <AlertSimple
                    alertProps={this.state.alertProps}
                    onAlertDismiss={this.handleAlertDismiss}
                    />
                </div>
            ) : (
                <div />
            );
        return (
            <div className="Upload">
                {alert}
                <div className="container">
                    <div className="row justify-content-center padDropzone">
                        <Dropzone
                        onFilesAdded={this.handleOnFilesAdded}
                        disabled={this.state.alertProps.visible || this.state.isUploading}
                        dropzoneProps={this.retrieveDropZoneProps}
                        />
                    </div>
                    {this.renderFileandProgress()}
                    <div className="row justify-content-center padHeightButton">{this.renderButton()}</div>
                </div>
            </div>
        );
    }

}