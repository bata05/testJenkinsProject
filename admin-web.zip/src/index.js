import "react-app-polyfill/ie11";
import "react-app-polyfill/stable";
import React from "react";
import ReactDOM from "react-dom";
import PacsnetValidator from "./PacsnetValidator";

ReactDOM.render(<PacsnetValidator />, document.getElementById("root"));
