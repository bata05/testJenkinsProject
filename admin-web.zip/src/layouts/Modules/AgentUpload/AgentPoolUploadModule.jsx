import React, { Component } from "react";
import { Card, CardHeader, CardBody } from "reactstrap";
import PanelHeader from "../../../components/PanelHeader/PanelHeader";
import AgentPoolContainer from "../../../components/AgentPool/AgentPoolUpload/AgentPoolContainer";

export default class AgentPoolUploadModule extends Component {
  render() {
    return (
      <div>
        <PanelHeader size="sm" />
        <div className="content">
          <Card>
            <CardHeader>
              <h5 className="title">Agent Pool Upload</h5>
            </CardHeader>
            <CardBody>
              <AgentPoolContainer {...this.props} />
            </CardBody>
          </Card>
        </div>
      </div>
    );
  }
}