import React, { Component } from "react";
import { Card, CardHeader, CardBody } from "reactstrap";
import PanelHeader from "../../../components/PanelHeader/PanelHeader";
import axios from "axios";
import { downloadDynamicFile } from "../../../utils/utils";

export default class DownloadEligibleFCsModules extends Component {

    handleFileDownload = (e) => {
        this.fileDownload().then((response)=>{
            downloadDynamicFile(new Blob([response.data]), 'Eligible_FCs.xlsx');
        }).catch((error) => {
            // console.log(error);
        });
    };

    fileDownload = () => {
        const configMapping = window.ConfigMapping;

        const finalUrl = configMapping.REACT_APP_ADMIN_SERVICE_URL + process.env.REACT_APP_DOWNLOAD_ELIGIBLEFCS;

        const formData = new FormData();
        const { session } = this.props;

        formData.append('empid',session.empid);
        formData.append('empName',session.empName);

        return  axios({method: 'post',url:finalUrl,data:formData,responseType:'blob'});
    };

    render() {
    return (
      <div>
        <PanelHeader size="sm" />
        <div className="content">
          <Card>
            <CardHeader>
              <h5 className="title">Download Eligible FCs</h5>
            </CardHeader>
            <CardBody>
                <button onClick={this.handleFileDownload}>Download</button>
            </CardBody>
          </Card>
        </div>
      </div>
    );
  }
}