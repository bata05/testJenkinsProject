import React, { Component } from "react";
import { Card, CardHeader, CardBody } from "reactstrap";
import PanelHeader from "../../../components/PanelHeader/PanelHeader";
import LeadGeneration from "../../../components/LeadGen/LeadGeneration";


export default class LeadGenerationModule extends Component {
    render() {
        return (
          <div>
            <PanelHeader size="sm" />
            <div className="content">
              <Card>
                <CardHeader>
                  <h5 className="title">Lead Generation</h5>
                </CardHeader>
                <CardBody>
                  <LeadGeneration {...this.props} />
                </CardBody>
              </Card>
            </div>
          </div>
        );
      }
}