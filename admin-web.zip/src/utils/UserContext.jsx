import React from 'react';

const UserContext = React.createContext({authToken: null});

export {
    UserContext
};