export const downloadDynamicFile = (blob, name) => {
    if (navigator.appVersion.toString().indexOf('.NET') >= 0) {
        window.navigator.msSaveBlob(blob, name);
    } else if (!!navigator.userAgent.match('CriOS')) { // iOS Chrome
        const reader = new FileReader();
        reader.onloadend = () => {
          window.open(reader.result, '_blank');
        };
        reader.readAsDataURL(blob);
    } else {
        let blobUrl = URL.createObjectURL(blob);
        // trigger download - Add a new 'a' and explicitly call its click() event.
        let downloadLink = document.createElement('a');
        downloadLink.setAttribute('href', blobUrl);
        document.body.appendChild(downloadLink);
        downloadLink.setAttribute('download', name);
        downloadLink.click();
        document.body.removeChild(downloadLink);
    }
}