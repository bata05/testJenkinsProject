D2C - Service

# Getting Started 
---------------------------

### 1. Edit the Properties file (if not using the default cacerts):
  * Cert file path - 
    ```
    hsm.keystorelocation = %path of cacerts.dat file%
    ```
    Default Value = src/main/resources/cert/cacerts.dat
   
    
   * Note : 
     
     >cacerts.dat keystore at src/main/resources/cert/cacerts.dat contains cert aliases for hsm and https://service-sit.prudential.com.sg.
     The keystore should be loaded as vm args during service startup.
     

### 2. Build the WAR

Using maven commands :
mvn clean install

### 3. Run Configuration (Standalone):
  * In Run configurations, create a new Application config for d2c-service.
 
  * Add the vm arguments to application config as below. 
   
  * *Replace the ***** with the cacerts keystore password found in the Properties file. *
  
  * Ensure the the *hsm.keystorelocation* property has the same file path configured.
 ```
 -Dspring.profiles.active=dev
 -Djavax.net.ssl.trustStore=src/main/resources/cert/cacerts.dat
 -Djavax.net.ssl.trustStorePassword=*****
 -Djavax.net.ssl.keyStore=src/main/resources/cert/cacerts.dat
 -Djavax.net.ssl.keyStorePassword=*****
 ```

  * Comment out the dependency scope for tomcat in the POM file.


Maven Build
------------
mvn clean install -Dmaven.wagon.http.ssl.insecure=true -Dsettings.security=./settings-security.xml -s ./settings.xml -DskipTests -f pom.xml