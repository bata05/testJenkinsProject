**Get Quotation Details API**

This API is used to 

Get Quotation

Get Premium Details based on Sum Assured

<br>

**Request URL**

All URIs are relative to *https://localhost:8080/d2c-service*

<br>

**Request Method**

POST

<br>

**Request Header Attribute**

Content-Type = application/json

x-ibm-client-id = {your subscribed client key}

<br>

**Example Request**
```javascript
{
	"system":{
		"status":"success",
		"apiVersion":"V1.0"
	},
	"payload":{
		"transactionId":"a0Y2t000000gOxoEAE",
		"DPTransactionId":"29b4b402-bf36-40f5-b33f-e5c16e459894",
		"clientProfile":{
			"dob":"12/01/1987",
			"gender":"M",
			"clientType":"ML"
		},
		"product": {
			"docId": "id_prod_can"
			"sumAssured": 300000.0
			"yearlyPremium": 541.5,
			"halfYearlyPremium": 273.46,
			"quarterlyPremium": 138.08,
			"monthlyPremium": 46.03,
			"discountedYearlyPremium": 541.5,
			"discountedHalfYearlyPremium": 273.46,
			"discountedQuarterlyPremium": 138.08,
			"discountedMonthlyPremium": 46.03
		}	
	}
}




<br>

**Example Response**
```javascript
{
	"system":{
		"status":"success",
		"apiVersion":"V1.0"
	},
	"payload":{
		"transactionId":"a0Y2t000000gOxoEAE",
		"DPTransactionId":"29b4b402-bf36-40f5-b33f-e5c16e459894",
		"clientProfile":{
			"dob":"12/01/1987",
			"gender":"M",
			"clientType":"ML"
		},
		"product": {
			"docId": "id_prod_can"
			"sumAssured": 300000.0
			"yearlyPremium": 541.5,
			"halfYearlyPremium": 273.46,
			"quarterlyPremium": 138.08,
			"monthlyPremium": 46.03,
			"discountedYearlyPremium": 541.5,
			"discountedHalfYearlyPremium": 273.46,
			"discountedQuarterlyPremium": 138.08,
			"discountedMonthlyPremium": 46.03
		}	
	}
}

<br>

**System Description**

|Name|Type|Required|Description|
|:---|:---|:---|:---|
|appVersion|String|Y|Version of the client’s app Default value: "1.0"|
|appKey|String|Y|Key to access this API|
|appName|String|Y|Application name. Default value: 'uobmighty'|
|clientIP|String|Y|Client IP address|
|clientUdid|String|N|To support future enhancement if client device UDID is required.|
|isPayloadEncrypted|String|N|Default to false, indicator of payload encryption|
|encryptionKey|String|N|Encryption key / public key to be used for encryption|

**Payload Description**

|Name|Type|Required|Description|
|:---|:---|:---|:---|
|transactionId|String|Y| Transaction ID from UOB|
|DPTransactionId|String|Y| DP Transaction ID|
|clientProfile|String|Y| Life assured information |
|product|String|Y| Product information|

 **Client Profile Description**

|Name|Type|Required|Description|
|:---|:---|:---|:---|
|dob|String|Y|Customer date of birth in the format DD/MM/YYYY|
|gender|String|Y|Customer's gender. Accepted values are Male, Female|
|clientType|String|Y|To support future possibility of Multiple Life. Default value: "ML" - Main Life. Accepted values are ML-Main Life, O-Owner, SL-Second Life,TL-Third Life|


**Selected Product Description**

|Name|Type|Required|Description|
|:---|:---|:---|:---|
|docId|String|Y|Document Id for product. Default value: "id_prod_can" - for PRUCancer 360|
|sumAssured|String|Y|Product Sum Assured|
|yearlyPremium|String|N|Product yearly premium|
|halfYearlyPremium|String|N|Product half yearly premium|
|quarterlyPremium|String|N|Product quarterly premium|
|monthlyPremium|String|N|Product monthly premium|
|yearlyDiscPremium|String|N|Product yearly discount premium|
|halfYearlyDiscPremium|String|N|Product half yearly discount premium|
|quarterlyDiscPremium|String|N|Product quarterly discount premium|
|monthlyDiscPremium|String|N|Product monthly discount premium|


<br>

**HTTP Status**

|Status|Description|
|:---|:---|
|`200`|OK|
|`400`|Bad request|
|`401`|Unauthorized|
|`404`|Not found|
|`413`|Request Too Large|
|`415`|Unsupported Media Type|
|`500`|Internal Server Error|

<br>


**Example Error Response**
```javascript
{
    "system":{
        "status":"error",
        "apiVersion": "1.0"
    },
    "payload":{
        "transactionId":"",
        "DPTransactionId":"",
        " errors":[{
            "code":"001",
            "description":""
        }]
    }
}

```