package com.prudential.d2c.batch;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import com.prudential.d2c.batch.mailservice.*;
import com.prudential.d2c.common.Constants;
import com.prudential.d2c.entity.ProductSalesInfo;
import com.prudential.d2c.entity.config.Channels;
import com.prudential.d2c.entity.dto.*;
import com.prudential.d2c.exception.D2CException;
import com.prudential.d2c.repository.ChannelAPICustomerApplicationRepository;
import com.prudential.d2c.repository.ChannelAPIDocumentRepository;
import com.prudential.d2c.repository.ChannelAPIMailRepository;
import com.prudential.d2c.repository.CustomRepository;
import com.prudential.d2c.repository.DigitalEndowmentAPICustomerApplicationRepository;
import com.prudential.d2c.repository.DigitalEndowmentAPIDocumentRepository;
import com.prudential.d2c.repository.DigitalEndowmentAPIMailRepository;
import com.prudential.d2c.service.*;
import com.prudential.d2c.utils.D2CUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.prudential.d2c.entity.MailTemplate;
import com.prudential.d2c.entity.MailTemplates;
import com.prudential.d2c.entity.config.ReportConfig;
import com.prudential.d2c.utils.DataUtils;

import static com.prudential.d2c.common.Constants.*;
import static com.prudential.d2c.common.MailTemplateConstants.QMAY018;
import static com.prudential.d2c.common.MailTemplateConstants.QMAY019;
import static com.prudential.d2c.common.MailTemplateConstants.QPS005;
import static org.apache.commons.lang3.StringUtils.contains;

@Service
public class Jobservice {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    private final String HOST_NAME_ERROR = "Can't get host name";

    @Autowired
    private CustomerApplicationService customerApplicationService;
   
    @Autowired
    private ProductSalesInfoService productSalesInfoService;
    
    @Autowired
    private CRMEmailService marketCloudService;
    
    @Autowired
    private MailService mailService;
    
    @Autowired
    private MailSendService mailSendService;
   
    @Autowired
    private CustomizedVelocityEngine velocityEngine;
    
    @Autowired
    private ApplicationDocumentService applicationDocumentService;
    
    @Autowired
    private ReportConfigService reportConfigService;
    
    @Autowired
    private CustomRepository customRepository;
    
    @Autowired
    private ChannelService channelService;
    
    @Autowired
    private TranCustomerAppService tranCustomerAppService;
    
    @Autowired
    ChannelAPIDocumentRepository channelAPIDocumentRepository;
    
    @Autowired
    private ChannelAPICustomerApplicationRepository channelAPICustomerApplicationRepository;
    
    @Autowired
    private ChannelAPIMailRepository channelAPIMailRepository;
    
    @Autowired
    DigitalEndowmentAPIDocumentRepository digitalEndowmentAPIDocumentRepository;
    
    @Autowired
    private DigitalEndowmentAPIMailRepository digitalEndowmentAPIMailRepository;
    
    @Autowired
    private DigitalEndowmentAPICustomerApplicationRepository digitalEndowmentAPICustomerApplicationRepository;
    
    @Autowired
    private LeadsService leadsService;

    @Autowired
    private DigitalEndowmentAPIService digitalEndowmentAPIService;

    @Value("#{'${email.filter.agentcodes}'.split(',')}")
    private List<String> agentCodesToBlockEmail;
    
    @Value("${to.email.sales.internal}")
    private String toInternalEmailList;
    
    @Value("${to.email.esub.internal}")
    private String toEsubEmailList;
    
    @Value("${to.email.error.internal}")
    private String toInternalErrorEmailList;
    
    @Value("${to.email.dpi.failed.questionnaire}")
    private String dpiFailedQuestionnaireEmailRecipients;
    
    @Value("${password.prefix.dpi.failed.questionnaire}")
    private String dpiFailedQuestionnairePasswordPrefix;

    private List<String> mailTypeToProcessInDP = Arrays.asList(MAIL_BACKUP, MAIL_CUSTOMER, MAIL_AGENT, MAIL_INTERNAL, MAIL_ERROR_INTERNAL, MAIL_ESUB, MAIL_TRANCHE);
    private List<String> mailTypesToFetch = Arrays.asList(MAIL_CUSTOMER, MAIL_INTERNAL);

    public void processMailList() {
        ConfigureProperties mailSenderType = mailService.getMailSenderType();
        ConfigureProperties salesforceStatus = mailService.getSalesforceStatus();
        List<MailList> mailLists = mailService.findByStatusCodeServerHostNameInMailTypesOrNotInAgentList(MAIL_ENABLE, getHostName(), agentCodesToBlockEmail, mailTypesToFetch);
        for (MailList value : mailLists) {
            try {
                CustomerApplication customerApplication = customerApplicationService.findCustomerApplicationByCustomId(value.getCustomId());
                if (isScheduledToProcessInDp(mailSenderType, value.getMailType(), customerApplication.getProductType())) {
                    List<ProductSalesInfo> productSalesInfos = productSalesInfoService.findProductSalesInfoByCustId(value.getCustomId());
                    processSendingEmailInDP(value, customerApplication, productSalesInfos);
                } else if (MAIL_SENDER_SALESFORCE == Integer.parseInt(mailSenderType.getConValue())) {
                    processMailListPassToSalesForce(value, salesforceStatus.getConValue());
                }
            } catch (Exception e) {
                logger.error("Exception occured while Processing Mail List.", e.getMessage());
                value.setStatusCode(MAIL_PROCESS_EXCEPTION);
                getMailService().updateMailStatusAndSendDateByMailId(value);
            }
        }
    }

    private String getHostName(){

        try {
            if(contains(System.getProperty(Constants.D2C_PATH_ENV),"D2C_portal_bact")){
                return "BACT";
            }
            InetAddress addr = java.net.InetAddress.getLocalHost();
            return addr.getHostName();
        } catch (UnknownHostException e) {
            throw new D2CException(HOST_NAME_ERROR);
        }


    }

    @SuppressWarnings("deprecation")
	private void processMailListPassToSalesForce(MailList mail, String salesforceStatus) {
        logger.info("Start to run processMailListPassToSalesForce.");
        try {

            if (SALESFORCE_ENABLE == Integer.parseInt(salesforceStatus)) {
                if (mail.getMailType().equals(MAIL_EDM_LEAD)) {
                    mail.setMailType(MAIL_PTV_LEAD);
                }
                // execute sending to salesforce
                String resultId = marketCloudService.triggerJourney(mail);
                if (StringUtils.isEmpty(resultId)) {
                    logger.error("Exception caught in processMailListPassToSalesForce: REQUEST_SERVICE_MESSAGE_ID is null");
                    logger.warn("mail_id: {} email type: {}", mail.getMailId(), mail.getMailType());
                    mail.setStatusCode(MAIL_SALESFORCE_EXCEPTION);
                    getMailService().updateMailListForCRMException(mail);
                } else {
                    mail.setStatusCode(MAIL_SALESFORCE_SUCCESS);
                    mail.setRequestServiceMessageId(resultId);
                    getMailService().updateMailListWithMessageID(mail);
                }
            }
        } catch (Exception e) {
            logger.error("Exception caught in processMailListPassToSalesForce:", e);
            logger.warn("mail_id: " + mail.getMailId() + "email type: " + mail.getMailType());
            mail.setStatusCode(MAIL_SALESFORCE_EXCEPTION);
            getMailService().updateMailListForCRMException(mail);
        }
    }

    private void processSendingEmailInDP(MailList mail, CustomerApplication customerApplication, List<ProductSalesInfo> productSalesInfos) {
        logger.info("Start to run processSendingEmailInDP.");
        try {
            MailTemplate mailTemplate = generateMailTemplate(mail, customerApplication, productSalesInfos);
            mailSendService.connectMailService(mailService.getMailServer());
            mailSendService.proceedSendMail(mailTemplate, customerApplication.getChannel(), mail.getMailType());
            mail.setStatusCode(MAIL_SENDING_SUCCESS);
        } catch (Exception e) {
            logger.error("exception caught in processMailLists:", e);
            logger.warn("mail_id: " + mail.getMailId() + "email type: " +  D2CUtils.removeCRLF(mail.getMailType()));
            mail.setStatusCode(MAIL_SENDING_EXCEPTION);
        } finally {
            mailService.updateMailStatusAndSendDateByMailId(mail);
            mailSendService.closeConnection();
        }
    }

    private MailTemplate generateMailTemplate(MailList mail, CustomerApplication customerApplication, List<ProductSalesInfo> productSalesInfos) {
        logger.debug("call send mail,details:{}", mail);
        MailTemplates templates = mailService.getMailTemplate();
        MailContent mailContent = null;
        ApplicationDocument applicationDocument = null;
        ReportConfig reportConfig = reportConfigService.findByChannelCode(customerApplication.getChannel());
        mailService.handleMailListData(mail);
        boolean isBodyContentRequiredToFetch = true;

        switch (mail.getMailType()) {
            case MAIL_AGENT:
                mailContent = new AgentMailContent(templates, mail);
                break;
            case MAIL_CUSTOMER:
                String viewLink = mailService.generateLinkForMailImages(mail, customerApplication);
                applicationDocument = applicationDocumentService.findByErefNoAndCustomId(mail.getErefNo(),
                        mail.getCustomId());
                mailContent = new CustomerMailContent(templates, mail, customerApplication, viewLink, applicationDocument);
                break;
            case MAIL_INTERNAL:
            	TransactionalCustomerApplication customData = tranCustomerAppService.findByCustId(customerApplication.getCustomId());
                mailContent = new InternalMailContent(templates, mail, customerApplication, toInternalEmailList, reportConfig, productSalesInfos, customData != null ? customData.getProductCodes() : "N/A");
                break;
            case MAIL_BACKUP:
                mailContent = new BackupMailContent(templates, mail);
                break;
            case MAIL_FAILQUESTION_LEAD:
                // FAILQUESTION_LEAD only for DPI Products
                mailContent = new DpiFailedQuestionnaireMailContent(templates.getDpiFailedQuestionnaire(), mail, customerApplication, reportConfig,
                        dpiFailedQuestionnaireEmailRecipients, dpiFailedQuestionnairePasswordPrefix);
                break;
            default:
                String answerQMAY019 = customerApplicationService.findAnswerByQuestionCode(customerApplication, QMAY019);
                String answerQPS005 = customerApplicationService.findAnswerByQuestionCode(customerApplication, QPS005);
                String answerQMAY018 = customerApplicationService.findAnswerByQuestionCode(customerApplication, QMAY018);
                mailContent = new LeadGenMailContent(templates, mail, velocityEngine, customerApplication, answerQMAY019,
                        answerQPS005, answerQMAY018);
                isBodyContentRequiredToFetch = false;
                break;
        }

        logger.info("Get mailContent template...{}", mailContent.getMailDetail().getTemplateName());
        String bodyContent = null;

        if (isBodyContentRequiredToFetch) {
            bodyContent = mailService.getMailContent(mailContent.getMailDetail().getTemplateName());
        }

        mailContent.handleValuesForMailDetail(bodyContent, mailService.getMailServiceEnvironment());
        mailService.addImagesForMailDetail(mailContent.getMailImages(), mailContent.getMailDetail());
        logger.info("Get mailDetail....{}", mailContent.getMailDetail());

        return mailContent.getMailDetail();

    }

    public void processCloseMailCheck() {
        List<MailList> maillists = getMailService().findByStatusCodeAndServerHostName(MAIL_CLOSE_VALUE, DataUtils.getHostName());

        if (maillists != null && !maillists.isEmpty()) {
            for (MailList mail : maillists) {
                logger.debug("Check Close Browser Email for mail_id: {}; customer id: {}", D2CUtils.removeCRLF(mail.getMailId()), D2CUtils.removeCRLF(mail.getCustomId()));
                mail.setStatusCode(MAIL_ENABLE);
                getMailService().updateMailStatusByMailId(mail);
            }
        }
    }

    public MailService getMailService() {
        return mailService;
    }

    public void setMailService(MailService mailService) {
        this.mailService = mailService;
    }

    public MailSendService getMailSendService() {
        return mailSendService;
    }

    public void setMailSendService(MailSendService mailSendService) {
        this.mailSendService = mailSendService;
    }

    @SuppressWarnings("deprecation")
	protected boolean isValidMailTypeToProcessInDP(String mailType) {
        return (!StringUtils.isEmpty(mailType) && mailTypeToProcessInDP.contains(mailType.toUpperCase()));
    }

    protected boolean isMailSenderDP(ConfigureProperties mailSenderType) {
        try {
            return (null != mailSenderType && MAIL_SENDER_DP == Integer.parseInt(mailSenderType.getConValue()));
        } catch (NumberFormatException e) {
            return false;
        }
    }

    protected boolean isScheduledToProcessInDp(ConfigureProperties mailSenderType, String mailType, String prodType) {
        return (isMailSenderDP(mailSenderType) || isValidMailTypeToProcessInDP(D2CUtils.removeCRLF(mailType)) || isDPIProductFailedQuestionnaireMailType(D2CUtils.removeCRLF(mailType), D2CUtils.removeCRLF(prodType)));
    }

    protected boolean isDPIProductFailedQuestionnaireMailType(String mailType, String prodType) {
        return (MAIL_FAILQUESTION_LEAD.equalsIgnoreCase(D2CUtils.removeCRLF(mailType)) && DPI_PRODUCT_LIST.contains(D2CUtils.removeCRLF(prodType)));
    }

    public void triggerChannelMail(String dpCustomId, String mailType) {
        logger.info("Channel API triggerChannelMail Started For DP Custom ID : {} for Mail Type : {}",
                D2CUtils.removeCRLF(dpCustomId), D2CUtils.removeCRLF(mailType));
        ChannelAPIMail channelAPIMail = new ChannelAPIMail(mailType);
        try {
            MailTemplates templates = mailService.getMailTemplate();
            MailContent mailContent = null;
            Optional<ChannelAPIReportSalesView> channelAPIReportSales = customRepository.getChannelAPIReportSales(dpCustomId);
            CustomerApplication customerApplication = customerApplicationService.findCustomerApplicationByCustomId(dpCustomId);
            ChannelAPICustomerApplication channelAPICustomerApplication = channelAPICustomerApplicationRepository.findByDpCustomId(dpCustomId);
            channelAPIMail.setDpCustomId(dpCustomId);
            channelAPIMail.setTransactionID(channelAPICustomerApplication.getTransactionID());
            if (channelAPIReportSales.isPresent() && customerApplication != null && channelAPICustomerApplication != null) {
                switch (mailType) {
                    case MAIL_AGENT:
                        if (!agentCodesToBlockEmail.contains(channelAPIReportSales.get().getAgentCode())) {
                            mailContent = new AgentMailContent(channelAPIReportSales.get(), templates, customerApplication, channelAPICustomerApplication.isExistingClient());
                            logger.info("Channel API triggerChannelMail Mail Content Prepared For DP Custom ID : {} for Mail Type : {}",
                                    D2CUtils.removeCRLF(dpCustomId), D2CUtils.removeCRLF(mailType));
                            break;
                        } else {
                            logger.info("Channel API triggerChannelMail Agent Not required to Trigger Mail For DP Custom ID : {} for Mail Type : {}",
                                    D2CUtils.removeCRLF(dpCustomId), D2CUtils.removeCRLF(mailType));
                            return;
                        }
                    case MAIL_CUSTOMER:
                        ChannelAPIDocument channelAPIDocument = channelAPIDocumentRepository.findByDpCustomId(dpCustomId);
                        String viewLink = mailService.generateLinkForMailImages(channelAPIReportSales.get(), customerApplication);
                        mailContent = new CustomerMailContent(channelAPIReportSales.get(), templates, customerApplication, viewLink, channelAPIDocument, channelAPICustomerApplication.isExistingClient());
                        logger.info("Channel API triggerChannelMail Mail Content Prepared For DP Custom ID : {} for Mail Type : {}",
                                D2CUtils.removeCRLF(dpCustomId), D2CUtils.removeCRLF(mailType));
                        break;
                    case MAIL_INTERNAL:
                        Channels channels = channelService.validateChannel(customerApplication.getChannel());
                        TransactionalCustomerApplication customData = tranCustomerAppService.findByCustId(dpCustomId);
                        mailContent = new InternalMailContent(channelAPIReportSales.get(), templates, toInternalEmailList, channels.getChannelName(), customerApplication.getProductType(),  customData != null ? customData.getProductCodes() : "N/A");
                        logger.info("Channel API triggerChannelMail Mail Content Prepared For DP Custom ID : {} for Mail Type : {}",
                                D2CUtils.removeCRLF(dpCustomId), D2CUtils.removeCRLF(mailType));
                        break;
                    default:
                        logger.info("Invalid Email Type : {} for Custom Id : {}", D2CUtils.removeCRLF(mailType), D2CUtils.removeCRLF(dpCustomId));
                        return;
                }

                String bodyContent = mailService.getMailContent(mailContent.getMailDetail().getTemplateName());
                mailContent.handleValuesForMailDetail(bodyContent, mailService.getMailServiceEnvironment());
                mailService.addImagesForMailDetail(mailContent.getMailImages(), mailContent.getMailDetail());

                mailSendService.connectMailService(mailService.getMailServer());
                mailSendService.proceedSendMail(mailContent.getMailDetail(), customerApplication.getChannel(), mailType);
                logger.info("Channel API triggerChannelMail Mail Sent Successfully For DP Custom ID : {} for Mail Type : {}",
                        D2CUtils.removeCRLF(dpCustomId), D2CUtils.removeCRLF(mailType));
                channelAPIMail.setUpdatedDate(new Date());
                channelAPIMail.setStatus(Constants.SUCCESS_STATUS);
            } else {
                channelAPIMail.setStatus(Constants.NOT_APPLICABLE);
                logger.info("No ChannelAPIReportSalesView Found For the Custom ID {}", D2CUtils.removeCRLF(dpCustomId));
                return;
            }
        } catch (Exception exception) {
            channelAPIMail.setUpdatedDate(new Date());
            channelAPIMail.setStatus(Constants.FAIL);
            logger.info("Channel API triggerChannelMail Mail Exception Occurred DP Custom ID : {} for Mail Type : {}",
                    D2CUtils.removeCRLF(dpCustomId), D2CUtils.removeCRLF(mailType));
            logger.error("Exception Occurred While triggerChannelMail :" + exception.getMessage(), exception);
        } finally {
            channelAPIMailRepository.save(channelAPIMail);
            mailSendService.closeConnection();
            logger.info("Channel API triggerChannelMail Completed For DP Custom ID : {} for Mail Type : {}",
                    D2CUtils.removeCRLF(dpCustomId), D2CUtils.removeCRLF(mailType));
        }
    }
    
    public void triggerDigitalEndowmentMail(String dpCustomID, String mailType, String exceptionString) {
        logger.info("Digital Endowment API triggerDigitalEndowmentMail Started For DP Custom ID : {} for Mail Type : {}", D2CUtils.removeCRLF(dpCustomID), D2CUtils.removeCRLF(mailType));
        DigitalEndowmentAPIMail digitalEndowmentAPIMail = new DigitalEndowmentAPIMail(mailType);
        try {
            MailTemplates templates = mailService.getMailTemplate();
            MailContent mailContent = null;
            Optional<DigitalEndowmentAPIReportSalesView> digitalEndowmentAPIReportSales = customRepository.getDigitalEndowmentAPIReportSales(dpCustomID);
            CustomerApplication customerApplication = customerApplicationService.findCustomerApplicationByCustomId(dpCustomID);
            DigitalEndowmentAPICustomerApplication digitalEndowmentAPICustomerApplication = digitalEndowmentAPICustomerApplicationRepository.findByDpCustomID(dpCustomID);
            digitalEndowmentAPIMail.setDpCustomID(dpCustomID);
            
            if(digitalEndowmentAPICustomerApplication!=null && digitalEndowmentAPICustomerApplication.getTransactionID()!=null) {
            	digitalEndowmentAPIMail.setTransactionID(digitalEndowmentAPICustomerApplication.getTransactionID());
            } else {
            	DigitalEndowmentAPIAudit submissionAuditObj = digitalEndowmentAPIService.findByCustomID(dpCustomID);
            	
            	if(submissionAuditObj!=null) {
            		digitalEndowmentAPIMail.setTransactionID(submissionAuditObj.getTransactionID());
            	} else {
            		digitalEndowmentAPIMail.setTransactionID(dpCustomID);
            	}
            }
            
            if (digitalEndowmentAPIReportSales.isPresent() && customerApplication != null && digitalEndowmentAPICustomerApplication != null) {
                switch (mailType) {
                    case MAIL_AGENT:
                        if (!agentCodesToBlockEmail.contains(digitalEndowmentAPIReportSales.get().getAgentCode())) {
                            mailContent = new AgentMailContent(digitalEndowmentAPIReportSales.get(), templates, customerApplication, digitalEndowmentAPICustomerApplication.isExistingClient());
                            logger.info("Digital Endowment API triggerDigitalEndowmentMail Mail Content Prepared For DP Custom ID : {} for Mail Type : {}",
                                    D2CUtils.removeCRLF(dpCustomID), D2CUtils.removeCRLF(mailType));
                            break;
                        } else {
                            logger.info("Digital Endowment API triggerDigitalEndowmentMail Agent Not required to Trigger Mail For DP Custom ID : {} for Mail Type : {}",
                                    D2CUtils.removeCRLF(dpCustomID), D2CUtils.removeCRLF(mailType));
                            return;
                        }
                    case MAIL_CUSTOMER:
                    	DigitalEndowmentAPIDocument digitalEndowmentAPIDocument = digitalEndowmentAPIDocumentRepository.findByDpCustomID(dpCustomID);
                        String viewLink = mailService.generateLinkForMailImages(digitalEndowmentAPIReportSales.get(), customerApplication);
                        mailContent = new CustomerMailContent(digitalEndowmentAPIReportSales.get(), templates, customerApplication, viewLink, digitalEndowmentAPIDocument, digitalEndowmentAPICustomerApplication.isExistingClient());
                        logger.info("Digital Endowment API triggerDigitalEndowmentMail Customer Mail Content Prepared For DP Custom ID : {} for Mail Type : {}",
                                D2CUtils.removeCRLF(dpCustomID), D2CUtils.removeCRLF(mailType));
                        break;
                    case MAIL_INTERNAL:
                        Channels channels = channelService.validateChannel(customerApplication.getChannel());
                        mailContent = new InternalMailContent(digitalEndowmentAPIReportSales.get(), templates, toInternalEmailList, channels.getChannelName());
                        logger.info("Digital Endowment API triggerDigitalEndowmentMail Internal Mail Content Prepared For DP Custom ID : {} for Mail Type : {}",
                                D2CUtils.removeCRLF(dpCustomID), D2CUtils.removeCRLF(mailType));
                        break;
                    case MAIL_ERROR_INTERNAL:
                    	mailContent = new DigitalEndowmentErrorMailContent(templates, toInternalErrorEmailList, exceptionString);
                        logger.info("Digital Endowment API triggerDigitalEndowmentMail Error Mail Content Prepared For DP Custom ID : {} for Mail Type : {}",
                                D2CUtils.removeCRLF(dpCustomID), D2CUtils.removeCRLF(mailType));
                        break;
                    default:
                        logger.info("Invalid Email Type : {} for Custom Id : {}", D2CUtils.removeCRLF(mailType), D2CUtils.removeCRLF(dpCustomID));
                        return;
                }

                String bodyContent = mailService.getMailContent(mailContent.getMailDetail().getTemplateName());
                mailContent.handleValuesForMailDetail(bodyContent, mailService.getMailServiceEnvironment());
                mailService.addImagesForMailDetail(mailContent.getMailImages(), mailContent.getMailDetail());

                mailSendService.connectMailService(mailService.getMailServer());
                if(mailType.equals(Constants.MAIL_ERROR_INTERNAL)) {
                	mailSendService.proceedSendMail(mailContent.getMailDetail(), Constants.AGENT_SUB_CHANNEL_PUL, mailType);
                } else {
                	mailSendService.proceedSendMail(mailContent.getMailDetail(), customerApplication.getChannel(), mailType);
                }
                logger.info("Digital Endowment API triggerDigitalEndowmentMail Mail Sent Successfully For DP Custom ID : {} for Mail Type : {}",
                        D2CUtils.removeCRLF(dpCustomID), D2CUtils.removeCRLF(mailType));
                digitalEndowmentAPIMail.setUpdatedDate(new Date());
                digitalEndowmentAPIMail.setStatus(Constants.SUCCESS_STATUS);
            } else {
            	digitalEndowmentAPIMail.setStatus(Constants.NOT_APPLICABLE);
                logger.info("No DigitalEndowmentAPIReportSalesView Found For the Custom ID {}", D2CUtils.removeCRLF(dpCustomID));
                return;
            }
        } catch (Exception exception) {
        	digitalEndowmentAPIMail.setUpdatedDate(new Date());
        	digitalEndowmentAPIMail.setStatus(Constants.FAIL);
            logger.info("Digital Endowment API triggerChannelMail Mail Exception Occurred DP Custom ID : {} for Mail Type : {}", D2CUtils.removeCRLF(dpCustomID), D2CUtils.removeCRLF(mailType));
            logger.error("Exception Occurred While triggerDigitalEndowmentMail :" + exception.getMessage(), exception);
        } finally {
        	digitalEndowmentAPIMailRepository.save(digitalEndowmentAPIMail);
            mailSendService.closeConnection();
            logger.info("Digital Endowment API triggerDigitalEndowmentMail Completed For DP Custom ID : {} for Mail Type : {}", D2CUtils.removeCRLF(dpCustomID), D2CUtils.removeCRLF(mailType));
        }
    }
    
    public void triggerDigitalEndowmentReportMail(String mailType) {
        logger.info("Digital Endowment API triggerDigitalEndowmentReportMail Started for Mail Type : {}", D2CUtils.removeCRLF(mailType));

        try {
            MailTemplates templates = mailService.getMailTemplate();
            MailContent mailContent = null;
            List <DigitalEndowmentAPIReportESubView> digitalEndowmentAPIReportEsubView = customRepository.getDigitalEndowmentAPIReportESub();
            List <DigitalEndowmentAPIReportTrancheView> digitalEndowmentAPIReportTrancheView = customRepository.getDigitalEndowmentAPIReportTranche();
            if (digitalEndowmentAPIReportEsubView != null && digitalEndowmentAPIReportTrancheView != null) {
                switch (mailType) {
                    case MAIL_ESUB:
                        mailContent = new InternalMailContent(digitalEndowmentAPIReportEsubView, templates, toEsubEmailList);
                        logger.info("Digital Endowment API triggerDigitalEndowmentMail Internal Mail Content Prepared for Mail Type : {}", D2CUtils.removeCRLF(mailType));
                        break;
                    case MAIL_TRANCHE:
                        mailContent = new InternalMailContent(digitalEndowmentAPIReportTrancheView, templates, toEsubEmailList, Constants.MAIL_TRANCHE);
                        logger.info("Digital Endowment API triggerDigitalEndowmentMail Internal Mail Content Prepared for Mail Type : {}", D2CUtils.removeCRLF(mailType));
                        break;

                    default:
                        logger.info("Invalid Email Type : {}", D2CUtils.removeCRLF(mailType));
                        return;
                }

                String bodyContent = mailService.getMailContent(mailContent.getMailDetail().getTemplateName());
                mailContent.handleValuesForMailDetail(bodyContent, mailService.getMailServiceEnvironment());
                mailService.addImagesForMailDetail(mailContent.getMailImages(), mailContent.getMailDetail());

                mailSendService.connectMailService(mailService.getMailServer());
                mailSendService.proceedSendMail(mailContent.getMailDetail(), Constants.AGENT_SUB_CHANNEL_PUL, mailType);
                logger.info("Digital Endowment API triggerDigitalEndowmentMail Mail Sent Successfully for Mail Type : {}", D2CUtils.removeCRLF(mailType));

            } else {
                logger.info("No DigitalEndowmentAPIReportESubView and DigitalEndowmentAPIReportTrancheView Found");
                return;
            }
        } catch (Exception exception) {
            logger.info("Digital Endowment API triggerChannelMail Mail Exception Occurred for Mail Type : {}", D2CUtils.removeCRLF(mailType));
            logger.error("Exception Occurred While triggerDigitalEndowmentMail :" + exception.getMessage(), exception);
        } finally {
            mailSendService.closeConnection();
            logger.info("Digital Endowment API triggerDigitalEndowmentMail Completed for Mail Type : {}", D2CUtils.removeCRLF(mailType));
        }
    }
    
    public void triggerDigitalEndowmentMarketingCloud(List<Leads> leadsLists) {
        try {
            for (Leads leads : leadsLists) {
                try {
                    processLeadsPassToSalesForce(leads,"1");
                } catch (Exception e) {
                    logger.error("Exception occured while Processing Leads List.", e.getMessage());
                }
            }

        } catch (Exception ex) {
            logger.error("Digital Endowment API - Exception in Lead MC ");
        }
    }

    @SuppressWarnings("deprecation")
	private void processLeadsPassToSalesForce(Leads leads, String salesforceStatus) {
        logger.info("Start to run processLeadsPassToSalesForce.");
        try {

            if (SALESFORCE_ENABLE == Integer.parseInt(salesforceStatus) && leads != null && !leads.isMcTriggered()) {
                // execute sending to salesforce
                String resultId = digitalEndowmentAPIService.triggerJourney(leads);
                leads.setMcTriggered(true);
                if (org.springframework.util.StringUtils.isEmpty(resultId)) {
                    logger.error("Exception caught in processLeadsPassToSalesForce: REQUEST_SERVICE_MESSAGE_ID is null");
                    logger.warn("mail_id: {}", leads.getId());
                    leads.setStatusCode(MAIL_SALESFORCE_EXCEPTION);
                    leadsService.updateLeadsForCRMException(leads);
                } else {
                    leads.setStatusCode(MAIL_SALESFORCE_SUCCESS);
                    leads.setRequestServiceMessageId(resultId);
                    leadsService.updateLeadsWithMessageID(leads);
                }
            }
        } catch (Exception e) {
            logger.error("Exception caught in processLeadsPassToSalesForce:", e);
            logger.warn("leads_id: " + leads.getId());
            leads.setMcTriggered(true);
            leads.setStatusCode(MAIL_SALESFORCE_EXCEPTION);
            leadsService.updateLeadsForCRMException(leads);
        }
    }

}
