package com.prudential.d2c.batch;

import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.expression.ParseException;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.MethodInvokingJobDetailFactoryBean;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;

import com.prudential.d2c.common.ConfigProperties;


@Configuration
public class SchedledConfiguration {
	private static final String KEY_THREAD_COUNT = "org.quartz.threadPool.threadCount";
    private static final String THREAD_COUNT = "1";
    private static final String TARGET_METHOD_WORK = "work";
    
    @Autowired
	private ConfigProperties configProperties;
	
   @Bean(name = "detailFactoryBean")
    public MethodInvokingJobDetailFactoryBean detailFactoryBean(ScheduledTasks scheduledTasks){
        MethodInvokingJobDetailFactoryBean bean = new MethodInvokingJobDetailFactoryBean ();
        bean.setTargetObject (scheduledTasks);
        bean.setTargetMethod (TARGET_METHOD_WORK);
        bean.setConcurrent (false);
        return bean;
    }

    @Bean(name = "cronTriggerBean")
    public CronTriggerFactoryBean cronTriggerBean(MethodInvokingJobDetailFactoryBean detailFactoryBean){
    	CronTriggerFactoryBean tigger = new CronTriggerFactoryBean ();
        tigger.setJobDetail (detailFactoryBean.getObject ());
        try {
       
             tigger.setCronExpression (configProperties.getJobTimer());//every 1 minute execute once
   
        } catch (ParseException e) {
        	return null;
        }
        return tigger;
    }

    @Bean
    public SchedulerFactoryBean schedulerFactory(CronTriggerFactoryBean cronTriggerBean){
        SchedulerFactoryBean bean = new SchedulerFactoryBean ();
        bean.setTriggers (cronTriggerBean.getObject());
		bean.setQuartzProperties(quartzProperties());
        return bean;
    }
    
    /**
     * Quartz configuration
     * 
     * @return Properties
     */
    private Properties quartzProperties() {
        Properties prop = new Properties();
        prop.put(KEY_THREAD_COUNT, THREAD_COUNT);
        return prop;
    }
}
