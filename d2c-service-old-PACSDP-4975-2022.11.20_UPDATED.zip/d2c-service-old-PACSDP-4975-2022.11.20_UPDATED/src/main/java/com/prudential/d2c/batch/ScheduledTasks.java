package com.prudential.d2c.batch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.stereotype.Component;

@Component
@Configurable
@EnableScheduling
public class ScheduledTasks {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private Jobservice jobservice;

	public void work() {
		logger.info("Start Jobservice to trigger emails to Agent and Customers for completed Sales and LeadGen");
		jobservice.processMailList();
		jobservice.processCloseMailCheck();
		logger.info("Completed Jobservice");
	}

}
