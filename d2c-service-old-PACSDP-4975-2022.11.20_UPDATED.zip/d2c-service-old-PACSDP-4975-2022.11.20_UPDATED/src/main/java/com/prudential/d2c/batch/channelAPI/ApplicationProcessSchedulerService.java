package com.prudential.d2c.batch.channelAPI;

import static org.apache.commons.lang3.StringUtils.contains;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.prudential.d2c.common.Constants;
import com.prudential.d2c.entity.dto.ChannelAPICustomerApplication;
import com.prudential.d2c.exception.D2CException;
import com.prudential.d2c.repository.ChannelAPICustomerApplicationRepository;

@Component
public class ApplicationProcessSchedulerService {

    @Autowired
    private ChannelAPICustomerApplicationRepository channelAPICustomerApplicationRepository;

    @Autowired
    private ApplicationProcessor applicationProcessor;


    @SuppressWarnings("unused")
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
    private final String HOST_NAME_ERROR = "Can't get host name";

    //@Scheduled(cron = "0 */5 * * * ?")
    @Scheduled(cron = "0 */1 * * * ?")
    public void processApplications() {
        System.out.println("Application Submission Triggered at " + Calendar.getInstance().getTime());
        List<ChannelAPICustomerApplication> pendingApplications;
        List<Integer> pendingAppIds = new ArrayList<>();
        pendingApplications = channelAPICustomerApplicationRepository.findByApplicationStatusAndServerHostName(ChannelAPICustomerApplication.ChannelAPICusAppStatus.VALIDATION_SUCCESS, getHostName());
        if (CollectionUtils.isNotEmpty(pendingApplications)) {
            pendingApplications.stream().forEach(app -> {
                app.setApplicationStatus(ChannelAPICustomerApplication.ChannelAPICusAppStatus.SUBMISSION_INIT);
                pendingAppIds.add(app.getId());

            });
            channelAPICustomerApplicationRepository.saveAll(pendingApplications);
        }
        applicationProcessor.process(pendingAppIds);
    }

    private String getHostName(){

        try {
            if(contains(System.getProperty(Constants.D2C_PATH_ENV),"D2C_portal_bact")){
                return "BACT";
            }
            InetAddress addr = java.net.InetAddress.getLocalHost();
            return addr.getHostName();
        } catch (UnknownHostException e) {
            throw new D2CException(HOST_NAME_ERROR);
        }


    }
}
