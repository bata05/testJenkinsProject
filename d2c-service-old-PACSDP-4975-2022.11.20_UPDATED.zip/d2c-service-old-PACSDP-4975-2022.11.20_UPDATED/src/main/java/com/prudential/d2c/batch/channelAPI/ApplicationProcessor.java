package com.prudential.d2c.batch.channelAPI;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class ApplicationProcessor {

    @Autowired
    private ApplicationSubmissionHandler applicationSubmissionHandler;

    @Async
    public void process(List<Integer> pendingApplicationIds) {
        pendingApplicationIds.stream().forEach(appID -> {
            applicationSubmissionHandler.handleSubmission(appID);
        });
    }
}
