package com.prudential.d2c.batch.channelAPI;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.prudential.d2c.batch.Jobservice;
import com.prudential.d2c.common.Constants;
import com.prudential.d2c.entity.dto.ChannelAPICustomerApplication;
import com.prudential.d2c.repository.ChannelAPICustomerApplicationRepository;
import com.prudential.d2c.repository.CustomRepository;
import com.prudential.d2c.service.ProposalDataService;
import com.prudential.d2c.service.impl.ApplicationProcessingImpl;
import com.prudential.d2c.service.impl.EsubServiceImpl;

@Service
public class ApplicationSubmissionHandler {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());	
	
    @Autowired
    private ChannelAPICustomerApplicationRepository channelAPICustomerApplicationRepository;
    
    @Autowired
    private ApplicationProcessingImpl applicationProcessing;
    
    @Autowired
    private ProposalDataService proposalDataService;
    
    @Autowired
    private CustomRepository customRepository;
    
    @Autowired
    private EsubServiceImpl esubService;
    
    @Autowired
    Jobservice jobservice;


    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void handleSubmission(Integer applicationId) {
    	

        ChannelAPICustomerApplication.ChannelAPICusAppStatus applicationStatus = ChannelAPICustomerApplication.ChannelAPICusAppStatus.PROCESSING_ERROR;
        ChannelAPICustomerApplication channelAPICustomerApplication = channelAPICustomerApplicationRepository.findById(applicationId).orElse(null);
        try {
            boolean proceed = true;
            try {
                applicationProcessing.assignAgentGenerateEref(channelAPICustomerApplication.getId());
            } catch (Exception ex) {
                proceed = false;
                   logger.error("FC Assignment Error ", ex);
            }
            applicationStatus = proceed ? ChannelAPICustomerApplication.ChannelAPICusAppStatus.FC_ASSIGN_SUCCESS : ChannelAPICustomerApplication.ChannelAPICusAppStatus.FC_ASSIGN_ERROR;
            customRepository.refreshEntityObject(channelAPICustomerApplication);

            if (proceed) {
                try {
                    jobservice.triggerChannelMail(channelAPICustomerApplication.getDpCustomId(), Constants.MAIL_INTERNAL);
                    jobservice.triggerChannelMail(channelAPICustomerApplication.getDpCustomId(), Constants.MAIL_AGENT);
                    proposalDataService.generateProposalPDFForAPI(channelAPICustomerApplication);
                } catch (Exception ex) {
                    proceed = false;
                    logger.error("Proposal Generation Error ", ex);
                }
            }
            applicationStatus = proceed ? ChannelAPICustomerApplication.ChannelAPICusAppStatus.PROPOSAL_GEN_SUCCESS : ChannelAPICustomerApplication.ChannelAPICusAppStatus.PROPOSAL_GEN_ERROR;
            customRepository.refreshEntityObject(channelAPICustomerApplication);

            //TO-DO - Incorporate ESub Process
            if (proceed) {
                try {
                    jobservice.triggerChannelMail(channelAPICustomerApplication.getDpCustomId(), Constants.MAIL_CUSTOMER);
                    esubService.submitEsub(channelAPICustomerApplication.getTransactionID());
                } catch (Exception ex) {
                    proceed = false;
                    logger.error("ESubmission Error ", ex);
                }
            }
            applicationStatus = proceed ? ChannelAPICustomerApplication.ChannelAPICusAppStatus.SUBMISSION_SUCCESS : ChannelAPICustomerApplication.ChannelAPICusAppStatus.SUBMISSION_ERROR;
            customRepository.refreshEntityObject(channelAPICustomerApplication);

        } finally {
            channelAPICustomerApplication.setApplicationStatus(applicationStatus);
            customRepository.mergeEntityObject(channelAPICustomerApplication);
        }

    }
}
