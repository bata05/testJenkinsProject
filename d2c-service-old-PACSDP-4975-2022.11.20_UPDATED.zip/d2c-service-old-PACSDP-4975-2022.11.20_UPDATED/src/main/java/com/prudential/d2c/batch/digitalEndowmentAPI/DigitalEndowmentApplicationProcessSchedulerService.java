package com.prudential.d2c.batch.digitalEndowmentAPI;

import static org.apache.commons.lang3.StringUtils.contains;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Optional;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.prudential.d2c.common.Constants;
import com.prudential.d2c.entity.DigitalEndowmentAPIDto;
import com.prudential.d2c.entity.dto.DigitalEndowmentAPIAudit;
import com.prudential.d2c.entity.dto.DigitalEndowmentAPICustomerApplication;
import com.prudential.d2c.exception.D2CException;
import com.prudential.d2c.repository.DigitalEndowmentAPICustomerApplicationRepository;
import com.prudential.d2c.service.DigitalEndowmentAPIService;

@Component
public class DigitalEndowmentApplicationProcessSchedulerService {
	
	private static final Logger logger = LoggerFactory.getLogger(DigitalEndowmentApplicationProcessSchedulerService.class);

    @Autowired
    private DigitalEndowmentAPICustomerApplicationRepository digitalEndowmentAPICustomerApplicationRepository;

    @Autowired
    private DigitalEndowmentApplicationProcessor digitalEndowmentapplicationProcessor;
    
    @Autowired
    private DigitalEndowmentAPIService digitalEndowmentAPIService;

    private final String HOST_NAME_ERROR = "Can't get host name";

    @Scheduled(cron = "0 */1 * * * ?")
    public void processApplications() {
        logger.info("DE Application Submission Triggered at " + Calendar.getInstance().getTime());
        List<DigitalEndowmentAPICustomerApplication> pendingApplications;
        List<DigitalEndowmentAPICustomerApplication> trancheErrorApplications;
        List<Integer> pendingAppIds = new ArrayList<>();
        List<Integer> trancheErrorAppIds = new ArrayList<>();

        pendingApplications = digitalEndowmentAPICustomerApplicationRepository.findFirst30ByApplicationStatusAndServerHostName(DigitalEndowmentAPICustomerApplication.DigitalEndowmentAPICusAppStatus.VALIDATION_SUCCESS, getHostName());
        if (CollectionUtils.isNotEmpty(pendingApplications)) {
            pendingApplications.stream().forEach(app -> {
            	Optional<DigitalEndowmentAPIAudit> submissionAuditObj = digitalEndowmentAPIService.findByTransactionIDAndApiTypeAndApiStatusOrderByCreateDateDesc(app.getTransactionID(), DigitalEndowmentAPIDto.DigitalEndowmentAPIType.APPLICATION_ESUBMISSION.toString(), Constants.ResponseStatus.SUCCESS);
            	if(submissionAuditObj.isPresent()) {
            		app.setApplicationStatus(DigitalEndowmentAPICustomerApplication.DigitalEndowmentAPICusAppStatus.SUBMISSION_INIT);
                    pendingAppIds.add(app.getId());
            	}
            });
            digitalEndowmentAPICustomerApplicationRepository.saveAll(pendingApplications);
        }
        digitalEndowmentapplicationProcessor.process(pendingAppIds);
        
        trancheErrorApplications = digitalEndowmentAPICustomerApplicationRepository.findFirst30ByApplicationStatusAndServerHostName(DigitalEndowmentAPICustomerApplication.DigitalEndowmentAPICusAppStatus.TRANCHE_ERROR, getHostName());
        if (CollectionUtils.isNotEmpty(trancheErrorApplications)) {
        	trancheErrorApplications.stream().forEach(appTranche -> {
        		Optional<DigitalEndowmentAPIAudit> submissionAuditObj = digitalEndowmentAPIService.findByTransactionIDAndApiTypeAndApiStatusOrderByCreateDateDesc(appTranche.getTransactionID(), DigitalEndowmentAPIDto.DigitalEndowmentAPIType.APPLICATION_ESUBMISSION.toString(), Constants.ResponseStatus.SUCCESS);
            	if(submissionAuditObj.isPresent()) {
	        		appTranche.setApplicationStatus(DigitalEndowmentAPICustomerApplication.DigitalEndowmentAPICusAppStatus.SUBMISSION_INIT);
	            	trancheErrorAppIds.add(appTranche.getId());
            	}

            });
            digitalEndowmentAPICustomerApplicationRepository.saveAll(trancheErrorApplications);
        }
        digitalEndowmentapplicationProcessor.process(trancheErrorAppIds);
      
    }
    
    @Scheduled(cron = "0 */15 * * * ?")
    public void processApplicationsEsubError() {
        logger.info("DE Application ESubmission Reprocess Triggered at " + Calendar.getInstance().getTime());
        List<DigitalEndowmentAPICustomerApplication> pendingApplications;
        List<Integer> pendingAppIds = new ArrayList<>();

        pendingApplications = digitalEndowmentAPICustomerApplicationRepository.findFirst30ByApplicationStatusAndServerHostName(DigitalEndowmentAPICustomerApplication.DigitalEndowmentAPICusAppStatus.SUBMISSION_ERROR, getHostName());
        if (CollectionUtils.isNotEmpty(pendingApplications)) {
            pendingApplications.stream().forEach(app -> {
            	Optional<DigitalEndowmentAPIAudit> submissionAuditObj = digitalEndowmentAPIService.findByTransactionIDAndApiTypeAndApiStatusOrderByCreateDateDesc(app.getTransactionID(), DigitalEndowmentAPIDto.DigitalEndowmentAPIType.APPLICATION_ESUBMISSION.toString(), Constants.ResponseStatus.SUCCESS);
            	if(submissionAuditObj.isPresent()) {
            		app.setApplicationStatus(DigitalEndowmentAPICustomerApplication.DigitalEndowmentAPICusAppStatus.SUBMISSION_INIT);
                    pendingAppIds.add(app.getId());
            	}
            });
            digitalEndowmentAPICustomerApplicationRepository.saveAll(pendingApplications);
        }
        digitalEndowmentapplicationProcessor.process(pendingAppIds);
       
    }
    
    //DATAHUB take over
    //@Scheduled(cron = "0 0/10 * * * ?")
    /*
    public void processReport() {
    	digitalEndowmentapplicationProcessor.processReport();
    }
    */

    private String getHostName(){

        try {
            if(contains(System.getProperty(Constants.D2C_PATH_ENV),"D2C_portal_bact")){
                return "BACT";
            }
            InetAddress addr = java.net.InetAddress.getLocalHost();
            return addr.getHostName();
        } catch (UnknownHostException e) {
            throw new D2CException(HOST_NAME_ERROR);
        }
    }
    

    @Scheduled(cron = "0 */5 * * * ?")
    public void processLeadMcDe() {
    	logger.info("DE processLeadMcDe Triggered at " + Calendar.getInstance().getTime());
        try {
            digitalEndowmentapplicationProcessor.processLeadMcDe();
        } catch (Exception ex) {
            System.out.println("DE processLeadMcDe Triggered ERROR: " + ex.getLocalizedMessage());
        }
    }
}
