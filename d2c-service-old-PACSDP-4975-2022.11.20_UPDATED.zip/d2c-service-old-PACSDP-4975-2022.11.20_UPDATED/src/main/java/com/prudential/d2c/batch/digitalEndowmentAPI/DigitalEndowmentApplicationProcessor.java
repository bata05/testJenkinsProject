package com.prudential.d2c.batch.digitalEndowmentAPI;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class DigitalEndowmentApplicationProcessor {

    @Autowired
    private DigitalEndowmentApplicationSubmissionHandler applicationSubmissionHandler;

    @Async
    public void process(List<Integer> pendingApplicationIds) {
        pendingApplicationIds.stream().forEach(appID -> {
            applicationSubmissionHandler.handleSubmission(appID);
        });
    }
    
    @Async
    public void processReport() {
    	 applicationSubmissionHandler.handleReport();
    }

    @Async
    public void processLeadMcDe() {
        applicationSubmissionHandler.handleLeadMcDe();
    }
}
