package com.prudential.d2c.batch.digitalEndowmentAPI;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.prudential.d2c.batch.Jobservice;
import com.prudential.d2c.common.Constants;
import com.prudential.d2c.entity.dto.CustomerApplication;
import com.prudential.d2c.entity.dto.DigitalEndowmentAPIAudit;
import com.prudential.d2c.entity.dto.DigitalEndowmentAPICustomerApplication;
import com.prudential.d2c.entity.dto.DigitalEndowmentAPIDocument;
import com.prudential.d2c.entity.dto.DigitalEndowmentAPIMail;
import com.prudential.d2c.entity.dto.Leads;
import com.prudential.d2c.entity.dto.TrancheCfg;
import com.prudential.d2c.entity.micro.DigitalEndowmentAPIESubPayment;
import com.prudential.d2c.entity.micro.DigitalEndowmentAPIRequest;
import com.prudential.d2c.entity.micro.DigitalEndowmentAPIRequestDocument;
import com.prudential.d2c.entity.micro.DigitalEndowmentAPITrancheResponse;
import com.prudential.d2c.exception.UpdateTrancheException;
import com.prudential.d2c.repository.CustomRepository;
import com.prudential.d2c.repository.CustomerApplicationRepository;
import com.prudential.d2c.repository.DigitalEndowmentAPICustomerApplicationRepository;
import com.prudential.d2c.repository.DigitalEndowmentAPIDocumentRepository;
import com.prudential.d2c.repository.DigitalEndowmentAPIMailRepository;
import com.prudential.d2c.repository.TrancheCfgRepository;
import com.prudential.d2c.service.DigitalEndowmentAPIService;
import com.prudential.d2c.service.LeadsService;
import com.prudential.d2c.service.ProposalDataService;
import com.prudential.d2c.service.impl.DigitalEndowmentAPIMyInfoPdfServiceImpl;
import com.prudential.d2c.service.impl.EsubServiceImpl;
import com.prudential.d2c.utils.ConvertBlobToObject;
import com.prudential.d2c.utils.D2CUtils;

@Service
public class DigitalEndowmentApplicationSubmissionHandler {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());	
	
    @Autowired
    private DigitalEndowmentAPICustomerApplicationRepository digitalEndowmentAPICustomerApplicationRepository;

    @Autowired
    private ProposalDataService proposalDataService;
    
    @Autowired
    private DigitalEndowmentAPIMyInfoPdfServiceImpl createMyInfoPdfService;
    
	@Autowired
    private DigitalEndowmentAPIService digitalEndowmentAPIService;
	
    @Autowired
    private DigitalEndowmentAPIDocumentRepository digitalEndowmentAPIDocumentRepository;
    
    @Autowired
    private DigitalEndowmentAPIMailRepository digitalEndowmentAPIMailRepository;

    @Autowired
    private CustomerApplicationRepository customerApplicationRepository;
    
    @Autowired
    private TrancheCfgRepository trancheCfgRepository;
    
    @Autowired
    private CustomRepository customRepository;
    
    @Autowired
    private EsubServiceImpl esubService;
    
    @Autowired
    Jobservice jobservice;

    @Autowired
    private LeadsService leadsService;


	@Transactional(propagation = Propagation.REQUIRES_NEW)
    public void handleSubmission(Integer applicationId) {
    	Optional<DigitalEndowmentAPIMail> errorMailObj = null;
    	
    	DigitalEndowmentAPICustomerApplication.DigitalEndowmentAPICusAppStatus applicationStatus = DigitalEndowmentAPICustomerApplication.DigitalEndowmentAPICusAppStatus.PROCESSING_ERROR;
    	DigitalEndowmentAPICustomerApplication digitalEndowmentAPICustomerApplication = digitalEndowmentAPICustomerApplicationRepository.findById(applicationId).orElse(null);
    	CustomerApplication customerApplication = customerApplicationRepository.findByCustomId(digitalEndowmentAPICustomerApplication.getDpCustomID());
    	DigitalEndowmentAPIAudit submissionAuditObj = null;
    	
    	try {
    		DigitalEndowmentAPIDocument digitalEndowmentAPIDocument = null;
        	DigitalEndowmentAPIRequest eSubRequest = new ConvertBlobToObject<>(DigitalEndowmentAPIRequest.class, digitalEndowmentAPICustomerApplication.getRequest()).getObject();
           
            boolean proceed = true;
            boolean trancheError = true;
            
            String channel;

            try {
            	String transId = digitalEndowmentAPICustomerApplication.getTransactionID();
            	//RPT
            	
            	submissionAuditObj = digitalEndowmentAPIService.findByTransactionIDAndApiStatus(digitalEndowmentAPICustomerApplication.getTransactionID(), Constants.SUCCESS_STATUS);
            	
    			digitalEndowmentAPIDocument = digitalEndowmentAPIDocumentRepository.findByTransactionID(transId);

    			if (digitalEndowmentAPIDocument == null) {
    				logger.info("DigitalEndowmentAPIDocument record Not Found in DB for Transaction {} ", D2CUtils.removeCRLF(transId));
    				digitalEndowmentAPIDocument = new DigitalEndowmentAPIDocument();
    				digitalEndowmentAPIDocument.setTransactionID(transId);
    				digitalEndowmentAPIDocument.setDpCustomID(digitalEndowmentAPICustomerApplication.getDpCustomID());
    			} else {
    				logger.info("DigitalEndowmentAPIDocument record Found in DB for Transaction {} ", D2CUtils.removeCRLF(transId));
    			}
           	 
           	    List<DigitalEndowmentAPIRequestDocument> docList = eSubRequest.getPayload().getDocument();
                
           	    
                proposalDataService.generateProposalPDFForDigitalEndowmentAPI(digitalEndowmentAPICustomerApplication, digitalEndowmentAPIDocument);   
                createMyInfoPdfService.submitDigitalEndowmentMyInfo(digitalEndowmentAPICustomerApplication, digitalEndowmentAPIDocument);
                
                for(DigitalEndowmentAPIRequestDocument doc: docList) {
                	if(digitalEndowmentAPIService.submitDigitalEndowmentQuotation(digitalEndowmentAPICustomerApplication, digitalEndowmentAPIDocument, doc.getDocumentId(), submissionAuditObj)) {
                		break;
                	};
                }
                
                for(DigitalEndowmentAPIRequestDocument doc: docList) {
                	if(digitalEndowmentAPIService.submitDigitalEndowmentPOA(digitalEndowmentAPICustomerApplication, digitalEndowmentAPIDocument, doc.getDocumentId(), submissionAuditObj)) {
                		break;
                	};
                } 
                //LOADTEST
                digitalEndowmentAPIDocumentRepository.save(digitalEndowmentAPIDocument);
                
            	
            } catch (Exception ex) {
                proceed = false;
                jobservice.triggerDigitalEndowmentMail(digitalEndowmentAPICustomerApplication.getDpCustomID(), Constants.MAIL_ERROR_INTERNAL, ex.getMessage() != null ? ex.getMessage() : "Esubmission Document Unexpected Error");
                logger.error("Digital Endowment PDF Generation Error ", ex);
            }
            
            applicationStatus = proceed ? DigitalEndowmentAPICustomerApplication.DigitalEndowmentAPICusAppStatus.PROPOSAL_GEN_SUCCESS : DigitalEndowmentAPICustomerApplication.DigitalEndowmentAPICusAppStatus.PROPOSAL_GEN_ERROR;
            customRepository.refreshEntityObject(digitalEndowmentAPICustomerApplication);

            if(eSubRequest.getPayload().getSrcInd()==null) {
            	channel = Constants.TRANCHE_SOURCE_PULSE;
            } else if(eSubRequest.getPayload().getSrcInd()!=null && StringUtils.isEmpty(eSubRequest.getPayload().getSrcInd())){
            	channel = Constants.TRANCHE_SOURCE_PULSE;
            } else {
            	channel = eSubRequest.getPayload().getSrcInd();
            }
            
            TrancheCfg trancheCfg = trancheCfgRepository.findValidTrancheByProductCodeAndComponentAndChannelAndStatus(eSubRequest.getPayload().getSqs().getProductCode(), eSubRequest.getPayload().getSqs().getLifeAssureds().get(0).getPlans().get(0).getPlanCode(), channel, new Date(), Constants.ACTIVE);
            
            if(trancheCfg !=null) {
	            if (proceed) {
	                try {
	                	//RPT	
	                	DigitalEndowmentAPITrancheResponse trancheResponse = digitalEndowmentAPIService.getUpdateTrancheResp(eSubRequest, customerApplication.getPolicyNo(), submissionAuditObj);
	                	
	                	if(trancheResponse==null) {
	                		throw new UpdateTrancheException("Error in calling Tranche Update API");
	                	} else if(trancheResponse != null && trancheResponse.getStatus().getCode().equals(Constants.TRANCHE_SUCCESS_CODE)){
	                		proceed = true;
	                		trancheError = false;
	                	}
	                	
	                	
	                } catch (UpdateTrancheException ex) {
	                    proceed = false;
	                    trancheError = true;
	                    errorMailObj = digitalEndowmentAPIMailRepository.findByDpCustomIDAndMailTypeAndStatus(digitalEndowmentAPICustomerApplication.getDpCustomID(), Constants.MAIL_ERROR_INTERNAL, Constants.SUCCESS_STATUS);
	                    if(!errorMailObj.isPresent()) {
	                    	jobservice.triggerDigitalEndowmentMail(digitalEndowmentAPICustomerApplication.getDpCustomID(), Constants.MAIL_ERROR_INTERNAL, ex.getMessage() != null ? ex.getMessage() : "Tranche Error");
	                        
	                    }
	                    logger.error("Unable to update Tranche. ", ex);
	                } catch (Exception ex) {
	                    proceed = false;
	                    trancheError = true;
	                    errorMailObj = digitalEndowmentAPIMailRepository.findByDpCustomIDAndMailTypeAndStatus(digitalEndowmentAPICustomerApplication.getDpCustomID(), Constants.MAIL_ERROR_INTERNAL, Constants.SUCCESS_STATUS);
	                    if(!errorMailObj.isPresent()) {
	                    	jobservice.triggerDigitalEndowmentMail(digitalEndowmentAPICustomerApplication.getDpCustomID(), Constants.MAIL_ERROR_INTERNAL, ex.getMessage() != null ? ex.getMessage() : "Tranche Unexpected Error");
	                        
	                    }
	                    logger.error("Unexpected error in updating Tranche. ", ex);
	                }       
	            }
            } else {
            	trancheError = false;
            }
             
            if (proceed) {
                try {
                	customRepository.mergeEntityObject(digitalEndowmentAPIDocument);
                	jobservice.triggerDigitalEndowmentMail(digitalEndowmentAPICustomerApplication.getDpCustomID(), Constants.MAIL_INTERNAL, null);
                    jobservice.triggerDigitalEndowmentMail(digitalEndowmentAPICustomerApplication.getDpCustomID(), Constants.MAIL_AGENT, null);
                    jobservice.triggerDigitalEndowmentMail(digitalEndowmentAPICustomerApplication.getDpCustomID(), Constants.MAIL_CUSTOMER, null);

                    esubService.submitDigitalEndowmentEsub(digitalEndowmentAPICustomerApplication.getTransactionID(), digitalEndowmentAPIDocument);
                
                } catch (Exception ex) {
                    proceed = false;
                    jobservice.triggerDigitalEndowmentMail(digitalEndowmentAPICustomerApplication.getDpCustomID(), Constants.MAIL_ERROR_INTERNAL, ex.getMessage() != null ? ex.getMessage() : "ESubmission Unexpected Error");
                    logger.error("ESubmission Error:", ex);
                }
               
            }
            
            if(!trancheError) {
            	applicationStatus = proceed ? DigitalEndowmentAPICustomerApplication.DigitalEndowmentAPICusAppStatus.SUBMISSION_SUCCESS : DigitalEndowmentAPICustomerApplication.DigitalEndowmentAPICusAppStatus.SUBMISSION_ERROR;
            } else {
            	applicationStatus = DigitalEndowmentAPICustomerApplication.DigitalEndowmentAPICusAppStatus.TRANCHE_ERROR;
            }
            
            applicationStatus = proceed ? DigitalEndowmentAPICustomerApplication.DigitalEndowmentAPICusAppStatus.SUBMISSION_SUCCESS : DigitalEndowmentAPICustomerApplication.DigitalEndowmentAPICusAppStatus.SUBMISSION_ERROR;
            customRepository.refreshEntityObject(digitalEndowmentAPICustomerApplication);
            
            //Tranche utiliztion and ESubmission report
            if(proceed && !trancheError && trancheCfg!=null) {
            
            	DigitalEndowmentAPIESubPayment paymentInfo = eSubRequest.getPayload().getPayment();
            	Double trancheSubmitted = trancheCfg.getSubmittedCumulativeTotal();
            	Double amount = 0.00;
            	
            	if(eSubRequest.getPayload().getPayment().getPaymentTransactionId() != null && eSubRequest.getPayload().getPayment().getPaymentTransactionId().equals(Constants.CASH)) {
            		amount = eSubRequest.getPayload().getSqs().getLifeAssureds().get(0).getPlans().get(0).getPremium();
            	} else {
            		amount = paymentInfo.getTransAmt();
            	}
            	
            	if(trancheCfg.getStatus().equals(Constants.ACTIVE)) {
		            Double premiumAccumulation = trancheCfg.getSubmittedCumulativeTotal() + amount;
		            trancheCfg.setSubmittedCumulativeTotal(premiumAccumulation);
		            customRepository.mergeEntityObject(trancheCfg);
            	}
	            
	            if(submissionAuditObj!=null) {

	            	if(trancheCfg.getStatus().equals(Constants.ACTIVE)) {
			            SimpleDateFormat parser = new SimpleDateFormat("EEE MMM d HH:mm:ss zzz yyyy");
			            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			            SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
			
			            submissionAuditObj.setFcCode(eSubRequest.getPayload().getAgentCode());
			            submissionAuditObj.setSinglePremium(amount);
			            submissionAuditObj.setPremiumAccumulation(trancheSubmitted);
			            submissionAuditObj.setCreditDate(dateFormat.format(parser.parse(paymentInfo.getTxnTimestamp())));
			            submissionAuditObj.setCreditTime(timeFormat.format(parser.parse(paymentInfo.getTxnTimestamp())));
			            submissionAuditObj.setChannel(channel);
			            submissionAuditObj.setEsubStatus(Constants.SUCCESS_STATUS);
			            submissionAuditObj.setTrancheId(trancheCfg.getId());
		
			            customRepository.mergeEntityObject(submissionAuditObj);
	            	}
	            } else {
	            	applicationStatus = DigitalEndowmentAPICustomerApplication.DigitalEndowmentAPICusAppStatus.AUDIT_ERROR;
	            }
            }
  
        } catch (ParseException e) {
        	logger.error("Digital Endowment API - Exception in parsing Date from Payment Info {} ");
		} finally {
        	digitalEndowmentAPICustomerApplication.setApplicationStatus(applicationStatus);
            customRepository.mergeEntityObject(digitalEndowmentAPICustomerApplication);
        }
    }
	
	@Transactional(propagation = Propagation.REQUIRES_NEW)
    public void handleReport() {
		try {
			jobservice.triggerDigitalEndowmentReportMail(Constants.MAIL_ESUB);
			jobservice.triggerDigitalEndowmentReportMail(Constants.MAIL_TRANCHE);
		} catch (Exception ex) {
			jobservice.triggerDigitalEndowmentMail("Tranche and Esub Report", Constants.MAIL_ERROR_INTERNAL, ex.getMessage() != null ? ex.getMessage() : "ESub and Tranche Unexpected Error");
		}
	}

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void handleLeadMcDe() {
        try {
            logger.info("Digital Endowment API - RUN in Lead MC ");
            List<Leads> leadsLists = leadsService.findLeadsListByMcTriggered();
            logger.info("Digital Endowment API - found leads size {} ", D2CUtils.removeCRLF(String.valueOf(leadsLists.size())));
            
            if(leadsLists.size()>0) {
            	jobservice.triggerDigitalEndowmentMarketingCloud(leadsLists);
            }

        } catch (Exception ex) {
            logger.error("Digital Endowment API - Exception in Lead MC ");
        }
    }

}
