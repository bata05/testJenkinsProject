package com.prudential.d2c.batch.mailservice;

import com.prudential.d2c.common.MailTemplateConstants;
import com.prudential.d2c.entity.MailTemplates;
import com.prudential.d2c.entity.dto.ChannelAPIReportSalesView;
import com.prudential.d2c.entity.dto.CustomerApplication;
import com.prudential.d2c.entity.dto.DigitalEndowmentAPIReportSalesView;
import com.prudential.d2c.entity.dto.MailList;
import com.prudential.d2c.utils.D2CUtils;
import com.prudential.d2c.utils.DataUtils;

/**
 * This mailContent is used for sending email to agent when a customer successfully applies a policy 
 *
 */
public class AgentMailContent extends MailContent {
	
	public AgentMailContent(MailTemplates templates,MailList mail) {
		super();
		this.setMailDetail(templates.getAgent());
		this.getMailDetail().setSendTo(mail.getAgentMail());

		//set subject
		this.getSubjectProperties().put(MailTemplateConstants.CLIENT_STATUS, DataUtils.getExistingClientTitle(mail.getIsExistingClient()));
		this.getSubjectProperties().put(MailTemplateConstants.PRODUCT_NAME, mail.getProductName());
		this.getSubjectProperties().put(MailTemplateConstants.GIVENNAME_NAME, D2CUtils.checkNullAndReturn(mail.getGivenName()));
		this.getSubjectProperties().put(MailTemplateConstants.SURNAME_NAME, D2CUtils.checkNullAndReturn(mail.getSurName()));

		//set body 
		this.getBodyProperties().put(MailTemplateConstants.PRODUCT_NAME, mail.getProductName());

        //PACSDP-3463 Handle given name in Sales email
        //Given Name is optional, Surname is mandatory
        String fullName = ((mail.getGivenName()!= null && !mail.getGivenName().isEmpty())? (mail.getGivenName()+" "):"") +
                          ((mail.getSurName()!= null && !mail.getSurName().isEmpty())? mail.getSurName():"");
		this.getBodyProperties().put(MailTemplateConstants.FULLNAME, fullName);

		this.getBodyProperties().put(MailTemplateConstants.AGENT_NAME, mail.getAgentName());
		this.getBodyProperties().put(MailTemplateConstants.BEGINNING_TITLE,
		    DataUtils.getBeginningTitleDescription(mail.getIsExistingClient()));
		this.getBodyProperties().put(MailTemplateConstants.POLICY_NUMBER, mail.getPolicyNumber());
		this.getBodyProperties().put(MailTemplateConstants.MOBILE_NUMBER, mail.getMobilePhone());
		this.getBodyProperties().put(MailTemplateConstants.EMAIL_ADDRESS, mail.getCustomerEmail());
		this.getBodyProperties().put(MailTemplateConstants.NRIC, mail.getNricFin());
		this.getBodyProperties().put(MailTemplateConstants.NATIONALITY_NAME,mail.getNationalityName());
		this.getBodyProperties().put(MailTemplateConstants.GENDER_NAME, mail.getGender());
		this.getBodyProperties().put(MailTemplateConstants.DOB,mail.getDob() );
	
		this.setMailImages(new String[]{MailTemplateConstants.PIC_PRULOGO});
		

	}

	public AgentMailContent(ChannelAPIReportSalesView channelAPIReportSalesView, MailTemplates templates, CustomerApplication customerApplication, boolean isExistingClient) {

		super();
		this.setMailDetail(templates.getAgent());
		this.getMailDetail().setSendTo(channelAPIReportSalesView.getAgentEmail());

		this.getSubjectProperties().put(MailTemplateConstants.CLIENT_STATUS, DataUtils.getExistingClientTitle(isExistingClient));
		this.getSubjectProperties().put(MailTemplateConstants.PRODUCT_NAME, channelAPIReportSalesView.getProductName());
		this.getSubjectProperties().put(MailTemplateConstants.GIVENNAME_NAME, D2CUtils.checkNullAndReturn(customerApplication.getGivenName()));
		this.getSubjectProperties().put(MailTemplateConstants.SURNAME_NAME, D2CUtils.checkNullAndReturn(customerApplication.getSurName()));

		this.getBodyProperties().put(MailTemplateConstants.PRODUCT_NAME, channelAPIReportSalesView.getProductName());

		String fullName = ((customerApplication.getGivenName()!= null && !customerApplication.getGivenName().isEmpty())? (customerApplication.getGivenName()+" "):"") +
				((customerApplication.getSurName()!= null && !customerApplication.getSurName().isEmpty())? customerApplication.getSurName():"");
		this.getBodyProperties().put(MailTemplateConstants.FULLNAME, fullName);

		this.getBodyProperties().put(MailTemplateConstants.AGENT_NAME, channelAPIReportSalesView.getAgentName());
		this.getBodyProperties().put(MailTemplateConstants.BEGINNING_TITLE,
				DataUtils.getBeginningTitleDescription(isExistingClient));
		this.getBodyProperties().put(MailTemplateConstants.POLICY_NUMBER, channelAPIReportSalesView.getProposalNo());
		this.getBodyProperties().put(MailTemplateConstants.MOBILE_NUMBER, channelAPIReportSalesView.getMobile());
		this.getBodyProperties().put(MailTemplateConstants.EMAIL_ADDRESS, channelAPIReportSalesView.getEmail());
		this.getBodyProperties().put(MailTemplateConstants.NRIC, customerApplication.getNricFin());
		this.getBodyProperties().put(MailTemplateConstants.NATIONALITY_NAME,customerApplication.getNationality());
		this.getBodyProperties().put(MailTemplateConstants.GENDER_NAME, customerApplication.getGender());
		this.getBodyProperties().put(MailTemplateConstants.DOB,channelAPIReportSalesView.getDob());

		this.setMailImages(new String[]{MailTemplateConstants.PIC_PRULOGO});

	}
	
	public AgentMailContent(DigitalEndowmentAPIReportSalesView digitalEndowmentAPIReportSalesView, MailTemplates templates, CustomerApplication customerApplication, boolean isExistingClient) {

		super();
		this.setMailDetail(templates.getAgent());
		this.getMailDetail().setSendTo(digitalEndowmentAPIReportSalesView.getAgentEmail());

		this.getSubjectProperties().put(MailTemplateConstants.CLIENT_STATUS, DataUtils.getExistingClientTitle(isExistingClient));
		this.getSubjectProperties().put(MailTemplateConstants.PRODUCT_NAME, digitalEndowmentAPIReportSalesView.getProductName());
		this.getSubjectProperties().put(MailTemplateConstants.GIVENNAME_NAME, D2CUtils.checkNullAndReturn(customerApplication.getGivenName()));
		this.getSubjectProperties().put(MailTemplateConstants.SURNAME_NAME, D2CUtils.checkNullAndReturn(customerApplication.getSurName()));

		this.getBodyProperties().put(MailTemplateConstants.PRODUCT_NAME, digitalEndowmentAPIReportSalesView.getProductName());

		String fullName = ((customerApplication.getGivenName()!= null && !customerApplication.getGivenName().isEmpty())? (customerApplication.getGivenName()+" "):"") +
				((customerApplication.getSurName()!= null && !customerApplication.getSurName().isEmpty())? customerApplication.getSurName():"");
		this.getBodyProperties().put(MailTemplateConstants.FULLNAME, fullName);

		this.getBodyProperties().put(MailTemplateConstants.AGENT_NAME, digitalEndowmentAPIReportSalesView.getAgentName());
		this.getBodyProperties().put(MailTemplateConstants.BEGINNING_TITLE,
				DataUtils.getBeginningTitleDescription(isExistingClient));
		this.getBodyProperties().put(MailTemplateConstants.POLICY_NUMBER, digitalEndowmentAPIReportSalesView.getProposalNo());
		this.getBodyProperties().put(MailTemplateConstants.MOBILE_NUMBER, digitalEndowmentAPIReportSalesView.getMobile());
		this.getBodyProperties().put(MailTemplateConstants.EMAIL_ADDRESS, digitalEndowmentAPIReportSalesView.getEmail());
		this.getBodyProperties().put(MailTemplateConstants.NRIC, customerApplication.getNricFin());
		this.getBodyProperties().put(MailTemplateConstants.NATIONALITY_NAME,customerApplication.getNationality());
		this.getBodyProperties().put(MailTemplateConstants.GENDER_NAME, customerApplication.getGender());
		this.getBodyProperties().put(MailTemplateConstants.DOB,digitalEndowmentAPIReportSalesView.getDob());

		this.setMailImages(new String[]{MailTemplateConstants.PIC_PRULOGO});

	}
}
