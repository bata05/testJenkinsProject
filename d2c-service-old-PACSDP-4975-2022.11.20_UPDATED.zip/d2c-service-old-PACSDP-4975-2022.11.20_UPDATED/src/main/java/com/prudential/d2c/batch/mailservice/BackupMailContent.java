package com.prudential.d2c.batch.mailservice;

import java.sql.Blob;
import java.util.List;

import org.springframework.util.StringUtils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.prudential.d2c.common.MailTemplateConstants;
import com.prudential.d2c.entity.MailTemplates;
import com.prudential.d2c.entity.dto.MailList;
import com.prudential.d2c.entity.micro.PdfFile;
import com.prudential.d2c.exception.D2CException;
/**
 * This mailContent is used for sending email to agent when a customer has exceptions when submit lifeAsia data 
 * 
 * @see com.prudential.d2c.controller.ComputeController#submitEsub(com.prudential.d2c.entity.micro.Compute)
 *
 */
public class BackupMailContent extends MailContent {
	
	@SuppressWarnings("deprecation")
	public BackupMailContent(MailTemplates templates, MailList mail){
		super();
		this.setMailDetail(templates.getBackup());
		this.getMailDetail().setSendTo(mail.getAgentMail());
		this.setMailImages(new String[]{MailTemplateConstants.PIC_PRULOGO});
		
        Blob blob = mail.getFileList();
        try {
            if(!StringUtils.isEmpty(blob)){
                String fcontent = new String(blob.getBytes((long) 1, (int) blob.length()));
                ObjectMapper mapper = new ObjectMapper();
                TypeReference<List<PdfFile>> mapType = new TypeReference<List<PdfFile>>() {
                };
                List<PdfFile> jsonToPersonList = mapper.readValue(fcontent, mapType);
                this.getMailDetail().setFileList(jsonToPersonList);
            }
        } catch(Exception e){
            throw new D2CException("Read mail content failed !");
        }

	}
  
	

}
