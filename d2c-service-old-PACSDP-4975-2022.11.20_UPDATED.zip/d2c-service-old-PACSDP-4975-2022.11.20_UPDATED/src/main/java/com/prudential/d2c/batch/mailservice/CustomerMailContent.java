package com.prudential.d2c.batch.mailservice;

import static java.lang.String.format;

import java.io.InputStream;
import java.sql.Blob;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.prudential.d2c.common.Constants;
import com.prudential.d2c.common.MailTemplateConstants;
import com.prudential.d2c.entity.MailTemplates;
import com.prudential.d2c.entity.dto.ApplicationDocument;
import com.prudential.d2c.entity.dto.ChannelAPIDocument;
import com.prudential.d2c.entity.dto.ChannelAPIReportSalesView;
import com.prudential.d2c.entity.dto.CustomerApplication;
import com.prudential.d2c.entity.dto.DigitalEndowmentAPIDocument;
import com.prudential.d2c.entity.dto.DigitalEndowmentAPIReportSalesView;
import com.prudential.d2c.entity.dto.MailList;
import com.prudential.d2c.entity.micro.PdfFile;
import com.prudential.d2c.exception.D2CException;
import com.prudential.d2c.utils.D2CUtils;
import com.prudential.d2c.utils.DataUtils;
import com.prudential.d2c.utils.EncryptDecryptUtil;
import com.prudential.d2c.utils.PasswordUtil;
import com.prudential.d2c.utils.StaticFileUtil;

/**
 * This mailContent is used for sending email to customer when the customer successfully applies a policy
 */
public class CustomerMailContent extends MailContent {

	private static Logger LOGGER = LoggerFactory.getLogger(CustomerMailContent.class);
	
    private static final String EMAIL_TO_CUSTOMER_PREFIX = "email-to-customer_";
    private static final String EMAIL_TO_CUSTOMER_CHANNEL = "email-to-customer_PER";
    private static final String EMAIL_TO_CUSTOMER_DE = "email-to-customer_DIGITALENDOWMENT";
    private static final String[] PIC_CUSTOMER_GROUP = new String[]{"logo-slogan.png", "facebook.png", "insta.png", "linkedin.png", "youtube.png", "mail-title.jpg"};
    private static final String PAR_BASIC_NAME = "PRUAssure Rewards";
    private static final String PER_BASIC_NAME = "PRUEasy Rewards";
    private static final String PAS_BASIC_NAME = "PRUActive Saver III";
    private static final String PA_BASIC_NAME = "PRUPersonal Accident";
    private static final String PC_BASIC_NAME = "PRUCancer 360";
    private static final String PS_BASIC_NAME = "PRUShield";
    private static final String PL_BASIC_NAME = "PRUlady";
    private static final String PM_BASIC_NAME = "PRUman";
    private static final String PT_BASIC_NAME = "PRUProtect Term";
    private static final String PAT_BASIC_NAME = "PRUActive Term";
    private static final String SCB_CHANNEL_NAME = "SCB";
    
    private static final String STATIC_PDF_FILE_NAME = "Terms_and_Conditions_eContract_eCorrespondence_DP" + Constants.SUFFIX_PDF;

    @SuppressWarnings("deprecation")
	public CustomerMailContent(MailTemplates templates, MailList mail, CustomerApplication customerApplication, String viewLink,
                               ApplicationDocument applicationDocument) {
        super();
        LOGGER.info("CustomerMailContent for CustomerId : {} and eRef : {}",
                mail.getCustomId(), mail.getErefNo());

        if(applicationDocument==null){
            LOGGER.error("applicationDocument for CustomerId : {} and eRef : {} is null", D2CUtils.removeCRLF(mail.getCustomId()), D2CUtils.removeCRLF(mail.getErefNo()));
        }
        this.setMailDetail(templates.getCustomer());
        this.getMailDetail().setSendTo(mail.getCustomerEmail());

        this.setMailImages(PIC_CUSTOMER_GROUP);

        this.getSubjectProperties().put(MailTemplateConstants.PRODUCT_NAME, mail.getProductName());

        this.getBodyProperties().put(MailTemplateConstants.PRODUCT_NAME, mail.getProductName());
        this.getBodyProperties().put(MailTemplateConstants.EREF_NO, mail.getErefNo());

        String channel = customerApplication.getChannel();

        LOGGER.info("CA channel={}", channel);

        if (!StringUtils.isEmpty(mail.getPaymentType())) {
            this.getMailDetail().setTemplateName(EMAIL_TO_CUSTOMER_PREFIX + mail.getPaymentType() + Constants.SUFFIX_HTML);

            this.getBodyProperties().put(MailTemplateConstants.MOBILE_NUMBER, mail.getMobilePhone());
            this.getBodyProperties().put(MailTemplateConstants.POLICY_NUMBER, mail.getPolicyNumber());

        }
        // Handle Customer Email for PRUEasy Rewards
        if (PER_BASIC_NAME.equals(mail.getProductName())) {
            this.getMailDetail().setTemplateName(EMAIL_TO_CUSTOMER_PREFIX + "PER" + Constants.SUFFIX_HTML);
        }

        String guideHtml = getGuideHtmlContent(mail.getProductName());
        String fcHtml = getFCHtmlContent(mail, channel);
        LOGGER.debug("guideHtml={}", guideHtml);

        LOGGER.debug("fcHtml={}", fcHtml);

        this.getBodyProperties().put(MailTemplateConstants.VIEW_LINK, viewLink);
        this.getBodyProperties().put(MailTemplateConstants.GUIDEHTML, guideHtml);
        this.getBodyProperties().put(MailTemplateConstants.FCHTML, fcHtml);

        try {
            if(null !=mail.getDob() || null !=mail.getNricFin()) {
                SimpleDateFormat formatter = new SimpleDateFormat(Constants.DOBFORMAT, Locale.ENGLISH);
                Date dob = formatter.parse(mail.getDob());
                List<PdfFile> attachmentFiles = new ArrayList<PdfFile>();
                String password = PasswordUtil.generatePdfPassword(mail.getNricFin(),dob);
                if(null != applicationDocument.getPiDocument())attachmentFiles.add(encryptParsedAttachment(applicationDocument.getPiDocument(), password));
                if(null != applicationDocument.getProposalDocument())attachmentFiles.add(encryptParsedAttachment(applicationDocument.getProposalDocument(),password));

                InputStream is = StaticFileUtil.generateStaticPdfInputStream(STATIC_PDF_FILE_NAME);
                if (null != is) {
                    byte[] bytes = StaticFileUtil.readFile(is);
                    if (null != bytes) {
                        String rawData = new String(Base64.getEncoder().encode(bytes));
                        PdfFile staticPdf = new PdfFile();
                        staticPdf.setRawData(rawData);
                        staticPdf.setFileName(STATIC_PDF_FILE_NAME);

                        attachmentFiles.add(staticPdf);
                    }
                }

                if(!attachmentFiles.isEmpty())this.getMailDetail().setFileList(attachmentFiles);
            }
        }  catch (Exception e) {
            LOGGER.error("Failed to add attachments to customer email with eRef: {} - exception: {}", mail.getErefNo(), e);
            throw new D2CException(format("Customer email attachment failed for eRef: %s", mail.getErefNo()));
        }
    }
    
    public CustomerMailContent(ChannelAPIReportSalesView channelAPIReportSalesView, MailTemplates templates, CustomerApplication customerApplication, String viewLink, ChannelAPIDocument channelAPIDocument, boolean isExistingClient) {

        super();
        this.setMailDetail(templates.getCustomer());
        this.getMailDetail().setSendTo(customerApplication.getCustomerEmail());

        this.setMailImages(PIC_CUSTOMER_GROUP);

        this.getSubjectProperties().put(MailTemplateConstants.PRODUCT_NAME, channelAPIReportSalesView.getProductName());

        this.getBodyProperties().put(MailTemplateConstants.PRODUCT_NAME, channelAPIReportSalesView.getProductName());
        this.getBodyProperties().put(MailTemplateConstants.EREF_NO, channelAPIReportSalesView.getErefNo());

        this.getMailDetail().setTemplateName(EMAIL_TO_CUSTOMER_CHANNEL + Constants.SUFFIX_HTML);

        this.getBodyProperties().put(MailTemplateConstants.MOBILE_NUMBER, channelAPIReportSalesView.getMobile());
        this.getBodyProperties().put(MailTemplateConstants.POLICY_NUMBER, channelAPIReportSalesView.getProposalNo());


        // Handle Customer Email for PRUEasy Rewards
        if (PER_BASIC_NAME.equals(channelAPIReportSalesView.getProductName())) {
        	this.getMailDetail().setTemplateName(EMAIL_TO_CUSTOMER_PREFIX + "PER" + Constants.SUFFIX_HTML);
        }

        String guideHtml = getGuideHtmlContent(channelAPIReportSalesView.getProductName());
        String fcHtml = getChannelHtmlContent(channelAPIReportSalesView, isExistingClient);

        this.getBodyProperties().put(MailTemplateConstants.VIEW_LINK, viewLink);
        this.getBodyProperties().put(MailTemplateConstants.GUIDEHTML, guideHtml);
        this.getBodyProperties().put(MailTemplateConstants.FCHTML, fcHtml);

        try {
            if (null != channelAPIReportSalesView.getDob() || null != channelAPIReportSalesView.getNricSuffix()) {
                SimpleDateFormat formatter = new SimpleDateFormat(Constants.DOBFORMAT, Locale.ENGLISH);
                Date dob = formatter.parse(channelAPIReportSalesView.getDob());
                List<PdfFile> attachmentFiles = new ArrayList<PdfFile>();
                String password = PasswordUtil.generatePdfPassword(customerApplication.getNricFin(), dob);
                if (null != channelAPIDocument.getQuotationDoc()) {
                    attachmentFiles.add(encryptParsedAttachment(channelAPIDocument.getQuotationDoc(), password));
                }
                if (null != channelAPIDocument.getProposalDoc()) {
                    attachmentFiles.add(encryptParsedAttachment(channelAPIDocument.getProposalDoc(), password));
                }
                InputStream is = StaticFileUtil.generateStaticPdfInputStream(STATIC_PDF_FILE_NAME);
                byte[] bytes = StaticFileUtil.readFile(is);
                String rawData = new String(Base64.getEncoder().encode(bytes));
                PdfFile staticPdf = new PdfFile();
                staticPdf.setRawData(rawData);
                staticPdf.setFileName(STATIC_PDF_FILE_NAME);
                attachmentFiles.add(staticPdf);

                if (!attachmentFiles.isEmpty()) {
                    this.getMailDetail().setFileList(attachmentFiles);
                }
            }
        } catch (Exception e) {
            LOGGER.warn("Failed to add attachments to customer email with eRef: {} - exception: {}", channelAPIReportSalesView.getErefNo(), e);
            throw new D2CException(format("Customer email attachment failed for eRef: %s", channelAPIReportSalesView.getErefNo()));
        }

    }
    
    public CustomerMailContent(DigitalEndowmentAPIReportSalesView digitalEndowmentAPIReportSalesView, MailTemplates templates, CustomerApplication customerApplication, String viewLink, DigitalEndowmentAPIDocument digitalEndowmentAPIDocument, boolean isExistingClient) {

        super();
        this.setMailDetail(templates.getCustomerDE());
        this.getMailDetail().setSendTo(customerApplication.getCustomerEmail());
        this.getMailDetail().setTemplateName(EMAIL_TO_CUSTOMER_DE + Constants.SUFFIX_HTML);

        this.setMailImages(PIC_CUSTOMER_GROUP);

        this.getSubjectProperties().put(MailTemplateConstants.PRODUCT_NAME, digitalEndowmentAPIReportSalesView.getProductName());

        this.getBodyProperties().put(MailTemplateConstants.PRODUCT_NAME, digitalEndowmentAPIReportSalesView.getProductName());
        this.getBodyProperties().put(MailTemplateConstants.EREF_NO, digitalEndowmentAPIReportSalesView.getErefNo());

        this.getBodyProperties().put(MailTemplateConstants.MOBILE_NUMBER, digitalEndowmentAPIReportSalesView.getMobile());
        this.getBodyProperties().put(MailTemplateConstants.POLICY_NUMBER, digitalEndowmentAPIReportSalesView.getProposalNo());

        String guideHtml = getGuideHtmlContent(digitalEndowmentAPIReportSalesView.getProductName());
        String fcHtml = getDigitalEndowmentHtmlContent(digitalEndowmentAPIReportSalesView, isExistingClient);

        this.getBodyProperties().put(MailTemplateConstants.VIEW_LINK, viewLink);
        this.getBodyProperties().put(MailTemplateConstants.GUIDEHTML, guideHtml);
        this.getBodyProperties().put(MailTemplateConstants.FCHTML, fcHtml);

        try {
            if (null != digitalEndowmentAPIReportSalesView.getDob() || null != digitalEndowmentAPIReportSalesView.getNricSuffix()) {
                SimpleDateFormat formatter = new SimpleDateFormat(Constants.DOBFORMAT, Locale.ENGLISH);
                Date dob = formatter.parse(digitalEndowmentAPIReportSalesView.getDob());
                List<PdfFile> attachmentFiles = new ArrayList<PdfFile>();
                String password = PasswordUtil.generatePdfPassword(customerApplication.getNricFin(), dob);
                if (null != digitalEndowmentAPIDocument.getQuotationDoc()) {
                    attachmentFiles.add(encryptParsedAttachment(digitalEndowmentAPIDocument.getQuotationDoc(), password));
                }
                if (null != digitalEndowmentAPIDocument.getProposalDoc()) {
                    attachmentFiles.add(encryptParsedAttachment(digitalEndowmentAPIDocument.getProposalDoc(), password));
                }

                InputStream is = StaticFileUtil.generateStaticDePdfInputStream(STATIC_PDF_FILE_NAME);
                byte[] bytes = StaticFileUtil.readFile(is);
                String rawData = new String(Base64.getEncoder().encode(bytes));
                PdfFile staticPdf = new PdfFile();
                staticPdf.setRawData(rawData);
                staticPdf.setFileName(STATIC_PDF_FILE_NAME);
                attachmentFiles.add(staticPdf);

                if (!attachmentFiles.isEmpty()) {
                    this.getMailDetail().setFileList(attachmentFiles);
                }
            }
        } catch (Exception e) {
            LOGGER.warn("Failed to add attachments to customer email with eRef: {} - exception: {}", digitalEndowmentAPIReportSalesView.getErefNo(), e);
            throw new D2CException(format("Customer email attachment failed for eRef: %s", digitalEndowmentAPIReportSalesView.getErefNo()));
        }

    }

    private PdfFile encryptParsedAttachment(Blob doc, String pwd) throws Exception {
        PdfFile pdfFile = null;
        try {
            String fcontent = new String(doc.getBytes((long) 1, (int) doc.length()));
            ObjectMapper mapper = new ObjectMapper();
            TypeReference<PdfFile> mapType = new TypeReference<PdfFile>() {
            };
            pdfFile = mapper.readValue(fcontent, mapType);
            String encrptedPDFData = EncryptDecryptUtil.encryptPdfContent(pdfFile.getRawData(), pwd);
            pdfFile.setRawData(encrptedPDFData);
        } catch (Exception e) {
            LOGGER.warn("Pdf encryption failed for parsed attachment");
            throw e;
        }
        return pdfFile;

	}

    //PACSDP-3510
    @SuppressWarnings("deprecation")
	private String getFCHtmlContent(MailList mail, String channel) {
        StringBuilder sb = null;

        if (!StringUtils.isEmpty(channel) && channel.equalsIgnoreCase(SCB_CHANNEL_NAME)) {
            sb = getSCBFCHtmlContent();
        } else {
            sb = getNonSCBFCHtmlContent(mail);
        }

        return sb.toString();
    }

    //PACSDP-3510
    private StringBuilder getSCBFCHtmlContent() {
        StringBuilder sb = new StringBuilder();
        sb.append("<br>").append("\n");

        return sb;
    }

    //PACSDP-3510
    @SuppressWarnings("deprecation")
	private StringBuilder getNonSCBFCHtmlContent(MailList mail) {
        String agentName = mail.getAgentName();
        String agentMail = mail.getAgentMail();
        String agentMobile = mail.getAgentMobile();
        String paymentType = mail.getPaymentType();
        String contactDescription = DataUtils.getContactDescriptionDetail(mail.getIsExistingClient());

        StringBuilder sb = new StringBuilder();
        sb.append("<br>").append("\n");

        if (!StringUtils.isEmpty(paymentType)) {
            sb.append("<p>Any questions?</p>").append("\n");
            sb.append("<p>").append(contactDescription).append("</p>").append("\n");
        } else {
            sb.append("<p>Should you have any questions, please contact your Financial Consultant. The financial consultant assigned to support you is:</p>").append("\n");
        }

        sb.append("<br>").append("\n");
        sb.append("<table class=\"info-box\">").append("\n");
        sb.append("<tr><td></td></tr>").append("\n");
        sb.append("<tr><td>").append("\n");
        sb.append("<p>").append(agentName).append("</p>").append("\n");
        sb.append("<p><a>").append(agentMobile).append("</a></p>").append("\n");
        sb.append("<p><a>").append(agentMail).append("</a></p>").append("\n");
        sb.append("</td></tr>").append("\n");
        sb.append("</table>").append("\n");
        sb.append("<br>").append("\n");

        return sb;
    }

    @SuppressWarnings("deprecation")
	private String getChannelHtmlContent(ChannelAPIReportSalesView channelAPIReportSalesView, boolean isExistingClient) {
        String agentName = channelAPIReportSalesView.getAgentName();
        String agentMail = channelAPIReportSalesView.getAgentEmail();
        String agentMobile = channelAPIReportSalesView.getAgentContact();
        String paymentType = "CASH";
        String contactDescription = DataUtils.getContactDescriptionDetail(isExistingClient);

        StringBuilder sb = new StringBuilder();
        sb.append("<br>").append("\n");

        if (!StringUtils.isEmpty(paymentType)) {
            sb.append("<p>Any questions?</p>").append("\n");
            sb.append("<p>").append(contactDescription).append("</p>").append("\n");
        } else {
            sb.append("<p>Should you have any questions, please contact your Financial Consultant. The financial consultant assigned to support you is:</p>").append("\n");
        }

        sb.append("<br>").append("\n");
        sb.append("<table class=\"info-box\">").append("\n");
        sb.append("<tr><td></td></tr>").append("\n");
        sb.append("<tr><td>").append("\n");
        sb.append("<p>").append(agentName).append("</p>").append("\n");
        sb.append("<p><a>").append(agentMobile).append("</a></p>").append("\n");
        sb.append("<p><a>").append(agentMail).append("</a></p>").append("\n");
        sb.append("</td></tr>").append("\n");
        sb.append("</table>").append("\n");
        sb.append("<br>").append("\n");

        return sb.toString();
    }
    
    @SuppressWarnings("deprecation")
	private String getDigitalEndowmentHtmlContent(DigitalEndowmentAPIReportSalesView digitalEndowmentAPIReportSalesView, boolean isExistingClient) {
        String agentName = digitalEndowmentAPIReportSalesView.getAgentName();
        String agentMail = digitalEndowmentAPIReportSalesView.getAgentEmail();
        String agentMobile = digitalEndowmentAPIReportSalesView.getAgentContact();
        String paymentType = "CASH";
        String contactDescription = DataUtils.getContactDescriptionDetail(isExistingClient);

        StringBuilder sb = new StringBuilder();
        sb.append("<br>").append("\n");

        if (!StringUtils.isEmpty(paymentType)) {
            sb.append("<p>Any questions?</p>").append("\n");
            sb.append("<p>").append(contactDescription).append("</p>").append("\n");
        } else {
            sb.append("<p>Should you have any questions, please contact your Financial Consultant. The financial consultant assigned to support you is:</p>").append("\n");
        }

        sb.append("<br>").append("\n");
        sb.append("<table class=\"info-box\">").append("\n");
        sb.append("<tr><td></td></tr>").append("\n");
        sb.append("<tr><td>").append("\n");
        sb.append("<p>").append(agentName).append("</p>").append("\n");
        sb.append("<p><a>").append(agentMobile).append("</a></p>").append("\n");
        sb.append("<p><a>").append(agentMail).append("</a></p>").append("\n");
        sb.append("</td></tr>").append("\n");
        sb.append("</table>").append("\n");
        sb.append("<br>").append("\n");

        return sb.toString();
    }

    //PACSDP-3319
    private String getGuideHtmlContent(String productName) {
        StringBuilder sb = null;

        //Get Life Guide HTML content for PAS, PER, PT, PAT
        if (PAS_BASIC_NAME.equalsIgnoreCase(productName) || PER_BASIC_NAME.equalsIgnoreCase(productName) || PT_BASIC_NAME.equalsIgnoreCase(productName) || PAT_BASIC_NAME.equalsIgnoreCase(productName)) {
            sb = getLifeGuideHtmlContent();
        }

        //Get Health Guide HTML content for PA, PS, PL, PM, and PC
        if (PA_BASIC_NAME.equalsIgnoreCase(productName) || PS_BASIC_NAME.equalsIgnoreCase(productName) || PM_BASIC_NAME.equalsIgnoreCase(productName) || PL_BASIC_NAME.equalsIgnoreCase(productName)) {
            sb = getHealthGuideHtmlContent();
        }

        //for PC, both life and health will be added
        if (PC_BASIC_NAME.equalsIgnoreCase(productName)) {
            sb = getLifeAndHealthGuideHtmlContent();
        }
        
        //for PAR, only life will be added
        if (PAR_BASIC_NAME.equalsIgnoreCase(productName)) {
            sb = getLifeGuideHtmlContent();
        }


        return (sb != null ? sb.toString() : "");
    }

    //PACSDP-3319
    private StringBuilder getLifeGuideHtmlContent() {
        StringBuilder sb = new StringBuilder();

        sb.append("<br><br>").append("\n");
        sb.append("Your Guide to Life Insurance <a href=\"https://www.prudential.com.sg/~/media/prudential/PDF/guides/lia_en.pdf\" target=\"_blank\" id=\"guideToLifeEnglish\" name=\"guideToLifeEnglish\" title=\"Your Guide to Life Insurance English\">English</a> | <a href=\"https://www.prudential.com.sg/~/media/prudential/PDF/guides/lia_cn.pdf\" target=\"_blank\" id=\"guideToLifeChinese\" name=\"guideToLifeChinese\" title=\"Your Guide to Life Insurance Chinese\">Chinese</a><br>").append("\n");

        return sb;
    }

    //PACSDP-3319
    private StringBuilder getHealthGuideHtmlContent() {
        StringBuilder sb = new StringBuilder();

        sb.append("<br><br>").append("\n");
        sb.append("Your Guide to Health Insurance <a href=\"https://www.prudential.com.sg/~/media/prudential/PDF/guides/ygthi16_english.pdf\" target=\"_blank\" id=\"guideToHealthEnglish\" name=\"guideToHealthEnglish\" title=\"Your Guide to Health Insurance English\">English</a> | <a href=\"https://www.prudential.com.sg/~/media/prudential/PDF/guides/ygthi16_chinese.pdf\" target=\"_blank\" id=\"guideToHealthChinese\" name=\"guideToHealthChinese\" title=\"Your Guide to Health Insurance Chinese\">Chinese</a><br>").append("\n");
		sb.append("<br>").append("\n");
		sb.append("Evaluating my Health Insurance Coverage <a href=\"https://www.prudential.com.sg/-/media/Prudential/Images/guides/askPRU/HiddenLink/14092020/EVALUATING-MY-HEALTH-INSURANCE-COVERAGE-english\" target=\"_blank\" id=\"guideToHealthInfographicEnglish\" name=\"guideToHealthInfographicEnglish\" title=\"Evaluating my Health Insurance Coverage English\">English</a> | <a href=\"https://www.prudential.com.sg/-/media/Prudential/Images/guides/askPRU/HiddenLink/14092020/EVALUATING-MY-HEALTH-INSURANCE-COVERAGE-Chinese\" target=\"_blank\" id=\"guideToHealthInfographicChinese\" name=\"guideToHealthInfographicChinese\" title=\"Evaluating my Health Insurance Coverage Chinese\">Chinese</a><br>").append("\n");

        return sb;
    }

    //PACSDP-3319
    private StringBuilder getLifeAndHealthGuideHtmlContent() {
        StringBuilder sb = new StringBuilder();

        sb.append("<br><br>").append("\n");
        sb.append("Your Guide to Life Insurance <a href=\"https://www.prudential.com.sg/~/media/prudential/PDF/guides/lia_en.pdf\" target=\"_blank\" id=\"guideToLifeEnglish\" name=\"guideToLifeEnglish\" title=\"Your Guide to Life Insurance English\">English</a> | <a href=\"https://www.prudential.com.sg/~/media/prudential/PDF/guides/lia_cn.pdf\" target=\"_blank\" id=\"guideToLifeChinese\" name=\"guideToLifeChinese\" title=\"Your Guide to Life Insurance Chinese\">Chinese</a><br>").append("\n");
        sb.append("<br>").append("\n");
        sb.append("Your Guide to Health Insurance <a href=\"https://www.prudential.com.sg/~/media/prudential/PDF/guides/ygthi16_english.pdf\" target=\"_blank\" id=\"guideToHealthEnglish\" name=\"guideToHealthEnglish\" title=\"Your Guide to Health Insurance English\">English</a> | <a href=\"https://www.prudential.com.sg/~/media/prudential/PDF/guides/ygthi16_chinese.pdf\" target=\"_blank\" id=\"guideToHealthChinese\" name=\"guideToHealthChinese\" title=\"Your Guide to Health Insurance Chinese\">Chinese</a><br>").append("\n");
		sb.append("<br>").append("\n");
        sb.append("Evaluating my Health Insurance Coverage <a href=\"https://www.prudential.com.sg/-/media/Prudential/Images/guides/askPRU/HiddenLink/14092020/EVALUATING-MY-HEALTH-INSURANCE-COVERAGE-english\" target=\"_blank\" id=\"guideToHealthInfographicEnglish\" name=\"guideToHealthInfographicEnglish\" title=\"Evaluating my Health Insurance Coverage English\">English</a> | <a href=\"https://www.prudential.com.sg/-/media/Prudential/Images/guides/askPRU/HiddenLink/14092020/EVALUATING-MY-HEALTH-INSURANCE-COVERAGE-Chinese\" target=\"_blank\" id=\"guideToHealthInfographicChinese\" name=\"guideToHealthInfographicChinese\" title=\"Evaluating my Health Insurance Coverage Chinese\">Chinese</a><br>").append("\n");

        return sb;
    }

}
