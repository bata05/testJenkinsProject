package com.prudential.d2c.batch.mailservice;

import javax.annotation.PostConstruct;

import org.apache.velocity.Template;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.runtime.RuntimeConstants;
import org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader;
import org.springframework.stereotype.Component;

/**
 * This class is used to instantiate VelocityEngine when using velocity to generate emails or PDFs
 * getTemplate will be called for generating templates
 */
@Component
public class CustomizedVelocityEngine {

	private static final String CLASSPATH_LOADER = "classpath.resource.loader.class";
    private static final String CLASSPATH = "classpath";
    private VelocityEngine engine;
	
	@PostConstruct
	public void init() {
	    engine = new VelocityEngine();
	    engine.setProperty(RuntimeConstants.RESOURCE_LOADER, CLASSPATH);
        engine.setProperty(CLASSPATH_LOADER, ClasspathResourceLoader.class.getName());
        engine.init();
	}
	
	public Template getTemplate(String templateName) {
	    return engine.getTemplate(templateName);
    }

}
