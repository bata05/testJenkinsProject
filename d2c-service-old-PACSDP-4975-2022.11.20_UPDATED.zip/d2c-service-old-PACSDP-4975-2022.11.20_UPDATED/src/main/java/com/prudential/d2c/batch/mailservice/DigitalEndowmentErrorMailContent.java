package com.prudential.d2c.batch.mailservice;

import com.prudential.d2c.common.Constants;
import com.prudential.d2c.common.MailTemplateConstants;
import com.prudential.d2c.entity.MailTemplates;
/**
 * This mailContent is used for sending email to agent when a customer has exceptions when submit lifeAsia data 
 * 
 * @see com.prudential.d2c.controller.ComputeController#submitEsub(com.prudential.d2c.entity.micro.Compute)
 *
 */
public class DigitalEndowmentErrorMailContent extends MailContent {
	private static final String EMAIL_TO_INTERNAL_DE = "email-to-internal_DIGITALENDOWMENT_ERROR";

	
	public DigitalEndowmentErrorMailContent(MailTemplates templates, String toInternalErrorEmailList, String exceptionString){
		super();
		this.setMailDetail(templates.getDeInternalError());
		this.getMailDetail().setSubject("Digital Endowment Error Notification");
		this.getMailDetail().setTemplateName(EMAIL_TO_INTERNAL_DE + Constants.SUFFIX_HTML);
		this.getMailDetail().setSendTo(toInternalErrorEmailList);
		this.getBodyProperties().put(MailTemplateConstants.EXCEPTIONS, exceptionString);
		this.setMailImages(new String[]{MailTemplateConstants.PIC_PRULOGO});
		
	}
	
}
