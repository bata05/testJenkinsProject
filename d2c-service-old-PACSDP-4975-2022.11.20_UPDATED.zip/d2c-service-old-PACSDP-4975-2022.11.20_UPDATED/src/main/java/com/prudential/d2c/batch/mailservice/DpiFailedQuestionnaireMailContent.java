package com.prudential.d2c.batch.mailservice;

import com.prudential.d2c.common.MailTemplateConstants;
import com.prudential.d2c.entity.MailTemplate;
import com.prudential.d2c.entity.config.ReportConfig;
import com.prudential.d2c.entity.dto.CustomerApplication;
import com.prudential.d2c.entity.dto.MailList;
import com.prudential.d2c.entity.micro.PdfFile;
import com.prudential.d2c.exception.D2CException;
import com.prudential.d2c.utils.D2CUtils;
import com.prudential.d2c.utils.DateUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.List;

import static com.prudential.d2c.common.Constants.*;
import static com.prudential.d2c.utils.ExcelUtil.generateExcelByteStreamWithPassword;
import static java.lang.String.format;

public class DpiFailedQuestionnaireMailContent extends MailContent {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DpiFailedQuestionnaireMailContent.class);
	private static final String TEMPLATE_PREFIX = "email-for-dpi-failed-questionnaire";
	private static final String ATTACHMENT_FILE_NAME_PREFIX = "DP_Failed_DPI_Questionnaire_";
	private static final String[] COLUMNS = { "ENTRY TYPE", "NAME", "EMAIL", "MOBILE PHONE",
			"NRIC", "DATE OF BIRTH", "GENDER", "NATIONALITY",
			"PRODUCT TYPE", "PRODUCT NAME", "CAMPAIGN ID", "EXISTING CUSTOMER", "FAILED QUESTIONNAIRE"};
	public static final String[] TEMPLATE_IMAGES = new String[] { "logo-slogan.png", "facebook.png", "insta.png",
			"linkedin.png", "youtube.png" };
	
	@SuppressWarnings("deprecation")
	public DpiFailedQuestionnaireMailContent(MailTemplate dpiFailedQuestionnaireTemplate, MailList mail,
											 CustomerApplication customerApplication, ReportConfig reportConfig, String toEmailRecipients, String passwordPrefix) {
		LOGGER.debug("Mail content for DPI failed questionnaire email with CustomId: {}", D2CUtils.removeCRLF(mail.getCustomId()));
		this.setMailDetail(dpiFailedQuestionnaireTemplate);
		this.setMailImages(TEMPLATE_IMAGES);
		this.getMailDetail().setSendTo(toEmailRecipients);
		this.getMailDetail().setTemplateName(TEMPLATE_PREFIX + SUFFIX_HTML);
		
		try {
			//set subject properties
			this.getSubjectProperties().put(MailTemplateConstants.CURRENT_DATE, DateUtil.getNowDateTime(DATE_FORMAT_DDMMYYYY_HYPHEN_DELIMITER));
			
			//set body properties
			SimpleDateFormat fmt = new SimpleDateFormat(DATEFORMAT);
			Date appCreatedDate = fmt.parse(customerApplication.getCreateDate());
			this.getBodyProperties().put(MailTemplateConstants.APPLICATION_DATE, new SimpleDateFormat(DATETIME_FORMAT_DDMMMYYYY_SPACE_DELIMITER).format(appCreatedDate));
			
			//setup data for excel attachment
			List<String> data = new ArrayList<>();
			data.add(null == reportConfig ? customerApplication.getChannel() : reportConfig.getChannelDescription());
			data.add(mail.getGivenName() + " " + mail.getSurName());
			data.add(mail.getCustomerEmail());
			data.add(mail.getMobilePhone());
			data.add(mail.getNricFin());
			data.add(mail.getDob());
			data.add(mail.getGender());
			data.add(mail.getNationalityName());
			data.add(StringUtils.isEmpty(mail.getProductType()) ? customerApplication.getProductType() : mail.getProductType());
			data.add(mail.getProductName());
			data.add(customerApplication.getCampaignId());
			data.add(mail.getIsExistingClient() ? SHORT_YES : SHORT_NO);
			data.add(SHORT_YES);

			List<List<String>> repData = new ArrayList<>();
			repData.add(data);
			PdfFile attachment = new PdfFile();
			String rawData = new String(Base64.getEncoder().encode(generateExcelByteStreamWithPassword(COLUMNS, repData, passwordPrefix, null)));
			attachment.setRawData(rawData);
			attachment.setFileName(new StringBuilder().append(ATTACHMENT_FILE_NAME_PREFIX)
										   .append(DateUtil.getNowDateTime(DATE_FORMAT_DDMMMYYYY_HHMM))
										   .append(XL_EXTENSION).toString());
			List<PdfFile> attachmentFiles = new ArrayList<>();
			attachmentFiles.add(attachment);
			
			if (!attachmentFiles.isEmpty()) {
				this.getMailDetail().setExcelAttachment(attachmentFiles);
			}
		} catch (Exception e) {
			LOGGER.warn("Failed to add attachments to DPI failed questionnaire email with customId: {} - exception: {}", D2CUtils.removeCRLF(mail.getCustomId()),
					e);
			throw new D2CException(format("DPI_Failed_Questionnaire email attachment failed for customId: %s !!", D2CUtils.removeCRLF(mail.getCustomId())));
		}
	}
	
	
	
}
