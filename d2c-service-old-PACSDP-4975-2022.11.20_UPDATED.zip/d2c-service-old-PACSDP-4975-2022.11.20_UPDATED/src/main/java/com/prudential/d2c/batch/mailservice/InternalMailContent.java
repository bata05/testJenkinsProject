package com.prudential.d2c.batch.mailservice;

import static java.lang.String.format;
import static java.util.Arrays.asList;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.List;

import com.prudential.d2c.entity.ProductSalesInfo;
import com.prudential.d2c.entity.dto.ChannelAPIReportSalesView;
import com.prudential.d2c.service.CustomerApplicationService;
import com.prudential.d2c.service.impl.CustomerApplicationServiceImpl;
import com.prudential.d2c.utils.BeanUtil;
import com.prudential.d2c.utils.D2CUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.prudential.d2c.common.Constants;
import com.prudential.d2c.common.MailTemplateConstants;
import com.prudential.d2c.entity.MailTemplates;
import com.prudential.d2c.entity.config.ReportConfig;
import com.prudential.d2c.entity.dto.CustomerApplication;
import com.prudential.d2c.entity.dto.DigitalEndowmentAPIReportESubView;
import com.prudential.d2c.entity.dto.DigitalEndowmentAPIReportSalesView;
import com.prudential.d2c.entity.dto.DigitalEndowmentAPIReportTrancheView;
import com.prudential.d2c.entity.dto.MailList;
import com.prudential.d2c.entity.micro.PdfFile;
import com.prudential.d2c.exception.D2CException;
import com.prudential.d2c.utils.DataUtils;
import com.prudential.d2c.utils.ExcelUtil;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

/**
 * This mailContent is used for sending email to internal group when the
 * customer successfully applies a policy
 */
public class InternalMailContent extends MailContent {

    private static final String EMAIL_TO_INTERNAL_PREFIX = "email-to-internal";
    private static final String EMAIL_TO_INTERNALESUBREPORT_PREFIX = "email-to-internalesubreport";
    private static final String EMAIL_TO_INTERNALTRANCHEREPORT_PREFIX = "email-to-internaltranchereport";
    private static final String[] columns = {"Source", "Customer's Name", "Email", "Contact Number", "NRIC Suffix", "Date of Birth", "Gender", "Nationality",
            "Product Name", "Campaign ID", "New/Existing Customer", "Application Date", "Client Number", "Agent Code", "Agent Name", "Agent Contact Number",
            "Query Status", "Proposal Number", "eRef Number", "Premium Amount", "Referral Agent Code", "Payment Frequency"};
    private static final String[] channelAPIColumns = {"Customer's Name", "Email", "Contact Number", "NRIC Suffix", "Date of Birth", "Gender", "Nationality", "Product Name",
            "Application Date", "Proposal Number", "Pru eRef Number", "UOB eRef Number", "Premium Amount", "Client Number", "Agent Code", "Agent Name", "Agent Contact Number", "Payment Frequency"};
    private static final String[] deAPIColumns = {"Source", "Customer's Name", "Email", "Contact Number", "NRIC Suffix", "Date of Birth", "Gender", "Nationality",
    		"Product Code", "Product Name", "Campaign ID", "New/Existing Customer", "Application Date", "Client Number", "Agent Code", "Agent Name", "Agent Contact Number",
            "Proposal Number", "eRef Number", "Payment Method", "Premium Amount", "LSA/PSA Agent Code", "Referral Agent Code", "Marketing Consent"};
    private static final String[] deESubColumns = {"CONTRACT TYPE", "BUSINESS SOURCE", "FC CODE", "EREFERENCE NUMBER", "SINGLE PREMIUM", "CREDIT DATE", "CREDIT TIME", "TRANSACTION STATUS",
    		"CURRENT TOTAL PREM", "TRANCHE LIMIT"};
    private static final String[] deTrancheColumns = {"CONTRACT TYPE", "CHANNEL", "MAXIMUM TOTAL SINGLE PREMIUM", "CURRENT TOTAL SINGLE PREMIUM"};
    private static final String[] PIC_CUSTOMER_GROUP = new String[]{"logo-slogan.png", "facebook.png", "insta.png",
            "linkedin.png", "youtube.png", "mail-title.jpg"};
    private static Logger LOGGER = LoggerFactory.getLogger(InternalMailContent.class);
    private static final String defaultColomnValue = "N/A";
    private static final String MALE = "MALE";
    private static final String FEMALE = "FEMALE";
    private static final String PAYMENT_MODE_ZERO_ZERO = "00";
    private static final String PAYMENT_MODE_ZERO_ONE = "01";
    private static final List<String> SP_PROD_TYPES = asList("PGP", "PGRP");
    private static final List<String> SP_PROD_CODES = asList(Constants.CATEGORY_PAS_XB8, Constants.CATEGORY_PAS_XR8);

    @SuppressWarnings("deprecation")
	public InternalMailContent(MailTemplates templates, MailList mail, CustomerApplication customerApp,
                               String toInternalEmailList, ReportConfig reportConfig, List<ProductSalesInfo> productSalesInfosList, String prodCode) {
        super();
        LOGGER.debug("InternalMailContent for CustomerId : {} and eRef : {}", mail.getCustomId(), mail.getErefNo());
        this.setMailDetail(templates.getInternal());
        this.getMailDetail().setSendTo(toInternalEmailList);

        LocalDate currentDate = LocalDate.now();
        int currentTime = LocalTime.now().getHour();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("ddMMMyyyy");
        String formattedDate = currentDate.format(formatter);

        this.setMailImages(PIC_CUSTOMER_GROUP);
        this.getMailDetail().setTemplateName(EMAIL_TO_INTERNAL_PREFIX + Constants.SUFFIX_HTML);

        int noOfRecords = CollectionUtils.isEmpty(productSalesInfosList) ? 1 : productSalesInfosList.size();


        try {
            SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date createdDate = fmt.parse(customerApp.getCreateDate());
            this.getBodyProperties().put(MailTemplateConstants.APPLICATION_DATE, new SimpleDateFormat("ddMMMyyyy HH:mm:ss").format(createdDate));


            List<PdfFile> attachmentFiles = new ArrayList<PdfFile>();
            PdfFile attachment = new PdfFile();

            ArrayList<List<String>> fileData = new ArrayList<>();

            for (int i = 0; i < noOfRecords; i++) {
                List<String> data = new ArrayList<>();
                if (null != reportConfig) {
                    //PACSDP-4615 Update DP reports to show Source as UOB or UOB Mighty accordingly
                    String channelDescription=null;
                    if(reportConfig.getChannelDescription().equalsIgnoreCase("UOB MightyApp")){
                        channelDescription = "UOB";
                    }
                    else{
                        channelDescription = reportConfig.getChannelDescription();
                    }

                    data.add(setDefaultIfEmpty(channelDescription));
                } else {
                    data.add(setDefaultIfEmpty(customerApp.getChannel()));
                }

                data.add(setDefaultIfEmpty(customerApp.getCustomerName()));
                data.add(setDefaultIfEmpty(mail.getCustomerEmail() != null ? mail.getCustomerEmail() : customerApp.getCustomerEmail()));
                data.add(setDefaultIfEmpty(mail.getMobilePhone() != null ? mail.getMobilePhone() : customerApp.getMobilePhone()).replace("+", ""));

                try {
                    data.add(setDefaultIfEmpty(!StringUtils.isEmpty(mail.getNricFin()) ? org.apache.commons.lang.StringUtils.right(mail.getNricFin(), 4) : ""));
                } catch (Exception ex) {
                    LOGGER.error("Error setting value for NRIC Prefix in sales notification report for CustomerId : {} and eRef : {} error : {}", D2CUtils.removeCRLF(mail.getCustomId()), D2CUtils.removeCRLF(mail.getErefNo()), ex.getMessage());
                    data.add(defaultColomnValue);
                }

                data.add(setDefaultIfEmpty(mail.getDob()));
                String genderVal = mail.getGender();
                data.add(StringUtils.isEmpty(genderVal) ? defaultColomnValue :
                        (genderVal.equalsIgnoreCase("M") ? MALE
                                : genderVal.equalsIgnoreCase("F") ? FEMALE : genderVal));

                String nationalityCode = !StringUtils.isEmpty(customerApp.getNationality()) ? customerApp.getNationality() :
                        !StringUtils.isEmpty(mail.getNationality()) ? mail.getNationality() : "";
                try {
                    CustomerApplicationService customerApplicationService = BeanUtil.getBean(CustomerApplicationServiceImpl.class);
                    data.add(customerApplicationService.findNationalityName(nationalityCode));

                } catch (Exception ex) {
                    LOGGER.error("Error setting value for Nationality[Description] in sales notification report for CustomerId : {} and eRef : {} error : {}", mail.getCustomId(), mail.getErefNo(), ex.getMessage());
                    data.add(setDefaultIfEmpty(nationalityCode));
                }

                ProductSalesInfo productSalesInfo = !CollectionUtils.isEmpty(productSalesInfosList) ? productSalesInfosList.get(i) : null;

                data.add(setDefaultIfEmpty((productSalesInfo != null && !StringUtils.isEmpty(productSalesInfo.getComponentDesc())) ?
                        productSalesInfo.getComponentDesc() :
                        mail.getProductName()));
                data.add(setDefaultIfEmpty(customerApp.getCampaignId()));
                data.add(DataUtils.isExistingClient(mail.getIsExistingClient()));
                data.add(setDefaultIfEmpty(customerApp.getCreateDate()));
                data.add(setDefaultIfEmpty(customerApp.getClientNumber()));
                data.add(setDefaultIfEmpty(mail.getAgentCode()));
                data.add(setDefaultIfEmpty(mail.getAgentName()));
                data.add(setDefaultIfEmpty(mail.getAgentMobile()));
                data.add(setDefaultIfEmpty(mail.getStage()));

                data.add(setDefaultIfEmpty((productSalesInfo != null && !StringUtils.isEmpty(productSalesInfo.getProposalNo())) ?
                        productSalesInfo.getProposalNo() :
                        customerApp.getPolicyNo()));

                data.add(setDefaultIfEmpty((productSalesInfo != null && !StringUtils.isEmpty(productSalesInfo.getErefNo())) ?
                        productSalesInfo.getErefNo() :
                        mail.getErefNo()));


                data.add((productSalesInfo != null && productSalesInfo.getTotalPremium() != null) ?
                        productSalesInfo.getTotalPremium().toString() :
                        defaultColomnValue);
                data.add(setDefaultIfEmpty(mail.getReferralAgentCode()));
                data.add(this.getPaymentMode(customerApp.getProductType(), prodCode));
                fileData.add(data);
            }
            String rawData = new String(Base64.getEncoder().encode(ExcelUtil.generateExcelByteStream(columns, fileData, null)));
            attachment.setRawData(rawData);
            attachment.setFileName("DP_SALES_" + formattedDate + "_" + currentTime + Constants.XL_EXTENSION);
            attachmentFiles.add(attachment);

            if (!attachmentFiles.isEmpty()) {
                this.getMailDetail().setExcelAttachment(attachmentFiles);
            }
        } catch (Exception e) {
            LOGGER.warn("Failed to add attachments to internal email with eRef: {} - exception: {}", mail.getErefNo(),
                    e);
            throw new D2CException(format("Internal email attachment failed for eRef: %s !!", mail.getErefNo()));
        }


    }

    @SuppressWarnings("deprecation")
	private String setDefaultIfEmpty(String value) {
        return (StringUtils.isEmpty(value) ? defaultColomnValue : value);
    }

    public InternalMailContent(ChannelAPIReportSalesView channelAPIReportSalesView, MailTemplates templates, String toInternalEmailList, String channelDescription, String prodType, String prodCode) {

        super();


        LocalDate currentDate = LocalDate.now();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("ddMMMyyyy");
        String formattedDate = currentDate.format(formatter);

        this.setMailDetail(templates.getInternal());
        this.getMailDetail().setSendTo(toInternalEmailList);
        this.getMailDetail().setSubject("Completed Sales Notification");
        this.setMailImages(PIC_CUSTOMER_GROUP);
        this.getMailDetail().setTemplateName(EMAIL_TO_INTERNAL_PREFIX + Constants.SUFFIX_HTML);

        try {

            this.getBodyProperties().put(MailTemplateConstants.APPLICATION_DATE, new SimpleDateFormat("ddMMMyyyy HH:mm:ss").format(channelAPIReportSalesView.getCreateDate()).toUpperCase());

            List<PdfFile> attachmentFiles = new ArrayList<PdfFile>();
            PdfFile attachment = new PdfFile();

            ArrayList<List<String>> fileData = new ArrayList<>();
            fileData.add(getData(channelAPIReportSalesView, prodType, prodCode));

            String rawData = new String(Base64.getEncoder().encode(ExcelUtil.generateExcelByteStream(channelAPIColumns, fileData, channelDescription + "_SALES_" + formattedDate.toUpperCase())));
            attachment.setRawData(rawData);
            attachment.setFileName(channelDescription + "_Sales_" + formattedDate.toUpperCase() + Constants.XL_EXTENSION);
            attachmentFiles.add(attachment);

            if (!attachmentFiles.isEmpty()) {
                this.getMailDetail().setExcelAttachment(attachmentFiles);
            }
        } catch (Exception e) {
            LOGGER.warn("Failed to add attachments to internal email with eRef: {} - exception: {}", channelAPIReportSalesView.getErefNo(),
                    e);
            throw new D2CException(format("Internal email attachment failed for eRef: %s !!", channelAPIReportSalesView.getErefNo()));
        }

    }
    
    public InternalMailContent(DigitalEndowmentAPIReportSalesView digitalEndowmentAPIReportSalesView, MailTemplates templates, String toInternalEmailList, String channelDescription) {

        super();


        LocalDate currentDate = LocalDate.now();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("ddMMMyyyy");
        String formattedDate = currentDate.format(formatter);

        this.setMailDetail(templates.getInternal());
        this.getMailDetail().setSendTo(toInternalEmailList);
        this.getMailDetail().setSubject("Completed Sales Notification");
        this.setMailImages(PIC_CUSTOMER_GROUP);
        this.getMailDetail().setTemplateName(EMAIL_TO_INTERNAL_PREFIX + Constants.SUFFIX_HTML);

        try {

            this.getBodyProperties().put(MailTemplateConstants.APPLICATION_DATE, new SimpleDateFormat("ddMMMyyyy HH:mm:ss").format(digitalEndowmentAPIReportSalesView.getCreateDate()).toUpperCase());

            List<PdfFile> attachmentFiles = new ArrayList<PdfFile>();
            PdfFile attachment = new PdfFile();

            ArrayList<List<String>> fileData = new ArrayList<>();
            fileData.add(getDEData(digitalEndowmentAPIReportSalesView));

            String rawData = new String(Base64.getEncoder().encode(ExcelUtil.generateExcelByteStream(deAPIColumns, fileData, channelDescription + "_SALES_" + formattedDate.toUpperCase())));
            attachment.setRawData(rawData);
            attachment.setFileName(channelDescription + "_Sales_" + formattedDate.toUpperCase() + Constants.XL_EXTENSION);
            attachmentFiles.add(attachment);

            if (!attachmentFiles.isEmpty()) {
                this.getMailDetail().setExcelAttachment(attachmentFiles);
            }
        } catch (Exception e) {
            LOGGER.warn("Failed to add attachments to internal email with eRef: {} - exception: {}", digitalEndowmentAPIReportSalesView.getErefNo(),
                    e);
            throw new D2CException(format("Internal email attachment failed for eRef: %s ", digitalEndowmentAPIReportSalesView.getErefNo()));
        }

    }
    
    public InternalMailContent(List <DigitalEndowmentAPIReportESubView> digitalEndowmentAPIReportESubViewList, MailTemplates templates, String toInternalEmailList) {

        super();


        LocalDateTime currentDate = LocalDateTime.now();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("ddMMMyyyy_HHmm");
        String formattedDate = currentDate.format(formatter);

        this.setMailDetail(templates.getInternal());
        this.getMailDetail().setSendTo(toInternalEmailList);
        this.getMailDetail().setSubject("Digital Endowment Submission reports");
        this.setMailImages(PIC_CUSTOMER_GROUP);
        this.getMailDetail().setTemplateName(EMAIL_TO_INTERNALESUBREPORT_PREFIX + Constants.SUFFIX_HTML);
        
        int noOfRecords = CollectionUtils.isEmpty(digitalEndowmentAPIReportESubViewList) ? 1 : digitalEndowmentAPIReportESubViewList.size();

        try {

            this.getBodyProperties().put(MailTemplateConstants.APPLICATION_DATE, new SimpleDateFormat("ddMMMyyyy HH:mm:ss").format(new Date()).toUpperCase());

            List<PdfFile> attachmentFiles = new ArrayList<PdfFile>();
            PdfFile attachment = new PdfFile();

            ArrayList<List<String>> fileData = new ArrayList<>();
            List<String> dataRecord;
            
            for (int i = 0; i < noOfRecords; i++) {
            	DigitalEndowmentAPIReportESubView digitalEndowmentAPIReportESubView = !CollectionUtils.isEmpty(digitalEndowmentAPIReportESubViewList) ? digitalEndowmentAPIReportESubViewList.get(i) : null;

            	dataRecord = new ArrayList<String>();
            	dataRecord = getDEEsubData(digitalEndowmentAPIReportESubView);
            	fileData.add(dataRecord);
            }

            String rawData = new String(Base64.getEncoder().encode(ExcelUtil.generateExcelByteStream(deESubColumns, fileData, "Digital_Endowment_Submission_Report" + formattedDate.toUpperCase())));
            attachment.setRawData(rawData);
            attachment.setFileName("Digital_Endowment_Submission_Report" + formattedDate.toUpperCase() + Constants.XL_EXTENSION);
            attachmentFiles.add(attachment);

            if (!attachmentFiles.isEmpty()) {
                this.getMailDetail().setExcelAttachment(attachmentFiles);
            }
        } catch (Exception e) {
            LOGGER.warn("Failed to add attachments to internal esub report email {} - exception: {}", e);
            throw new D2CException(format("Internal email attachment failed for esub report"));
        }

    }
    
    public InternalMailContent(List <DigitalEndowmentAPIReportTrancheView> digitalEndowmentAPIReportTrancheViewList, MailTemplates templates, String toInternalEmailList, String mailType) {

        super();


        LocalDateTime currentDate = LocalDateTime.now();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("ddMMMyyyy_HHmm");
        String formattedDate = currentDate.format(formatter);

        this.setMailDetail(templates.getInternal());
        this.getMailDetail().setSendTo(toInternalEmailList);
        this.getMailDetail().setSubject("Digital Endowment Tranche Utilization_Report");
        this.setMailImages(PIC_CUSTOMER_GROUP);
        this.getMailDetail().setTemplateName(EMAIL_TO_INTERNALTRANCHEREPORT_PREFIX + Constants.SUFFIX_HTML);
        
        int noOfRecords = CollectionUtils.isEmpty(digitalEndowmentAPIReportTrancheViewList) ? 1 : digitalEndowmentAPIReportTrancheViewList.size();

        try {

            this.getBodyProperties().put(MailTemplateConstants.APPLICATION_DATE, new SimpleDateFormat("ddMMMyyyy HH:mm:ss").format(new Date()).toUpperCase());

            List<PdfFile> attachmentFiles = new ArrayList<PdfFile>();
            PdfFile attachment = new PdfFile();

            ArrayList<List<String>> fileData = new ArrayList<>();
            List<String> dataRecord;
            
            for (int i = 0; i < noOfRecords; i++) {
            	DigitalEndowmentAPIReportTrancheView digitalEndowmentAPIReportTrancheView = !CollectionUtils.isEmpty(digitalEndowmentAPIReportTrancheViewList) ? digitalEndowmentAPIReportTrancheViewList.get(i) : null;
            	
            	dataRecord = new ArrayList<String>();
            	dataRecord = getDETrancheData(digitalEndowmentAPIReportTrancheView);
            	fileData.add(dataRecord);
            }

            String rawData = new String(Base64.getEncoder().encode(ExcelUtil.generateExcelByteStream(deTrancheColumns, fileData, "Digital_Endowment_Tranche_Utilization_Report" + formattedDate.toUpperCase())));
            attachment.setRawData(rawData);
            attachment.setFileName("Digital_Endowment_Tranche_Utilization_Report" + formattedDate.toUpperCase() + Constants.XL_EXTENSION);
            attachmentFiles.add(attachment);

            if (!attachmentFiles.isEmpty()) {
                this.getMailDetail().setExcelAttachment(attachmentFiles);
            }
        } catch (Exception e) {
            LOGGER.warn("Failed to add attachments to internal tranche report email {} - exception: {}", e);
            throw new D2CException(format("Internal email attachment failed for tranche report"));
        }

    }

    private List<String> getData(ChannelAPIReportSalesView channelAPIReportSalesView, String prodType, String prodCode) {
        List<String> data = new ArrayList<>();
        data.add(setDefaultIfEmpty(channelAPIReportSalesView.getName()));
        data.add(setDefaultIfEmpty(channelAPIReportSalesView.getEmail()));
        data.add(setDefaultIfEmpty(channelAPIReportSalesView.getMobile()));
        data.add(setDefaultIfEmpty(channelAPIReportSalesView.getNricSuffix()));
        data.add(setDefaultIfEmpty(channelAPIReportSalesView.getDob()));
        data.add(setDefaultIfEmpty(channelAPIReportSalesView.getGender()));
        data.add(setDefaultIfEmpty(channelAPIReportSalesView.getNationality()));
        data.add(setDefaultIfEmpty(channelAPIReportSalesView.getProductName()));
        data.add(setDefaultIfEmpty(channelAPIReportSalesView.getApplicationDate()));
        data.add(setDefaultIfEmpty(channelAPIReportSalesView.getProposalNo()));
        data.add(setDefaultIfEmpty(channelAPIReportSalesView.getErefNo()));
        data.add(setDefaultIfEmpty(channelAPIReportSalesView.getChannelERefNo()));
        data.add(channelAPIReportSalesView.getPremiumAmount() != null ? String.valueOf(channelAPIReportSalesView.getPremiumAmount()) : defaultColomnValue);
        data.add(setDefaultIfEmpty(channelAPIReportSalesView.getClientNo()));
        data.add(setDefaultIfEmpty(channelAPIReportSalesView.getAgentCode()));
        data.add(setDefaultIfEmpty(channelAPIReportSalesView.getAgentName()));
        data.add(setDefaultIfEmpty(channelAPIReportSalesView.getAgentContact()));
        data.add(this.getPaymentMode(prodType, prodCode));
        return data;
    }
    
    private List<String> getDEData(DigitalEndowmentAPIReportSalesView digitalEndowmentAPIReportSalesView) {
        List<String> data = new ArrayList<>();
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportSalesView.getSource()));
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportSalesView.getName()));
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportSalesView.getEmail()));
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportSalesView.getMobile()));
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportSalesView.getNricSuffix()));
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportSalesView.getDob()));
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportSalesView.getGender()));
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportSalesView.getNationality()));
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportSalesView.getProductCode()));
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportSalesView.getProductName()));
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportSalesView.getCampaignId()));
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportSalesView.getExistingCustomer()));
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportSalesView.getApplicationDate()));
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportSalesView.getClientNo()));
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportSalesView.getAgentCode()));
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportSalesView.getAgentName()));
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportSalesView.getAgentContact()));
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportSalesView.getProposalNo()));
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportSalesView.getErefNo()));
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportSalesView.getPaymentMethod()));
        data.add(digitalEndowmentAPIReportSalesView.getPremiumAmount() != null ? String.valueOf(digitalEndowmentAPIReportSalesView.getPremiumAmount()) : defaultColomnValue);
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportSalesView.getPsaLsaAgentCode()));
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportSalesView.getReferralAgentCode()));
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportSalesView.getMarketingConsent()));
        return data;
    }

    private List<String> getDEEsubData(DigitalEndowmentAPIReportESubView digitalEndowmentAPIReportESubView) {
        List<String> data = new ArrayList<>();
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportESubView.getContractType()));
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportESubView.getBusinessSource()));
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportESubView.getFcCode()));
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportESubView.getEreferenceNumber()));
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportESubView.getSinglePremium()));
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportESubView.getCreditDate()));
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportESubView.getCreditTime()));
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportESubView.getTransactionStatus()));
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportESubView.getCurrentTotalPrem()));
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportESubView.getTrancheLimit()));
        return data;
    }
    
    private List<String> getDETrancheData(DigitalEndowmentAPIReportTrancheView digitalEndowmentAPIReportTrancheView) {
        List<String> data = new ArrayList<>();
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportTrancheView.getContractType()));
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportTrancheView.getChannel()));
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportTrancheView.getCurrentTotalSinglePremium()));
        data.add(setDefaultIfEmpty(digitalEndowmentAPIReportTrancheView.getMaximumTotalSinglePremium()));
        return data;
    }
    
    private String getPaymentMode(String prodType, String prodCode){
        if((prodType != null && SP_PROD_TYPES.contains(prodType.toUpperCase()))
                || (prodCode != null && SP_PROD_CODES.contains(prodCode.toUpperCase()))){
            return PAYMENT_MODE_ZERO_ZERO;
        }
        return PAYMENT_MODE_ZERO_ONE;
    }
}
