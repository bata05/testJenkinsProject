package com.prudential.d2c.batch.mailservice;

import java.io.FileNotFoundException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;

import com.prudential.d2c.common.Constants;
import com.prudential.d2c.common.MailTemplateConstants;
import com.prudential.d2c.entity.MailTemplates;
import com.prudential.d2c.entity.dto.CustomerApplication;
import com.prudential.d2c.entity.dto.MailList;
import com.prudential.d2c.utils.DataUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.ResourceUtils;

/**
 * This mailContent is used for sending email to agent when a policy needs leadgen help
 *
 */
public class LeadGenMailContent extends MailContent {
	private static final String GETHELP_MAIL_SUBJECT = "your ${clientStatus} has requested assistance with ${productName}";
    private static final String ABANDONED_MAIL_SUBJECT = "Your ${clientStatus}, ${givenName} ${surName} is interested in ${productName}";
    private static final String TIMEOUT_CLOSEBROWSER_MAIL_SUBJECT = "your ${clientStatus},${givenName} ${surName} has an unfinished application for ${productName}";
	private static final String LEADGEN_MAIL_TEMPLATE_NAME = "static/mailTemplate/email-to-LEADGEN.vm";
	private static final Logger LOGGER = LoggerFactory.getLogger(LeadGenMailContent.class);
    private VelocityContext velocityContext;
	private Template template;
	
    @Override
    public void handleValuesForMailDetail(String bodyContent, String subjectEnv) {
    
        this.setSubjectTitlesAndEmails(subjectEnv);
        StringWriter writer = new StringWriter();
        //No exception of type Object can be thrown; an exception type must be a subclass of Throwable
        template.merge(velocityContext, writer );

        this.getMailDetail().setContent(writer.toString());
        
    }
	public LeadGenMailContent(MailTemplates templates, MailList mail, final CustomizedVelocityEngine velocityEngine, 
		CustomerApplication customerApplication, String answerQMAY019, String answerQPS005, String answerQMAY018) {
        super();
        this.setMailDetail(templates.getLeadgen());
        this.setMailImages(new String[]{MailTemplateConstants.PIC_PRULOGO});
		this.getMailDetail().setSendTo(mail.getAgentMail());
		
		if (Constants.MAIL_GETHELP.equalsIgnoreCase(mail.getMailType())) {
			this.getMailDetail().setSubject(GETHELP_MAIL_SUBJECT);
		} else if (Constants.MAIL_TIMEOUT.equalsIgnoreCase(mail.getMailType())
				|| Constants.MAIL_CLOSE.equalsIgnoreCase(mail.getMailType())) {
			this.getMailDetail().setSubject(TIMEOUT_CLOSEBROWSER_MAIL_SUBJECT);
		} else {
			this.getMailDetail().setSubject(ABANDONED_MAIL_SUBJECT);
		}
		
		try {
			this.getMailDetail().setTemplateName(ResourceUtils.getFile(LEADGEN_MAIL_TEMPLATE_NAME).getAbsolutePath());
		} catch (FileNotFoundException e) {
			LOGGER.error("Error while reading leadgen mail template from path: {}", e);
			throw new RuntimeException("Failed to load the resources. Cannot process request.");
		}
		
		velocityContext = new VelocityContext();
		
		this.getSubjectProperties().put(MailTemplateConstants.CLIENT_STATUS, DataUtils.getExistingClientTitle(mail.getIsExistingClient()));
		this.getSubjectProperties().put(MailTemplateConstants.PRODUCT_NAME, mail.getProductName());
		this.getSubjectProperties().put(MailTemplateConstants.GIVENNAME_NAME, mail.getGivenName());
		this.getSubjectProperties().put(MailTemplateConstants.SURNAME_NAME, mail.getSurName());

		velocityContext.put(MailTemplateConstants.AGENT_NAME, mail.getAgentName());
		velocityContext.put(MailTemplateConstants.GIVENNAME_NAME, mail.getGivenName());
		velocityContext.put(MailTemplateConstants.SURNAME_NAME, mail.getSurName());
		
		velocityContext.put(MailTemplateConstants.PRODUCT_NAME, mail.getProductName());
		
		String[] pros = mail.getProductName().split(Constants.COMMA_SIGN);
		this.getSubjectProperties().put(MailTemplateConstants.PRODUCT_NAME, pros[0]);
		velocityContext.put(MailTemplateConstants.PRODUCT_NAME, pros[0]);
		List<String> riders = null;
		int i = 1;
		if(pros.length>1){
			riders = new ArrayList<>();
			while(i<pros.length){
				riders.add(pros[i]);
				i++;
			}
		}
		
		velocityContext.put(MailTemplateConstants.RIDERS,riders );
		
		velocityContext.put(MailTemplateConstants.HELP_DESCRIPTION, mail.getHelpDescription());
		
		velocityContext.put(MailTemplateConstants.STAGE_LEAD_GENERATED, mail.getStage());
		velocityContext.put(MailTemplateConstants.MOBILE_NUMBER, mail.getMobilePhone());
		velocityContext.put(MailTemplateConstants.HELP_DESCRIPTION, mail.getHelpDescription());
		velocityContext.put(MailTemplateConstants.EMAIL_ADDRESS, mail.getCustomerEmail());
		velocityContext.put(MailTemplateConstants.CONTACT_DAY, mail.getContactDay());
		velocityContext.put(MailTemplateConstants.CONTACT_TIME, mail.getContactTime());
		
		//CUSTOMER DETAILS
		velocityContext.put(MailTemplateConstants.NRIC, mail.getNricFin());
		velocityContext.put(MailTemplateConstants.DOB, mail.getDob());
		velocityContext.put(MailTemplateConstants.GENDER_NAME, mail.getGender());
		velocityContext.put(MailTemplateConstants.NATIONALITY_NAME, mail.getNationalityName());
		velocityContext.put(MailTemplateConstants.TXT_RESIDENCY_STATUS, customerApplication.getResidencyStatus());
		
		//APPLICATION DETAILS
		velocityContext.put(MailTemplateConstants.QMAY019, answerQMAY019);
		velocityContext.put(MailTemplateConstants.QPS005, answerQPS005);
		velocityContext.put(MailTemplateConstants.TXT_RESIDENTIAL_POSTALCODE, customerApplication.getResidentialPostalCode());
		velocityContext.put(MailTemplateConstants.TXT_RESIDENTIAL_BLOCKNO, customerApplication.getResidentialBlockNo());
		velocityContext.put(MailTemplateConstants.TXT_RESIDENTIAL_STREET, customerApplication.getResidentialStreetName());
		velocityContext.put(MailTemplateConstants.TXT_RESIDENTIAL_BUILDING, customerApplication.getResidentialBuildingName());
		velocityContext.put(MailTemplateConstants.TXT_RESIDENTIAL_UNITNO, customerApplication.getResidentialUnitNo());
		velocityContext.put(MailTemplateConstants.QMAY018, answerQMAY018);
		velocityContext.put(MailTemplateConstants.MARKETING_CONSENT, null);
		velocityContext.put(MailTemplateConstants.TXT_CAMPAIGN_ID, customerApplication.getCampaignId());
		velocityContext.put(MailTemplateConstants.TXT_DP_SOURCE, mail.getMailType());

		template = velocityEngine.getTemplate(this.getMailDetail().getTemplateName());
		
	}
	

}
