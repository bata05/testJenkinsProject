package com.prudential.d2c.batch.mailservice;

import java.util.Properties;

import org.apache.commons.lang3.StringUtils;

import com.prudential.d2c.common.Constants;
import com.prudential.d2c.common.MailTemplateConstants;
import com.prudential.d2c.entity.MailTemplate;
import com.prudential.d2c.utils.DataUtils;

public class MailContent {
	private MailTemplate mailDetail;
	private Properties subjectProperties ;
	private Properties bodyProperties ;
	private String[] mailImages;
	
	public MailContent(){
		bodyProperties = new Properties();
		subjectProperties = new Properties();
		mailDetail = new MailTemplate();
	}
	
	public void setSubjectTitlesAndEmails(String subjectEnv){
		
		this.getMailDetail().setSubject(DataUtils.composeMessageByProperties(this.getMailDetail().getSubject(),subjectProperties));
		if (StringUtils.isEmpty(subjectEnv)) {			
		   return;
		}
		
        //add title for different environments except prod
        if (!subjectEnv.equalsIgnoreCase(MailTemplateConstants.ENV_PROD)) {
            this.getMailDetail().setSubject(Constants.LEFT_BRACKET + subjectEnv.toUpperCase() + Constants.RIGHT_BRACKET + this.getMailDetail().getSubject());
        }
	}
	public void handleValuesForMailDetail(String bodyContent, String subjectEnv) {
		
		setSubjectTitlesAndEmails(subjectEnv);
		this.getMailDetail().setContent(DataUtils.composeMessageByProperties(bodyContent,bodyProperties));

	}


	public MailTemplate getMailDetail() {
		return mailDetail;
	}


	public void setMailDetail(MailTemplate mailDetail) {
		this.mailDetail = mailDetail;
	}

	public Properties getSubjectProperties() {
		return subjectProperties;
	}

	public Properties getBodyProperties() {
		return bodyProperties;
	}

	public void setSubjectProperties(Properties subjectProperties) {
		this.subjectProperties = subjectProperties;
	}

	public void setBodyProperties(Properties bodyProperties) {
		this.bodyProperties = bodyProperties;
	}
	public String[] getMailImages() {
		return mailImages;
	}
	public void setMailImages(String[] mailImages) {
		this.mailImages = mailImages;
	}


}
