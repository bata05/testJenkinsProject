package com.prudential.d2c.batch.mailservice;

import com.prudential.d2c.common.ConfigProperties;
import com.prudential.d2c.common.Constants;
import com.prudential.d2c.entity.EmailAutherticatorbean;
import com.prudential.d2c.entity.MailServer;
import com.prudential.d2c.entity.MailTemplate;
import com.prudential.d2c.entity.micro.PdfFile;
import com.prudential.d2c.exception.D2CException;
import com.prudential.d2c.repository.ChannelRepository;
import com.prudential.d2c.service.DominoService;
import com.prudential.d2c.utils.D2CUtils;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;
import java.util.Base64;
import java.util.Date;
import java.util.Map.Entry;
import java.util.Properties;

@Repository
public class MailSendService {
    @Autowired
    private ConfigProperties configProperties;
    @Autowired
    private DominoService dominoService;

    @Autowired
    private ChannelRepository channelRepository;

    private static final String MIME_TYPE_PDF = "application/pdf";
    
    private static final String MIME_TYPE_EXCEL = "application/vnd.ms-excel";

    private static final String MORE_STRING = ">";

    private static final String LESS_STRING = "<";

    private static final String MULTI_PART_VAULE = "related";

    private static final String MAIL_SMTP_SEND_PARTIAL_VALUE = "true";

    private static final String MAIL_SMTP_SEND_PARTIAL = "mail.smtp.sendPartial";

    private static final String MAIL_TRANSPORT_PROTOCOL_VALUE = "smtp";

    private static final String MAIL_TRANSPORT_PROTOCOL = "mail.transport.protocol";

    private static final String MAIL_SMTP_AUTH_VALUE = "false";

    private static final String MAIL_SMTP_AUTH = "mail.smtp.auth";

    private static final String MAIL_SMTP_HOST = "mail.smtp.host";

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

	private Transport transport;
	private Session mailSession;



	public Transport getTransport() {
		return transport;
	}

	public void setTransport(Transport transport) {
		this.transport = transport;
	}

	public Session getMailSession() {
		return mailSession;
	}

	public void setMailSession(Session mailSession) {
		this.mailSession = mailSession;
	}

	public void connectMailService(MailServer mailServer){

		EmailAutherticatorbean myEmailAuther = new EmailAutherticatorbean(mailServer.getMailUser(),
				mailServer.getMailPwd());
		Properties props = new Properties();
		props.setProperty(MAIL_SMTP_HOST, mailServer.getMailHost());
		props.setProperty(MAIL_SMTP_AUTH, MAIL_SMTP_AUTH_VALUE);
		props.setProperty(MAIL_TRANSPORT_PROTOCOL, MAIL_TRANSPORT_PROTOCOL_VALUE);
		props.setProperty(MAIL_SMTP_SEND_PARTIAL, MAIL_SMTP_SEND_PARTIAL_VALUE);

		mailSession = javax.mail.Session.getInstance(props, (Authenticator) myEmailAuther);
		mailSession.setDebug(mailServer.isDebug());

		try {
		    transport = mailSession.getTransport(MAIL_TRANSPORT_PROTOCOL_VALUE);
            transport.connect(mailServer.getMailHost(), mailServer.getMailPort(), mailServer.getMailUser(),
            		mailServer.getMailPwd());
        } catch (MessagingException e) {
            throw new D2CException("Error occured when connecting mail service. ", e);
        }
	}

    public void proceedSendMail(MailTemplate mailDetail, String channel, String mailType) {

        logger.info("proceedSendMail started.");

        MimeMessage mimeMsg = new javax.mail.internet.MimeMessage(mailSession);

        try {
            InternetAddress sentFrom = new InternetAddress(mailDetail.getMailFrom());
            mimeMsg.setFrom(sentFrom);

            InternetAddress[] sendTo = InternetAddress.parse(D2CUtils.removeCRLF(mailDetail.getSendTo()));
            mimeMsg.setRecipients(MimeMessage.RecipientType.TO, sendTo);

            String subject = mailDetail.getSubject();

            if (dominoService.isValidDominoChannelByCode(channel) && !mailType.equals(Constants.MAIL_CUSTOMER)) {
                String channelName = channelRepository.findByChannelCode(channel).getChannelName();
                subject += " (" + channelName + ")";
            }

            mimeMsg.setSubject(D2CUtils.removeCRLF(subject), D2CUtils.removeCRLF(mailDetail.getSubjectCode()));

            String ccListString = configProperties.getCcEmail();
            InternetAddress[] ccList = InternetAddress.parse(ccListString);
            mimeMsg.setRecipients(MimeMessage.RecipientType.CC, ccList);

            Multipart multipart = new MimeMultipart(MULTI_PART_VAULE);
            MimeBodyPart messageBodyPart = new MimeBodyPart();
            messageBodyPart.setContent(mailDetail.getContent(), mailDetail.getMimeType());
            multipart.addBodyPart(messageBodyPart);
            // add image
            for (Entry<String, String> entry : mailDetail.getMailImages().entrySet()) {
                multipart.addBodyPart(createImageMimeBodyPart(entry.getKey(), entry.getValue()));
            }

            // add attachment
            if (CollectionUtils.isNotEmpty(mailDetail.getFileList())) {
                for (PdfFile pdf : mailDetail.getFileList()) {
                    multipart.addBodyPart(createPdfBodyPart(pdf));
                }
            }
            
            // add excel attachment
            if (CollectionUtils.isNotEmpty(mailDetail.getExcelAttachment())) {
                for (PdfFile pdf : mailDetail.getExcelAttachment()) {
                    multipart.addBodyPart(createExcelBodyPart(pdf));
                }
            }

            mimeMsg.setContent(multipart);
            mimeMsg.setSentDate(new Date());
            mimeMsg.saveChanges();

            transport.sendMessage(mimeMsg, mimeMsg.getAllRecipients());
        } catch (MessagingException e) {
            logger.error("proceedSendMail - Error occured when sending mails. ");
            throw new D2CException("Error occured when sending mails ", e);
        }

    }

    public void proceedSendMail(MailTemplate mailDetail) {

        logger.info("proceedSendMail() started.");

        MimeMessage mimeMsg = new javax.mail.internet.MimeMessage(mailSession);

        try {
            InternetAddress sentFrom = new InternetAddress(mailDetail.getMailFrom());
            mimeMsg.setFrom(sentFrom);

            InternetAddress[] sendTo = InternetAddress.parse(D2CUtils.removeCRLF(mailDetail.getSendTo()));
            mimeMsg.setRecipients(MimeMessage.RecipientType.TO, sendTo);

            String subject = mailDetail.getSubject();

            mimeMsg.setSubject(D2CUtils.removeCRLF(subject), D2CUtils.removeCRLF(mailDetail.getSubjectCode()));

            Multipart multipart = new MimeMultipart(MULTI_PART_VAULE);
            MimeBodyPart messageBodyPart = new MimeBodyPart();
            messageBodyPart.setContent(mailDetail.getContent(), mailDetail.getMimeType());
            multipart.addBodyPart(messageBodyPart);
            // add image
            if (mailDetail.getMailImages()!=null) {
                for (Entry<String, String> entry : mailDetail.getMailImages().entrySet()) {
                    multipart.addBodyPart(createImageMimeBodyPart(entry.getKey(), entry.getValue()));
                }
            }

            // add attachment
            if (CollectionUtils.isNotEmpty(mailDetail.getFileList())) {
                for (PdfFile pdf : mailDetail.getFileList()) {
                    multipart.addBodyPart(createPdfBodyPart(pdf));
                }
            }

            // add excel attachment
            if (CollectionUtils.isNotEmpty(mailDetail.getExcelAttachment())) {
                for (PdfFile pdf : mailDetail.getExcelAttachment()) {
                    multipart.addBodyPart(createExcelBodyPart(pdf));
                }
            }

            mimeMsg.setContent(multipart);
            mimeMsg.setSentDate(new Date());
            mimeMsg.saveChanges();

            transport.sendMessage(mimeMsg, mimeMsg.getAllRecipients());
            logger.info("proceedSendMail() ended.");
        } catch (MessagingException e) {
            logger.error("proceedSendMail() - Error occured when sending mails. message={}",e.getMessage());
            throw new D2CException("Error occured when sending mails ", e);
        }

    }

	@SuppressWarnings("deprecation")
	public void closeConnection() {
		try {
			if(!StringUtils.isEmpty(transport)){
				transport.close();
			}
		} catch (MessagingException e) {
			logger.error("Caught exceptions when close mail transport:",e);
		}

	}

	private MimeBodyPart createImageMimeBodyPart(String imageName, String imagepath)
			throws MessagingException {
		MimeBodyPart jpgBody = new MimeBodyPart();
		FileDataSource fds = new FileDataSource(imagepath);
		jpgBody.setDataHandler(new DataHandler(fds));
		jpgBody.setContentID(LESS_STRING + imageName + MORE_STRING);
		jpgBody.setDisposition(MimeBodyPart.INLINE);

		return jpgBody;
	}

	private MimeBodyPart createPdfBodyPart(PdfFile pdf) throws MessagingException {

		MimeBodyPart fileBodyPart = new MimeBodyPart();
		DataSource pdfds = new ByteArrayDataSource(Base64.getDecoder().decode(pdf.getRawData()), MIME_TYPE_PDF);
		fileBodyPart.setDataHandler(new DataHandler(pdfds));
		fileBodyPart.setFileName(D2CUtils.removeCRLF(pdf.getFileName()));
		fileBodyPart.setDisposition(MimeBodyPart.ATTACHMENT);

		return fileBodyPart;
	}
	
	private MimeBodyPart createExcelBodyPart(PdfFile pdf) throws MessagingException {

		MimeBodyPart fileBodyPart = new MimeBodyPart();
		DataSource pdfds = new ByteArrayDataSource(Base64.getDecoder().decode(pdf.getRawData()), MIME_TYPE_EXCEL);
		fileBodyPart.setDataHandler(new DataHandler(pdfds));
		fileBodyPart.setFileName(D2CUtils.removeCRLF(pdf.getFileName()));
		fileBodyPart.setDisposition(MimeBodyPart.ATTACHMENT);

		return fileBodyPart;
	}
}
