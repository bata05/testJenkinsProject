package com.prudential.d2c.common;

public enum ChannelSource {

    DIA(1, "DIA"),
    UOB(2, "UOB"),
    SCB(3, "SCB"),
	KPL(4, "KPL"),
    // TODO: Change the code when finalised
    UOB_MIGHTY(5, "MYT");

    int id;
    String code;

    ChannelSource(int id, String code){
        this.id = id;
        this.code = code;
    }

    public int getId() {
        return id;
    }

    public String getCode() {
        return code;
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
