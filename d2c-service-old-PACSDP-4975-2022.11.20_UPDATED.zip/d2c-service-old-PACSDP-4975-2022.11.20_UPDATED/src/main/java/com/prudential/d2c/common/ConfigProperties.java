package com.prudential.d2c.common;

import org.springframework.beans.factory.annotation.Value;

import lombok.Getter;
import lombok.Setter;

/**
 * The properties which used in application will be read from respective properties file
 */

@Getter
@Setter
public abstract class ConfigProperties {

    @Value("${micro.appkey}")
    private String appkey;
    
    @Value("${micro.sqsengine.products}")
    private String productsUrl;
    
    @Value("${micro.compute.url}")
    private String computeUrl;
    
    @Value("${micro.computeAll.url}")
    private String computeAllUrl;
    
    @Value("${micro.agent.url}")
    private String agentUrl;
    
    @Value("${micro.esub.url}")
    private String esubUrl;
    
    @Value("${micro.esubV2.url}")
    private String esubUrlV2;
    
    @Value("${micro.esub.proposalnumfetch.url}")
    private String fetchProposalNumUrl;
    
    @Value("${micro.esub.pulseproposalnumfetch.url}")
    private String fetchPulseProposalNumUrl;
    
    @Value("${hsm.keystorelocation}")
    private String keystoreLocation;
    
    @Value("${hsm.keystorepassword}")
    private String keystorePassword;
    
    @Value("${hsm.ip}")
    private String hsmIP;
    
    @Value("${mail.host}")
    private String mailHost;
    
    @Value("${mail.user}")
    private String mailUser;
    
    @Value("${mail.cc}")
    private String ccEmail;
    
    @Value("${server.hostAddress}")
    private String host;
    
    @Value("${server.apiPath}")
    private String apiPath;
    
    @Value("${server.htmlPath}")
    private String htmlPath;
    
    @Value("${encryption.enable}")
    private String encryption;
    
    @Value("${d2c.mid}")
    private String mid;
    
    @Value("${micro.security.rsaKey.url}")
    private String rsaKeyUrl;

    @Value("${micro.security.authenticate}")
    private String authenticateUrl;
    
    @Value("${micro.security.otpRequest}")
    private String otpRequestUrl;
    
    @Value("${micro.security.otpVerify}")
    private String otpVerifyUrl;
    
    @Value("${micro.client.get}")
    private String clientInfofetch;
    
    @Value("${micro.client.search}")
    private String clientSearchUrl;
    
    @Value("${micro.client.policynumber}")
    private String clientInfoByPolicyNumber;
    
    @Value("${micro.client.checkPolicy}")
    private String checkPolicyByNric ;
    
    @Value("${micro.questionnaire.url}")
    private String questionnaireUrl;

    @Value("${micro.policy.getLast}")
    private String lastIssuedPolicyUrl;

    @Value("${micro.card.getCardInfo}")
    private String cardInfoUrl;

    @Value("${timeout.millis}")
    private long timeoutMillis;
    @Value("${otp.expiry}")
    private long otpExpiry;

    @Value("${payment.gateway}")
    private String paymentGateway;
    @Value("${payment.secretKey}")
    private String paymentSecretKey;

    @Value("${allow.origin}")
    private String allowOrigin;

    @Value("${otpVerify.attempt.times}")
    private int otpVerifyAttempTimes;

    @Value("${otpVerify.attempt.limitMinutes}")
    private int otpVerifyAttemptLimitMinutes;

    @Value("${otpRequest.limitMins}")
    private int otpRequestLimitMins;

    @Value("${pacs.key}")
    private String pacsKey;

    @Value("${pacs.salt}")
    private String pacsSalt;

    @Value("${default.campaignId}")
    private String defaultCampaignId;

    @Value("${mcApp.name}")
    private String mcAppName;
    @Value("${mcApp.id}")
    private String mcAppId;
    @Value("${mcApp.clientId}")
    private String mcAppClientId;
    @Value("${mcApp.clientSecret}")
    private String mcAppClientSecret;
    @Value("${mcApp.grantType}")
    private String mcAppGrantType;
    @Value("${mcApp.requestToken.url}")
    private String mcAppRequestTokenUrl;
    @Value("${mcApp.events.url}")
    private String mcAppDataEventsUrl;
    @Value("${mcApp.event.definition}")
    private String mcAppEventDefinition;
    @Value("${mcApp.contacts.url}")
    private String mcAppContactsUrl;
    @Value("${micro.validate.agent.url}")
    private String validateAgentUrl;

    @Value("${server.env}")
    private String serverEnvironment;

    @Value("${job.timer}")
    private String jobTimer;

    // Cybersource Payment
    @Value("${3dscheck.wait.ms}")
    private int enrollCheckWaitMs;
    @Value("${onUs.mid}")
    private String onUsMID;
    @Value("${offUs.mid}")
    private String offUsMID;
    @Value("${cybersource.checkoutUrl}")
    private String cybCheckoutUrl;
    @Value("${cybersource.secretkey}")
    private String csSecretKey;
    @Value("${cybersource.accesskey}")
    private String csAccessKey;
    @Value("${cybersource.profileid}")
    private String csProfileId;

    @Value("${dp.esubJsonLog.enabled}")
    private int esubJsonLogEnabled;

    @Value("${timeout.pruaccess.params.seconds}")
    private int timeOutPruaccessParams;

    @Value("${timeout.hsm.storage.seconds}")
    private int timeOutHSMStorage;

    @Value("${sio.link.expiry.first.campaign}")
    private String SIOLinkExpiryFirstCamp;
    
    @Value("${dp.uob.private.key.location}")
    private String rsaPrivateKeyLocation;

    @Value("${dp.uob.public.key.location}")
    private String rsaPublicKeyLocation;

    @Value("${front.token.url}")
    private String frontTokenURL;
    
    @Value("${request.payment.prupay.url}")
    private String prupayURL;
    
    @Value("${update.tranche.url}")
    private String updateTrancheURL;
    
    @Value("${fetch.document.url}")
    private String fetchDocumentURL;
    
    @Value("${dp.prupay.security}")
    private String base64PrivateKey;
    
    @Value("${to.email.error.internal}")
    private String internalEmail;

    
    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "ConfigProperties [appkey=" + appkey + ", productsUrl=" + productsUrl + ", computeUrl=" + computeUrl
                + ", computeAllUrl=" + computeAllUrl + ", agentUrl=" + agentUrl + ", esubUrl=" + esubUrl
                + ", keystoreLocation=" + keystoreLocation + ", keystorePassword=" + keystorePassword + ", hsmIP="
                + hsmIP + ", mailHost=" + mailHost + ", mailUser=" + mailUser + ", host=" + host + ", apiPath="
                + apiPath + ", htmlPath=" + htmlPath + ", encryption=" + encryption + ", mid=" + mid + ", rsaKeyUrl="
                + rsaKeyUrl + ", authenticateUrl=" + authenticateUrl + ", otpRequestUrl=" + otpRequestUrl
                + ", otpVerifyUrl=" + otpVerifyUrl + ", clientInfofetch=" + clientInfofetch + ", clientSearchUrl="
                + clientSearchUrl + ", questionnaireUrl=" + questionnaireUrl + ", lastIssuedPolicyUrl="
                + lastIssuedPolicyUrl + ", cardInfoUrl=" + cardInfoUrl + ", timeoutMillis=" + timeoutMillis
                + ", otpExpiry=" + otpExpiry + ", paymentGateway=" + paymentGateway + ", paymentSecretKey="
                + paymentSecretKey + ", allowOrigin=" + allowOrigin + ", otpVerifyAttempTimes=" + otpVerifyAttempTimes
                + ", otpVerifyAttemptLimitMinutes=" + otpVerifyAttemptLimitMinutes + ", otpRequestLimitMins="
                + otpRequestLimitMins + ", pacsKey=" + pacsKey + ", pacsSalt=" + pacsSalt + ", defaultCampaignId="
                + defaultCampaignId + ", mcAppName=" + mcAppName + ", mcAppId=" + mcAppId + ", mcAppClientId="
                + mcAppClientId + ", mcAppClientSecret=" + mcAppClientSecret + ", mcAppRequestTokenUrl="
                + mcAppRequestTokenUrl + ", mcAppDataEventsUrl=" + mcAppDataEventsUrl + ", mcAppEventDefinition="
                + mcAppEventDefinition + ", mcAppContactsUrl=" + mcAppContactsUrl + ", serverEnvironment="
                + serverEnvironment + ", jobTimer=" + jobTimer + ", enrollCheckWaitMs=" + enrollCheckWaitMs
                + ", onUsMID=" + onUsMID + ", offUsMID=" + offUsMID + ", cybCheckoutUrl=" + cybCheckoutUrl
                + ", csSecretKey=" + csSecretKey + ", csAccessKey=" + csAccessKey + ", csProfileId=" + csProfileId
                + ", clientInfoByPolicyNumber=" + clientInfoByPolicyNumber + ", checkPolicyByNric=" + checkPolicyByNric
                + "]";
    }

}
