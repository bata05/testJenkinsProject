package com.prudential.d2c.common;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static java.util.Arrays.asList;

public class Constants {

    private Constants() {

    }

    public static final String APP_NAME = "d2c-service";
    public static final String EQUAL_SIGN = "=";
    public static final String COMMA_SIGN = ",";
    public static final String DOT = ".";
    public static final String SLASH = "/";
    public static final String SLASH_SPACE = " / ";
    public static final String UNDERLINE = "_";
    public static final String HYPHEN = "-";
    public static final String PLUS = "+";
    public static final String SHARP = "#";
    public static final String SINGLE_QUOTE = "'";
    public static final String DOUBLE_QUOTE_ESCAPE = "\"";
    public static final String EMPTY_STRING = "";
    public static final String SPACE_STRING = " ";
    public static final String DOLLAR_IN_BRACKET = "[,$]";
    public static final String LEFT_BRACKET = "[";
    public static final String RIGHT_BRACKET = "] ";
    public static final String NEW_LINE = "\n";
    public static final char CHAR_COMMA = ',';
    public static final String COLON = " : ";
    public static final String FOUR_DIGIT_STAR = "****";
    public static final String SEMICOLON = ";";
    public static final String AMOUNT_ZERO = "$ 0.00";

    public static final String SHORT_YES = "Y";
    public static final String SHORT_NO = "N";
    public static final String STRING_YES = "YES";
    public static final String STRING_NO = "NO";

    public static final String ENCODING_UTF8 = "UTF-8";
    public static final String SUFFIX_HTML = ".html";
    public static final String SUFFIX_PDF = ".pdf";

    public static final String DOBFORMAT = "dd/MM/yyyy";
    public static final String DATEFORMAT = "yyyy-MM-dd HH:mm:ss";
    public static final String DATETIME_FORMAT = "yyyy-MM-dd-HH:mm:ss";
    public static final String DATETIME_FORMAT_MYINFO = "dd-MMM-yyyy HH:mm:ss";
    public static final String TIME_FORMAT_FOR_CYBSCR = "yyyy-MM-dd'T'HH:mm:ss'Z'";
    public static final String DATE_FORMAT_DDMMMYY = "ddMMMyy";
    public static final String DATE_FORMAT_DDMMYYYY = "ddMMyyyy";
    
    public static final String DATETIME_FORMAT_DDMMMYYYY_SPACE_DELIMITER = "dd MMM yyyy HH:mm:ss";
    public static final String DATE_FORMAT_DDMMYYYY_HYPHEN_DELIMITER = "dd-MM-yyyy";
    public static final String DATE_FORMAT_DDMMMYYYY_HHMM = "ddMMMyyyy_HHmm";
    public static final String DATE_FORMAT_DDMMMYYYY2 = "dd MMM yyyy";
    public static final String DATE_FORMAT_DDMMMYYYY3 = "dd MMMM yyyy";

    public static final String COMPUTE_ALL = "computeAll";
    public static final String VALID_BASE64 = "^([A-Za-z0-9+/]{4})*([A-Za-z0-9+/]{4}|[A-Za-z0-9+/]{3}=|[A-Za-z0-9+/]{2}==)$";

    public static final int SECONDS_OF_MUNITE = 60;
    public static final int MILLISECONDS_OF_SECOND = 1000;
    public static final String NONE = "None";

    //DROPDOWN CODE CATEGARY in DROPDOWNLIST Table
	// PFCOPT066 nationality
    // PFCOPT070 residential country (same as PFCOPT066)
    // MPFCOPT070 maximum country for one question
    // PFCOPT067 nation people
    public static final String DROPDOWN_CODE_OF_NATIONALITY = "PFCOPT066";
    public static final String DROPDOWN_CODE_OF_MAXIMUM_COUNTRY = "MPFCOPT070";
    public static final String DROP_DOWN_CODE_OF_COUNTRY = "PFCOPT070";
    public static final String DROPDOWN_SPR = "SPR";
    public static final String OPTION_OTHERS = "Others";

    //reg expression
    public static final String LETTER_NUMBER_REGEXP = "^[A-Za-z0-9]+$";
    public static final String NUMBER_REGEXP = "^[0-9]+$";
    public static final String NAME_REGEXP = "[A-Za-z\\-,.()/&#%@\\s]+$";
    public static final String SINGAPORE_POSTAL_CODE_REGEXP = "\\d{6}";
    public static final String OBJECT_NAME_REGEXP = "[\\w\\s\\-',.()/&#%@]+$";

    //config value in DB
    public static final String CONFIG_TRUE = "1";
    public static final String CONFIG_FALSE = "0";

    public static final String VALUE_NUM_1 = "1";

    // HSM config
    public static final int RANDOMLENGTH = 16;

    public static final int DOMAIN = 22;
    public static final int KEYINDEX = 1;
    public static final int KEYTYPEENC = 10;
    public static final int KEYTYPEDEC = 11;

    // System request
    public static final String APPVERSION = "1.0";
    public static final String APPNAME = "d2c";
    public static final String APPNAME_MIGHTY = "UOB-MIGHTY";
    public static final String APPNAME_PULSE = "Pulse";

    // E-Reference No
    public static final String TRANSACTIONTYPE = "DN";

    // Sign status
    public static final int SIGN_ONLINE = 1;
    public static final int SIGN_OFFLINE = 2;
    public static final int SIGN_UPDATING = 3;

    public static final String START_POLICY_STATUS = "0";
    public static final String SAVE_ABOUTYOU_STATUS = "1";
    public static final String SAVE_MOREABOUTYOU_STATUS = "2";
    public static final String SAVE_PRODUCT_SPECIFIED_STATUS = "3";
    //review/editable/existingCustomer/ timeout /leadgen
    public static final String SAVE_ALL_STATUS = "4";

    public static final String SAVE_ESUB_SUCCESS_STATUS = "10";

    // QuotationRequestType
    public static final String PRUPERSONAL_ACCIDENT = "PA";
    public static final String RECOVERY_AID = "RA";
    public static final String FRACTURE_CARE_PA = "FCPA";
    public static final String PRU_SHIELD = "PS";
    public static final String PRU_FLEXI_CASH = "PFC";
    public static final String PRU_EASY_TERM = "ET";
    public static final String PRU_PROTECT_TERM = "PT";
    public static final String PRU_SMART_MAN = "PM";
    public static final String PRU_SMART_LADY = "PL";
    public static final String PRU_GOLDEN_RP = "PGRP";
    public static final String PRU_TERM_VANTAGE = "PTV";
    public static final String PRU_INVESTOR_GUARANTEED_PLUS = "PGP";
    public static final String PRU_LIFE_MULTIPLIER_FLEX = "PLMF";
    public static final String PRU_TRIPLE_PROTECT = "PTP";
    public static final String PRU_ACTIVE_SAVER = "PAS";
    public static final String PRU_ACTIVE_TERM = "PAT";
    public static final String PRU_ACTIVE_RETIREMENT = "PAR";
    public static final String PRU_CANCER = "PC";

    //Doc_id
    public static final String PRU_SMART_MAN_ID = "id_prod_sm1";
    public static final String PRU_SMART_LADY_ID = "id_prod_sl2";

    //Age category for PL and PM
    public static final String PRU_MAN_AGE = "165";
    public static final String PRU_LADY_AGE = "275";

    //Currency
    public static final String SNG_CURRENCY = "SGD";

    public static final String SNG_IDD = "+65";

    //Residency Code
    public static final String SINGAPOREAN = "SNG";
    public static final String PERMANENT_RESIDENT = "SPR";
    public static final String SINGAPOREAN_CODE = "1";
    public static final String PERMANENT_RESIDENT_CODE = "2";
    public static final String OTHER_CODE = "3";

    //used for PA product checking
    //if it is over 50 , the compo product is XAD9 ,else XAD8
    public static final int PA_AGE_LIMIT = 50;
    // Country of Residency
    public static final String SINGAPORE = "SNG";
    // questionnaire prueasy/protect
    public static final String CHANNEL_NB = "NB";
    public static final String CHANNEL_SCB = "SCB";
    public static final String CHANNEL_EDM = "EDM";
    public static final String CHANNEL_DIA = "DIA";
    public static final String CHANNEL_PRU_ACCESS = "PRU";
    
    //PruShield Proposal - channel
    public static final String PS_CHANNEL_SCB = "SCB";
    public static final String PS_CHANNEL_UOB = "UOB";
    public static final String PS_CHANNEL_PUL = "PUL";
    
    public static final String DE_CHANNEL_PUL = "PUL";

    // category type
    public static final String CATEGORY_PA = "PAU";
    public static final String CATEGORY_PA_COMPO_XAD8 = "XAD8";
    public static final String CATEGORY_PA_COMPO_XAD9 = "XAD9";
    public static final String CATEGORY_PS = "PM1";
    public static final String CATEGORY_PS_COMPO = "PMR1";
    public static final String CATEGORY_PFC = "EC7";
    public static final String CATEGORY_PFC_COMPO = "DAN7";
    public static final String CATEGORY_PM = "SM1";
    public static final String CATEGORY_PM_COMPO = "XML1";
    public static final String CATEGORY_PL = "SL2";
    public static final String CATEGORY_PL_COMPO = "XSL4";
    public static final String CATEGORY_ET = "CT7";
    public static final String CATEGORY_ET_COMPO = "TGT2";
    public static final String CATEGORY_PTV = "LT4";
    public static final String CATEGORY_PTV_COMPO = "TLT8";
    public static final String CATEGORY_PGRP_AL = "AL7";// "AM7" another choice
    public static final String CATEGORY_PGRP_AL_COMPO = "ALA7";
    public static final String CATEGORY_PAS_XB8 = "XB8";
    public static final String CATEGORY_PAS_XR8 = "XR8";
    public static final String CATEGORY_PAS_EC28_COMPO = "EC28";
    public static final String CATEGORY_PAS_ES28_COMPO = "ES28";
    public static final String CATEGORY_PAS_XW8 = "XW8";
    public static final String CATEGORY_PAS_EX48_COMPO = "EX48";
    public static final String CATEGORY_PGP = "IN7";
    public static final String CATEGORY_PGP_COMPO = "INN7";
    public static final String CATEGORY_PT = "TB1";
    public static final String CATEGORY_PT_COMPO = "BBT1";
    public static final String CATEGORY_PLMF = "WR7_1";
    public static final String CATEGORY_PLMF_COMPO = "";
    public static final String PRU_CANCER_360_LA_COMPO_CODE = "CAN4";
    public static final String CATEGORY_PAR_IPF = "IPF";

    public static final String PGRP_RETIRE_AGE_SAMPLE = "60"; //only for call agent API, pgrp retried age can be 55,60,65,70

    public static final String DOCID_PREFIX = "id_prod_";
    public static final String RETURN_AGENT_VALUE = "1";
    public static final String AGENT_CHANNEL_PD = "PD";
    public static final String AGENT_SUB_CHANNEL_PD_SCB = "PD-SCB";
    public static final String AGENT_CHANNEL_PT = "DP";
    public static final String AGENT_SUB_CHANNEL_PT = "DPI";
    public static final String AGENT_CHANNEL_PUL = "DP";
    public static final String AGENT_SUB_CHANNEL_PUL = "PUL";
    public static final String AGENT_CHANNEL_FCLINK= "DP";
    public static final String AGENT_SUB_CHANNEL_FCLINK = "FCLINK";

    // MailType
    public static final String MAIL_AGENT = "AGENT";
    public static final String MAIL_BACKUP = "BACKUP";
    public static final String MAIL_NEW_LEAD = "NEW_LEAD";
    public static final String MAIL_EX_LEAD = "EXISTING_LEAD";
    public static final String MAIL_PTV_LEAD = "PTV_LEAD";
    public static final String MAIL_EDM_LEAD = "EDM_LEAD";
    public static final String MAIL_DE_LEAD = "DE_LEAD";
    public static final String MAIL_CUSTOMER = "CUSTOMER";
    public static final String MAIL_INTERNAL = "INTERNAL";
    public static final String MAIL_ERROR_INTERNAL = "ERROR_INTERNAL";
    public static final String MAIL_ESUB = "ESUB";
    public static final String MAIL_TRANCHE = "TRANCHE";
    public static final String MAIL_PLMF_LEAD = "PLMF_LEAD";

    public static final String MAIL_FAILQUESTION_LEAD = "FAILQUESTION_LEAD";
    public static final String MAIL_INELIGIBLE_LEAD = "INELIGIBLE_LEAD";
    public static final String MAIL_INCOMPLETEDATA_LEAD = "INCOMPLETEDATA_LEAD";
    public static final String MAIL_GETHELP = "GETHELP_LEAD";
    public static final String MAIL_TIMEOUT = "SESSIONTIMEOUT";
    public static final String MAIL_CLOSE = "CLOSEBROWSER";

    //encrytion decrytion
    public static final String ENCRYPT_METHOD_MD5 = "MD5";
    public static final String SHA256_ALGORITHM = "SHA-256";
    public static final String SHA512_ALGORITHM = "SHA-512";

    // use this configurable value to control sending mail to CRM switch
    //if the value is 1, send the mail to CRM
    //if the value is 0 , send the mail by DP
    public static final String MAIL_SENDER_TYPE = "MAIL_SENDER_TYPE";
    public static final int MAIL_SENDER_SALESFORCE = 1;
    public static final int MAIL_SENDER_DP = 0;
    public static final int ESUBMISSION_JSON_WRITE_ENABLED = 1;

    public static final String SALESFORCE_STATUS = "SALESFORCE_STATUS";
    public static final int SALESFORCE_ENABLE = 1;
    public static final int SALESFORCE_DISABLE = 0;
    
    public static final String AMT_0 = "0";

    /**
     * 0 : the email is prepared to be sent
     * 1 : mail is sent successfully in DP
     * 2 : exception happen when sending mails by DP
     * 3 : mail data is sent successfully to CRM(salesforce)
     * 4 : exception happen when sending mail data to CRM side
     * 5 : identifies the connection status with front end ,
     *     if lose the connection, the value will be 0,
     *     prepare to send emails
     * 6 : connection data is abandoned , no need to listen anymore
     */
    public static final int MAIL_ENABLE = 0;
    public static final int MAIL_SENDING_SUCCESS = 1;
    public static final int MAIL_SENDING_EXCEPTION = 2;
    public static final int MAIL_SALESFORCE_SUCCESS = 3;
    public static final int MAIL_SALESFORCE_EXCEPTION = 4;
    public static final int MAIL_CLOSE_VALUE = 5;
    public static final int MAIL_CLOSE_ABANDON = 6;
    public static final int MAIL_PROCESS_EXCEPTION = 7;

    public static final String MAIL_BACKUP_CONFIGURE = "BACKUP_MAIL";
    public static final String MAIL_GETHELP_CONFIGURE = "SERVICE_MAIL";

    public static final String AUTHTYPE_AGENT = "A";
    public static final String AUTHTYPE_CUSTOMER = "C";

    public static final String SUCCESS_STATUS = "success";
    public static final String ERROR_STATUS = "error";
    public static final String SUCCESS = "SUCCESS";
    public static final String FAIL = "FAIL";

    public static final String NOT_APPLICABLE = "N/A";

    public static final String POLICY_DESCRIPTION = "Is this to replace another policy?";

    // user action log
    public static final String ACTION_OTP_SUBMIT = "OTP SUBMIT";
    public static final String ACTION_OTP_REQUEST = "OTP REQUEST";

    // Marketing Cloud
    public static final String PROSPECT_CUSTOMER = "Prospect";
    public static final String EXISTING_CUSTOMER = "Existing";
    public static final String QMAY_QUESTION_TYPE = "QMAY";
    public static final String QPS_QUESTION_TYPE = "QPS";

    public static final String IMAGE_PATH = "static/img/";
    public static final String LOGO_IMG_NAME = "prulogo-mobile.png";
    public static final String CHECKBOX_IMG_NAME = "Checkbox_16x16.png";

    // System env generic
    public static final String D2C_PATH_ENV = "D2C_PATH";
    public static final String CONF_FOLDER_NAME = "/conf/";

    public static final String PAYMENT_MODE_YEARLY = "Y";
    public static final String PAYMENT_MODE_MONTHLY = "M";
    // CyberSource Payment
    public static final String TERM_URL = "handlePaRes";
    public static final String PAYMENT_HMAC_SHA256 = "HmacSHA256";
    public static final String PAYMENT_TIME_ZONE = "UTC";

    public static final boolean ON_US = true;
    public static final boolean OFF_US = false;

    public static final String ON_US_FLAG = "Y";
    public static final String OFF_US_FLAG = "N";
    
    public static final String TRUE_FLAG = "true";
    public static final String FALSE_FLAG = "false";

    public static final String CS_ERROR_DECISION = "ERROR";
    public static final String CS_ACCEPT_DECISION = "ACCEPT";
    public static final String CS_DECLINE_DECISION = "DECLINE";
    public static final String CS_REJECT_DECISION = "REJECT";
    public static final String CS_CANCEL_DECISION = "CANCEL";

    public static final String SUCCESS_REASON_CODE = "100";
    public static final String NOT_ENROLLED_REASON_CODE = "475";

    public static final String RUN_SERVICE = "true";
    public static final String SETUP_SERVICE = "payerAuthSetupService_run";
    public static final String CHECK_ENROLL_SERVICE = "payerAuthEnrollService_run";
    public static final String VALIDATE_ENROLL_SERVICE = "payerAuthValidateService_run";
    public static final String CC_AUTHORIZE_SERVICE = "ccAuthService_run";
    public static final String CC_CAPTURE_SERVICE = "ccCaptureService_run";

    public static final String SETUP_REPLY_REASON_CODE = "payerAuthSetupReply_reasonCode";
    public static final String SETUP_REPLY_ACCESS_TOKEN = "payerAuthSetupReply_accessToken";
    public static final String SETUP_REPLY_DEVICE_DATA_COLLECTION_URL = "payerAuthSetupReply_deviceDataCollectionURL";
    public static final String SETUP_REPLY_REFERENCE_ID = "payerAuthSetupReply_referenceID";
    
    public static final String ENROLL_SERVICE_REFERENCE_ID = "payerAuthEnrollService_referenceID";
    public static final String ENROLL_SERVICE_RETURN_URL = "payerAuthEnrollService_returnURL";
    public static final String ENROLL_SERVICE_ACS_WINDOW_SIZE = "payerAuthEnrollService_acsWindowSize";
    
    public static final String ENROLL_REPLY_ACS_TRANSACTIONID = "payerAuthEnrollReply_acsTransactionID";
    public static final String ENROLL_REPLY_AUTHENTICATION_RESULT = "payerAuthEnrollReply_authenticationResult";
    public static final String ENROLL_REPLY_CAVV = "payerAuthEnrollReply_cavv";
    public static final String ENROLL_REPLY_ACS_URL = "payerAuthEnrollReply_acsURL";
    public static final String ENROLL_REPLY_XID = "payerAuthEnrollReply_xid";
    public static final String ENROLL_REPLY_PAREQ = "payerAuthEnrollReply_paReq";
    public static final String ENROLL_REPLY_CHALLENGE_REQUIRED = "payerAuthEnrollReply_challengeRequired";
    public static final String ENROLL_REPLY_STEP_UP_URL = "payerAuthEnrollReply_stepUpUrl";
    public static final String ENROLL_REPLY_ACCESS_TOKEN = "payerAuthEnrollReply_accessToken";
    public static final String ENROLL_REPLY_AUTHENTICATION_TRANSACTION_ID = "payerAuthEnrollReply_authenticationTransactionID";
    public static final String ENROLL_REPLY_COMMERCEINDICATOR = "payerAuthEnrollReply_commerceIndicator";
    public static final String ENROLL_REPLY_ECIRAW = "payerAuthEnrollReply_eciRaw";
    public static final String ENROLL_REPLY_ECI = "payerAuthEnrollReply_eci";
    public static final String ENROLL_REPLY_SPECIFICATION_VERSION = "payerAuthEnrollReply_specificationVersion";
    public static final String ENROLL_REPLY_CARD_BIN = "payerAuthEnrollReply_cardBin";
    public static final String ENROLL_REPLY_CARD_TYPE_NAME = "payerAuthEnrollReply_cardTypeName";
    public static final String ENROLL_REPLY_THREE_DS_SERVER_TRANSACTION_ID = "payerAuthEnrollReply_threeDSServerTransactionID";
    public static final String ENROLL_REPLY_VERES_ENROLLED = "payerAuthEnrollReply_veresEnrolled";
    public static final String ENROLL_REPLY_UCAF_COLLECTION_INDICATOR = "payerAuthEnrollReply_ucafCollectionIndicator";
    public static final String ENROLL_REPLY_DIRECTORY_SERVER_TRANSACTION_ID = "payerAuthEnrollReply_directoryServerTransactionID";
    public static final String ENROLL_REPLY_PARES_STATUS  = "payerAuthEnrollReply_paresStatus";
    public static final String ENROLL_REPLY_REASONCODE  = "payerAuthEnrollReply_reasonCode";
    public static final String ENROLL_REPLY_STATUS = "payerAuthEnrollReply_authenticationStatusMessage";
    
    public static final String VALIDATE_REPLY_CAVV = "payerAuthValidateReply_cavv";
    public static final String VALIDATE_REPLY_XID = "payerAuthValidateReply_xid";
    public static final String VALIDATE_REPLY_UCAF_AUTHENTICATION_DATA = "payerAuthValidateReply_ucafAuthenticationData";
    public static final String VALIDATE_REPLY_REASONCODE = "payerAuthValidateReply_reasonCode";
    public static final String VALIDATE_REPLY_STATUS = "payerAuthValidateReply_authenticationStatusMessage";

    public static final String VALIDATE_AUTHENTICATION_TRANSACTION_ID = "payerAuthValidateService_authenticationTransactionID";
    public static final String VALIDATE_CCAUTHSERVICE_COMMERCEINDICATOR = "ccAuthService_commerceIndicator";
    public static final String VALIDATE_REPLY_PARES_STATUS = "payerAuthValidateReply_paresStatus";
    public static final String VALIDATE_REPLY_SPECIFICATION_VERSION = "payerAuthValidateReply_specificationVersion";
    
    public static final String BILL_TO_CITY = "billTo_city";
    public static final String BILL_TO_COUNTRY = "billTo_country";
    public static final String BILL_TO_EMAIL = "billTo_email";
    public static final String BILL_TO_FIRST_NAME = "billTo_firstName";
    public static final String BILL_TO_LAST_NAME = "billTo_lastName";
    public static final String BILL_TO_STREET1 = "billTo_street1";
    public static final String CARD_TYPE = "card_cardType";
    public static final String CARD_ACCOUNT_NUMBER = "card_accountNumber";
    public static final String CARD_EXPIRATION_MONTH = "card_expirationMonth";
    public static final String CARD_EXPIRATION_YEAR = "card_expirationYear";
    public static final String REQUEST_ID = "requestID";
    public static final String MERCHANT_ID = "merchantID";
    public static final String MERCHANT_REF_NO = "merchantReferenceCode";
    public static final String TOKEN = "recurringSubscriptionInfo_subscriptionID";
    //public static final String CARDTYP = "card_type";
    public static final String CURRENCY = "purchaseTotals_currency";
    public static final String AMOUNT = "purchaseTotals_grandTotalAmount";
    public static final String SIGNED_PARES = "payerAuthValidateService_signedPARes";
    public static final String DECISION = "decision";
    public static final String REASON_CODE = "reasonCode";
    
    public static final String UCAF_COLLECTION_INDICATOR = "ucaf_collectionIndicator";
    public static final String UCAF_AUTHENTICATION_DATA = "ucaf_authenticationData";

    public static final String CC_AUTH_SERVICE_CAVV = "ccAuthService_cavv";
    public static final String CC_AUTH_SERVICE_XID = "ccAuthService_xid";
    public static final String CC_AUTH_SERVICE_PA_SPECIFICATION_VERSION = "ccAuthService_paSpecificationVersion";
    public static final String CC_AUTH_SERVICE_DIRECTORY_SERVER_TRANSACTION_ID = "ccAuthService_directoryServerTransactionID";

    public static final String BANK_APPROVAL_CODE = "ccAuthReply_authorizationCode";
    public static final String BANK_RESPONSE_CODE = "ccAuthReply_processorResponse";

    public static final String CYB_VISA_CARD = "001";
    public static final String CYB_MASTER_CARD = "002";
    public static final String ESUB_VISA_CARD = "3";
    public static final String ESUB_MASTER_CARD = "2";
    public static final String ESUB_ENETS = "N";
    public static final String ESUB_ENETS_PAYMENTMETHOD = "EN";
    public static final String ESUB_ENETS_PAYMENTMETHOD_IDX = "12";
    
    public static final String TYDE_NEW_BUSINESS = "NBZ";

    public static final String SIGN_ERROR = "SIGN_ERROR";
    public static final String TOKEN_STATUS_FAIL = "TOKEN_FAIL";
    public static final String TOKEN_STATUS_SUCC = "TOKEN_SUCC";
    public static final String TOKEN_STATUS_CANC = "USER_CANCEL";
    public static final String CHECK_ENROLL_STATUS_WIP = "3DS_WIP";
    public static final String CHECK_ENROLL_STATUS_FAIL = "3DS_FAIL";
    public static final String CHECK_ENROLL_STATUS_NOT_ENROLLED = "NOT_ENROLLED";
    public static final String CHECK_ENROLL_STATUS_FRICTION = "FRICTION";
    public static final String CHECK_ENROLL_STATUS_SUCC = "3DS_SUCC";
    public static final String VALI_ENROLL_STATUS_FAIL = "AUTH_FAIL";
    public static final String VALI_ENROLL_STATUS_SUCC = "AUTH_SUCC";
    public static final String PAY_STATUS_WIP = "PAY_WIP";
    public static final String PAY_STATUS_FAIL = "PAY_FAIL";
    public static final String PAY_STATUS_SUCC = "PAY_SUCC";

    public static final String ENCRYPTIONKEY = "encryptionKey";
    public static final String CLIENTUDID = "clientUdid";


    public static final String PROPERTIES_SUFFIX = ".properties";

    public static final String CYB_CHECKOUT_URL = "https://testsecureacceptance.cybersource.com/token/create";

    // Proposal PDF
    public static final String DOLLAR = "$";
    public static final String DOLLAR_WITH_SPACE = "$ ";
    public static final String LEFT_PARENTHESES_WITH_SPACE = " (";
    public static final String RIGHT_PARENTHESES = ")";

    public static final String RESIDENCY_SC_AB = "SC";
    public static final String RESIDENCY_SC_FULL = "Singaporean";
    public static final String RESIDENCY_SPR_AB = "SPR";
    public static final String RESIDENCY_SPR_FULL = "Singapore Permanent Resident/Employment pass/Work permit";
    public static final String RESIDENCY_OTHER_AB = "OTH";
    public static final String RESIDENCY_OTHER_FULL = "Others (e.g. Dependant Pass/Long Term Visit Pass/Student Pass/Social Visit Pass, etc)";
    public static final String COUNTRY_OF_BIRTH_US = "US";
    public static final String COUNTRY_OF_BIRTH_NON_US = "Non US";
    public static final String NULL_STRING = "null";
    public static final String FEMALE_STRING = "Female";
    public static final String MALE_STRING = "Male";

    public static final String DEFAULT_MARITAL_STATUS = "Z";
    public static final String DEFAULT_EMPLOYMENT_TYPE = "F";
    public static final String ANNUAL_INCOME_TYPE = "1";
    public static final String DEFAULT_CLIENT_RELATIONSHIP = "FA";
    public static final String DEFAULT_CLIENT_ID = "1";

    public static final String OK_STRING = "OK";

    public static final String DEFAULT_HEIGHT_SIO="170";
    public static final String DEFAULT_WEIGHT_SIO="60";

    public final static String VALID_STATUS="valid";
    public final static String NON_VALID_STATUS="not valid";

    // mid config
    public static final String ON_US_MID = "uobsg_001500068234";
    public static final String OFF_US_MID = "uobsg_001500068242";

    public static final String LEAD_GEN_FLAG_LIKE_SQL = "LEAD_GEN_FLAG_";

    public static final Integer CONFIG_DELETE_INDICATOR = 1;

    public static final Integer PTV_MIN_ASSURED = 500000;
    public static final Integer PTV_MAX_ASSURED = 1000000;
    public static final Integer PTV_MIN_TERM = 10;
    public static final Integer PTV_MAX_TERM = 70;

    public static final Integer PAS_MAX_PREMIUM = 5000000;
    public static final Integer PAS_SRS_MIN_PREMIUM = 10000;
    public static final Integer PAS_CASH_MIN_PREMIUM = 10000;
    public static final Integer PAS_SRS_MIN_AGE = 19;

    public static final double PER_MIN_PREMIUM = 10000;
    public static final double PER_MAX_PREMIUM = 50000;
    public static final double PER_MIN_SUM_ASSURED = 30400.0;
    public static final double PER_MAX_SUM_ASSURED = 151600.0;


    public static final String PRODUCT_DOC_ID_IS_EMPTY = "Product Doc Id is empty ";

    // Doc Categories for encryption
    public static final String DOC_CATEGORY_PI = "BI";
    public static final String DOC_CATEGORY_PROPOSAL = "Proposal";
    public static final String XL_EXTENSION = ".xlsx";

    // DPI Product List
    public static final List<String> DPI_PRODUCT_LIST = Arrays.asList(PRU_PROTECT_TERM);

    // Company footer
    public static final String PRU_FOOTER = "Prudential Assurance Company Singapore (Pte) Limited, Reg. No 199002477Z";
    public static final String AGENT_CHANNEL_TIED = "AD";
    public static final String AGENT_CHANNEL_BANC = "PD";

    public static final List<String> DIRECT_ENTRY_CHANNEL_CODES = Collections.unmodifiableList(Arrays.asList("PUL","DTR"));
    public static final String FC_ENTRY_CHANNEL_CODE = "DTR";
    public static final String PULSE_ENTRY_CHANNEL_CODE = "PUL";

    public static final List<String> PAS_PRODUCT_CODE_LIST = Collections.unmodifiableList(Arrays.asList(ProductValidatorEnum.XW8.getProdCode(), ProductValidatorEnum.XR8.getProdCode(), ProductValidatorEnum.XB8.getProdCode()));

    public static final List<String> PAS_SP_PROD_CODES = asList("XB8", "XR8");

    public static final String SRS_PAYMENT = "R";
    
    public static final String SP_PAYMENT = "S";

    public static final String CASH_PAYMENT = "Q";

    public static final List<String> GENDER = asList("M", "F");

    public static final BigDecimal DISC_CALC_HUNDRED = new BigDecimal("100");

    public static final String RT_EQUAL_TO_PT = "Policy term must be same as Premium Term";

	public static final List<String> RES_STATUS_LIST = asList(RESIDENCY_SC_AB, RESIDENCY_SPR_AB, RESIDENCY_OTHER_AB);

    public static final String EMAIL_PATTERN="^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$";

    public static final List<String> INDUSTRY_CATEGORY_OTHER = asList("10", "11");

    public static final List<String> PAYMENT_MODE_LIST = asList("00", "01", "02", "04", "12");

    public static final Integer CHA_API_EDU_QUALI_REQUIRED_AGE = 62;
    
    public static final String ENTRY_NML = "NML";
    public static final String BASIC = "BASIC";
    public static final String PULSE_SRC_PD_UOB = "PD-UOB";
    public static final String PULSE_SRC_PD_SCB = "PD-SCB";
    public static final String PULSE_SUBCHANNEL = "G";
    
    public static final String PAYMENTMETHOD_SINGLEPREMIUM = "00";
    public static final String PRUPAY_BANKRETURNCODE = "00";
    public static final String PRUPAY_BANKAPPROVALCODE = "000000";
    public static final String MERCREF_APPEND = "00000000";
    public static final String TRANCHE_SOURCE_PULSE = "PULSE";
    public static final String TRANCHE_SOURCE_SCB = "D2C_SCB";
    public static final String TRANCHE_SOURCE_UOB = "D2C_UOB";
    public static final String TRANCHE_PREMIUM = "premium";
    public static final String TRANCHE_CHANNEL = "tranche_channel";
    public static final String TRANCHE_CLIENT = "clients";
    public static final String TRANCHE_PROPOSAL = "proposal";
    public static final String TRANCHE_AGENT = "agent";
    public static final String TRANCHE_STRING_DATATYPE = "String"; 
    public static final String TRANCHE_CUSTOMER_DATATYPE = "Customer";
    public static final String TRANCHE_PROPOSAL_DATATYPE = "Proposal";
    public static final String TRANCHE_AGENT_DATATYPE = "Agent";
    public static final String TRANCHE_NRIC = "NRIC";
    public static final String TRANCHE_STRING_TRUE = "true";
    public static final String TRANCHE_SUCCESS_CODE = "0";
    public static final String POA = "POA";
    public static final String ACTIVE = "Active";
    
    public static final String EMPLOYMENT_PASS = "Employment Pass";
    public static final String ENTRE_PASS = "Entre Pass";
    public static final String S_PASS = "S Pass";
    public static final String WORK_PERMIT = "Work Permit";
    public static final String CASH = "CASH";

    public static class ResponseStatus {

        public static final String SUCCESS = "success";

        public static final String ERROR = "error";

    }
}
