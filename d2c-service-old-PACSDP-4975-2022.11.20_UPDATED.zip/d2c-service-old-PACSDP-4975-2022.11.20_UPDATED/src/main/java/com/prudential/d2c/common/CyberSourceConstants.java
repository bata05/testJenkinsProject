/**
 * 
 */
package com.prudential.d2c.common;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * The constants list here will be used to CyberSource payment related features.
 */
public class CyberSourceConstants {

    private CyberSourceConstants() {

    }
    //properties mapping for parameters from cybersource.
    public static final String DECISION = "decision";

    public static final String REASON_CODE = "reason_code";

    public static final String SIGNATURE = "signature";
    
    public static final String REQ_AMOUNT = "req_amount";

    public static final String REQ_CARD_EXPIRY_DATE = "req_card_expiry_date";

    public static final String REQ_CARD_TYPE = "req_card_type";

    public static final String REQ_CARD_NUMBER = "req_card_number";

    public static final String REQ_CURRENCY = "req_currency";

    public static final String REQ_LOCALE = "req_locale";

    public static final String REQ_PAYMENT_METHOD = "req_payment_method";

    public static final String PAYMENT_TOKEN = "payment_token";

    public static final String REQ_REFERENCE_NUMBER = "req_reference_number";

    public static final String REQ_TRANSACTION_TYPE = "req_transaction_type";

    public static final String REQ_TRANSACTION_UUID = "req_transaction_uuid";

    public static final String SIGNED_FIELD_NAMES = "signed_field_names";
    
    public static final String REQ_BILL_TO_FORENAME = "req_bill_to_forename";
    
    public static final String REQ_BILL_TO_SURNAME = "req_bill_to_surname";
    
    public static final String REQ_BILL_TO_EMAIL = "req_bill_to_email";
    
    public static final String REQ_BILL_TO_ADDRESS_LINE1 = "req_bill_to_address_line1";
    
    public static final String REQ_BILL_TO_ADDRESS_CITY = "req_bill_to_address_city";
    
    public static final String REQ_BILL_TO_ADDRESS_COUNTRY = "req_bill_to_address_country";
    
    // CyberSourcePaymentController
    public static final String REQ_FIELDS_ERR = "The ErefNo is a required field.";

    public static final String GET_OBJ_PROP_VALUE_ERR = "Getting value from field {} is failed when generate signature for CyberSource and it will be ignored in the output signature.";

    public static final String GENERATE_SIGNATURE_FIALED = "Generate the signature fialed.";

    public static final String CYBER_SECURED_KEY_EMPTY_ERR = "CyberSource secured key in appliction properties is empty.";

    public static final String REQ_CYBER_CHECKOUT_FIELD_ERR = "The following fields Signature, SignedFieldNames, PaymentToken, ReferenceNumber, ReasonCode and Decision are required.";

    public static final String REQ_GEN_SIGNATURE_FIELDS_ERR = "Required fields for Custom Id, Signed field names and Reference numbers";
    
    public static final String MISS_MANDORY_CONFIG_DATA_ERROR = "Missing mandory config data: transactionUuid or accessKey or profileID or checkoutURL.";

    public static final String CYBER_CHECKOUT_RESULT_CHECKING_FAILED = "CyberSource checkout result checking failed.";

    //Make it comma delimited
    //public static final String CYBER_PRODUCT_CODES_DISCOUNT = "PM1,PM2,PMB";

    public static final List<String> CYBER_PRODUCT_CODES_DISCOUNT = Collections.unmodifiableList(Arrays.asList("PM1", "PM2", "PMB"));

    // CyberSourceServiceImpl
    public static final String LIFEASIA_CODE = "00";

    public static final String RETRIEVED_APPLICATION_INFO_FAILED = "Retrieved application information from database failed.";

    public static final String SAVE_CYBER_SOURCE_TO_DATABASE_FAILED = "Save the CyberSource payment to database into database failed.";

    public static final String HANDLE_ISSUEING_RESULT_FAILED = "Handle ISSUEING bank authentication result failed.";

    public static final String ERROR_HAPPENNED_WHILE_ENROLLMENT_CHECKING = "Error happenned while enrollment checking.";

    public static final String ERROR_HAPPENNED_WHILE_SERVICE_REQUEST_CHECKING = "Error happenned while service request checking.";
}
