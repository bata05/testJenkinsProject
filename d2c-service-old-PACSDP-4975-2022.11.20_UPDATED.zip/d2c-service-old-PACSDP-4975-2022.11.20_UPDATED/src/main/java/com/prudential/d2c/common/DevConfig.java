package com.prudential.d2c.common;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;

/**
 * The properties which used in application will be read from application.properties
 */
@Configuration
@Profile(value = "dev")
@PropertySource(value="classpath:application-dev.properties", ignoreResourceNotFound = true)
public class DevConfig extends ConfigProperties {

}
