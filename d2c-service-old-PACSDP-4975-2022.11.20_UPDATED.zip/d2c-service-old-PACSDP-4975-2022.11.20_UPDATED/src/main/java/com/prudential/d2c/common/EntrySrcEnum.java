package com.prudential.d2c.common;

public enum EntrySrcEnum {
    EDM, NML;
}
