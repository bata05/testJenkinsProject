package com.prudential.d2c.common;
/**
 * This file is used for Email related values
 *
 */
public class MailTemplateConstants {

    private MailTemplateConstants() {
        throw new IllegalStateException("Utility class!Don't instantiate!");
    }

    public static final String CONTACT_DIRECT_NONEXISTING_CLIENT = "Contact us if you need support regarding your application, or other Prudential products.";
    public static final String CONTACT_DIRECT_EXISTING_CLIENT = "The financial consultant assigned to support you is:";
    public static final String CUSTOMER_TITLE_NONEXISTING_CLIENT = "prospect";
    public static final String CUSTOMER_TITLE_EXISTING_CLIENT = "customer";
    public static final String CUSTOMER_BODY_NONEXISTING_CLIENT = "A new customer has been assigned to you.";
    public static final String CUSTOMER_BODY_EXISTING_CLIENT = "Your customer";
    public static final String TITLE_MALE = "He";
    public static final String TITILE_FEMALE = "She";
    public static final String SEX_FEMALE = "Female";

    public static final String AGENT_NAME="agentName";
    public static final String AGENT_MAIL="agentMail";
    public static final String AGENT_MOBILE="agentMobile";
    public static final String PRODUCT_NAME="productName";

    public static final String VIEW_LINK = "viewLink";

    public static final String CLIENT_STATUS="clientStatus";

    public static final String POLICY_NUMBER ="policyNumber";
    public static final String MOBILE_NUMBER = "mobileNumber";
    public static final String EMAIL_ADDRESS = "emailAddress";
    public static final String NRIC = "nric";
    public static final String DOB = "dob";//date of birth
    public static final String RIDERS = "riders";
    public static final String GUIDEHTML="guideHtml";
    public static final String FCHTML="fcHtml";

    public static final String BEGINNING_TITLE = "beginning";


    public static final String STAGE_LEAD_GENERATED = "stageLeadGenerated";
    public static final String AGE = "age";
    public static final String SEX_TITLE ="Sex";
    public static final String EREF_NO = "erefNo";


    public static final String PIC_PRULOGO = "prulogo-mobile.png";

    public static final String CONTACT_DESCRIPTION = "contactDescription";
    public static final String HELP_DESCRIPTION = "helpDescription";
    public static final String CONTACT_DAY = "contactDay";
    public static final String CONTACT_TIME = "contactTime";
    public static final String FILLED_HOLDER ="filled";

    public static final String ENV_UAT = "uat";
    public static final String ENV_SIT = "sit";
    public static final String ENV_PROD = "prod";

    public static final String AGENT_NAME_FOR_NEW_CUSTOMER = "Prudential Customer Support Team";
    public static final String AGENT_MOBILE_FOR_NEW_CUSTOMER ="1-800-333-0333";

    public static final String FEMALE_STRING_SHORTCUT = "F";
    //customer paymentType
    public static final String USD = "USD";
    public static final String SGD_CASH = "SGD_CASH";
    public static final String SRS = "SRS";
    public static final String INTEND_SRS = "INTEND_SRS";

    public static final String FILE_MAIL_TEMPLATE_JSON = "mail_template.json";
    public static final String BROWSER_CLOSED_PROMPT = "Browser Closed";
    public static final String PTV_HELP_DESCRIPTION = "Completing the PRUterm Vantage application process.";
    public static final String PLMF_HELP_DESCRIPTION = "Completing the PRULife Multiplier Flex application process.";
    public static final String NEW_LEAD_HELP_DESCRIPTION = "Completing application process of ";
    public static final String OCCUPATION_NAME = "occupation";
    public static final String AGE_NAME = "age";
    public static final String ISEXISTINGCLIENT_NAME = "isExistingClient";
    public static final String GIVENNAME_NAME = "givenName";
    public static final String SURNAME_NAME = "surName";
    public static final String FULLNAME="fullName";
    public static final String CUSTOMEREMAIL_NAME = "customerEmail";
    public static final String DOB_NAME = "dob";
    public static final String GENDER_NAME = "gender";
    public static final String NRICFIN_NAME = "nricFin";
    public static final String NATIONALITY_NAME = "nationality";
    public static final String MOBILEPHONE_NAME = "mobilePhone";
    public static final String CLIENTNUMBER_NAME = "clientNumber";
    public static final String CHANNEL_NAME ="channel";
    public static final String PRODUCTTYPE_NAME = "productType";
    public static final String REQUESTFINANCIALCONSULTANT_NAME = "requestFinancialConsultant";
    public static final String CAMPAIGNID_NAME = "campaignId";
    public static final String TRACKINGID_NAME = "trackingId";
    public static final String TXT_RESIDENCY_STATUS = "txtResidencyStatus";
    public static final String PHONE_IDD ="phoneIDD";
    public static final String PHONE_COUNTRY_CODE ="phoneCountryCode";
    
    public static final String QMAY019 = "QMAY019";
    public static final String QPS005 = "QPS005";
    public static final String QMAY018 = "QMAY018";
    
    public static final String TXT_RESIDENTIAL_POSTALCODE = "txtResidentialPostalCode";
    public static final String TXT_RESIDENTIAL_BLOCKNO = "txtResidentialBlockNo";
    public static final String TXT_RESIDENTIAL_STREET = "txtResidentialStreet";
    public static final String TXT_RESIDENTIAL_BUILDING = "txtResidentialBuilding";
    public static final String TXT_RESIDENTIAL_UNITNO = "txtResidentialUnitNo";
    
    public static final String MARKETING_CONSENT = "marketingConsent";
    public static final String TXT_CAMPAIGN_ID = "txtCampaignID";
    public static final String TXT_DP_SOURCE = "txtDPSource";
    
    public static final String APPLICATION_DATE = "applicationDate";
    public static final String EXISTING_CUSTOMER = "Existing customer";
    public static final String NEW_CUSTOMER = "New customer";
    
    public static final String CURRENT_DATE = "currentDate";

    public static final String BUSINESS_NAME="businessName";
    public static final String FCLINK="fcLink";
    public static final String BR="br";
    public static final String EXCEPTIONS="exceptions";
}
