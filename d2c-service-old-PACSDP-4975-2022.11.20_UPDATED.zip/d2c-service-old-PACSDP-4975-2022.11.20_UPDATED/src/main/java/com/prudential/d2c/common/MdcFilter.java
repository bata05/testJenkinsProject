package com.prudential.d2c.common;

import lombok.NonNull;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

import static cool.graph.cuid.Cuid.createCuid;
import static org.apache.commons.lang3.StringUtils.isBlank;
import static org.apache.commons.lang3.StringUtils.upperCase;

@Component
public class MdcFilter implements Filter {
    public static final String CUID = "cuid";
    public static final String MISSING_SESSION_ID = "missing-session-id";
    public static final String X_SESSION_ID = "X-Session-Id";
    public static final String X_REQUEST_ID = "X-Request-Id";

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        final HeaderProvider headerProvider = new HeaderProvider((HttpServletRequest) request);
        final String sessionId = headerProvider.getHeader(X_SESSION_ID, MISSING_SESSION_ID);
        // when request ID is not present in the incoming request then generate new one
        final String requestId = headerProvider.getHeader(X_REQUEST_ID, createUUID());
        final String cuid = String.format("sess[%s] req[%s] ", upperCase(sessionId), upperCase(requestId));

        MDC.put(CUID, cuid);
        try {
            chain.doFilter(request, response);
        } finally {
            MDC.remove(CUID);
        }
    }

    String createUUID() {
        return createCuid();
    }

    @Override
    public void destroy() {
    }
}

class HeaderProvider {
    private final HttpServletRequest req;

    HeaderProvider(HttpServletRequest req) {
        this.req = req;
    }

    protected @NonNull
    String getHeader(String requestHeaderKey, @NonNull String defaultValue) {
        String headerValue = req.getHeader(requestHeaderKey);
        if (isBlank(headerValue)) {
            return defaultValue;
        }

        return headerValue;
    }

}
