package com.prudential.d2c.common;

/**
 * Payment method for SRS Product
 * PGP
 * PGRP
 */
public enum PaymentMethod {
    SRS, INTEND, CASH
}
