/**
 * 
 */
package com.prudential.d2c.common;


public enum PaymentMethodMapping {

	CASH_CHEQUE(1, "Q", "Cash/Cheque"),
	CPF_OA(2, "O", "CPF Ordinary Account"),
	CPF_SA(3, "S", "CPF Special Account"),
	CPF_SRS(4, "R", "Supplementary Retirement Scheme (SRS) Account"),
	PRUCARD(5, "V", "PruCard"),
	INTERBANK_GIRO(6, "Q", "Interbank GIRO"),
	CREDIT_CARD(7, "V", "Credit Card"),
	MINIMUM_SUM_SCHEME(8, "Q", "Minimum Sum Scheme (MSS)"),
	MINIMUM_SUM_PLUS_SCHEME(9, "Q", "Minimum Sum Plus Scheme (MSPS)"),
	MEDISAVE(10, "V", "Medisave"),
	MATURITY_PROCEEDS_TRANSFER(11, "Q", "Maturity Proceeds Transfer");

	private int idx;
	private String code;
	private String desc;

	private PaymentMethodMapping(int idx, String code, String desc) {
		this.idx = idx;
		this.code = code;
		this.desc = desc;
	}

	public int getIdx() {
		return idx;
	}

	public String getCode() {
		return code;
	}

	public String getDesc() {
		return desc;
	}

	public static PaymentMethodMapping filterByIdx(int idx) {
		PaymentMethodMapping m = null;
		for (PaymentMethodMapping p : PaymentMethodMapping.values()) {
			if (p.getIdx() == idx) {
				m = p;
				break;
			}
		}
		return m;
	}

	public static PaymentMethodMapping filterByCode(String code) {
		PaymentMethodMapping m = null;
		for (PaymentMethodMapping p : PaymentMethodMapping.values()) {
			if (p.getCode().equals(code)) {
				m = p;
				break;
			}
		}
		return m;
	}

	public static boolean containsByPropasalIndex(int idx) {
		for (PaymentMethodMapping p : PaymentMethodMapping.values()) {
			if (p.getIdx() == idx) {
				return true;
			}
		}
		return false;
	}

	public static boolean containsBySQSIndex(String code) {
		for (PaymentMethodMapping p : PaymentMethodMapping.values()) {
			if (p.getCode().toString().trim().equals(code.toUpperCase().trim())) {
				return true;
			}
		}
		return false;
	}
	
	@Override
	public String toString() {
		return this.getCode();
	}
}
