package com.prudential.d2c.common;

public enum ProductComputeValidatorEnum {

    ET(1, "CT7", "PRUeasy term", "id_prod_ct7");

    private String prodCode, prodDesc, docId;
    private int prodId;

    ProductComputeValidatorEnum(int prodId, String prodCode, String prodDesc, String docId){
        this.prodId = prodId;
        this.prodCode = prodCode;
        this.prodDesc = prodDesc;
        this.docId = docId;
    }

    public String getProdCode() {
        return prodCode;
    }

    public String getProdDesc() {
        return prodDesc;
    }

    public int getProdId() {
        return prodId;
    }

    public String getDocId() {
        return docId;
    }
}
