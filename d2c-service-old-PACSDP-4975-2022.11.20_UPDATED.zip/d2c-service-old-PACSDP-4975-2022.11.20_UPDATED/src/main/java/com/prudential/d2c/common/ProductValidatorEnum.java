package com.prudential.d2c.common;

public enum ProductValidatorEnum {

    /**
     * PGP
     */
    IN7(1, "IN7", "PruInvestor Guaranteed Plus 5yr (SGD)", "id_prod_in7"),
    IN6(2, "IN6", "PruInvestor Guaranteed Plus 5yr (USD)", "id_prod_in6"),
    IR7(3, "IR7", "PruInvestor Guaranteed Plus 5yr (SRS)", "id_prod_ir7"),

    /**
     * Pru protect term
     */
    TB1(4, "IN6", "PRUprotect term", "id_prod_tb1"),
    RB1(5, "RB1", "PRUprotect term", "id_prod_rb1"),
    TC1(6, "TC1", "PRUprotect term", "id_prod_tc1"),
    
    /**
     * PRUgolden Retirement Premier (PGRP)
     */
	AL7(7, "AL7", "PRUgolden retirement premier", "id_prod_al7"),
	AM7(8, "AM7", "PRUgolden retirement premier", "id_prod_am7"),

    /**
     * PRUshield Premier (PS)
     */
    PM1(9, "PM1", "PRUshield Premier", "id_prod_spm1"),
    PM2(10, "PM2", "PRUshield Premier", "id_prod_spm2"),
    PMB(11, "PMB", "PRUshield Premier", "id_prod_pmb"),

    /**
     * PAS
     */
    XW8(12, "XW8", "PRUActive Saver III", "id_prod_xw8"),
    XR8(13, "XR8", "PRUActive Saver III", "id_prod_xr8"),
    XB8(14, "XB8", "PRUActive Saver III", "id_prod_xb8"),

    /**
     * PER
     */
    XZ7(15, "XZ7", "PruEasy Rewards", "id_prod_xz7"),

    PC(16, "CAN", "PRUCancer 360", "id_prod_can"),
	
	/**
     * PAT SIO
     */
	PAT(17, "LT5", "PRUActive Term", "id_prod_lt5");
	

    private String prodCode, prodDesc, docId;
    private int prodId;

    ProductValidatorEnum(int prodId, String prodCode, String prodDesc, String docId){
        this.prodId = prodId;
        this.prodCode = prodCode;
        this.prodDesc = prodDesc;
        this.docId = docId;
    }

    public String getProdCode() {
        return prodCode;
    }

    public String getProdDesc() {
        return prodDesc;
    }

    public int getProdId() {
        return prodId;
    }

    public String getDocId() {
        return docId;
    }

    public boolean isDocIdEquals(String docId) {
        return this.docId.equalsIgnoreCase(docId);
    }
}
