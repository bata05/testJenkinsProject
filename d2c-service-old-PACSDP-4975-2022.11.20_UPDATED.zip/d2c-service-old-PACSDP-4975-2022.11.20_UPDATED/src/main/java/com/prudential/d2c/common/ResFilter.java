package com.prudential.d2c.common;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Hex;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class ResFilter implements Filter {

    @SuppressWarnings("unused")
	private static final String MESSAGE_GIGEST_SHA_1 = "SHA-1";

    private static final String CSP_SCRIPT_NONCE = "CSP_SCRIPT_NONCE";

    private static final String NOSNIFF = "nosniff";

    private static final String X_CONTENT_TYPE_OPTIONS = "X-Content-Type-Options";

    private static final String ACCESS_CONTROL_ALLOW_HEADERS_VALUE = "X-Requested-With,Origin,Content-Type, Accept,Authorization,X-Session-Id,X-Request-Id";

    private static final String HTTP_METHODS = "GET, POST, PUT, DELETE";

    private static final String OPTIONS = "OPTIONS";

    private static final String ACCESS_CONTROL_ALLOW_HEADERS = "Access-Control-Allow-Headers";

    private static final String ACCESS_CONTROL_ALLOW_METHODS = "Access-Control-Allow-Methods";

    private static final String ACCESS_CONTROL_REQUEST_METHOD = "Access-Control-Request-Method";

    private static final String ACCESS_CONTROL_ALLOW_ORIGIN = "Access-Control-Allow-Origin";

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    /** Configuration member to specify if web app use web fonts */
    public static final boolean APP_USE_WEBFONTS = false;

    /** Configuration member to specify if web app use videos or audios */
    public static final boolean APP_USE_AUDIOS_OR_VIDEOS = false;

    /** Configuration member to specify if filter must add CSP directive used by Mozilla (Firefox) */
    public static final boolean INCLUDE_MOZILLA_CSP_DIRECTIVES = true;

    /** Filter configuration */
    @SuppressWarnings("unused")
    private FilterConfig filterConfig = null;

    /** List CSP HTTP Headers */
    private List<String> cspHeaders = new ArrayList<>();

    /** Collection of CSP polcies that will be applied */
    private String policies = null;

    /** Used for Script Nonce */
    private SecureRandom prng = null;

    private ConfigProperties configProperties;

    public ResFilter(ConfigProperties configProperties) {
        this.configProperties = configProperties;
    }

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;

        response.addHeader(ACCESS_CONTROL_ALLOW_ORIGIN, configProperties.getAllowOrigin());

        if (request.getHeader(ACCESS_CONTROL_REQUEST_METHOD) != null && OPTIONS.equals(request.getMethod())) {
            response.addHeader(ACCESS_CONTROL_ALLOW_METHODS, HTTP_METHODS);
            response.addHeader(ACCESS_CONTROL_ALLOW_HEADERS, ACCESS_CONTROL_ALLOW_HEADERS_VALUE);
        }
        response.addHeader(X_CONTENT_TYPE_OPTIONS, NOSNIFF);
        //////////////////////////////////////
        /* Step 1 : Detect if target resource is a Frame */
        // Customize here according to your context...

        /* Step 2 : Add CSP policies to HTTP response */
        StringBuilder policiesBuffer = new StringBuilder(this.policies);

        // If resource is a frame add Frame/Sandbox CSP policy

        // Frame + Sandbox : Here sandbox allow nothing, customize sandbox options depending on your app....
        policiesBuffer.append(Constants.SEMICOLON).append("frame-src 'self';sandbox");
        if (INCLUDE_MOZILLA_CSP_DIRECTIVES) {
            policiesBuffer.append(Constants.SEMICOLON).append("frame-ancestors 'self' *.prudential.com.sg");
        }

        // Add Script Nonce CSP Policy
        // --Generate a random number
        String randomNum = Integer.toString(this.prng.nextInt());
        // --Get its digest
        MessageDigest sha;
        try {
            sha = MessageDigest.getInstance(Constants.SHA256_ALGORITHM);
        }
        catch (NoSuchAlgorithmException e) {
            throw new ServletException(e);
        }
        byte[] digest = sha.digest(randomNum.getBytes());
        // --Encode it into HEXA
        String scriptNonce = Hex.encodeHexString(digest);
        policiesBuffer.append(Constants.SEMICOLON).append("script-nonce ").append(scriptNonce);
        // --Made available script nonce in view app layer
        request.setAttribute(CSP_SCRIPT_NONCE, scriptNonce);

        // Add policies to all HTTP headers
        for (String header : this.cspHeaders) {
            response.setHeader(header, policiesBuffer.toString());
        }

        /* Step 3 : Let request continue chain filter */

        chain.doFilter(req, res);
    }

    @Override
    public void destroy() {
        logger.info("destroy");
    }

    @Override
    public void init(FilterConfig arg0) throws ServletException {
        // Get filter configuration
        this.filterConfig = arg0;

        // Init secure random
        try {
            this.prng = SecureRandom.getInstance("SHA1PRNG");
        }
        catch (NoSuchAlgorithmException e) {
            throw new ServletException(e);
        }

        // Define list of CSP HTTP Headers
        this.cspHeaders.add("Content-Security-Policy");
        this.cspHeaders.add("X-Content-Security-Policy");
        this.cspHeaders.add("X-WebKit-CSP");

        // Define CSP policies
        // Loading policies for Frame and Sandboxing will be dynamically defined : We need to know if context use Frame
        List<String> cspPolicies = new ArrayList<>();
        String originLocationRef = "'self'";
        // --Disable default source in order to avoid browser fallback loading using 'default-src' locations
        cspPolicies.add("default-src 'none'");
        // --Define loading policies for Scripts
        cspPolicies.add("script-src " + originLocationRef + " 'strict-dynamic'");
        if (INCLUDE_MOZILLA_CSP_DIRECTIVES) {
            cspPolicies.add("options strict-dynamic");
            cspPolicies.add("xhr-src 'self'");
        }
        // --Define loading policies for Plugins
        cspPolicies.add("object-src " + originLocationRef);
        // --Define loading policies for Styles (CSS)
        cspPolicies.add("style-src " + originLocationRef);
        // --Define loading policies for Images
        cspPolicies.add("img-src " + originLocationRef);
        // --Define loading policies for Form
        cspPolicies.add("form-action " + originLocationRef);
        // --Define loading policies for Audios/Videos
        if (APP_USE_AUDIOS_OR_VIDEOS) {
            cspPolicies.add("media-src " + originLocationRef);
        }
        // --Define loading policies for Fonts
        if (APP_USE_WEBFONTS) {
            cspPolicies.add("font-src " + originLocationRef);
        }
        // --Define loading policies for Connection
        cspPolicies.add("connect-src " + originLocationRef);
        // --Define loading policies for Plugins Types
        cspPolicies.add("plugin-types application/pdf application/x-shockwave-flash");
        // --Define browser XSS filtering feature running mode
        cspPolicies.add("reflected-xss block");

        // Target formating
        this.policies = cspPolicies.toString().replaceAll("(\\[|\\])", "").replaceAll(",", ";").trim();
    }

}
