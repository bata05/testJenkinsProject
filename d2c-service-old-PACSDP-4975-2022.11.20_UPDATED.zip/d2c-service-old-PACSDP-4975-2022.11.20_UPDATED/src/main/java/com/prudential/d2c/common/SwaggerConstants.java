package com.prudential.d2c.common;

public class SwaggerConstants {

    /**
     * Configuration details
     */
    public static final String TITLE = "Channel API";

    public static final String BASE_PACKAGE = "com.prudential.d2c";

    public static final String GET_QUOTATION = "Get Quotation";
    public static final String GET_QUOTATION_TAG = "Get Quotation Details";
    public static final String GET_QUOTATION_NOTED = "Get Premium Details based on Sum Assured";

    public static final String GET_QUOTATION_DOC = "Get Quotation Document";
    public static final String GET_QUOTATION_DOC_TAG = "Get Quotation Details & Document Token";
    public static final String GET_QUOTATION_DOC_NOTED = "Get Premium Details & Quotation Document Token Based on Sum Assured";


    public static final String SUBMIT_APPLICATION = "Submit Application";
    public static final String SUBMIT_APPLICATION_TAG = "Submit Channel Application For Proposal";
    public static final String SUBMIT_APPLICATION_NOTED = "Get the Proposal Number for the Valid Submitted Application";


}
