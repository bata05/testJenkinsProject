package com.prudential.d2c.common;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;

/**
 * The properties which used in application will be read from application.properties
 */
@Configuration
@Profile(value = "uat")
@PropertySource(value = { "file:${D2C_PATH}/conf/application.properties" }, ignoreResourceNotFound = true)
public class UatConfig extends ConfigProperties{

}
