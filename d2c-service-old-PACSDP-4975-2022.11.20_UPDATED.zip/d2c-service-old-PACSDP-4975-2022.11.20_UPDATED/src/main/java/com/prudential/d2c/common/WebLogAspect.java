package com.prudential.d2c.common;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.prudential.d2c.entity.TransactionLogin;
import com.prudential.d2c.service.UserActionLogService;

@Aspect
@Component
@Order(-5)
public class WebLogAspect {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private UserActionLogService actionLogService;

    @Pointcut("execution( public * com.prudential.d2c.controller.LoginController.otpVerify(..))")
    public void otpSubmitLog() {
        logger.debug("execute otpSubmitLog");
    }

    @Before("otpSubmitLog()")
    public void doBeforeOtpSubmit(JoinPoint joinPoint) {

        Object[] args = joinPoint.getArgs();

        TransactionLogin loginObj = (TransactionLogin) args[0];

        actionLogService.saveActionLog(loginObj, Constants.ACTION_OTP_SUBMIT);
    }

}
