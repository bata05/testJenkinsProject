package com.prudential.d2c.config;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.net.ssl.SSLContext;

import org.apache.http.client.HttpClient;
import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.LaxRedirectStrategy;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.format.FormatterRegistry;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.prudential.d2c.common.Constants;
import com.prudential.d2c.common.Interceptor;
import com.prudential.d2c.entity.dto.CustomerApplicationDecrypter;
import com.prudential.d2c.entity.dto.MailListDecrypter;

@SuppressWarnings("deprecation")
@Configuration
@EnableAutoConfiguration
@ComponentScan(basePackages = {
    "com.prudential.d2c.controller"
})
@EnableJpaRepositories(basePackages ="com.prudential.d2c.repository")
@EntityScan(basePackages = {"com.prudential.d2c.entity"})
@EnableWebMvc
public class CommonConfiguration extends WebMvcConfigurerAdapter{
    private static final String PATH_PATTERN = "/*/*";

    @Override
	public void addInterceptors(InterceptorRegistry registry){
		registry.addInterceptor(new Interceptor()).addPathPatterns(PATH_PATTERN);
		
		super.addInterceptors(registry);
	}

	@Bean
	public CustomerApplicationDecrypter getCustomerApplicationDecrypter(){
    	return new CustomerApplicationDecrypter();
	}

	@Bean
	public MailListDecrypter getMailListDecrypter(){
		return new MailListDecrypter();
	}

	@Override
	public void addFormatters(FormatterRegistry registry) {
		registry.addConverter(getCustomerApplicationDecrypter());
		registry.addConverter(getMailListDecrypter());
	}
	
	@Bean(name = "multipartResolver")
	public CommonsMultipartResolver createMultipartResolver() {
	    CommonsMultipartResolver resolver=new CommonsMultipartResolver();
	    resolver.setDefaultEncoding(Constants.ENCODING_UTF8);
	    resolver.setMaxUploadSize(5000000);
	    
	    return resolver;
	}

	@Bean
	public DPRestTemplateInterceptor dpRestTemplateInterceptor(){
		return new DPRestTemplateInterceptor();
	}
	
	@Bean
	public RestTemplate restTemplate() throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException {
		RestTemplate restTemplate = new RestTemplate();

        TrustStrategy acceptingTrustStrategy = (X509Certificate[] chain, String authType) -> true;
        SSLContext sslContext = org.apache.http.ssl.SSLContexts.custom().loadTrustMaterial(null, acceptingTrustStrategy).build();
        SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(sslContext);
        
        HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
		
		RequestConfig requestConfig = RequestConfig.custom()
                .setCookieSpec(CookieSpecs.STANDARD)
                .build();
		
		HttpClient httpClient = HttpClientBuilder.create()
                .setSSLSocketFactory(csf)
                .setDefaultRequestConfig(requestConfig)
                .setRedirectStrategy(new LaxRedirectStrategy())
                .build();

        factory.setHttpClient(httpClient);

        restTemplate.setRequestFactory(factory);
        
        List<HttpMessageConverter<?>> messageConverters = new ArrayList<HttpMessageConverter<?>>();        
	      //Add the Jackson Message converter
	      MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
	
	      converter.setSupportedMediaTypes(Collections.singletonList(MediaType.APPLICATION_JSON));        
	      messageConverters.add(converter);  
	      restTemplate.setMessageConverters(messageConverters); 
	      restTemplate.getMessageConverters()
	        .add(0, new StringHttpMessageConverter(StandardCharsets.UTF_8));

		return restTemplate;
	}

	@Bean
	public RestTemplate mcRestTemplate() throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException {
		RestTemplate restTemplate = new RestTemplate();
		
		List<ClientHttpRequestInterceptor> interceptors = restTemplate.getInterceptors();
        if (CollectionUtils.isEmpty(interceptors)) {
            interceptors = new ArrayList<>();
        }
        interceptors.add(dpRestTemplateInterceptor());
        restTemplate.setInterceptors(interceptors);

		restTemplate.getMessageConverters()
				.add(0, new StringHttpMessageConverter(Charset.forName("UTF-8")));
		
        TrustStrategy acceptingTrustStrategy = (X509Certificate[] chain, String authType) -> true;
        SSLContext sslContext = org.apache.http.ssl.SSLContexts.custom().loadTrustMaterial(null, acceptingTrustStrategy).build();
        SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(sslContext);
        
        HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
		
		RequestConfig requestConfig = RequestConfig.custom()
                .setCookieSpec(CookieSpecs.STANDARD)
                .build();
		
		HttpClient httpClient = HttpClientBuilder.create()
                .setSSLSocketFactory(csf)
                .setDefaultRequestConfig(requestConfig)
                .setRedirectStrategy(new LaxRedirectStrategy())
                .build();

        factory.setHttpClient(httpClient);

        restTemplate.setRequestFactory(factory);

		return restTemplate;
	}

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("swagger-ui.html")
                .addResourceLocations("classpath:/META-INF/resources/");

        registry.addResourceHandler("/webjars/**")
                .addResourceLocations("classpath:/META-INF/resources/webjars/");
    }
}
