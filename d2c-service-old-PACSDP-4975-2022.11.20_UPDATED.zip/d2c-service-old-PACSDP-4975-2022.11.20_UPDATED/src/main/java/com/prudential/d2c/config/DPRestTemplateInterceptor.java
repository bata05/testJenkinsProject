package com.prudential.d2c.config;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;

public class DPRestTemplateInterceptor implements ClientHttpRequestInterceptor {

    public static final String URI = "URI : {}";
    public static final String METHOD = "Method : {}";
    public static final String HEADERS = "Headers : {}";
    public static final String REQUEST_BODY = "Request body : {}";
    public static final String STATUS_CODE = "Status code : {}";
    public static final String STATUS_TEXT = "Status text : {}";
    public static final String RESPONSE_BODY = "Response body : {}";
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Override
    public ClientHttpResponse intercept(HttpRequest httpRequest, byte[] bytes,
                                        ClientHttpRequestExecution clientHttpRequestExecution) throws IOException {
        logRequest(httpRequest, bytes);
        ClientHttpResponse response = clientHttpRequestExecution.execute(httpRequest, bytes);
        logResponse(response);
        return response;
    }

    protected void logRequest(HttpRequest request, byte[] body) throws IOException {
        logInfo(URI, request.getURI());
        logInfo(METHOD, request.getMethod());
        logInfo(HEADERS, request.getHeaders());
        logInfo(REQUEST_BODY, new String(body, "UTF-8"));
    }

    protected void logResponse(ClientHttpResponse response) throws IOException {
        logInfo(STATUS_CODE, response.getStatusCode());
        logInfo(STATUS_TEXT, response.getStatusText());
        logInfo(HEADERS, response.getHeaders());
        logInfo(RESPONSE_BODY, response.getBody());
    }

    protected void logInfo(String param1, Object param2) {
        if(logger.isInfoEnabled()){
            logger.info(param1, param2);
        }
    }
}
