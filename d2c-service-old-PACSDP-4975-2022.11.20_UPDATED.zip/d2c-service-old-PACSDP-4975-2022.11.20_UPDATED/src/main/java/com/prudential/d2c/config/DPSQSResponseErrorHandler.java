package com.prudential.d2c.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.prudential.d2c.entity.micro.ComputeMicroResponse;
import com.prudential.d2c.entity.micro.Error;
import com.prudential.d2c.exception.DPValidationException;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.ResponseErrorHandler;

import java.io.IOException;
import java.util.Collections;
import java.util.Set;

public class DPSQSResponseErrorHandler implements ResponseErrorHandler {

    public static final String VALIDATION_ERRORS_ = "Validation errors ";
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Override
    public boolean hasError(ClientHttpResponse clientHttpResponse) throws IOException {
        //TODO if pru service return proper response code we need to handle here
    	HttpStatus code = clientHttpResponse.getStatusCode();
    	return code != HttpStatus.OK && code != HttpStatus.NO_CONTENT && code != HttpStatus.NOT_MODIFIED;
    }

    @Override
    public void handleError(ClientHttpResponse clientHttpResponse) throws IOException {
        Set<Error> sqsErrors = getSQSErrors(clientHttpResponse);
        if(CollectionUtils.isNotEmpty(sqsErrors)){
            throw new DPValidationException(VALIDATION_ERRORS_, sqsErrors);
        }
    }

    @SuppressWarnings("unchecked")
	public Set<Error> getSQSErrors(ClientHttpResponse clientHttpResponse) throws IOException {
        try {
            ComputeMicroResponse computeResponsePayload = new ObjectMapper().readValue(clientHttpResponse.getBody(), ComputeMicroResponse.class);
            if (computeResponsePayload != null && computeResponsePayload.getPayload() != null
                    && CollectionUtils.isNotEmpty(computeResponsePayload.getPayload().getErrors())) {
                return computeResponsePayload.getPayload().getErrors();
            }
        } catch (Exception exception){
            //Need to continue with the request if unable to un marshal the object to support project flow
            if(logger.isErrorEnabled()){
                logger.error(" DPSQSResponseErrorHandler Error : " +exception);
            }
        }
        return Collections.EMPTY_SET;
    }
}
