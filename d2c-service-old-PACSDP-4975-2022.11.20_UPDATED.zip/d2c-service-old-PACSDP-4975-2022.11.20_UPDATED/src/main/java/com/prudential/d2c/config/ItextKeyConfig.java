package com.prudential.d2c.config;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import com.itextpdf.license.LicenseKey;

/**
 * @author thofiqullakhan
 */
@Component
@Profile({"!dev"})
public class ItextKeyConfig {

    @Value("${itext.key.location}")
    private String itextKeyLocation;

    @PostConstruct
    public void InitializeMap(){
        LicenseKey.loadLicenseFile(itextKeyLocation);
    }
}
