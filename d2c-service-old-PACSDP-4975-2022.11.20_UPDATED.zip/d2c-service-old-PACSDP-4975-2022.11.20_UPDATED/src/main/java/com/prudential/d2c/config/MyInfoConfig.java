package com.prudential.d2c.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@Getter 
@Setter 
public class MyInfoConfig {
	@Value("${myinfo.keystore.location}")
    private String keystore;
	
	@Value("${myinfo.keystore.passphrase}")
    private String keystorePassphrase;

    @Value("${myinfo.private.key.alias}")
    private String privateKeyAlias;
    
    @Value("${myinfo.keystore.private.key.passphrase}")
    private String privateKeyPassphrase;
    
    @Value("${myinfo.public.cert.alias}")
    private String publicCertAlias;

    @Value("${myinfo.client.id}")
    private String clientId;
    
    @Value("${myinfo.client.secret}")
    private String clientSecret;
    
    @Value("${myinfo.redirect.url}")
    private String redirectUrl;
    
    @Value("${myinfo.attributes}")
    private String attributes;
    
    @Value("${myinfo.environment}")
    private String environment;
    
    @Value("${myinfo.token.url}")
    private String tokenUrl;
    
    @Value("${myinfo.person.url}")
    private String personUrl;
    
    @Value("${myinfo.proxy.token.url}")
    private String proxyTokenUrl;
    
    @Value("${myinfo.proxy.person.url}")
    private String proxyPersonUrl;
    
    @Value("${myinfo.use.proxy}")
    private String useProxy;

    @Value("${myinfo.stub.location}")
    private String stub;

    @Value("${myinfo.auth.api.url}")
    private String authApiUrl;

    @Value("${myinfo.code}")
    private String code;

    @Value("${myinfo.state}")
    private String state;

    @Value("${myinfo.txnNo}")
    private String txnNo;
}
