package com.prudential.d2c.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMethod;

import com.prudential.d2c.common.SwaggerConstants;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.builders.ResponseMessageBuilder;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.ResponseMessage;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SuppressWarnings("deprecation")
@Configuration
@EnableSwagger2
public class SwaggerConfig {
	
	@Bean
    public Docket api() {
        return new Docket(DocumentationType.SWAGGER_2).select()
                .apis(RequestHandlerSelectors.basePackage(SwaggerConstants.BASE_PACKAGE))
                .paths(PathSelectors.regex("/channelAPI/.*"))
                .build()
                .useDefaultResponseMessages(false)
                .globalResponseMessage(RequestMethod.GET, configureGlobalResponseMessages())
                .globalResponseMessage(RequestMethod.POST, configureGlobalResponseMessagesPOST())
                .apiInfo(apiInfo());
    }

    private ApiInfo apiInfo() {
        return new ApiInfoBuilder().title(SwaggerConstants.TITLE)
                .description("")
                .version("V1.0")
                .build();
    }

	private List<ResponseMessage> configureGlobalResponseMessages() {
        List<ResponseMessage> responseMessages = new ArrayList<ResponseMessage>();

        responseMessages
                .add(new ResponseMessageBuilder().code(HttpStatus.OK.value()).message(HttpStatus.OK.getReasonPhrase().toUpperCase() + " - Request completed successfully").build());

        responseMessages.add(new ResponseMessageBuilder().code(HttpStatus.BAD_REQUEST.value())
                .message(HttpStatus.BAD_REQUEST.getReasonPhrase().toUpperCase() + " - Error occurred with the request header or payload could not be decoded")
                .build());

        responseMessages.add(new ResponseMessageBuilder().code(HttpStatus.UNAUTHORIZED.value()).message(
                HttpStatus.UNAUTHORIZED.getReasonPhrase().toUpperCase() + " - Authentication failed. Missing authentication credentials or invalid security token")
                .build());

        responseMessages.add(new ResponseMessageBuilder().code(HttpStatus.NOT_FOUND.value())
                .message(HttpStatus.NOT_FOUND.getReasonPhrase().toUpperCase() + " - The requested resource could not be found").build());

        responseMessages.add(
                new ResponseMessageBuilder().code(HttpStatus.PAYLOAD_TOO_LARGE.value()).message(HttpStatus.PAYLOAD_TOO_LARGE.getReasonPhrase().toUpperCase() + " - Max size limit reached").build());

        responseMessages.add(new ResponseMessageBuilder().code(HttpStatus.INTERNAL_SERVER_ERROR.value())
                .message(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase().toUpperCase() + " - Service is unavailable or unhandled exception").build());

        return responseMessages;

    }

	private List<ResponseMessage> configureGlobalResponseMessagesPOST() {
        List<ResponseMessage> responseMessages = configureGlobalResponseMessages();

        responseMessages.add(new ResponseMessageBuilder().code(HttpStatus.UNSUPPORTED_MEDIA_TYPE.value()).message(
                HttpStatus.UNSUPPORTED_MEDIA_TYPE.getReasonPhrase().toUpperCase() + " - POST/PUT/PATCH request occurred without a application/json content type")
                .build());

        return responseMessages;
    }

}

