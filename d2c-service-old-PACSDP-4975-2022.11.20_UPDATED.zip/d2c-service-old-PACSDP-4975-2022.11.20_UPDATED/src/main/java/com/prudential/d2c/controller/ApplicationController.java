package com.prudential.d2c.controller;

import java.io.IOException;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.*;
import java.util.regex.Pattern;

import com.prudential.d2c.common.ConfigProperties;
import com.prudential.d2c.entity.micro.*;
import com.prudential.d2c.utils.D2CUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.http.HttpStatus;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PathVariable;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.prudential.d2c.common.Constants;
import com.prudential.d2c.common.ProposalConstants;
import com.prudential.d2c.entity.AnswerBody;
import com.prudential.d2c.entity.D2CResponse;
import com.prudential.d2c.entity.Policy;
import com.prudential.d2c.entity.QuestionnaireAnswer;
import com.prudential.d2c.entity.dto.CustomerApplication;
import com.prudential.d2c.entity.micro.payload.AssignAgentResponsePayload;
import com.prudential.d2c.entity.micro.payload.QuestionDetail;
import com.prudential.d2c.entity.micro.payload.QuestionnaireRequest;
import com.prudential.d2c.service.AssignedAgentService;
import com.prudential.d2c.service.ClientService;
import com.prudential.d2c.service.CustomerApplicationService;
import com.prudential.d2c.service.QuestionnaireComparator;
import com.prudential.d2c.service.micro.PolicyService;
import com.prudential.d2c.service.micro.QuestionnaireService;
import com.prudential.d2c.service.ProductService;
import com.prudential.d2c.utils.DataUtils;
import com.prudential.d2c.utils.DateUtil;
import com.prudential.d2c.utils.StaticFileUtil;

import static com.prudential.d2c.exception.AppWideExceptionHandle.MSG_ERROR;

@RestController
@EnableAutoConfiguration
public class ApplicationController {
    private static final String ERROR_WHEN_GET_AGENT_BY_CUSTOM_ID = "Get Exception when calling getAgentByCustomId!";

    private static final String CANNOT_FIND_AGENT_FROM_API = "Couldn't find agent from API!";

    private static final String CUSTOMER_APPLICATION_IS_NOT_EXIST = "Customer Application is Null!";

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ConfigProperties configProperties;
    
    @Autowired
    private QuestionnaireService questionnaireService;
    
    @Autowired
    private PolicyService policyService;
    
    @Autowired
    private AssignedAgentService assignedAgentService;
    
    @Autowired
    private CustomerApplicationService customerApplicationService;
    
    @Autowired
    private ClientService clientService;
    
    @Autowired
    private ProductService productService;

    public void setLastPolicyPurchaseDate(QuestionnaireRequest qrp, D2CResponse d2cResponse) {
        try {
            List<Policy> policies = policyService.getLastIssuedPolicy(qrp.getPolicyRequestPayload());
            String issueDate = null;
            if (CollectionUtils.isNotEmpty(policies)) {
                issueDate = policies.get(0).getIssueDate();
            }
            qrp.getLifeProfile().setLastPolicyPurchaseDate(issueDate);
        } catch (Exception e) {
            d2cResponse.setMessage(MSG_ERROR);
            logger.error("Got exception when calling getLastIssuedPolicy: ", e);
            qrp.getLifeProfile().setLastPolicyPurchaseDate("");
        }
    }

    @RequestMapping(
        value = "/questionnaire",
        method = RequestMethod.POST,
        consumes = MediaType.APPLICATION_JSON_VALUE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    public Object getQuestionnaire(@RequestBody QuestionnaireRequest qrp) {
        logger.info("Invoking: questionnaire.");
    	D2CResponse d2cResponse = new D2CResponse();
        try {
            List<QuestionDetail> questionsRes = new ArrayList<>();

            if (qrp.getPolicyRequestPayload() != null) {
                setLastPolicyPurchaseDate(qrp, d2cResponse);
            }

            QuestionnaireResponse qResponse = questionnaireService.getQuestionnaire(qrp);

            if (qResponse.getSystem().getStatus().equalsIgnoreCase(Constants.SUCCESS_STATUS)) {
                List<QuestionDetail> questions = qResponse.getPayload().getQuestionnaire();
                separateQuestions(questionsRes, questions, null);
                QuestionnaireComparator qc = new QuestionnaireComparator();
                Collections.sort(questionsRes, qc);


    			logger.debug("getQuestionnaire response body: {}",
    						StaticFileUtil.convertObjectToJsonFormat(questionsRes));
    			
    			} else {
    				d2cResponse.setStatusCode(HttpStatus.SC_BAD_REQUEST);
    				logger.error("Return errors back: {}", qResponse.getPayload().getFirstErrorMessage());
    				d2cResponse.setMessage(qResponse.getPayload().getFirstErrorMessage());
    				d2cResponse.setStatus(Constants.ERROR_STATUS);
    				return d2cResponse;
    			}
			d2cResponse.setStatusCode(HttpStatus.SC_OK);
			d2cResponse.setStatus(Constants.SUCCESS_STATUS);
			d2cResponse.setPayload(questionsRes);

		} catch (Exception e) {
			d2cResponse.setStatus(Constants.ERROR_STATUS);
			d2cResponse.setStatusCode(HttpStatus.SC_INTERNAL_SERVER_ERROR);
			d2cResponse.setMessage(MSG_ERROR);
			logger.error("Get exception when call backend questionnaire API:", e);
		}

        logger.debug("Respose from questionnaire: " +d2cResponse.toString() );
        
		return d2cResponse;
	}

    public void questionAddAnswer(Blob questionA, List<QuestionDetail> questionsRes) throws SQLException, IOException {

        Map<String, AnswerBody> answerMap = new HashMap<>();

        ObjectMapper mapper = new ObjectMapper();
        TypeReference<List<QuestionnaireAnswer>> listType = new TypeReference<List<QuestionnaireAnswer>>() {
        };
        String answerString = DataUtils.changeBlobtoString(questionA);
        List<QuestionnaireAnswer> questionnaireAnswerlist = mapper.readValue(answerString, listType);

        for (QuestionnaireAnswer ques : questionnaireAnswerlist) {
            answerMap.put(ques.getQuestion().getCode(), ques.getAnswer());
        }

        for (QuestionDetail qd : questionsRes) {
            if (answerMap.get(qd.getCode()) != null) {
                qd.setAnswer(answerMap.get(qd.getCode()));
            }
        }
    }

    private void separateQuestions(List<QuestionDetail> questionsRes, List<QuestionDetail> questions, String order) {
        if (CollectionUtils.isNotEmpty(questions)) {
            for (int i = 0; i < questions.size(); i++) {
                QuestionDetail question = questions.get(i);
                if (StringUtils.isEmpty(order)) {
                    question.setOrder(question.getSequence());
                } else {
                    question.setOrder(order + Constants.HYPHEN + question.getSequence());
                }
                if (!ProposalConstants.QMAY011.equals(question.getCode())) {
                    if (CollectionUtils.isNotEmpty(question.getSubQuestions())) {
                        separateQuestions(questionsRes, question.getSubQuestions(), question.getOrder());
                        question.setSubQuestions(null);
                    }
                    questionsRes.add(question);
                }
            }
        }
    }

    /**
     * front end will use this service to get agent info by customId or client Number
     * 
     * @param agentRequest
     *            customId is required
     * @return
     */
    @RequestMapping(
        value = "/getAgentByCustomId",
        method = RequestMethod.POST,
        consumes = MediaType.APPLICATION_JSON_VALUE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    public D2CResponse getAgentByCustomId(@RequestBody AssignAgentRequest agentRequest) {
        //TODO : Check this , but no need since this is called from Help pages only
        logger.info("Invoking getAgentByCustomId.");

        logger.debug("Start to call getAgentByCustomId: {} " + D2CUtils.removeCRLF(agentRequest.getCustomId()));
        

        try {
            AgentData agentData = assignedAgentService.getAgentByCustomId(agentRequest.getCustomId());

            if (agentData != null) {
                return new D2CResponse(Constants.SUCCESS_STATUS, HttpStatus.SC_OK, null, agentData);
            }
            // if can't get agent info from the local DB ,then call the agent API to fetch it.
            CustomerApplication customerApplication = customerApplicationService
                    .findCustomerApplicationByCustomId(agentRequest.getCustomId());

            if (customerApplication == null) {
                return new D2CResponse(Constants.ERROR_STATUS, HttpStatus.SC_BAD_REQUEST,
                    CUSTOMER_APPLICATION_IS_NOT_EXIST, null);
            }

            if (StringUtils.isEmpty(agentRequest.getClientNumber())) {
                agentRequest.setClientNumber(customerApplication.getClientNumber());
            }

            String proType = customerApplication.getProductType();
            String age = null;

            if (Constants.PRUPERSONAL_ACCIDENT.equals(proType)) {
                // if this is a PA product , need to get age to set product details
                ClientResponse response = clientService.getClientInfo(agentRequest.getClientNumber());
                List<ClientInfo> clientList = response.getPayload().getClientList();

                if (CollectionUtils.isNotEmpty(clientList)) {
                    // the client Info is coming from API , and generally only one returned, if it returns many , pick up the first
                    ClientInfo clientInfo = clientList.get(0);
                    age = String.valueOf(DateUtil.getAgeByBirthday(clientInfo.getDateOfBirth(), Constants.DOBFORMAT));
                }
            }

            agentRequest.setAge(age);
            agentRequest.setProType(proType);
            agentRequest.setChannelType(customerApplication.getChannel());

            AssignAgentResponsePayload assignAgentResponsePayload = assignedAgentService.callAssignAgent(agentRequest);

            if (assignAgentResponsePayload == null) {
                return new D2CResponse(Constants.ERROR_STATUS, HttpStatus.SC_BAD_REQUEST, CANNOT_FIND_AGENT_FROM_API,
                    null);
            }

            agentData = assignAgentResponsePayload.getAssignedAgent();
    

            return new D2CResponse(Constants.SUCCESS_STATUS, HttpStatus.SC_OK, null, agentData);

        } catch (Exception e) {
            logger.error(ERROR_WHEN_GET_AGENT_BY_CUSTOM_ID, e);

            return new D2CResponse(Constants.ERROR_STATUS, HttpStatus.SC_INTERNAL_SERVER_ERROR,
                ERROR_WHEN_GET_AGENT_BY_CUSTOM_ID, null);

        }

    }

    @RequestMapping(
            value = "/checkpromo/{productCodeAndChannelCode}",
            method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public D2CResponse checkPromo(@PathVariable String productCodeAndChannelCode) {
    	logger.info("Check Promo path variable : {}", D2CUtils.removeCRLF(productCodeAndChannelCode));

    	String[] splitter = productCodeAndChannelCode.split(Pattern.quote("_"));
    	String productCode="";
    	String channelCode="";
    	
    	productCode = splitter[0];
    	
    	if(splitter.length>=2) {
    		channelCode = splitter[1];
    	}
    	logger.info("Product Code : {} and Channel Code: {}", D2CUtils.removeCRLF(productCode), D2CUtils.removeCRLF(channelCode));
    	
        PromoResponse promoResponse = getStaticDiscountForUIBanner(productCode);
        if (promoResponse != null) {
            return new D2CResponse(Constants.SUCCESS_STATUS, HttpStatus.SC_OK, null, promoResponse);
        }

        return new D2CResponse(Constants.SUCCESS_STATUS, HttpStatus.SC_OK, null, productService.validateProductPromo(productCode,channelCode.isEmpty()?"ALL":channelCode));

    }

    public PromoResponse getStaticDiscountForUIBanner(String productCode) {
        Map<String, PromoResponse> staticDiscountConfig = new HashMap<>();

        Date fromDate = DateUtil.getStringToDate("12-10-2020 00:00:00", "dd-M-yyyy hh:mm:ss");
        if ("prod".equalsIgnoreCase(configProperties.getServerEnvironment())) {
            fromDate = DateUtil.getStringToDate("12-11-2020 00:00:00","dd-M-yyyy hh:mm:ss");
        }

        Date toDate = DateUtil.getStringToDate("31-12-2020 23:59:59", "dd-M-yyyy hh:mm:ss");
        Date currentDate = new Date();
        if (currentDate.after(fromDate) && currentDate.before(toDate)) {
            double percentage = 10;
            int startAge = 1;
            int endAge = 99;
            Map<String, String> products = new HashMap<>();
            //products.put("LT5", "PRUActive Term");
            for (Map.Entry<String, String> product : products.entrySet()) {
                PromoResponse promoResponse = new PromoResponse();
                promoResponse.setStartAge(startAge);
                promoResponse.setEndAge(endAge);
                promoResponse.setFromValidityDate(fromDate);
                promoResponse.setToValidityDate(toDate);
                promoResponse.setPromoValid(Boolean.FALSE);
                promoResponse.setPromoStatic(Boolean.TRUE);
                try {
                    String promoMsg = "Enjoy <strong>${discount}% premium discount</strong> perpetually when you purchase ${productName} from now till ${endDate}. The discounted premium amount will be refunded to you after the policy is incepted. <a href='https://cloud.campaigns.prudential.com.sg/pat_sio_promo' target='_blank'>Terms and Conditions</a> apply.";
                    Map<String, String> map = new HashMap<String, String>();
                    map.put("discount", Integer.valueOf((int) percentage).toString());
                    promoResponse.setDiscountPercentage(percentage);
                    map.put("productName", product.getValue());
                    map.put("endDate", DateUtil.getFormattedDateString(toDate, Constants.DATE_FORMAT_DDMMMYYYY3));
                    for (Map.Entry<String, String> entry : map.entrySet()) {
                        promoMsg = promoMsg.replace("${" + entry.getKey() + "}", entry.getValue());
                    }
                    promoResponse.setPromoMsg(promoMsg);
                } catch (Exception exception) {
                    logger.error("Exception during promo Discount MSG: " + exception.getMessage(), exception);
                }
                staticDiscountConfig.put(product.getKey(), promoResponse);
            }
        }
        return staticDiscountConfig.get(productCode);
    }

}
