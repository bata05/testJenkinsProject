package com.prudential.d2c.controller;


import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.prudential.d2c.common.ConfigProperties;
import com.prudential.d2c.service.AssignedAgentService;


@RestController
public class BaseController {
	@Autowired
	protected HttpServletRequest request;
	@Autowired
	protected ConfigProperties configProperties;
	@Autowired
	protected AssignedAgentService assignedAgentService;
}
