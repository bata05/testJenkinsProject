package com.prudential.d2c.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.prudential.d2c.entity.config.Campaigns;
import com.prudential.d2c.service.CampaignsService;

@RestController
@RequestMapping(value = "/campaigns")
public class CampaignsController {

    @Autowired
    private CampaignsService campaignsService;

    @RequestMapping("/validate")
    public Object validateCampaign(@RequestBody Campaigns campaigns){
        return campaignsService.validateCampaign(campaigns);
    }
}
