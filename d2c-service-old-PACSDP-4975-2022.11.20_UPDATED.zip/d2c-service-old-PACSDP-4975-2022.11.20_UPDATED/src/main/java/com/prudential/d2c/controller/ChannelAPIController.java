package com.prudential.d2c.controller;

import java.sql.Blob;
import java.text.ParseException;
import java.util.*;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.reflect.TypeToken;
import com.prudential.d2c.common.ConfigProperties;
import com.prudential.d2c.common.Constants;
import com.prudential.d2c.common.CyberSourceConstants;
import com.prudential.d2c.entity.ChannelAPIDto;
import com.prudential.d2c.entity.config.ChannelProductMapping;
import com.prudential.d2c.entity.config.Channels;
import com.prudential.d2c.entity.config.Products;
import com.prudential.d2c.entity.config.ProductsConfig;
import com.prudential.d2c.entity.dto.ChannelAPIAudit;
import com.prudential.d2c.entity.dto.CustomerApplication;
import com.prudential.d2c.entity.dto.Occupation;
import com.prudential.d2c.entity.micro.ChannelAPIAddress;
import com.prudential.d2c.entity.micro.ChannelAPIAppSubmissionRequest;
import com.prudential.d2c.entity.micro.ChannelAPIAppSubmissionResponse;
import com.prudential.d2c.entity.micro.ChannelAPIApplication;
import com.prudential.d2c.entity.micro.ChannelAPIApplicationStatus;
import com.prudential.d2c.entity.micro.ChannelAPIBasePayLoad;
import com.prudential.d2c.entity.micro.ChannelAPIBaseRequest;
import com.prudential.d2c.entity.micro.ChannelAPIBaseResponse;
import com.prudential.d2c.entity.micro.ChannelAPIClientProfile;
import com.prudential.d2c.entity.micro.ChannelAPIError;
import com.prudential.d2c.entity.micro.ChannelAPIPayment;
import com.prudential.d2c.entity.micro.ChannelAPIPersonProfile;
import com.prudential.d2c.entity.micro.ChannelAPIProduct;
import com.prudential.d2c.entity.micro.ChannelAPIQuestionnaire;
import com.prudential.d2c.entity.micro.ChannelAPIQuotationAndQuotationDocumentRequest;
import com.prudential.d2c.entity.micro.ChannelAPIQuotationAndQuotationDocumentResponse;
import com.prudential.d2c.entity.micro.ChannelAPIRequest;
import com.prudential.d2c.entity.micro.ChannelAPIResponse;
import com.prudential.d2c.entity.micro.PromoResponse;
import com.prudential.d2c.exception.ChannelAPIException;
import com.prudential.d2c.repository.ChannelProductMappingRepository;
import com.prudential.d2c.service.ChannelAPIService;
import com.prudential.d2c.service.ChannelService;
import com.prudential.d2c.service.CustomerApplicationService;
import com.prudential.d2c.service.OccupationService;
import com.prudential.d2c.service.ProductConfigService;
import com.prudential.d2c.service.ProductService;
import com.prudential.d2c.type.ChannelAPIExceptionType;
import com.prudential.d2c.utils.ChannelAPIDataUtils;
import com.prudential.d2c.utils.ConvertBlobToObject;
import com.prudential.d2c.utils.D2CUtils;
import com.prudential.d2c.utils.DateUtil;
import com.prudential.d2c.utils.JweUtils;
import com.prudential.d2c.utils.RsaUtils;

import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(value = "/channelAPI")
@ApiResponses(value = {
        @ApiResponse(code = 200, message = "OK."),
        @ApiResponse(code = 400, message = "Bad Request."),
        @ApiResponse(code = 500, message = "Internal Server Error.")
})
public class ChannelAPIController extends BaseController {

    @Autowired
    private ProductConfigService productConfigService;

    @Autowired
    private ChannelAPIService channelAPIService;

    @Autowired
    private OccupationService occupationService;

    @Autowired
    private ProductService productService;

    @Autowired
    private ChannelService channelService;

    @Autowired
    private ChannelProductMappingRepository channelProductMappingRepository;

    @Autowired
    protected CustomerApplicationService customerApplicationService;

    @Autowired
    protected ConfigProperties configProperties;


    @PostMapping(value = "/getQuotation", consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<ChannelAPIBaseResponse> getQuotation(@RequestHeader(value = "appName", required = false) String appName, @RequestBody ChannelAPIBaseRequest request) throws ChannelAPIException {
        return doChannelAPIProcess(new ChannelAPIDto(request.getRequestBody(), ChannelAPIDto.ChannelAPIType.QUOTATION, D2CUtils.generateUUID(), appName));
    }


    @PostMapping(value = "/getQuotationDocument", consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<ChannelAPIBaseResponse> getQuotationDocument(@RequestHeader(value = "appName", required = false) String appName, @RequestBody ChannelAPIBaseRequest request) throws ChannelAPIException {
        return doChannelAPIProcess(new ChannelAPIDto(request.getRequestBody(), ChannelAPIDto.ChannelAPIType.QUOTATION_DOCUMENT, null, appName));
    }

    @PostMapping(value = "/submitApplication", consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<ChannelAPIBaseResponse> submitApplication(@RequestHeader(value = "appName", required = false) String appName, @RequestBody ChannelAPIBaseRequest request) throws ChannelAPIException {
        return doChannelAPIProcess(new ChannelAPIDto(request.getRequestBody(), ChannelAPIDto.ChannelAPIType.APPLICATION_SUBMISSION, null, appName));
    }

    private ResponseEntity<ChannelAPIBaseResponse> doChannelAPIProcess(ChannelAPIDto channelAPIDto) throws ChannelAPIException {

        if (StringUtils.isBlank(channelAPIDto.getChannelName())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }

        if (StringUtils.isBlank(channelAPIDto.getEncryptedRequestPayload())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }

        try {

            logger.info("Channel API Processing Starts For : {} ", channelAPIDto.getRequestType());

            initiateAudit(channelAPIDto);

            decodePayLoad(channelAPIDto);

            if(StringUtils.isNotBlank(channelAPIDto.getRequestJson()))
              validatePayload(channelAPIDto);

            if (CollectionUtils.isNotEmpty(channelAPIDto.getErrors())) {
                logger.info("Channel API Decode Failed : {}", channelAPIDto);
                return ResponseEntity.ok(getErrorResponse(channelAPIDto));
            }

            logger.info("Channel API Decode Success : {}", channelAPIDto);

            convertRequestJsonTORequestObject(channelAPIDto);

            if (CollectionUtils.isNotEmpty(channelAPIDto.getErrors())) {
                logger.info("Channel API Object Conversion Failed : {}", channelAPIDto);
                return ResponseEntity.ok(getErrorResponse(channelAPIDto));
            }

            logger.info("Channel API JSON to Object Conversion Success : {}", channelAPIDto);

            validate(channelAPIDto);

            if (CollectionUtils.isNotEmpty(channelAPIDto.getErrors())) {
                logger.info("Channel API Validate Failed : {}", channelAPIDto);
                return ResponseEntity.ok(getErrorResponse(channelAPIDto));
            }

            logger.info("Channel API Validate Success : {}", channelAPIDto);

            ChannelAPIBasePayLoad processResponse = process(channelAPIDto);

            if (CollectionUtils.isNotEmpty(channelAPIDto.getErrors())) {
                logger.info("Channel API Process Failed : {}", channelAPIDto);
                return ResponseEntity.ok(getErrorResponse(channelAPIDto));
            }

            logger.info("Channel API Process Success : {}", channelAPIDto);

            String successResponse = getSuccessResponse(channelAPIDto, processResponse);

            logger.info("Channel API Processing Ends : {} ", channelAPIDto);

            return ResponseEntity.ok(new ChannelAPIBaseResponse(200, successResponse));

        } catch (Exception exception) {
            logger.error("Exception Occurred While doChannelAPIProcess : " + exception.getMessage(), exception);
            throw new ChannelAPIException("Exception occurred while Channel API Processing.");
        } finally {
            channelAPIService.updateChannelAPIAudit(channelAPIDto);
        }

    }

    private void initiateAudit(ChannelAPIDto channelAPIDto) {
        ChannelAPIAudit channelAPIAudit = new ChannelAPIAudit(channelAPIDto.getRequestType().toString());
        channelAPIDto.setAudit(channelAPIAudit);
        channelAPIService.saveChannelAPIAudit(channelAPIAudit);
    }

    private void decodePayLoad(ChannelAPIDto channelAPIDto) {
        try {
            if (StringUtils.isNotBlank(channelAPIDto.getEncryptedRequestPayload())) {
                channelAPIDto.setRequestJson(JweUtils.decrypt(channelAPIDto.getEncryptedRequestPayload(), RsaUtils.getRsaPrivateCertificate(configProperties.getRsaPrivateKeyLocation())));
            } else {
                channelAPIDto.getErrors().add(ChannelAPIExceptionType.INVALID_JWE_REQUEST_PAYLOAD);
            }
        } catch (Exception exception) {
            logger.error("Exception occurred while decrypting PayLoad: " + channelAPIDto + " " + exception.getMessage(), exception);
            channelAPIDto.getErrors().add(ChannelAPIExceptionType.INVALID_JWE_REQUEST_PAYLOAD);
        }
    }

    private void validatePayload(ChannelAPIDto channelAPIDto){
        String payload = channelAPIDto.getRequestJson();
        String htmlPattern = "<(\"[^\"]*\"|'[^']*'|[^'\">])*>";
        Pattern pattern = Pattern.compile(htmlPattern);
        Matcher matcher = pattern.matcher(payload);

        if(matcher.find()){
            channelAPIDto.getErrors().add(ChannelAPIExceptionType.INVALID_JSON_PAYLOAD_CONTAIN_SCRIPT);
        }
    }

    private void convertRequestJsonTORequestObject(ChannelAPIDto channelAPIDto) {
        try {
            if (StringUtils.isNotBlank(channelAPIDto.getRequestJson())) {
                if (ChannelAPIDto.ChannelAPIType.APPLICATION_SUBMISSION.equals(channelAPIDto.getRequestType())) {
                    channelAPIDto.setChannelAPIRequest(new ObjectMapper().readValue(channelAPIDto.getRequestJson(),
                            new TypeReference<ChannelAPIRequest<ChannelAPIAppSubmissionRequest>>() {
                            }));
                } else {
                    channelAPIDto.setChannelAPIRequest(new ObjectMapper().readValue(channelAPIDto.getRequestJson(),
                            new TypeReference<ChannelAPIRequest<ChannelAPIQuotationAndQuotationDocumentRequest>>() {
                            }));
                }
            } else {
                channelAPIDto.getErrors().add(ChannelAPIExceptionType.INVALID_JSON_REQUEST_PAYLOAD);
            }
        } catch (Exception exception) {
            logger.error("Exception occurred while converting PayLoad to Object Type : " + channelAPIDto + " " + exception.getMessage(), exception);
            channelAPIDto.getErrors().add(ChannelAPIExceptionType.INVALID_JSON_REQUEST_PAYLOAD);
        }
    }

    @SuppressWarnings("unchecked")
	private void validate(ChannelAPIDto channelAPIDto) {

        List<ChannelAPIExceptionType> errorList = new ArrayList<>();

        try {

            if (ChannelAPIDto.ChannelAPIType.QUOTATION.equals(channelAPIDto.getRequestType()) || ChannelAPIDto.ChannelAPIType.QUOTATION_DOCUMENT.equals(channelAPIDto.getRequestType())) {

                ChannelAPIRequest<ChannelAPIQuotationAndQuotationDocumentRequest> request = channelAPIDto.getChannelAPIRequest();

                String dpTransactionId = channelAPIService.getDPTransactionIDForChannelAPITransaction(channelAPIDto.getTransactionId());

                if (StringUtils.isNotBlank(dpTransactionId)) {
                    channelAPIDto.setDPTransactionID(dpTransactionId);
                }

                if (null == request.getPayload()) {
                    errorList.add(ChannelAPIExceptionType.INVALID_REQUEST_PAYLOAD);
                }

                if (StringUtils.isBlank(channelAPIDto.getChannelName())) {
                    errorList.add(ChannelAPIExceptionType.REQUIRED_APP_NAME);
                }

                if (!D2CUtils.validateObjectName(request.getPayload().getTransactionId())) {

                    errorList.add(ChannelAPIExceptionType.INVALID_TRANSACTION_ID);

                } else {

                    channelAPIDto.setChannelTransactionID(request.getPayload().getTransactionId());

                    Optional<ChannelAPIAudit> submissionAuditObj = channelAPIService.getChannelAPIAuditForTransactionAndApiTypeAndApiStatus(channelAPIDto.getChannelTransactionID(), ChannelAPIDto.ChannelAPIType.APPLICATION_SUBMISSION.toString(), Constants.ResponseStatus.SUCCESS);

                    if (submissionAuditObj.isPresent()) {
                        errorList.add(ChannelAPIExceptionType.ALREADY_SUBMITTED);
                    }

                }

                if (request.getPayload().getClientProfile() == null) {
                    errorList.add(ChannelAPIExceptionType.INVALID_CLIENTPROFILE);
                }

                if (request.getPayload().getProduct() == null) {
                    errorList.add(ChannelAPIExceptionType.INVALID_REQUEST_PAYLOAD);
                }

                if (!StringUtils.equals("ML", request.getPayload().getClientProfile().getClientType())) {
                    errorList.add(ChannelAPIExceptionType.INVALID_CLIENT_TYPE);
                }

                if (StringUtils.isEmpty(request.getPayload().getProduct().getDocId())) {
                    errorList.add(ChannelAPIExceptionType.INVALID_PRODUCT_TYPE);
                }

                ProductsConfig productsConfig = productConfigService.findBySqsDocId(request.getPayload().getProduct().getDocId());
                if (productsConfig == null || productsConfig.getD2cProduct() == null) {
                    errorList.add(ChannelAPIExceptionType.INVALID_PRODUCT_TYPE);
                } else {
                    channelAPIDto.setDpProductCode(productsConfig.getD2cProduct().getProductCode());
                    Products products = productService.validateProduct(productsConfig.getD2cProduct().getProductCode());
                    if (products == null) {
                        errorList.add(ChannelAPIExceptionType.INVALID_PRODUCT_TYPE);
                    } else if (StringUtils.isNotBlank(channelAPIDto.getChannelName())) {
                        Channels channels = channelService.validateChannelByName(channelAPIDto.getChannelName());
                        if (channels == null) {
                            errorList.add(ChannelAPIExceptionType.INVALID_APP_NAME);
                        } else {
                            channelAPIDto.setChannelName(channels.getChannelCode());
                            ChannelProductMapping channelProductMapping = channelProductMappingRepository.findByChannelsAndProducts(channels, products);
                            if (channelProductMapping == null) {
                                errorList.add(ChannelAPIExceptionType.INVALID_PRODUCT_TYPE);
                            }
                        }
                    }
                }

                if (!Constants.GENDER.contains(request.getPayload().getClientProfile().getGender())) {
                    errorList.add(ChannelAPIExceptionType.INVALID_GENDER_TYPE);
                }

                if (StringUtils.isEmpty(request.getPayload().getClientProfile().getDob())) {
                    errorList.add(ChannelAPIExceptionType.INVALID_DOB);
                }

                Date dob = DateUtil.getStringToDateStrict(request.getPayload().getClientProfile().getDob(), Constants.DOBFORMAT);

                if (dob == null) {
                    throw new ParseException("DOB error",1);
                }

                int ageNextBirthDay = DateUtil.getAgeByNextBirthday(dob);
                if (productsConfig != null && (productsConfig.getMinAge() != null && productsConfig.getMaxAge() != null) && (ageNextBirthDay < productsConfig.getMinAge() || ageNextBirthDay > productsConfig.getMaxAge())) {
                    errorList.add(ChannelAPIExceptionType.INVALID_AGE);
                }

                if (request.getPayload().getProduct().getSumAssured() == null) {
                    errorList.add(ChannelAPIExceptionType.REQUIRED_SUM_ASSURED);
                } else if (productsConfig != null && (productsConfig.getMinSumAssured() != null && productsConfig.getMaxSumAssured() != null)
                        && (request.getPayload().getProduct().getSumAssured() < productsConfig.getMinSumAssured() || request.getPayload().getProduct().getSumAssured() > productsConfig.getMaxSumAssured())) {
                    errorList.add(ChannelAPIExceptionType.INVALID_SUM_ASSURED);
                }

                if (ChannelAPIDto.ChannelAPIType.QUOTATION_DOCUMENT.equals(channelAPIDto.getRequestType())) {

                    if (!D2CUtils.validateObjectName(channelAPIDto.getDPTransactionID())) {
                        errorList.add(ChannelAPIExceptionType.INVALID_TRANSACTION_ID);
                    }

                    if (StringUtils.isBlank(request.getPayload().getClientProfile().getNric())) {
                        errorList.add(ChannelAPIExceptionType.EMPTY_NRIC);
                    }

                    ChannelAPIExceptionType validationMessage =
                            D2CUtils.validateGivenName(request.getPayload().getClientProfile().getGivenName());
                    if (validationMessage != null) errorList.add(validationMessage);

                    validationMessage = D2CUtils.validateSurName(request.getPayload().getClientProfile().getSurname());
                    if (validationMessage != null) errorList.add(validationMessage);

                    if (StringUtils.isBlank(request.getPayload().getClientProfile().getOccupationCode())) {
                        errorList.add(ChannelAPIExceptionType.INVALID_OCCUPATION_CODE);
                    }

                    Occupation occupation = occupationService.getOccupationbyCode(request.getPayload().getClientProfile().getOccupationCode());

                    if (occupation == null) {
                        errorList.add(ChannelAPIExceptionType.INVALID_OCCUPATION_CODE);
                    }

                    if (occupation != null && !StringUtils.equalsIgnoreCase(request.getPayload().getClientProfile().getOccupationClass(), occupation.getClassOccupation())) {
                        errorList.add(ChannelAPIExceptionType.INVALID_OCCUPATION_CLASS);
                    }

                    if (occupation != null && !StringUtils.equalsIgnoreCase(request.getPayload().getClientProfile().getOccupationDesc(), occupation.getDescription())) {
                        errorList.add(ChannelAPIExceptionType.INVALID_OCCUPATION_DESC);
                    }
                }
                
                if(request.getPayload().getProduct().getPaymentMode()!=null && !request.getPayload().getProduct().getPaymentMode().isEmpty()) {
                	List<String> paymentModeList = new ArrayList<String>(Arrays.asList("Y","M","H","Q","SP"));
                	if(!paymentModeList.contains(request.getPayload().getProduct().getPaymentMode())) {
                		errorList.add(ChannelAPIExceptionType.INVALID_PAYMENT_MODE);
                	}
                } 
                channelAPIDto.getErrors().addAll(errorList);
            } else if (ChannelAPIDto.ChannelAPIType.APPLICATION_SUBMISSION.equals(channelAPIDto.getRequestType())) {
                this.validateApplicationSubmission(channelAPIDto);
            }
        } catch (Exception exception) {
            logger.error("Exception occurred while converting PayLoad to Object Type : " + channelAPIDto + " " + exception.getMessage(), exception);
            if(exception instanceof ParseException){
                channelAPIDto.getErrors().add(ChannelAPIExceptionType.INVALID_DOB);
            }else{
                channelAPIDto.getErrors().add(ChannelAPIExceptionType.INTERNAL_ERROR);
            }

        }

    }


    @SuppressWarnings("rawtypes")
	private void validateApplicationSubmission(ChannelAPIDto channelAPIDto) {

        List<ChannelAPIExceptionType> errorList = new ArrayList<>();

        Predicate<String> genderValidator = gender -> Constants.GENDER.contains(gender);
        Predicate<String> residencyStatusValidator = rs -> Constants.RES_STATUS_LIST.contains(rs);

        Predicate<String> annualIncomeValidator = annIncome -> {
            try {
                if (annIncome.equals("0") || annIncome.matches("^([1-9][0-9]{0,12})$")) {
                    return true;
                }
            } catch (Exception ex) {
                logger.error("channel API - Exception in validating annualIncome value {} ", annIncome, ex);
            }
            return false;
        };

        ChannelAPIRequest channelAPIRequest = channelAPIDto.getChannelAPIRequest();

        if (null == channelAPIRequest.getPayload()) {
            errorList.add(ChannelAPIExceptionType.INVALID_REQUEST_PAYLOAD);
        }

        if (StringUtils.isBlank(channelAPIDto.getChannelName())) {
            errorList.add(ChannelAPIExceptionType.REQUIRED_APP_NAME);
        }

        Channels channels = channelService.validateChannelByName(channelAPIDto.getChannelName());

        if (channels == null) {
            errorList.add(ChannelAPIExceptionType.INVALID_APP_NAME);
        } else {
            channelAPIDto.setChannelName(channels.getChannelCode());
        }

        ChannelAPIBasePayLoad payload = channelAPIRequest.getPayload();
        ChannelAPIAppSubmissionRequest channelAPIAppSubmissionRequest = (ChannelAPIAppSubmissionRequest) payload;

        if (null == channelAPIAppSubmissionRequest.getApplication()) {
            logger.error("channel API - {} : Invalid Request Payload, Application not available", channelAPIDto.getRequestType().toString());
            errorList.add(ChannelAPIExceptionType.INVALID_REQUEST_PAYLOAD);
        }

        if (CollectionUtils.isEmpty(errorList)) {
            ChannelAPIApplication application = channelAPIAppSubmissionRequest.getApplication();
            String transactionId = null;
            ProductsConfig productsConfig = null;

            Optional<ChannelAPIAudit> quotationDocumentAuditObj = null;

            if (StringUtils.isBlank(application.getTransactionId())) {
                logger.error("channel API - {} : No Transaction Id Available in the request", D2CUtils.removeCRLF(channelAPIDto.getRequestType().toString()));
                errorList.add(ChannelAPIExceptionType.EMPTY_TRANSACTION_ID);
            }else if(!D2CUtils.validateObjectName(application.getTransactionId())){
                logger.error("channel API - {} : Invalid Transaction Id Available in the request",  D2CUtils.removeCRLF(channelAPIDto.getRequestType().toString()));
                errorList.add(ChannelAPIExceptionType.INVALID_TRANSACTION_ID);
            } else if (StringUtils.isBlank(application.getPartnerEref())) {
                logger.error("channel API - {} : Invalid Request Payload, Partner Eref not available", D2CUtils.removeCRLF(channelAPIDto.getRequestType().toString()));
                errorList.add(ChannelAPIExceptionType.REQUIRED_PARTNER_EREF);
                //Add Transaction ID and Custom ID so can appear in CHANNEL_API_AUDIT table if Partner Eref is missing
                channelAPIAppSubmissionRequest.setTransactionId(application.getTransactionId());

                quotationDocumentAuditObj = channelAPIService.getChannelAPIAuditForTransactionAndApiTypeAndApiStatus(application.getTransactionId(), ChannelAPIDto.ChannelAPIType.QUOTATION_DOCUMENT.toString(), Constants.ResponseStatus.SUCCESS);
                if (quotationDocumentAuditObj.isPresent()) {
                    ChannelAPIAudit quotationDocumentAudit = quotationDocumentAuditObj.get();
                    String dpTransId = quotationDocumentAudit.getDpCustomId();

                    channelAPIAppSubmissionRequest.setDpTransactionId(dpTransId);
                    channelAPIDto.setDPTransactionID(dpTransId);
                }
            }else if(!D2CUtils.validateObjectName(application.getPartnerEref())){
                logger.error("channel API - {} : Invalid Request Payload, Partner Eref not available", D2CUtils.removeCRLF(channelAPIDto.getRequestType().toString()));
                errorList.add(ChannelAPIExceptionType.INVALID_PARTNER_EREF);
            }
            else {
                transactionId = application.getTransactionId();
                channelAPIAppSubmissionRequest.setTransactionId(transactionId);
                channelAPIDto.setPartnerEref(application.getPartnerEref());

                Optional<ChannelAPIAudit> submissionAuditObj = channelAPIService.getChannelAPIAuditForTransactionAndApiTypeAndApiStatus(transactionId, ChannelAPIDto.ChannelAPIType.APPLICATION_SUBMISSION.toString(), Constants.ResponseStatus.SUCCESS);
                if (submissionAuditObj.isPresent()) {
                    logger.error("channel API - {} : Application already submitted for transactionId {} ", D2CUtils.removeCRLF(channelAPIDto.getRequestType().toString()), D2CUtils.removeCRLF(channelAPIDto.getTransactionId()));
                    errorList.add(ChannelAPIExceptionType.ALREADY_SUBMITTED);
                } else {
                    quotationDocumentAuditObj = channelAPIService.getChannelAPIAuditForTransactionAndApiTypeAndApiStatus(transactionId, ChannelAPIDto.ChannelAPIType.QUOTATION_DOCUMENT.toString(), Constants.ResponseStatus.SUCCESS);
                    if (quotationDocumentAuditObj.isPresent()) {
                        ChannelAPIAudit quotationDocumentAudit = quotationDocumentAuditObj.get();
                        String dpTransId = quotationDocumentAudit.getDpCustomId();

                        channelAPIAppSubmissionRequest.setDpTransactionId(dpTransId);
                        channelAPIDto.setDPTransactionID(dpTransId);

                        CustomerApplication savedCustomerApplication = customerApplicationService.findCustomerApplicationByCustomId(dpTransId);
                        if (savedCustomerApplication == null) {
                            logger.error("channel API - {} : No Customer Application found in DB with given TransactionId {}", D2CUtils.removeCRLF(channelAPIDto.getRequestType().toString()), transactionId);
                            channelAPIDto.getErrors().add(ChannelAPIExceptionType.INTERNAL_ERROR);
                        } else {
                            Optional<ProductsConfig> productsConfigObj = channelAPIService.loadProductsConfigByProductType(savedCustomerApplication.getProductType());
                            if (productsConfigObj.isPresent()) {
                                productsConfig = productsConfigObj.get();
                            } else {
                                logger.error("channel API - {} :  Couldn't load the Product Configfrom DB for productType {}  / TransactionId {}",
                                        D2CUtils.removeCRLF(channelAPIDto.getRequestType().toString()),
                                        D2CUtils.removeCRLF(savedCustomerApplication.getProductType()),
                                        D2CUtils.removeCRLF(transactionId));
                                channelAPIDto.getErrors().add(ChannelAPIExceptionType.INTERNAL_ERROR);
                            }
                        }

                    } else {
                        logger.error("channel API - {} : No Valid Transaction[SUCCESS] available with given TransactionId {}", D2CUtils.removeCRLF(channelAPIDto.getRequestType().toString()), D2CUtils.removeCRLF(transactionId));
                        errorList.add(ChannelAPIExceptionType.INVALID_TRANSACTION_ID);
                    }
                }
            }

            int anb = 0;
            if (CollectionUtils.isEmpty(errorList)) {
                //ApplicationData Validation
                if (application.getClientProfile() == null) {
                    errorList.add(ChannelAPIExceptionType.EMPTY_CLIENTPROFILE);
                } else {
                    ChannelAPIClientProfile clientProfile = application.getClientProfile();

                    ChannelAPIExceptionType validationMessage = D2CUtils.validateSurName(clientProfile.getSurname().trim());
                    if (validationMessage != null) errorList.add(validationMessage);

                    validationMessage = D2CUtils.validateGivenName(clientProfile.getGivenName().trim());
                    if (validationMessage != null) errorList.add(validationMessage);

                    int result = nricValidator.apply(clientProfile.getNric());
                    if (result == 1) {
                        errorList.add(ChannelAPIExceptionType.EMPTY_NRIC);
                    } else {
                        clientProfile.setNric(clientProfile.getNric().trim());
                        if (result == 2) {
                            errorList.add(ChannelAPIExceptionType.NRIC_TOO_LONG);
                        }
                        if (result == 3) {
                            errorList.add(ChannelAPIExceptionType.INVALID_NRIC);
                        }
                    }

                    if (StringUtils.isEmpty(clientProfile.getDob())) {
                        errorList.add(ChannelAPIExceptionType.EMPTY_DOB);
                    } else {
                        clientProfile.setDob(clientProfile.getDob().trim());
                        if (clientProfile.getDob().length() > 10 || StringUtils.isEmpty(DateUtil.checkDateFormatStrict(clientProfile.getDob(), Constants.DOBFORMAT))) {
                            errorList.add(ChannelAPIExceptionType.INVALID_DOB);
                        } else {
                            try {
                                Date dob = DateUtil.getStringToDateStrict(clientProfile.getDob(), Constants.DOBFORMAT);
                                anb = DateUtil.getAgeByNextBirthday(dob);

                                if (productsConfig != null && anb < productsConfig.getMinAge() || anb > productsConfig.getMaxAge()) {
                                    errorList.add(ChannelAPIExceptionType.INVALID_AGE);
                                }
                            } catch (Exception ex) {
                                errorList.add(ChannelAPIExceptionType.INVALID_DOB);
                                logger.error("Exception occurred while validating age : " + channelAPIDto + " " + ex.getMessage(), ex);
                            }
                        }
                    }

                    if (StringUtils.isEmpty(clientProfile.getGender())) {
                        errorList.add(ChannelAPIExceptionType.EMPTY_GENDER);
                    } else {
                        clientProfile.setGender(clientProfile.getGender().trim());
                        if (!genderValidator.test(clientProfile.getGender())) {
                            errorList.add(ChannelAPIExceptionType.INVALID_GENDER_TYPE);
                        }
                    }

                    if (StringUtils.isEmpty(clientProfile.getResidencyStatus())) {
                        errorList.add(ChannelAPIExceptionType.EMPTY_RESIDENCY_STATUS);
                    } else {
                        clientProfile.setResidencyStatus(clientProfile.getResidencyStatus().trim());
                        if (!residencyStatusValidator.test(clientProfile.getResidencyStatus())) {
                            errorList.add(ChannelAPIExceptionType.INVALID_RESIDENCY_STATUS);
                        } else if (Constants.RESIDENCY_OTHER_AB.equals(clientProfile.getResidencyStatus())) {
                            if (StringUtils.isEmpty(clientProfile.getWorkPassCode())) {
                                errorList.add(ChannelAPIExceptionType.EMPTY_WORKPASS_CODE);
                            } else {
                                clientProfile.setWorkPassCode(clientProfile.getWorkPassCode().trim());
                                if (!(ChannelAPIDataUtils.getPassTypeByCode(clientProfile.getWorkPassCode())).isPresent()) {
                                    errorList.add(ChannelAPIExceptionType.INVALID_WORKPASS_CODE);
                                }
                            }
                        }
                    }

                    if (StringUtils.isEmpty(clientProfile.getNationalityCode())) {
                        errorList.add(ChannelAPIExceptionType.EMPTY_NATIONALITY_CODE);
                    } else {
                        clientProfile.setNationalityCode(clientProfile.getNationalityCode().trim());
                        if (Constants.NOT_APPLICABLE.equals(customerApplicationService.findNationalityName(clientProfile.getNationalityCode()))) {
                            errorList.add(ChannelAPIExceptionType.INVALID_NATIONALITY_CODE);
                        }
                    }

                    if (StringUtils.isEmpty(clientProfile.getMobileNumber())) {
                        errorList.add(ChannelAPIExceptionType.EMPTY_MOBILE_NUMBER);
                    } else {
                        clientProfile.setMobileNumber(clientProfile.getMobileNumber().trim());
                        if (clientProfile.getMobileNumber().length() > 15) {
                            errorList.add(ChannelAPIExceptionType.MOBILE_NUMBER_TOO_LONG);
                        } else {
                            if (!clientProfile.getMobileNumber().matches("^\\+[0-9]{9,}$")) {
                                errorList.add(ChannelAPIExceptionType.INCORRECT_MOBILE_NUMBER_FORMAT);
                            } else {
                                if (clientProfile.getMobileNumber().startsWith("+65")) {
                                    String number = clientProfile.getMobileNumber().substring(3);
                                    if (!(number.length() == 8 && (number.startsWith("8") || number.startsWith("9")))) {
                                        errorList.add(ChannelAPIExceptionType.INVALID_MOBILE_NUMBER);
                                    }
                                }
                            }
                        }
                    }

                    if (StringUtils.isEmpty(clientProfile.getEmail())) {
                        errorList.add(ChannelAPIExceptionType.EMPTY_EMAIL);
                    } else {
                        clientProfile.setEmail(clientProfile.getEmail().trim());

                        if (clientProfile.getEmail().length() > 100) {
                            errorList.add(ChannelAPIExceptionType.EMAIL_TOO_LONG);
                        }
                        Pattern pattern = Pattern.compile(Constants.EMAIL_PATTERN);
                        Matcher matcher = pattern.matcher(clientProfile.getEmail());
                        if (!matcher.matches()) {
                            errorList.add(ChannelAPIExceptionType.INVALID_EMAIL);
                        }
                    }

                    if (StringUtils.isEmpty(clientProfile.getOccupationClass())) {
                        errorList.add(ChannelAPIExceptionType.EMPTY_OCCUPATION_CLASS);
                    } else {
                        clientProfile.setOccupationClass(clientProfile.getOccupationClass().trim());
                    }

                    if (StringUtils.isEmpty(clientProfile.getOccupationCode())) {
                        errorList.add(ChannelAPIExceptionType.EMPTY_OCCUPATION_CODE);
                    } else {
                        clientProfile.setOccupationCode(clientProfile.getOccupationCode().trim());
                        Occupation occupation = occupationService.getOccupationbyCode(clientProfile.getOccupationCode());

                        if (occupation == null) {
                            errorList.add(ChannelAPIExceptionType.INVALID_OCCUPATION_CODE);
                        }

                        if (occupation != null && !StringUtils.equalsIgnoreCase(clientProfile.getOccupationClass(), occupation.getClassOccupation())) {
                            errorList.add(ChannelAPIExceptionType.INVALID_OCCUPATION_CLASS);
                        }
                    }

                    if (clientProfile.getAnnualIncome() == null) {
                        errorList.add(ChannelAPIExceptionType.EMPTY_ANNUAL_INCOME);
                    } else if (!annualIncomeValidator.test(clientProfile.getAnnualIncome())) {
                        errorList.add(ChannelAPIExceptionType.INVALID_ANNUAL_INCOME);
                    }

                    if (StringUtils.isEmpty(clientProfile.getIndustryCode())) {
                        errorList.add(ChannelAPIExceptionType.EMPTY_INDUSTRY_CODE);
                    } else {
                        clientProfile.setIndustryCode(clientProfile.getIndustryCode().trim());
                        if (!(ChannelAPIDataUtils.getIndustryByCode(clientProfile.getIndustryCode()).isPresent())) {
                            errorList.add(ChannelAPIExceptionType.INVALID_INDUSTRY_CODE);
                        } else if (!Constants.INDUSTRY_CATEGORY_OTHER.contains(clientProfile.getIndustryCode())) {
                            if (StringUtils.isEmpty(clientProfile.getEmployerName())) {
                                errorList.add(ChannelAPIExceptionType.EMPTY_EMPLOYER_NAME);
                            }
                            int val;
                            if ((val = mandatoryAndMaxNValidator.apply(clientProfile.getEmployerName(), 30)) > 0) {
                                errorList.add(val == 1 ? ChannelAPIExceptionType.EMPTY_EMPLOYER_NAME : ChannelAPIExceptionType.EMPLOYER_NAME_TOO_LONG);
                            }
                            if (StringUtils.isEmpty(clientProfile.getDesignationCode())) {
                                errorList.add(ChannelAPIExceptionType.EMPTY_DESIGNATION_CODE);
                            } else {
                                clientProfile.setDesignationCode(clientProfile.getDesignationCode().trim());
                                if (!(ChannelAPIDataUtils.getDesignationByCode(clientProfile.getDesignationCode())).isPresent()) {
                                    errorList.add(ChannelAPIExceptionType.INVALID_DESIGNATION_CODE);
                                }
                            }
                        }
                    }

                    validateResidencyAddress(clientProfile.getResidentialAddress(), errorList);
                    validateMailingAddress(clientProfile.getMailingAddress(), errorList);
                }
                validateQuestionnaire(application.getQuestionnaire(), anb, errorList);
                validatePayment(application.getPayment(), errorList, channelAPIDto, quotationDocumentAuditObj.get(), productsConfig);
            }
        }

        channelAPIDto.getErrors().addAll(errorList);
    }

    private void validateResidencyAddress(ChannelAPIAddress residencyAddress, List<ChannelAPIExceptionType> errorList) {
        if (residencyAddress == null) {
            errorList.add(ChannelAPIExceptionType.EMPTY_RESIDENCE_ADDRESS);
        } else {
            int result = 0;
            result = mandatoryAndMaxNValidator.apply(residencyAddress.getPostcode(), 30);
            if (result > 0) {
                errorList.add(result == 1 ? ChannelAPIExceptionType.RES_ADD_EMPTY_POST_CODE : ChannelAPIExceptionType.RES_ADD_POST_CODE_TOO_LONG);
            } else if (!D2CUtils.validateSgPostalCode(residencyAddress.getPostcode())){
                errorList.add(ChannelAPIExceptionType.RES_ADD_POST_CODE_INVALID);
            }
            result = mandatoryAndMaxNValidator.apply(residencyAddress.getBlockNumber(), 30);
            if (result > 0) {
                errorList.add(result == 1 ? ChannelAPIExceptionType.RES_ADD_EMPTY_BLOCK_NUMBER : ChannelAPIExceptionType.RES_ADD_BLOCK_NUMBER_TOO_LONG);
            } else if (!D2CUtils.hasOnlyLetterOrNumber(residencyAddress.getBlockNumber())) {
                errorList.add(ChannelAPIExceptionType.RES_ADD_BLOCK_NUMBER_INVALID_CHARACTER);
            }
            result = mandatoryAndMaxNValidator.apply(residencyAddress.getStreet(), 30);
            if (result > 0) {
                errorList.add(result == 1 ? ChannelAPIExceptionType.RES_ADD_EMPTY_STREET : ChannelAPIExceptionType.RES_ADD_STREET_TOO_LONG);
            } else if (!D2CUtils.validateObjectName(residencyAddress.getStreet())) {
                errorList.add(ChannelAPIExceptionType.RES_ADD_STREET_INVALID_CHARACTER);
            }
            if (StringUtils.isNotEmpty(residencyAddress.getBuildingName())) { // Building name isn't mandatory
                if(residencyAddress.getBuildingName().length() > 30)
                    errorList.add(ChannelAPIExceptionType.RES_ADD_BUILDING_NAME_TOO_LONG);
                if (!D2CUtils.validateObjectName(residencyAddress.getBuildingName()))
                    errorList.add(ChannelAPIExceptionType.RES_ADD_BUILDING_NAME_INVALID_CHARACTER);
            }
            result = mandatoryAndMaxNValidator.apply(residencyAddress.getUnitNumber(), 30);
            if (result > 0) {
                errorList.add(result == 1 ? ChannelAPIExceptionType.RES_ADD_EMPTY_UNIT_NO : ChannelAPIExceptionType.RES_ADD_UNIT_NO_TOO_LONG);
            } else if (!D2CUtils.validateObjectName(residencyAddress.getUnitNumber())) {
                errorList.add(ChannelAPIExceptionType.RES_ADD_UNIT_NO_INVALID_CHARACTER);
            }

            if (StringUtils.isEmpty(residencyAddress.getCountryCode())) {
                errorList.add(ChannelAPIExceptionType.RES_ADD_EMPTY_COUNTRY_CODE);
            } else {
                residencyAddress.setCountryCode(residencyAddress.getCountryCode().trim());
                if (!"SNG".equalsIgnoreCase(residencyAddress.getCountryCode())) {
                    errorList.add(ChannelAPIExceptionType.RES_ADD_INVALID_COUNTRY_CODE);
                }
            }
        }
    }

    private void validateMailingAddress(ChannelAPIAddress mailingAddress, List<ChannelAPIExceptionType> errorList) {
        Function<String, Boolean> max30Validator = str -> {
            return (StringUtils.isEmpty(str) || str.length() <= 30);
        };
        if (mailingAddress != null) {
            int result = 0;
            result = mandatoryAndMaxNValidator.apply(mailingAddress.getPostcode(), 30);
            if (result > 0) {
                errorList.add(result == 1 ? ChannelAPIExceptionType.MAIL_ADD_EMPTY_LINE_1 : ChannelAPIExceptionType.MAIL_ADD_LINE_1_TOO_LONG);
            } else if (!D2CUtils.validateObjectName(mailingAddress.getPostcode())) {
                errorList.add(ChannelAPIExceptionType.MAIL_ADD_LINE_1_INVALID_CHARACTER);
            }

            if (!max30Validator.apply(mailingAddress.getBlockNumber())) {
                errorList.add(ChannelAPIExceptionType.MAIL_ADD_LINE_2_TOO_LONG);
            }
            if (StringUtils.isNotEmpty(mailingAddress.getBlockNumber()) && !D2CUtils.validateObjectName(mailingAddress.getBlockNumber())) {
                errorList.add(ChannelAPIExceptionType.MAIL_ADD_LINE_2_INVALID_CHARACTER);
            }

            if (!max30Validator.apply(mailingAddress.getStreet())) {
                errorList.add(ChannelAPIExceptionType.MAIL_ADD_LINE_3_TOO_LONG);
            }
            if (StringUtils.isNotEmpty(mailingAddress.getStreet()) && !D2CUtils.validateObjectName(mailingAddress.getStreet())) {
                errorList.add(ChannelAPIExceptionType.MAIL_ADD_LINE_3_INVALID_CHARACTER);
            }

            if (!max30Validator.apply(mailingAddress.getBuildingName())) {
                errorList.add(ChannelAPIExceptionType.MAIL_ADD_LINE_4_TOO_LONG);
            }
            if (StringUtils.isNotEmpty(mailingAddress.getBuildingName()) && !D2CUtils.validateObjectName(mailingAddress.getBuildingName())) {
                errorList.add(ChannelAPIExceptionType.MAIL_ADD_LINE_4_INVALID_CHARACTER);
            }

            if (!max30Validator.apply(mailingAddress.getUnitNumber())) {
                errorList.add(ChannelAPIExceptionType.MAIL_ADD_LINE_5_TOO_LONG);
            }
            if (StringUtils.isNotEmpty(mailingAddress.getUnitNumber()) && !D2CUtils.validateObjectName(mailingAddress.getUnitNumber())) {
                errorList.add(ChannelAPIExceptionType.MAIL_ADD_LINE_5_INVALID_CHARACTER);
            }

            if (StringUtils.isEmpty(mailingAddress.getCountryCode())) {
                errorList.add(ChannelAPIExceptionType.MAIL_ADD_EMPTY_COUNTRY_CODE);
            } else {
                mailingAddress.setCountryCode(mailingAddress.getCountryCode().trim());
                if (customerApplicationService.findCountryName(mailingAddress.getCountryCode()).equalsIgnoreCase(Constants.NOT_APPLICABLE)) {
                    errorList.add(ChannelAPIExceptionType.MAIL_ADD_INVALID_COUNTRY_CODE);
                }
            }

        }

    }

    private void validateQuestionnaire(ChannelAPIQuestionnaire questionnaire, int anb, List<ChannelAPIExceptionType> errorList) {

        Function<String, Integer> mandatoryAndBooleanValidator = str -> {
            if (StringUtils.isEmpty(str)) {
                return 1;
            }
            if (!str.matches("^([0,1])$")) {
                return 2;
            }
            return 0;
        };

        if (questionnaire == null) {
            errorList.add(ChannelAPIExceptionType.EMPTY_QUESTIONNAIRE);
        } else {
            int result = 0;
            /*if (anb >= Constants.CHA_API_EDU_QUALI_REQUIRED_AGE) {
                if (StringUtils.isEmpty(questionnaire.getHighestEducation())) {
                    errorList.add(ChannelAPIExceptionType.EMPTY_HIGHEST_LVL_OF_EDUCATION);
                } else {
                    questionnaire.setHighestEducation(questionnaire.getHighestEducation().trim());
                    Optional<String> eduQualiObj = ChannelAPIDataUtils.getEducationQualificationByCode(questionnaire.getHighestEducation());
                    if (!eduQualiObj.isPresent()) {
                        errorList.add(ChannelAPIExceptionType.INVALID_HIGHEST_LVL_OF_EDUCATION);
                    } else if (ChannelAPIDataUtils.EducationalQualification.NOQU.getCode().equals(questionnaire.getHighestEducation())) {
                        errorList.add(ChannelAPIExceptionType.HIGHEST_LVL_OF_EDUCATION_REQUIRED);
                    }
                }
            } else if (StringUtils.isNotEmpty(questionnaire.getHighestEducation())) {
                errorList.add(ChannelAPIExceptionType.HIGHEST_LVL_OF_EDUCATION_NOT_REQUIRED);
            }*/

            result = mandatoryAndBooleanValidator.apply(questionnaire.getOffshoreDeclaration());
            if (result > 0) {
                errorList.add(result == 1 ? ChannelAPIExceptionType.EMPTY_OFFSHORE_DECLARATION : ChannelAPIExceptionType.INVALID_OFFSHORE_DECLARATION);
            }

            result = mandatoryAndBooleanValidator.apply(questionnaire.getIsBeneficialOwner());
            if (result > 0) {
                errorList.add(result == 1 ? ChannelAPIExceptionType.EMPTY_BO_DECLARATION : ChannelAPIExceptionType.INVALID_BO_DECLARATION);
            } else if (Constants.CONFIG_TRUE.equals(questionnaire.getIsBeneficialOwner())) {
                this.validateBeneficiaryOwnerProfile(questionnaire.getBeneficialOwnerProfile(), errorList);
            }

            result = mandatoryAndBooleanValidator.apply(questionnaire.getIsPoliticallyExposed());
            if (result > 0) {
                errorList.add(result == 1 ? ChannelAPIExceptionType.EMPTY_IS_POLITICALLY_EXPOSED : ChannelAPIExceptionType.INVALID_IS_POLITICALLY_EXPOSED);
            } else if (Constants.CONFIG_TRUE.equals(questionnaire.getIsPoliticallyExposed())) {
                this.validatePoliticallyExposedProfile(questionnaire.getPoliticallyExposedProfile(), errorList);
            }

            result = mandatoryAndBooleanValidator.apply(questionnaire.getHealthDeclaration());
            if (result > 0) {
                errorList.add(result == 1 ? ChannelAPIExceptionType.EMPTY_HEALTH_DECLARATION : ChannelAPIExceptionType.INVALID_HEALTH_DECLARATION);
            }

            result = mandatoryAndBooleanValidator.apply(questionnaire.getMarketingConsent());
            if (result > 0) {
                errorList.add(result == 1 ? ChannelAPIExceptionType.EMPTY_MARKETING_CONSENT : ChannelAPIExceptionType.INVALID_MARKETING_CONSENT);
            }
        }
    }

    private void validateBeneficiaryOwnerProfile(ChannelAPIPersonProfile boProfile, List<ChannelAPIExceptionType> errorList) {
        if (boProfile == null) {
            errorList.add(ChannelAPIExceptionType.EMPTY_BENEFICIAL_OWNER);
        } else {
            int result = 0;
            result = mandatoryAndMaxNValidator.apply(boProfile.getName(), 60);
            if (result == 1) {
                errorList.add(ChannelAPIExceptionType.BO_EMPTY_NAME);
            } else {
                boProfile.setName(boProfile.getName().trim());
                if (!boProfile.getName().chars().allMatch(nameValidator::test)) {
                    errorList.add(ChannelAPIExceptionType.BO_INVALID_NAME);
                }
            }
            if (result == 2) {
                errorList.add(ChannelAPIExceptionType.BO_NAME_TOO_LONG);
            }

            result = nricValidator.apply(boProfile.getNric());
            if (result == 1) {
                errorList.add(ChannelAPIExceptionType.BO_EMPTY_NRIC);
            } else {
                boProfile.setNric(boProfile.getNric().trim());
                if (result == 2) {
                    errorList.add(ChannelAPIExceptionType.BO_NRIC_TOO_LONG);
                }
                if (result == 3) {
                    errorList.add(ChannelAPIExceptionType.BO_INVALID_NRIC);
                }
            }

            if (StringUtils.isEmpty(boProfile.getDob())) {
                errorList.add(ChannelAPIExceptionType.BO_EMPTY_DATE_OF_BIRTH);
            } else {
                boProfile.setDob(boProfile.getDob().trim());
                if (StringUtils.isEmpty(DateUtil.checkDateFormatStrict(boProfile.getDob(), Constants.DOBFORMAT))) {
                    errorList.add(ChannelAPIExceptionType.BO_INVALID_DATE_OF_BIRTH);
                }
            }

            if (StringUtils.isEmpty(boProfile.getNationalityCode())) {
                errorList.add(ChannelAPIExceptionType.BO_EMPTY_NATIONALITY);
            } else {
                boProfile.setNationalityCode(boProfile.getNationalityCode().trim());
                if (customerApplicationService.findNationalityName(boProfile.getNationalityCode()).equalsIgnoreCase(Constants.NOT_APPLICABLE)) {
                    errorList.add(ChannelAPIExceptionType.BO_INVALID_NATIONALITY);
                }
            }

            if (StringUtils.isEmpty(boProfile.getResidencyCountryCode())) {
                errorList.add(ChannelAPIExceptionType.BO_EMPTY_RES_COUNTRY_CODE);
            } else {
                boProfile.setResidencyCountryCode(boProfile.getResidencyCountryCode().trim());
                if (customerApplicationService.findCountryName(boProfile.getResidencyCountryCode()).equalsIgnoreCase(Constants.NOT_APPLICABLE)) {
                    errorList.add(ChannelAPIExceptionType.BO_INVALID_RES_COUNTRY_CODE);
                }
            }

            result = mandatoryAndMaxNValidator.apply(boProfile.getRelationship(), 30);
            if (result > 0) {
                errorList.add(result == 1 ? ChannelAPIExceptionType.BO_EMPTY_RELATIONSHIP : ChannelAPIExceptionType.BO_RELATIONSHIP_TOO_LONG);
            } else {
                boProfile.setRelationship(boProfile.getRelationship().trim());
                if (!D2CUtils.validateObjectName(boProfile.getRelationship())) {
                    errorList.add(ChannelAPIExceptionType.BO_INVALID_RELATIONSHIP);
                }
            }
        }
    }

    private void validatePoliticallyExposedProfile(ChannelAPIPersonProfile pepProfile, List<ChannelAPIExceptionType> errorList) {
        if (pepProfile == null) {
            errorList.add(ChannelAPIExceptionType.EMPTY_POLITICALLY_EXPOSED_PROFILE);
        } else {
            int result = 0;
            result = mandatoryAndMaxNValidator.apply(pepProfile.getName(), 60);
            if (result == 1) {
                errorList.add(ChannelAPIExceptionType.PEP_EMPTY_NAME);
            } else {
                pepProfile.setName(pepProfile.getName().trim());
                if (!pepProfile.getName().chars().allMatch(nameValidator::test)) {
                    errorList.add(ChannelAPIExceptionType.PEP_INVALID_NAME);
                }
            }
            if (result == 2) {
                errorList.add(ChannelAPIExceptionType.PEP_NAME_TOO_LONG);
            }

            result = nricValidator.apply(pepProfile.getNric());
            if (result == 1) {
                errorList.add(ChannelAPIExceptionType.PEP_EMPTY_NRIC);
            } else {
                pepProfile.setNric(pepProfile.getNric().trim());
                if (result == 2) {
                    errorList.add(ChannelAPIExceptionType.PEP_NRIC_TOO_LONG);
                }
                if (result == 3) {
                    errorList.add(ChannelAPIExceptionType.PEP_INVALID_NRIC);
                }
            }

            if (StringUtils.isEmpty(pepProfile.getDob())) {
                errorList.add(ChannelAPIExceptionType.PEP_EMPTY_DATE_OF_BIRTH);
            } else {
                pepProfile.setDob(pepProfile.getDob().trim());
                if (StringUtils.isEmpty(DateUtil.checkDateFormatStrict(pepProfile.getDob(), Constants.DOBFORMAT))) {
                    errorList.add(ChannelAPIExceptionType.PEP_INVALID_DATE_OF_BIRTH);
                }
            }

            if (StringUtils.isEmpty(pepProfile.getNationalityCode())) {
                errorList.add(ChannelAPIExceptionType.PEP_EMPTY_NATIONALITY);
            } else {
                pepProfile.setNationalityCode(pepProfile.getNationalityCode().trim());
                if (customerApplicationService.findNationalityName(pepProfile.getNationalityCode()).equalsIgnoreCase(Constants.NOT_APPLICABLE)) {
                    errorList.add(ChannelAPIExceptionType.PEP_INVALID_NATIONALITY);
                }
            }

            if (StringUtils.isEmpty(pepProfile.getResidencyCountryCode())) {
                errorList.add(ChannelAPIExceptionType.PEP_EMPTY_RES_COUNTRY_CODE);
            } else {
                pepProfile.setResidencyCountryCode(pepProfile.getResidencyCountryCode().trim());
                if (customerApplicationService.findCountryName(pepProfile.getResidencyCountryCode()).equalsIgnoreCase(Constants.NOT_APPLICABLE)) {
                    errorList.add(ChannelAPIExceptionType.PEP_INVALID_RES_COUNTRY_CODE);
                }
            }

            result = mandatoryAndMaxNValidator.apply(pepProfile.getRelationship(), 30);
            if (result > 0) {
                errorList.add(result == 1 ? ChannelAPIExceptionType.PEP_EMPTY_RELATIONSHIP : ChannelAPIExceptionType.PEP_RELATIONSHIP_TOO_LONG);
            } else {
                pepProfile.setRelationship(pepProfile.getRelationship().trim());
                if (!D2CUtils.validateObjectName(pepProfile.getRelationship())) {
                    errorList.add(ChannelAPIExceptionType.PEP_INVALID_RELATIONSHIP);
                }
            }

            result = mandatoryAndMaxNValidator.apply(pepProfile.getNatureOfPublicFunc(), 30);
            if (result > 0) {
                errorList.add(result == 1 ? ChannelAPIExceptionType.PEP_EMPTY_NATURE : ChannelAPIExceptionType.PEP_NATURE_TOO_LONG);
            } else {
                pepProfile.setNatureOfPublicFunc(pepProfile.getNatureOfPublicFunc().trim());
                if (!D2CUtils.validateObjectName(pepProfile.getNatureOfPublicFunc())) {
                    errorList.add(ChannelAPIExceptionType.PEP_INVALID_NATURE);
                }
            }
        }
    }

    private void validatePayment(ChannelAPIPayment payment, List<ChannelAPIExceptionType> errorList, ChannelAPIDto channelAPIDto, ChannelAPIAudit quotationAudit, ProductsConfig productsConfig) {
        if (payment == null) {
            errorList.add(ChannelAPIExceptionType.EMPTY_PAYMENT);
        } else {
            boolean validatePremium = true;
            if (StringUtils.isEmpty(payment.getPaymentMode())) {
                errorList.add(ChannelAPIExceptionType.EMPTY_PAYMENT_MODE);
                validatePremium = false;
            } else {
                payment.setPaymentMode(payment.getPaymentMode().trim());
                if (!Constants.PAYMENT_MODE_LIST.contains(payment.getPaymentMode())) {
                    errorList.add(ChannelAPIExceptionType.INVALID_PAYMENT_MODE);
                    validatePremium = false;
                }
            }

            if (StringUtils.isEmpty(payment.getPremiumAmount())) {
                errorList.add(ChannelAPIExceptionType.EMPTY_PREMIUM_AMOUNT);
                validatePremium = false;
            } else {
                payment.setPremiumAmount(payment.getPremiumAmount().trim());
                Integer valRes = premiumFormatValidator.apply(payment.getPremiumAmount());
                if (valRes > 0) {
                    errorList.add(valRes == 1 ? ChannelAPIExceptionType.INVALID_PREMIUM_AMOUNT : ChannelAPIExceptionType.INVALID_PREMIUM_AMOUNT_FORMAT);
                    validatePremium = false;
                }
            }

            if (validatePremium) {

                boolean promoEnabled = false;
                double premium = 0d;
                if (!CyberSourceConstants.CYBER_PRODUCT_CODES_DISCOUNT.contains(productsConfig.getSqsProductCode())) {
                    PromoResponse promoResponse = productService.validateProductPromo(productsConfig.getSqsProductCode(),channelAPIDto.getChannelName());
                    if (promoResponse != null && promoResponse.isPromoValid() && promoResponse.getDiscountPercentage() != null) {
                        promoEnabled = true;
                        logger.info("Promotion enabled for product for dpTransactionID (CustomID) {} ", channelAPIDto.getDPTransactionID());
                    }
                }

                try {
                    ChannelAPIResponse<ChannelAPIQuotationAndQuotationDocumentResponse> quotApiResponse = new ConvertBlobToObject<ChannelAPIResponse<ChannelAPIQuotationAndQuotationDocumentResponse>>
                            (new TypeToken<ChannelAPIResponse<ChannelAPIQuotationAndQuotationDocumentResponse>>() {
                            }.getType(), (Blob) quotationAudit.getResponse()).getObject2();

                    if (quotApiResponse != null && quotApiResponse.getPayload() != null) {
                        ChannelAPIQuotationAndQuotationDocumentResponse quotationDocResponse = quotApiResponse.getPayload();
                        String paymentMode = payment.getPaymentMode();
                        int pMode = Constants.PAYMENT_MODE_LIST.indexOf(paymentMode);


                        if (quotationDocResponse.getProduct() != null) {
                            ChannelAPIProduct chAPIproduct = quotationDocResponse.getProduct();

                            switch (pMode) {
                                case 1:
                                    premium = promoEnabled ? chAPIproduct.getDiscountedYearlyPremium() : chAPIproduct.getYearlyPremium();
                                    break;
                                case 2:
                                    premium = promoEnabled ? chAPIproduct.getDiscountedHalfYearlyPremium() : chAPIproduct.getHalfYearlyPremium();
                                    break;
                                case 3:
                                    premium = promoEnabled ? chAPIproduct.getDiscountedQuarterlyPremium() : chAPIproduct.getQuarterlyPremium();
                                    break;
                                case 4:
                                    premium = promoEnabled ? chAPIproduct.getDiscountedMonthlyPremium() : chAPIproduct.getMonthlyPremium();
                                    break;
                                default:
                                    premium = promoEnabled ? chAPIproduct.getDiscountedYearlyPremium() : chAPIproduct.getYearlyPremium();
                                    break;
                            }
                        }
                    }
                    if (premium != Double.valueOf(payment.getPremiumAmount())) {
                        errorList.add(ChannelAPIExceptionType.INCORRECT_PREMIUM_AMOUNT);
                    }
                } catch (Exception ex) {
                    errorList.add(ChannelAPIExceptionType.INTERNAL_ERROR);
                    logger.error("Exception Occurred validating payment-Premium for dpTransactionID (CustomID) {} ", channelAPIDto.getDPTransactionID(), ex);
                }
            }

            if (StringUtils.isEmpty(payment.getPaymentMethod())) {
                errorList.add(ChannelAPIExceptionType.EMPTY_PAYMENT_METHOD);
            } else {
                payment.setPaymentMethod(payment.getPaymentMethod().trim());
                if (!"Q".equals(payment.getPaymentMethod())) {
                    errorList.add(ChannelAPIExceptionType.INVALID_PAYMENT_METHOD);
                }
            }

        }
    }

    @SuppressWarnings("unchecked")
	private <T extends ChannelAPIBasePayLoad> T process(ChannelAPIDto channelAPIDto) throws Exception {
        ChannelAPIBasePayLoad response = null;
        ChannelAPIDto.ChannelAPIType apiType = channelAPIDto.getRequestType();
        try {
            if (ChannelAPIDto.ChannelAPIType.QUOTATION.equals(apiType)) {
                logger.info("Processing for Quotation For : {} : " + channelAPIDto);
                response = channelAPIService.getQuotation(channelAPIDto);
            } else if (ChannelAPIDto.ChannelAPIType.QUOTATION_DOCUMENT.equals(apiType)) {
                logger.info("Processing for Quotation Document For : {} : " + channelAPIDto);
                response = channelAPIService.getQuotationDocument(channelAPIDto);
            } else if (ChannelAPIDto.ChannelAPIType.APPLICATION_SUBMISSION.equals(apiType)) {
                response = channelAPIService.submitCustomerApplication(channelAPIDto);
            }
        } catch (Exception exception) {
            logger.error("Exception occurred while processing : " + channelAPIDto + " " + exception.getMessage(), exception);
            throw  exception;
        }
        if (response == null) {
            throw new Exception("Response Not Received");
        }
        return (T) response;
    }

    private ChannelAPIBaseResponse getErrorResponse(ChannelAPIDto channelAPIDto) {

        buildErrorResponse(channelAPIDto);

        convertResponseObjectTOResponseJson(channelAPIDto);

        encodePayLoad(channelAPIDto);

        return new ChannelAPIBaseResponse(400, channelAPIDto.getEncryptedResponsePayload());
    }

    private <T extends ChannelAPIBasePayLoad> String getSuccessResponse(ChannelAPIDto channelAPIDto, T response) {

        buildSuccessResponse(channelAPIDto, response);

        convertResponseObjectTOResponseJson(channelAPIDto);

        encodePayLoad(channelAPIDto);

        return channelAPIDto.getEncryptedResponsePayload();

    }

    private void convertResponseObjectTOResponseJson(ChannelAPIDto channelAPIDto) {
        try {
            if (channelAPIDto != null && channelAPIDto.getChannelAPIResponse() != null) {
                channelAPIDto.setResponseJson(new ObjectMapper().writeValueAsString(channelAPIDto.getChannelAPIResponse()));
                logger.info("Channel API Object to JSON Conversion Success : {}", channelAPIDto);
            } else {
                logger.info("No response defined : {}", channelAPIDto);
            }
        } catch (Exception exception) {
            logger.error("Exception occurred while converting Object to Payload Type : " + channelAPIDto + " " + exception.getMessage(), exception);
        }
    }

    private void encodePayLoad(ChannelAPIDto channelAPIDto) {
        try {
            if (StringUtils.isNotBlank(channelAPIDto.getResponseJson())) {
                channelAPIDto.setEncryptedResponsePayload(JweUtils.encrypt(channelAPIDto.getResponseJson(), RsaUtils.getRsaPublicKey(configProperties.getRsaPublicKeyLocation())));
                logger.info("Channel API Encode Success : {}", channelAPIDto);
            } else {
                logger.info("No response JSON defined : {}", channelAPIDto);
            }
        } catch (Exception exception) {
            logger.error("Exception occurred while Encrypting PayLoad: " + channelAPIDto + " " + exception.getMessage(), exception);
        }
    }

    private <T extends ChannelAPIBasePayLoad> void buildSuccessResponse(ChannelAPIDto channelAPIDto, T response) {
        if (response != null) {
            channelAPIDto.setChannelAPIResponse(buildResponse(response, Constants.ResponseStatus.SUCCESS));
            logger.info("Channel API Build Success Response Success : {}", channelAPIDto);
        } else {
            logger.info("No success Object defined : {}", channelAPIDto);
        }
    }

    private void buildErrorResponse(ChannelAPIDto channelAPIDto) {
        if (CollectionUtils.isNotEmpty(channelAPIDto.getErrors())) {
            if (ChannelAPIDto.ChannelAPIType.APPLICATION_SUBMISSION.equals(channelAPIDto.getRequestType())) {
                ChannelAPIApplicationStatus applicationStatus = ChannelAPIApplicationStatus.builder()
                        .transactionId(channelAPIDto.getTransactionId())
                        .DPTransactionId(channelAPIDto.getDPTransactionID())
                        .partnerEref(channelAPIDto.getPartnerEref())
                        .errors(getChannelAPIErrors(channelAPIDto.getErrors()))
                        .build();
                ChannelAPIAppSubmissionResponse response = ChannelAPIAppSubmissionResponse.builder().applicationStatus(applicationStatus).build();
                channelAPIDto.setChannelAPIResponse(buildResponse(response, Constants.ResponseStatus.ERROR));
                logger.info("Channel API Build Error Response Success for {} traId {}", channelAPIDto.getRequestType(), channelAPIDto.getTransactionId());

            } else {
                ChannelAPIQuotationAndQuotationDocumentResponse response = new ChannelAPIQuotationAndQuotationDocumentResponse();
                response.setTransactionId(channelAPIDto.getTransactionId());
                response.setDpTransactionId(channelAPIDto.getDPTransactionID());
                response.setErrors(getChannelAPIErrors(channelAPIDto.getErrors()));
                channelAPIDto.setChannelAPIResponse(buildResponse(response, Constants.ResponseStatus.ERROR));
                logger.info("Channel API Build Error Response Success : {}", channelAPIDto);
            }
        } else {
            logger.info("No errors defined : {}", channelAPIDto);
        }
    }

    private List<ChannelAPIError> getChannelAPIErrors(List<ChannelAPIExceptionType> errorList) {
        List<ChannelAPIError> channeAPIErrors = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(errorList)) {
            for (ChannelAPIExceptionType error : errorList) {
                ChannelAPIError channelAPIError = new ChannelAPIError();
                channelAPIError.setCode(error.getCode());
                channelAPIError.setDescription(error.getMessage());
                channeAPIErrors.add(channelAPIError);
            }
        } else {
            logger.info("No errors defined.");
        }
        return channeAPIErrors;
    }

    private <T extends ChannelAPIBasePayLoad> ChannelAPIResponse<?> buildResponse(T response, String responseStatus) {
        ChannelAPIResponse<T> channelAPIResponse = new ChannelAPIResponse<>();
        ChannelAPIResponse.System channelAPIResponseSystem = new ChannelAPIResponse.System();
        channelAPIResponseSystem.setStatus(responseStatus);
        channelAPIResponseSystem.setApiVersion("V1.0");
        channelAPIResponse.setSystem(channelAPIResponseSystem);
        channelAPIResponse.setPayload(response);
        return channelAPIResponse;
    }

    private static final Logger logger = LoggerFactory.getLogger(ChannelAPIController.class);

    private final BiFunction<String, Integer, Integer> mandatoryAndMaxNValidator = (str, max) -> {
        if (StringUtils.isEmpty(str)) {
            return 1;
        }
        if (str.trim().length() > max) {
            return 2;
        }
        return 0;
    };

    private final Predicate<Integer> nameValidator = c -> (Character.isLetter(c) || Character.isSpaceChar(c));

    private final Function<String, Integer> nricValidator = nric -> {
        if (StringUtils.isEmpty(nric)) {
            return 1;
        }
        if (nric.trim().length() > 9) {
            return 2;
        }
        if (!D2CUtils.validateNRIC(nric.trim())) {
            return 3;
        }

        return 0;
    };


    private final Function<String, Integer> premiumFormatValidator = premium -> {
        try {
            if (!premium.matches("^([1-9][0-9]*(.[0-9]+)?)$")) {
                return 1;
            }
            if (!premium.matches("^([1-9][0-9]*(\\.[0-9][0-9]?)?)$")) {
                return 2;
            }
        } catch (Exception ex) {
            logger.error("channel API - Exception in validating premium format value {} ", premium, ex);
            return 1;
        }
        return 0;
    };

}
