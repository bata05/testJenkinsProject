package com.prudential.d2c.controller;

import com.prudential.d2c.entity.config.Channels;
import com.prudential.d2c.service.ChannelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/channel")
public class ChannelController {

    @Autowired
    private ChannelService channelService;

    @RequestMapping("/validate")
    public Object validateChannel(@RequestBody Channels channels){
        return channelService.validateChannel(channels.getChannelName());
    }

}
