package com.prudential.d2c.controller;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.prudential.d2c.common.Constants;
import com.prudential.d2c.common.CyberSourceConstants;
import com.prudential.d2c.entity.*;
import com.prudential.d2c.entity.config.PassTypeMapping;
import com.prudential.d2c.entity.dto.*;
import com.prudential.d2c.entity.micro.*;
import com.prudential.d2c.entity.micro.payload.ComputeResponsePayload;
import com.prudential.d2c.exception.D2CException;
import com.prudential.d2c.repository.*;
import com.prudential.d2c.security.JwtProvider;
import com.prudential.d2c.security.JwtService;
import com.prudential.d2c.service.*;
import com.prudential.d2c.service.micro.SQSEngineService;
import com.prudential.d2c.service.micro.impl.SQSEngineServiceImpl;
import com.prudential.d2c.utils.ConvertBlobToObject;
import com.prudential.d2c.utils.D2CUtils;
import com.prudential.d2c.utils.DocumentUtil;
import com.prudential.d2c.utils.EncryptedIdsUtil;
import org.apache.commons.collections.CollectionUtils;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import javax.servlet.http.HttpServletRequest;
import javax.sql.rowset.serial.SerialBlob;
import javax.xml.bind.DatatypeConverter;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Blob;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.prudential.d2c.common.Constants.*;
import static com.prudential.d2c.utils.StaticFileUtil.convertObjectToJsonFormat;
import static java.util.Arrays.asList;
import static org.springframework.util.StringUtils.isEmpty;

@RestController
@EnableAutoConfiguration
public class ComputeController extends BaseController {

    private static final double DEFAULT_VALUE = 0.0;

    private static final String COMPOCODE_DAN7 = "dan7";

    private static final String COMPOCODE_ENP7 = "enp7";

    private static final String SUFFIX_REFNO = "00000000";

    private static final String PROPOSAL_FOR = "Proposal for ";

    private static final String NB_PROPOSAL = "NB_PROPOSAL";

    private static final String COUNTRY_CODE_SG = "SG";

    private static final String BENEFIT_DESCRIPTION_OPTION_3 = "ACCUMULATE CASH BENEFIT";

    private static final String BENEFIT_DESCRIPTION_OPTION_2 = "DEFERMENT OF CASH BENEFIT";

    private static final String BENEFIT_DESCRIPTION_OPTION_1 = "5% YEARlY CASH BENEFIT";

    private static final String OPTION_CODE_3 = "3";

    private static final String OPTION_CODE_2 = "2";

    private static final String OPTION_CODE_1 = "1";

    private static final String RISK_DESCRIPTION = "For PRUshield Premier, premiums will increase when you reached the next age band. In addition, premium rates are not guaranteed and may be adjusted based on future claims experience. The Company reserves the right to vary premiums at any time by giving 30 days' notice to the policy-owner before doing so. Exclusions (such as preexisting conditions and listed circumstances) apply; please refer to product summary for details. Please note that deductible & co-insurance apply if PruShield Extra is not taken up. There is an annual claim limit for a policy year and exclusions (such as preexisting conditions and listed circumstances) apply; please refer to product summary for details.";

    private static final String BENEFITS_DESCRIPTION = "PRUshield Premier is a medical insurance plan. It provides benefits to meet needs of those who would like more coverage and insurance protection against hospitalisation in A wards of Restructured Hospitals. Please note that PruShield A Plus will automatically replace your existing shield plan with another insurer (if any) when incepted.";

    private static final String PAYMENY_TYPE_INDICATOR_R = "R";

    private static final String PRODUCT_EC7 = "ec7";

    private static final String DOC_ID_EC7 = "id_prod_ec7";

    private static final String CLIENT_ML = "ML";

    private static final String PAYMENT_MODE_Y = "Y";

    private static final String PAYMENT_MODE_M = "M";

    private static final String CURRENCY_SGD = "SGD";

    private static final String COMPUTE_REQUEST = "computeRequest: {}";

    private static final int SEQUENCE_1 = 1;

    private static final int SEQUENCE_2 = 2;

    public static final String HYPHEN = "-";
    public static final String SRS_PAYMENT = "R";
    public static final String CASH_PAYMENT = "Q";
    public static final String PAYMENT_MODE_ZERO_ZERO = "00";
    public static final String PAYMENT_MODE_ZERO_ONE = "01";
    public static final String PAYMENT_TYPE_INDICATOR_S = "S";

    private static String productCodeForLogger = "NA";

    private static String timeStampForLogger = "NA";

    private static final List<String> SP_PROD_TYPES = asList("PGP", "PGRP");
    private static final List<String> SP_PROD_CODES = asList(Constants.CATEGORY_PAS_XB8, Constants.CATEGORY_PAS_XR8);
    private static final List<String> PAS_SP_PROD_CODES = asList(Constants.CATEGORY_PAS_XB8, Constants.CATEGORY_PAS_XR8);
    private static final List<String> SRS_PAYMENT_PROD_CODES = asList(Constants.CATEGORY_PAS_XR8);
    private static final List<String> SRS_PAYMENT_PROD_TYPES = asList("PAS");
    private static final List<String> SRS_QUESTION_CODES = asList("QMAY03601", "QMAY03602");

    @SuppressWarnings("unused")
	@Autowired
    private JwtProvider jwtProvider;
    
    @Autowired
	private RestTemplate restTemplate;

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Value("${esub.json.log.path}")
    private String esub_json_log_path;

    @Autowired
    private QuotationRepository quotationRepository;

    @Autowired
    DominoService dominoService;

    @Autowired
    private QuotationBenefitRepository quotationBenefitRepository;

    @SuppressWarnings("unused")
	@Autowired
    private ErefDataService erefDataService;

    @Autowired
    private ApplicationDataRepository applicationDataRepository;

    @SuppressWarnings("unused")
	@Autowired
    private ProductSalesInfoRepository productSalesInfoRepository;

    @Autowired
    BusinessLookUpService businessLookUpService;

    @Autowired
    private MailService mailService;

    @Autowired
    CountryIDDRepository countryIDDRepository;

    @Autowired
    private CustomerApplicationService customerApplicationService;

    @Autowired
    private ApplicationCybDataRepository applicationCybDataRepository;

    @Autowired
    private TranCustomerAppService tranCustomerAppService;

    @Autowired
    ChannelRepository channelRepository;

    @Autowired
    private SQSEngineService sqsEngineService;

    @Autowired
    private ClientService clientService;

    @Autowired
    private MailListRepository mailListRepository;

    @Autowired
    private DpApiService apiService;

    @Autowired
    private AgentDetailsRepository agentDetailsRepository;

    @Autowired
    private CustomerApplicationRepository customerApplicationRepository;
    
    @Autowired
    private ApplicationDocumentService applicationDocumentService;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private ProductService productService;

    @Autowired
    private ProductPromoService productPromoService;

    @Autowired
	private MyInfoDataRespository myInfoDataRespository;
    
    @Autowired
    private PassTypeMappingRepository passTypeMappingRepository;
    
    /**
     * This method is used to get the premium, SumAssured and payout based on the yearly premium from page
     * <p>
     * Only for Quotation - PRUflexicash
     *
     * @param computeRequest
     * @return ComputeResponse
     * @throws Exception
     */
    @RequestMapping(
            value = "/pfcComputeAll",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ComputeResponse computeAll(@RequestBody D2CRequest computeRequest, boolean generatePdf) {
        logger.info("calling pfcComputeAll()");
        try {
            String convertObjectToJsonFormatForComputeRequest = convertObjectToJsonFormat(computeRequest);
            String logComputeRequestFormat = COMPUTE_REQUEST;
            logger.debug(logComputeRequestFormat, convertObjectToJsonFormatForComputeRequest);
            
            // Build header
            HttpHeaders headers = getHeaders();

            Compute compute = generatePFCComputeAllRequest(computeRequest, generatePdf);

            SelectedPolicyOption selectedPolicyOption = generateSelectedPolicyOption(computeRequest);

            compute.getPayload().getSelectedSQSProducts().get(0).setSelectedPolicyOption(selectedPolicyOption);
            String convertObjectToJsonFormatForCompute = convertObjectToJsonFormat(compute);
            logger.debug(logComputeRequestFormat, convertObjectToJsonFormatForCompute);
            HttpEntity<Compute> entityReq = new HttpEntity<>(compute, headers);
            Date date1 = new Date();
            String date1Format = getDf().format(date1);
            logger.info("call url: {} on {}", configProperties.getComputeUrl(), date1Format);
            
            Compute computeRes = restTemplate.postForObject(configProperties.getComputeUrl(), entityReq, Compute.class);
            Date date2 = new Date();
            String date2Format = getDf().format(date2);
            String logEndServiceAndCostInfoFormat = "end service on {} and cost time: {}";
            logger.info(logEndServiceAndCostInfoFormat, date2Format, (date2.getTime() - date1.getTime()));
            String convertObjectToJsonFormatForComputeRes = convertObjectToJsonFormat(computeRes);
            logger.debug("computeResponse : {} ", convertObjectToJsonFormatForComputeRes);
            computeRes.setSystem(getComputeSystem());
            computeRes.getPayload().getSelectedSQSProducts().get(0).setSelectedPolicyOption(selectedPolicyOption);
            HttpEntity<Compute> entityAllReq = new HttpEntity<>(computeRes, headers);
            String convertObjectToJsonFormatForComputeAllRequest = convertObjectToJsonFormat(entityAllReq);
            logger.debug("computeAllRequest : {}", convertObjectToJsonFormatForComputeAllRequest);
            Date date3 = new Date();
            String date3Format = getDf().format(date3);
            logger.info("call urlAll: {} on {}", configProperties.getComputeAllUrl(), date3Format);
            Compute computeAllRes = restTemplate.postForObject(configProperties.getComputeAllUrl(), entityAllReq,
                    Compute.class);
            Date date4 = new Date();
            String date4Format = getDf().format(date4);
            logger.info(logEndServiceAndCostInfoFormat, date4Format, (date4.getTime() - date3.getTime()));
            String computeAllResponseJsonFormat = convertObjectToJsonFormat(computeAllRes);
            logger.debug("computeAllResponse: {}", computeAllResponseJsonFormat);

            String mainPayout = computeAllRes.getPayload().getSelectedSQSProducts().get(0).getTables()
                    .getMainBenefitTable().getData().get(Integer.valueOf(computeRequest.getSelectedTerm()) - 1).get(13);
            String accumulatedPayout = computeAllRes.getPayload().getSelectedSQSProducts().get(0).getTables()
                    .getAccumulatedBenefitTable().getData().get(Integer.valueOf(computeRequest.getSelectedTerm()) - 1)
                    .get(3);
            ComputeResponse res = new ComputeResponse();
            res.setPremium(computeAllRes.getPayload().getSelectedSQSProducts().get(0).getTotalPremium());
            res.setMonthlyPremium(computeAllRes.getPayload().getSelectedSQSProducts().get(0).getTotalMonthlyPremium());
            res.setYearlyPremium(computeAllRes.getPayload().getSelectedSQSProducts().get(0).getTotalYearlyPremium());
            res.setEnp7Premium(
                    computeAllRes.getPayload().getSelectedSQSProducts().get(0).getComponents().get(0).getPremium());
            res.setEnp7MonthlyPremium(
                    computeAllRes.getPayload().getSelectedSQSProducts().get(0).getComponents().get(0).getMonthlyPremium());
            res.setEnp7YearlyPremium(
                    computeAllRes.getPayload().getSelectedSQSProducts().get(0).getComponents().get(0).getYearlyPremium());

            res.setDan7Premium(
                    computeAllRes.getPayload().getSelectedSQSProducts().get(0).getComponents().get(1).getPremium());
            res.setDan7MonthlyPremium(
                    computeAllRes.getPayload().getSelectedSQSProducts().get(0).getComponents().get(1).getMonthlyPremium());
            res.setDan7YearlyPremium(
                    computeAllRes.getPayload().getSelectedSQSProducts().get(0).getComponents().get(1).getYearlyPremium());

            res.setSumAssured(
                    computeAllRes.getPayload().getSelectedSQSProducts().get(0).getComponents().get(0).getSumAssured());
            res.setMinSumAssured(
                    computeRes.getPayload().getSelectedSQSProducts().get(0).getComponents().get(0).getMinSumAssured());
            res.setMainPayout(Double.valueOf(mainPayout));
            res.setAccumulatedPayout(Double.valueOf(accumulatedPayout));
            res.setTotalPayout(res.getMainPayout() + res.getAccumulatedPayout());

            String totalDeathBenefit = computeAllRes.getPayload().getSelectedSQSProducts().get(0).getTables()
                    .getMainBenefitTable().getData().get(Integer.valueOf(computeRequest.getSelectedTerm()) - 1).get(26);
            String totalSV = computeAllRes.getPayload().getSelectedSQSProducts().get(0).getTables()
                    .getMainBenefitTable().getData().get(Integer.valueOf(computeRequest.getSelectedTerm()) - 1).get(32);

            res.setTotalDeathBenefit(Double.valueOf(totalDeathBenefit));
            res.setTotalSV(Double.valueOf(totalSV));

            if (generatePdf) {
                res.setPdfFile(computeAllRes.getPayload().getPdfData().getFile());
            }
            logger.debug("computeAll Response: {} ", res);
            logger.info("end computeAll()");

            return res;
        } catch (Exception e) {
            logger.error(e.getMessage());
            throw new D2CException("Compute all error");
        }
    }

    //
    // /**
    // * This method is used to get pdf and erefcode on summary page for both three quotations
    // *
    // * @param computeRequest
    // * @return ComputeResponse
    // * @throws Exception
    // */
    @SuppressWarnings("deprecation")
	@RequestMapping(
            value = "/finalComputeAll",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object computeAllFinal(@RequestBody D2CRequest computeRequest) {
        logger.info("calling finalComputeAll()");
        // Build header
        HttpHeaders headers = getHeaders();
        if (logger.isDebugEnabled()) {
            logger.debug(COMPUTE_REQUEST, convertObjectToJsonFormat(computeRequest));
        }


        String requestType = computeRequest.getReqType();

        ComputeResponse res = new ComputeResponse();
        // build compute request

        Compute processComputeRes = null;

        if (Constants.PRU_FLEXI_CASH.equalsIgnoreCase(requestType)) {
            res = computeAll(computeRequest, true);
            computeRequest.setSumAssured(res.getSumAssured());
        } else {
            Compute compute;
            if (Constants.PRU_SHIELD.equalsIgnoreCase(requestType)) {
                compute = generatePSComputeRequest(computeRequest);
            } else {
                CustomerApplication customerApplication = customerApplicationService.findCustomerApplicationByCustomId(computeRequest.getCustomId());
                ClientInfo clientInfo = null;
                boolean isExistingCustomer = false;
                if (customerApplication.getClientNumber() != null) {
                    isExistingCustomer = true;
                    List<ClientInfo> clientList = clientService.getClientByClientNumber(customerApplication.getClientNumber());
                    clientInfo = clientList.get(0);
                }

                if (!isPremiumModified(computeRequest) || (isExistingCustomer &&  !validateLifeProfileForExistingCustomer (computeRequest , clientInfo))) {
                    res.setStatusCode(HttpStatus.SC_EXPECTATION_FAILED);
                    logger.error("Return errors back: {}", res.toString());
                    res.setStatus(Constants.ERROR_STATUS);
                    return res;
                }

                setDecryptedNameInComputeReq(computeRequest);


                compute = generatePAComputeRequest(computeRequest);
                res.setPremium(Double.valueOf(getPAPremiums(computeRequest).getTotalYearlyPremium()));
            }
            HttpEntity<Compute> entityReq = new HttpEntity<>(compute, headers);

            String convertObjectToJsonFormatForFinalComputeAllRequest = convertObjectToJsonFormat(compute);
            logger.debug("finalComputeAllRequest: {}", convertObjectToJsonFormatForFinalComputeAllRequest);
            Date date1 = new Date();
            String date1Format = getDf().format(date1);
            logger.debug("call urlAll: {} on {}", configProperties.getComputeAllUrl(), date1Format);
            Compute computeAllRes = restTemplate.postForObject(configProperties.getComputeAllUrl(), entityReq,
                    Compute.class);

            processComputeRes = computeAllRes;

            Date date2 = new Date();
            String date2Format = getDf().format(date2);
            logger.debug("end service on {} and cost time: {}", date2Format, (date2.getTime() - date1.getTime()));
            if (logger.isDebugEnabled()) {
                logger.debug("finalComputeAllResponse : {} ", convertObjectToJsonFormat(computeAllRes));
            }
            if (!ObjectUtils.isEmpty(computeAllRes.getPayload().getPdfData())) {
                res.setPdfFile(computeAllRes.getPayload().getPdfData().getFile());
            }
            if (CollectionUtils.isNotEmpty(computeAllRes.getPayload().getSelectedSQSProducts()) && CollectionUtils
                    .isNotEmpty(computeAllRes.getPayload().getSelectedSQSProducts().get(0).getComponents())) {
                computeRequest.setSumAssured(
                        computeAllRes.getPayload().getSelectedSQSProducts().get(0).getComponents().get(0).getSumAssured());
            }
        }
        // build MD5
        if (!StringUtils.isEmpty(res.getPdfFile())) {
            byte[] resDecode = Base64.getDecoder().decode(res.getPdfFile());

            byte[] hash;
            try {
                hash = MessageDigest.getInstance(Constants.SHA256_ALGORITHM).digest(resDecode);
            } catch (NoSuchAlgorithmException e) {
                logger.error("Build MD5 error");
                throw new D2CException("Build MD5 error");
            }
            String pdfMD5 = DatatypeConverter.printHexBinary(hash);
            logger.info("MD5 actual: {}", D2CUtils.removeCRLF(pdfMD5));
            res.setPdfMD5(pdfMD5);
        }

        productPromoService.calculateDiscountPromo(processComputeRes);
        String erefCode = apiService.generateErefNo(computeRequest.getCustomId(), processComputeRes);

        /*TransactionalCustomerApplication customData = tranCustomerAppService.findByCustId(computeRequest.getCustomId());
        if (customData == null || customData.getComputeAllObj() == null) {
            String agentCode = assignedAgentService.getAgentCodeByCustomId(computeRequest.getCustomId());
            if (!agentCode.equals(Constants.NOT_APPLICABLE)) {
                erefCode = erefDataService.generateEREFCode(agentCode);
            }
        } else {
            Compute compute = new ConvertBlobToObject<>(Compute.class, customData.getComputeAllObj()).getObject();
            erefCode = compute.getPayload().geteReferenceNo();
        }*/

        res.setErefCode(erefCode);

        processComputeRes.getPayload().seteReferenceNo(erefCode);

        tranCustomerAppService.saveComputeAllObj(processComputeRes, computeRequest.getCustomId());

        logger.info("finalComputeAll Response: {} ", res);
        logger.info("end finalComputeAll()");

        return res;
    }

    /**
     * This method will get the quotation details based on the request type
     *
     * @param computeRequest
     * @return QuotationPlanResult
     */
    @SuppressWarnings("deprecation")
	// @CrossOrigin
    @RequestMapping(
            value = "/quotation",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object quotation(@RequestBody D2CRequest computeRequest) {
        logger.info("calling quotation()");
        if (logger.isDebugEnabled()) {
            logger.debug("calling quotation: ", convertObjectToJsonFormat(computeRequest));
        }
        String occupationCode = computeRequest.getOccupationCode();
        String residencyCode = computeRequest.getResidencyCode();
        Integer age = computeRequest.getAge();
        // Get the req type to verify the service
        // PA:PruPersonal Accident -- get a free quote
        // RA:PruPersonal Accident -- select this plan
        // PS:PRUshield -- get a free quote
        String reqType = computeRequest.getReqType();
        String planCode = computeRequest.getPlanCode();
        logger.info("computeRequest:{}", computeRequest);

        if (Constants.RECOVERY_AID.equalsIgnoreCase(reqType)) {

            QuotationPlan quotationPlan = new QuotationPlan();
            List<QuotationPlan> quotationFCPAList = new ArrayList<>();

            final Quotation quotation = quotationRepository.findByTypeAndOccupationClassAndPlan(Constants.RECOVERY_AID, occupationCode, planCode);

            //TODO: To cater for individual channel code discounts
            PromoResponse promoResponse = productService.validateProductPromo(ProductEnum.PA.getProdCode(),"ALL");

            if (!StringUtils.isEmpty(quotation)) {

                quotationPlan = this.populateQuotationWithPromoDiscount(Arrays.asList(quotation), promoResponse).get(0);
                final List<Quotation> quotationListFCPA = quotationRepository
                        .findByTypeAndOccupationClassAndFirstAgeLessThanEqualAndLastAgeGreaterThanEqualAndResidency(
                                Constants.FRACTURE_CARE_PA, occupationCode, age, age, residencyCode);



                quotationFCPAList.addAll(this.populateQuotationWithPromoDiscount(quotationListFCPA, promoResponse));
            }

            QuotationPlanResult quotationPlanResult = new QuotationPlanResult();

            quotationPlanResult.setQuotationRA(quotationPlan);
            quotationPlanResult.setQuotationFCPAList(quotationFCPAList);
            logger.info("quotation response: {}", quotationPlanResult);
            logger.warn("end quotation()");
            return quotationPlanResult;

        } else {

            List<Quotation> quotationList;
            String promoProd = "";
            if (Constants.PRUPERSONAL_ACCIDENT.equalsIgnoreCase(reqType)) {
                promoProd = ProductEnum.PA.getProdCode();
                quotationList = quotationRepository
                        .findByTypeAndOccupationClassAndFirstAgeLessThanEqualAndLastAgeGreaterThanEqualAndResidency(
                                reqType, occupationCode, age, age, residencyCode);
            } else {
                quotationList = quotationRepository
                        .findByTypeAndFirstAgeLessThanEqualAndLastAgeGreaterThanEqualAndResidency(reqType, age, age,
                                residencyCode);
            }
   
            //TODO: To cater for individual channel code discounts
            List<QuotationPlan> quotationPlanList = populateQuotationWithPromoDiscount(quotationList, productService.validateProductPromo(promoProd,"ALL"));

            logger.debug("quotation response: {}", quotationPlanList);
            logger.warn("end quotation()");
            return quotationPlanList;
        }

    }

    @SuppressWarnings("deprecation")
	private List<QuotationPlan> populateQuotationWithPromoDiscount(List<Quotation> quotationList, PromoResponse productPromo) {
        List<QuotationPlan> quotationPlanList = new ArrayList<>();

        double discountRate = 0;
        if (productPromo != null && productPromo.isPromoValid() && productPromo.getDiscountPercentage() != null) {
            discountRate = productPromo.getDiscountPercentage() / 100;
        }

        QuotationPlan quotationPlan;
        for (Quotation quotation : quotationList) {
            quotationPlan = new QuotationPlan();
            quotationPlan.setPlanName(quotation.getPlan());
            quotationPlan.setMainValue(quotation.getMainValue());

            if(discountRate > 0 && !StringUtils.isEmpty(quotation.getMainValue())) {
                String premiumValue = quotation.getMainValue().replaceAll(Constants.DOLLAR_IN_BRACKET, EMPTY_STRING);
                quotationPlan.setDiscountedMainValue(Constants.DOLLAR + this.calculateDiscountedPremium(premiumValue, quotationPlan.getPlanName(), discountRate ));
            }

            quotationPlan.setMainValue2(quotation.getMainValue2());
            quotationPlan.setSumAssured(quotation.getSumAssured());
            final List<QuotationBenefit> quotationBenefitList = quotationBenefitRepository
                    .findByPlanAndType(quotation.getPlan(), quotation.getType());
            quotationPlan.setBenefits(quotationBenefitList);

            quotationPlanList.add(quotationPlan);
        }

        return quotationPlanList;

    }

    /**
     * This method is used to re get quotation once the occupationCode updated based on job title input
     * <p>
     * Only for Quotation - PruPersonal Accident
     *
     * @param computeRequest
     * @return ComputeResponse
     */
    @SuppressWarnings("deprecation")
	@RequestMapping(
            value = "/finalQuotation",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object quotationFinal(@RequestBody D2CRequest computeRequest) {
        logger.debug("calling finalQuotation()");
        if (logger.isDebugEnabled()) {
            logger.debug("calling quotationfinal: ", convertObjectToJsonFormat(computeRequest));
        }
        String occupationCode = computeRequest.getOccupationCode();
        String residencyCode = computeRequest.getResidencyCode();
        Integer age = computeRequest.getAge();
        String reqType = computeRequest.getReqType();

        String planCode = computeRequest.getPlanCode();
        String planRA = computeRequest.getPlanRA();
        String planFCPA = computeRequest.getPlanFCPA();
        logger.debug(COMPUTE_REQUEST, computeRequest);

        ComputeResponse res = new ComputeResponse();
        String premiumPA = Constants.START_POLICY_STATUS;
        String premiumRA = Constants.START_POLICY_STATUS;
        String premiumPAFE = Constants.START_POLICY_STATUS;
        String premiumPS1 = Constants.START_POLICY_STATUS;
        String premiumPS2 = Constants.START_POLICY_STATUS;
        double discountedTotalPremium = 0;

        if (Constants.PRUPERSONAL_ACCIDENT.equalsIgnoreCase(reqType)) {
        	//TODO: To cater for individual channel code discounts
            PromoResponse productPromo = productService.validateProductPromo(ProductEnum.PA.getProdCode(),"ALL");
            double discountRate = 0;
            if (productPromo != null && productPromo.isPromoValid() && productPromo.getDiscountPercentage() != null) {
                discountRate = productPromo.getDiscountPercentage() / 100;
            }

            if (!StringUtils.isEmpty(planCode)) {
                final Quotation quotationPA = quotationRepository
                        .findByTypeAndOccupationClassAndPlanAndFirstAgeLessThanEqualAndLastAgeGreaterThanEqualAndResidency(
                                Constants.PRUPERSONAL_ACCIDENT, occupationCode, planCode, age, age, residencyCode);

                premiumPA = quotationPA.getMainValue().replaceAll(Constants.DOLLAR_IN_BRACKET, EMPTY_STRING);
                res.setPremiumPA(quotationPA.getMainValue());

                if (discountRate > 0) {
                    double discountedMainValue = calculateDiscountedPremium(premiumPA,quotationPA.getPlan(), discountRate);
                    discountedTotalPremium += discountedMainValue;
                    res.setDiscountedPremiumPA(Constants.DOLLAR + String.valueOf(discountedMainValue));
                }

                res.setSumAssuredPA(quotationPA.getSumAssured());
            }
            if (!StringUtils.isEmpty(planRA)) {
                final Quotation quotationRA = quotationRepository
                        .findByTypeAndOccupationClassAndPlan(Constants.RECOVERY_AID, occupationCode, planRA);
                premiumRA = quotationRA.getMainValue().replaceAll(Constants.DOLLAR_IN_BRACKET, EMPTY_STRING);
                res.setPremiumRA(quotationRA.getMainValue());

                if (discountRate > 0) {
                    double discountedMainValue = calculateDiscountedPremium(premiumRA, quotationRA.getPlan(), discountRate);
                    discountedTotalPremium += discountedMainValue;
                    res.setDiscountedPremiumRA(Constants.DOLLAR + String.valueOf(discountedMainValue));
                }

                res.setSumAssuredRA(quotationRA.getSumAssured());
            }
            if (!StringUtils.isEmpty(planFCPA)) {
                final Quotation quotationFCPA = quotationRepository
                        .findByTypeAndOccupationClassAndPlanAndFirstAgeLessThanEqualAndLastAgeGreaterThanEqualAndResidency(
                                Constants.FRACTURE_CARE_PA, occupationCode, planFCPA, age, age, residencyCode);
                premiumPAFE = quotationFCPA.getMainValue().replaceAll(Constants.DOLLAR_IN_BRACKET, EMPTY_STRING);
                res.setPremiumPAFE(quotationFCPA.getMainValue());

                if (discountRate > 0) {
                    double discountedMainValue = calculateDiscountedPremium(premiumPAFE, quotationFCPA.getPlan(), discountRate);
                    discountedTotalPremium += discountedMainValue;
                    res.setDiscountedPremiumPAFE(Constants.DOLLAR + String.valueOf(discountedMainValue));
                }

                res.setSumAssuredPAFE(quotationFCPA.getSumAssured());
            }

            res.setPremium(Double.valueOf(premiumPA) + Double.valueOf(premiumRA) + Double.valueOf(premiumPAFE));
            if (discountRate > 0 && discountedTotalPremium > 0) {
                res.setDiscountedPremium(discountedTotalPremium);
            }

        } else if (Constants.PRU_SHIELD.equalsIgnoreCase(reqType)) {
            List<Quotation> quotationList;

            quotationList = quotationRepository
                    .findByTypeAndFirstAgeLessThanEqualAndLastAgeGreaterThanEqualAndResidency(reqType, age, age,
                            residencyCode);

            if (CollectionUtils.isNotEmpty(quotationList)) {
                Quotation quotation = quotationList.get(0);
                premiumPS1 = quotation.getMainValue().replaceAll(Constants.DOLLAR_IN_BRACKET, EMPTY_STRING);
                premiumPS2 = quotation.getMainValue2().replaceAll(Constants.DOLLAR_IN_BRACKET, EMPTY_STRING);
            }
            res.setPremium(Double.valueOf(premiumPS1) + Double.valueOf(premiumPS2));

        }
        if (logger.isDebugEnabled()) {
            logger.debug("quotationFinal response: {}", convertObjectToJsonFormat(res));
        }
        logger.debug("end quotationFinal()");
        return res;

    }

    @SuppressWarnings("deprecation")
	private double calculateDiscountedPremium(String mainValue, String plan, double discountRate) {
        double discountedMainValue = 0;
        if (discountRate > 0 && !StringUtils.isEmpty(mainValue)) {
            try {

                //Using BigDecimal to accommodate Correct Rounding and to avoid decimal precision issues when calculating with double
                BigDecimal premiumObj = new BigDecimal(mainValue).setScale(2);
                BigDecimal discountRateObj = new BigDecimal(String.valueOf(discountRate)).setScale(2);
                BigDecimal discountObj = premiumObj.multiply(discountRateObj).setScale(2, RoundingMode.HALF_UP);
                discountedMainValue = premiumObj.subtract(discountObj).doubleValue();
            } catch (Exception ex) {
                logger.error("Error occurred at calculating discounted Premium value for : " + plan, ex);
            }

        }
        return discountedMainValue;
    }

    private ComputeResponsePayload transformComputeToComputeResponse(Compute compute) {
        ComputeResponsePayload computeResponsePayload = new ComputeResponsePayload();
        Payload payload = compute.getPayload();

        //Only setting variables needed for the eSubmission function

        computeResponsePayload.setLifeProfiles(new ArrayList<>());
        for (LifeProfile lifeProfile : payload.getLifeProfiles()) {
            computeResponsePayload.getLifeProfiles().add(lifeProfile);
        }
        computeResponsePayload.setErefCode(payload.geteReferenceNo());
        computeResponsePayload.setSelectedSQSProducts(new ArrayList<>());
        for (SelectedSQSProduct selectedSQSProduct : payload.getSelectedSQSProducts()) {
            Product product = new Product();

            product.setProdCode(selectedSQSProduct.getProdCode());
            product.setProdDesc(selectedSQSProduct.getProdDesc());
            product.setTotalPremium((double) selectedSQSProduct.getTotalPremium());
            product.setTotalYearlyPremium((double) selectedSQSProduct.getTotalYearlyPremium());
            product.setTotalHalfYearlyPremium((double) selectedSQSProduct.getTotalHalfYearlyPremium());
            product.setTotalQuarterlyPremium((double) selectedSQSProduct.getTotalQuarterlyPremium());
            product.setTotalMonthlyPremium((double) selectedSQSProduct.getTotalMonthlyPremium());
            product.setComponents(new ArrayList<>());

            for (SelectedSQSProductComponent sqsProductComponent : selectedSQSProduct.getComponents()) {
                Component component = new Component();

                component.setCompoCode(sqsProductComponent.getCompoCode());
                component.setIsBasic(sqsProductComponent.getIsBasic());
                component.setIsRequired(sqsProductComponent.getIsRequired());
                component.setLifeInsuredType(sqsProductComponent.getLifeInsuredType());
                component.setTerm(sqsProductComponent.getTerm());
                component.setBenefitTerm(sqsProductComponent.getBenefitTerm());
                component.setMinPolicyTerm(sqsProductComponent.getMinPolicyTerm());
                component.setPremiumTerm(sqsProductComponent.getPremiumTerm());
                if (sqsProductComponent.getPremium() != null) {
                    component.setPremium((double) sqsProductComponent.getPremium().doubleValue());
                }
                if (sqsProductComponent.getYearlyPremium() != null) {
                    component.setYearlyPremium((double) sqsProductComponent.getYearlyPremium().doubleValue());
                }
                if (sqsProductComponent.getMonthlyPremium() != null) {
                    component.setMonthlyPremium((double) sqsProductComponent.getMonthlyPremium().doubleValue());
                }
                if (sqsProductComponent.getSumAssured() != null) {
                    component.setSumAssured((double) sqsProductComponent.getSumAssured().doubleValue());
                }
                component.setCompoDesc(sqsProductComponent.getCompoDesc());
                component.setSequence(sqsProductComponent.getSequence());
                if (sqsProductComponent.getMinSumAssured() != null) {
                    component.setMinSumAssured((double) sqsProductComponent.getMinSumAssured().doubleValue());
                }
                if (sqsProductComponent.getMaxSumAssured() != null) {
                    component.setMaxSumAssured((double) sqsProductComponent.getMaxSumAssured().doubleValue());
                }
                component.setBenefitsDesc(sqsProductComponent.getBenefitsDesc());
                component.setRiskDesc(sqsProductComponent.getRisksDesc());
                component.setBenefitCode(sqsProductComponent.getBenefitCode());
                component.setIsDefault(sqsProductComponent.isDefault());
                PlanOption planOption = new PlanOption();
                if (sqsProductComponent.getSelectedCompoPlanOption() != null) {
                    planOption.setOptCode(sqsProductComponent.getSelectedCompoPlanOption().getOptCode());
                    planOption.setOptDescp(sqsProductComponent.getSelectedCompoPlanOption().getOptDescp());
                    planOption.setOptValue(sqsProductComponent.getSelectedCompoPlanOption().getOptValue());
                    planOption.setIsOptValueEditable(sqsProductComponent.getSelectedCompoPlanOption().isOptValueEditable());
                    component.setSelectedCompoPlanOption(planOption);
                } else
                    component.setSelectedCompoPlanOption(null);
                component.setSelectedTermOption(null);

                product.getComponents().add(component);
            }

            computeResponsePayload.getSelectedSQSProducts().add(product);
        }
        return computeResponsePayload;
    }

    /**
     * Return payment method
     * @param prodType
     * @param prodCode
     * @return
     */
    private String getPaymentMethod(String prodType, String prodCode){
        if(SRS_PAYMENT_PROD_TYPES.contains(prodType.toUpperCase())){
            if(SRS_PAYMENT_PROD_CODES.contains(prodCode.toUpperCase())){
                return SRS_PAYMENT;
            }
        }
        return CASH_PAYMENT;
    }

    /**
     * Get the payment mode
     * 00, 01
     * @param prodType
     * @param prodCode
     * @return
     */
    private String getPaymentMode(String prodType, String prodCode){
        if(SP_PROD_TYPES.contains(prodType.toUpperCase()) || SP_PROD_CODES.contains(prodCode.toUpperCase())){
            return PAYMENT_MODE_ZERO_ZERO;
        }
        return PAYMENT_MODE_ZERO_ONE;
    }

    /**
     * Payment type indicator
     * @param prodType
     * @param prodCode
     * @return
     */
    private String getPaymentTypeIndicator(String prodType, String prodCode){
        if(SP_PROD_TYPES.contains(prodType.toUpperCase()) || SP_PROD_CODES.contains(prodCode.toUpperCase())){
            return PAYMENT_TYPE_INDICATOR_S;
        }
        return PAYMENY_TYPE_INDICATOR_R;
    }

    /**
     * Override product details for single premium PAS Product based on payment type
     * @param computeAllResponse
     * @param computeRequest
     * @return
     */
    private ComputeResponsePayload overrideProductDetailsForSinglePremium(ComputeResponsePayload computeAllResponse, Compute computeRequest){
        Product product = computeAllResponse.getSelectedSQSProducts().get(0);
        if(product.getProdCode().equalsIgnoreCase(Constants.CATEGORY_PAS_XB8)){
            String passpPaymentMethod = getPASSPPaymentMethod(computeRequest.getPayload().getProposal().getForms());
            if(passpPaymentMethod.equals(SRS_PAYMENT)){
                product.setProdCode(Constants.CATEGORY_PAS_XR8);
                product.setDocId(Constants.DOCID_PREFIX+Constants.CATEGORY_PAS_XR8.toLowerCase());
                Component basicComponent = getBasicComponent(product.getComponents());
                basicComponent.setCompoCode(Constants.CATEGORY_PAS_EC28_COMPO);
            }
        }
        return computeAllResponse;
    }

    private Component getBasicComponent(List<Component> components){
        return components.stream()
                .filter(component -> component.getIsBasic())
                .findFirst()
                .orElse(null);
    }

    private String getPASSPPaymentMethod(List<Form> questionForm){
        for (Form questionFormVal : questionForm) {
            for (QuestionnaireForm questionaire : questionFormVal.getQuestionnaireForms()) {
                for (Question question : questionaire.getQuestions()) {
                    if (SRS_QUESTION_CODES.contains(question.getQuestionCode().toUpperCase())
                            && question.getAnswerValue() != null && question.getAnswerValue().equals(Constants.VALUE_NUM_1)) {
                        return SRS_PAYMENT;
                    }
                }
            }
        }
        return CASH_PAYMENT;
    }


    /**
     * business logic: summary createPDF--> save application_data--> makepayment -->updatePaymentStatus -->esub update
     *
     * @throws IOException
     */
    @SuppressWarnings("deprecation")
	@ResponseBody
    @RequestMapping(
            value = "/submitEsub",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public Object submitEsub(@RequestBody Compute compute) throws IOException, CloneNotSupportedException {
        if (logger.isDebugEnabled()) {
            logger.debug("calling submitEsub method");
        }

        logger.info("Invoking submitEsub.");
        logger.info("submitEsub payload : {} ", convertObjectToJsonFormat(compute));

        List<ProductSalesInfo> productSalesInfos = new ArrayList<>();

        //Hold front end request data
        Compute computeRequest = compute;

        //PACSDP-4610
        //Validate file MimeType
        //Validate Image content
        //Validate file Name length
        //Validate file Name Pattern
        //Validate Image File Size
        //Validate file type
        //Validate file extension (PDF)
        //Remove all control chars from filename

        List<PdfFile> pdfFiles =computeRequest.getPayload().getFiles();
        for(int i=0;i<pdfFiles.size();i++){
            String fileName = pdfFiles.get(i).getFileName();
            String fileType = pdfFiles.get(i).getFileType();

            //Remove all control chars from filename
            fileName=D2CUtils.removeControlCharFull(fileName);

            //validate file extension
            if(!fileName.toLowerCase().endsWith(DocumentUtil.FILE_EXT_PDF)){
                logger.error("file extension not valid, fileName={}",fileName);
                return new Response(Constants.ERROR_STATUS);
            }


            //validate file type
            if(!D2CUtils.validateFileType(fileType)){
                logger.error("file type not valid,fileName={}",fileName);
                return new Response(Constants.ERROR_STATUS);
            }

            //Validate file Name Length
            if(!D2CUtils.validateFileNameLength(fileName)){
                logger.error("Invalid file name length. Filename={}, length={}", fileName, fileName.length());
                return new Response(Constants.ERROR_STATUS);
            }

            //Validate file Name Pattern
            if(!D2CUtils.validateAndRenameFileNamePattern(fileName)){
                logger.error("Invalid file name pattern: {}", fileName);
                return new Response(Constants.ERROR_STATUS);
            }


            String rawData =pdfFiles.get(i).getRawData();
            logger.info("pdfFiles {}. rawData={}",i,rawData);

            if(rawData != null) {
            	byte[] bytes = Base64.getDecoder().decode(rawData.getBytes());
            	//Validate image file size
                //Max file size for PDF is 7 MB
                float maxFileSize=7*1024*1024;
                if(DocumentUtil.validateImageFileSize(bytes,maxFileSize)){
                    logger.error("PDF file size exceeds max limit (7MB): {}", fileName);
                    return new Response(Constants.ERROR_STATUS);
                }
                
                //  logger.debug("rawData: {}", rawData);
                // logger.debug("decodedRawData: {}", decodedRawData);

                //check validMimeType from content
                if(!DocumentUtil.isValidMimeType(bytes,DocumentUtil.MIME_TYPE_PDF)){
                    logger.error("Invalid image mime type: {}", fileName);
                    return new Response(Constants.ERROR_STATUS);
                }

                try {
                    //parse image to validate image content
                    int numOfPages=DocumentUtil.parsePdf(bytes);
                    logger.error("numOfPages={}",numOfPages);
                    if(numOfPages < 1){
                        throw new Exception("numOfPages is less than 1");
                    }
                }catch(Exception e)  {
                    logger.error("Invalid image file: {}, error message={}", fileName, e.getMessage());
                    return new Response(Constants.ERROR_STATUS);
                }
            } else {
            	logger.error("Null raw data: {}", fileName);
            }

        }

        compute = new Compute();
        Payload payload = new Payload();
        compute.setPayload(payload);

        String customId = computeRequest.getPayload().getCustomId();
        String channelCode = computeRequest.getPayload().getProposal().getSrcInd()!=null?computeRequest.getPayload().getProposal().getSrcInd():"";;
        compute.getPayload().setCustomId(customId);
        TransactionalCustomerApplication customData = tranCustomerAppService.findByCustId(customId);
        CustomerApplication customerApp = customerApplicationService.findCustomerApplicationByCustomId(customId);
        ApplicationCybData appCybData = applicationCybDataRepository.findByCustomId(customId);
       
        MailList mailRequest = new MailList();
        mailRequest.setCustomId(customId);
        mailRequest.setMailType(Constants.MAIL_CLOSE);
        List<MailList> mailList = mailService.findMailListByCustomIdAndMailType(mailRequest);

        //only one close browser in DB according to one customId
        MailList mail = mailList.get(0);


        //Testing configuration should not affect normal flow
        try {
            productCodeForLogger = customerApp.getProductType();
            timeStampForLogger = String.valueOf(new Date().getTime());
        } catch (Exception e) {
            logger.debug("Error fetching necessary information for json testing file");
        }

        writeJson("frontend_compute.txt", convertObjectToJsonFormat(computeRequest));

        if (appCybData == null && (customerApp.getProductType().equals("PAS") || customerApp.getProductType().equals("PGP") || customerApp.getProductType().equals("PER")
                || customerApp.getProductType().equals("PGRP"))) {
            appCybData = new ApplicationCybData();
        }
        ComputeResponsePayload computeAllResponse = new ConvertBlobToObject<>(ComputeResponsePayload.class, customData.getComputeAllObj()).getObject();
        customerApp = customerApplicationService.findCustomerApplicationByCustomId(customId);

        //If the product is PA, need to transform the object fetched from the database
        if (customerApp.getProductType().equals("PA")) {
            Compute processCompute = new ConvertBlobToObject<>(Compute.class, customData.getComputeAllObj()).getObject();
            computeAllResponse = transformComputeToComputeResponse(processCompute);
        }

        //override the product information if SRS selected for XC7
        if(PAS_SP_PROD_CODES.contains(computeAllResponse.getSelectedSQSProducts().get(0).getProdCode().toUpperCase())){
            computeAllResponse = overrideProductDetailsForSinglePremium(computeAllResponse, computeRequest);
        }
        String prodCode = computeAllResponse.getSelectedSQSProducts().get(0).getProdCode();
       
        logger.info("SubmitEsub channel Code: {}", channelCode);
        boolean isPrushieldPromoValid = CyberSourceConstants.CYBER_PRODUCT_CODES_DISCOUNT.contains(prodCode) && productService.validateProductPromo(prodCode,channelCode.isEmpty()?"ALL":channelCode).isPromoValid();

        //Note: paymentMethod is being overridden in eSub Pruservice in PruShield(Q,M)
        String paymentMethodVal = getPaymentMethod(customerApp.getProductType(), prodCode);

        invokeSaleCompleteAA(customId, customerApp, computeAllResponse);

        writeJson("customData.txt", convertObjectToJsonFormat(customData));
        writeJson("computeAllResponse.txt", convertObjectToJsonFormat(computeAllResponse));

        String ref = computeAllResponse.getErefCode();

        //Basic init of Compute object
        //PDF files are already set by the front-end in the compute object, no need to touch to it
        compute.setSystem(getComputeSystem());
        compute.getPayload().setTransactionId(EncryptedIdsUtil.generateTransactionId(18));
        compute.getPayload().seteReferenceNo(ref);

        //Get data from the client sent by the front-end
        String maritalStatus = computeRequest.getPayload().getClients().get(0).getMaritalStatus();

        //Init of client list object which apparently always contains only one element
        compute.getPayload().setClients(new ArrayList<>(1));
        EsubClient esubClient = new EsubClient();

        //Set hardcoded data in the client object
        esubClient.setClientId(1);
        esubClient.setChristianName("");
        esubClient.setYearsResideOutside(0);
        esubClient.setDaysResideInside(7300);
        esubClient.setRace("");
        esubClient.setPublicServiceOfficer(false);
        esubClient.setStaffSelectedCompany(false);
        esubClient.setResidentialSameAsProposer(true);
        esubClient.setCountryOfStudy("SNG");
        esubClient.setEducation("");
        esubClient.setEnglishSpeaking(true);
        esubClient.setEmployer("");
        esubClient.setEmploymentType("F");
        esubClient.setAnnualIncomeType("1");
        esubClient.setAnnualBonus(0);
        esubClient.setOtherIncome(0);
        esubClient.setJobDuties("");
        esubClient.setBusinessIndustry("");
        esubClient.setOtherOccupation("");
        esubClient.setYearsToSupport(2);
        esubClient.setDisclose(false);
        esubClient.setPrivateConfidential(false);
        esubClient.setPersonalReason(false);
        esubClient.setJointAsset(false);
        esubClient.setDiscloseOtherReason("");
        esubClient.setAccompanied(false);
        esubClient.setTrusteeName("");
        esubClient.setTrusteeNric("");
        esubClient.setTrusteeRelationship("");
        esubClient.setRelationship("");
        esubClient.setFin("");
        esubClient.setChildOwnCpf(false);
        esubClient.setFiledUsTax(false);
        esubClient.setClientRelationship("FA");

        //Need Attention
        esubClient.setGivenName(customerApp.getGivenName());
        esubClient.setSurname(customerApp.getSurName());
        esubClient.setDateOfBirth(customerApp.getDob());
        esubClient.setSalutation(customerApp.getGender().equals("F") ? "Ms" : "Mr");
        esubClient.setGender(customerApp.getGender());

        String nationality = customerApp.getResidencyStatus();
        if (nationality != null && nationality.equals("SPR")) {
            esubClient.setNationality("SPR");
            esubClient.setNationalitySpr(customerApp.getNationality());
            esubClient.setResidency("SPR");
        } else if (nationality != null && (nationality.equals("SC") || nationality.equals("SNG"))) {
            esubClient.setNationality(customerApp.getNationality());
            esubClient.setNationalitySpr("");
            esubClient.setResidency("SC");
        } else {
            esubClient.setNationality(customerApp.getNationality());
            esubClient.setNationalitySpr("");
            esubClient.setResidency("OTH");
        }
        esubClient.setNric(customerApp.getNricFin());

        //Set maritalStatus from a variable send by the front-end
        esubClient.setMaritalStatus(isEmpty(maritalStatus) ? "Z" : maritalStatus);

        LifeProfile lifeProfile = computeAllResponse.getLifeProfiles().get(0);
        esubClient.setSmoker(lifeProfile.isSmoker());
        if (!StringUtils.isEmpty(customerApp.getHeight())) {
            esubClient.setHeight(Double.parseDouble(customerApp.getHeight()));
        }
        if (!StringUtils.isEmpty(customerApp.getWeight())) {
            esubClient.setWeight(Double.parseDouble(customerApp.getWeight()));
        }
        esubClient.setCountryOfBirth(setDefaultEmptyVal(customerApp.getNationality()));
        esubClient.setCpfAccountNo(customerApp.getNricFin());
        esubClient.setMailSameAsResidential(computeRequest.getPayload().getClients().get(0).isMailSameAsResidential());
        esubClient.setOccupation(setDefaultEmptyVal(lifeProfile.getOccupationCode()));
        esubClient.setOccupationClass(setDefaultEmptyVal(lifeProfile.getOccupation()));
        esubClient.setAnnualIncome(Double.parseDouble(customerApp.getAnnualIncome()));
        esubClient.setAgeNextBirthday(lifeProfile.getAge());

        //Set client's contact object
        esubClient.setContact(new EsubClientContact());

        //Set client's contact hardcoded variables
        esubClient.getContact().setOfficePhoneArea("");
        esubClient.getContact().setMobilePhoneArea("");
      //  esubClient.getContact().setHomePhone("SGP");
        esubClient.getContact().setHomePhone(mail.getPhoneCountryCode());
        esubClient.getContact().setOfficePhone("SGP");
        esubClient.getContact().setMobilePhone("SGP");

        //Set non hardcoded variables (homePhoneArea and email) in client's contact object here
        esubClient.getContact().setEmail(customerApp.getCustomerEmail());

        Optional.ofNullable(mail).ifPresent(m -> esubClient.getContact().setHomePhoneArea(getFormattedPhoneNumber(m)));

        //Init client addresses list
        esubClient.setAddresses(new ArrayList<>(3));
        EsubClientAddress residentialAddress = new EsubClientAddress();
        EsubClientAddress mailingAddress = new EsubClientAddress();
        EsubClientAddress emptyAddress = new EsubClientAddress();

        //Hardcoded variable in the residential address
        residentialAddress.setAddressType("RESIDENTIAL");
        residentialAddress.setCity("");
        residentialAddress.setState("");

        //Set non hardcoded in the residential address object
        String country = customerApp.getResidentialCountry();

        CountryIDD matchingCoutnry = countryIDDRepository.findById(country).orElse(null);
        residentialAddress.setCountry(setDefaultEmptyVal(matchingCoutnry.getCode()));
        residentialAddress.setPostalCode(setDefaultEmptyVal(customerApp.getResidentialPostalCode()));
        residentialAddress.setBlock(setDefaultEmptyVal(customerApp.getResidentialBlockNo()));
        residentialAddress.setStreetName(setDefaultEmptyVal(customerApp.getResidentialStreetName()));
        residentialAddress.setFloorUnit(setDefaultEmptyVal(customerApp.getResidentialUnitNo()));
        residentialAddress.setBuildingName(setDefaultEmptyVal(customerApp.getResidentialBuildingName()));

        //Hardcoded variable in the mailing address
        mailingAddress.setAddressType("MAILING");
        mailingAddress.setCity("");
        mailingAddress.setState("");
        String mailingCountry = customerApp.getMailingCountry();
        CountryIDD matchingMailingCountry = countryIDDRepository.findById(mailingCountry).orElse(null);
        //Set non hardcoded in the mailing address object
        mailingAddress.setCountry(setDefaultEmptyVal(matchingMailingCountry.getCode()));
        mailingAddress.setPostalCode(setDefaultEmptyVal(customerApp.getMailingPostalCode()));
        mailingAddress.setBlock(setDefaultEmptyVal(customerApp.getMailingBlockNo()));
        mailingAddress.setStreetName(setDefaultEmptyVal(customerApp.getMailingStreetName()));
        mailingAddress.setFloorUnit(setDefaultEmptyVal(customerApp.getMailingUnitNo()));
        mailingAddress.setBuildingName(setDefaultEmptyVal(customerApp.getMailingBuildingName()));

        //Fill the empty address
        emptyAddress.setAddressType("");
        emptyAddress.setCountry("");
        emptyAddress.setPostalCode("");
        emptyAddress.setBlock("");
        emptyAddress.setStreetName("");
        emptyAddress.setFloorUnit("");
        emptyAddress.setBuildingName("");
        emptyAddress.setCity("");
        emptyAddress.setState("");

        //Set addresses in the client object in this specific order
        esubClient.getAddresses().add(0, residentialAddress);
        esubClient.getAddresses().add(1, mailingAddress);
        esubClient.getAddresses().add(2, emptyAddress);

        //Set the client in the client list
        compute.getPayload().getClients().add(0, esubClient);

        //Get the basic component to be use later
        List<Component> components = computeAllResponse.getSelectedSQSProducts().get(0).getComponents();
        Component basicComponent = null;
        for (Component component : components) {
            //Prushield isBasic flag main component is set in FE
            if (component.getIsBasic()) {
                basicComponent = component;
                break;
            }
        }

        //Init the SQSProduct object
        SQSProduct sqsProduct = new SQSProduct();
        //Set hardcoded variables in the sqs object
        sqsProduct.setSqsId(1);
        sqsProduct.setBackdating(false);
        sqsProduct.setPremiumBackDate(null);
        sqsProduct.setSqsVersion("SQS V1.0.0 B1.100 E E. & O.E 0");
        if(customerApp.getProductType().equals("PAT")){
            sqsProduct.setSqsVersion("SQS V9.5.0 B1.100 E");
        }
        sqsProduct.setClientId(1);
        sqsProduct.setProductCategoryCode("");
        sqsProduct.setProductCode(prodCode);
        sqsProduct.setImpairedLife(false);
        sqsProduct.setCrisisWaiver(false);
        sqsProduct.setEarlyCrisisWaiver(false);
        sqsProduct.setPortfolioNo("");
        sqsProduct.setProductCategoryId(2);

        //Set non hardcoded variable in the sqs object
        String currency = computeAllResponse.getSelectedSQSProducts().get(0).getCurrency();
        sqsProduct.setCurrencyCode(customerApp.getProductType().equals("PGP") ? currency : "SGD");
        sqsProduct.setProductCurrency(customerApp.getProductType().equals("PGP") ? currency : "SGD");

        String paymentTypeIndicatorVal = getPaymentTypeIndicator(customerApp.getProductType(), prodCode);
        sqsProduct.setPaymentTypeIndicator(paymentTypeIndicatorVal);

        String paymentModeVal = getPaymentMode(customerApp.getProductType(), prodCode);

        //Set policy option from the front-end variable
        sqsProduct.setPolicyOption(computeRequest.getPayload().getSqs().getPolicyOption());

        //Set the timestamp
        sqsProduct.setSqsTimestamp(String.valueOf((new Date().getTime() / 1000)));

        //Init the lifeAssured list in sqsProduct here
        sqsProduct.setLifeAssureds(new ArrayList<>(1));
        SQSProductLifeAssured lifeAssured = new SQSProductLifeAssured();

        //Set hardcoded variables in the life assured object
        lifeAssured.setLifeAssuredId(1);
        lifeAssured.setLifeAssuredType("MAIN");
        lifeAssured.setClientType("LO");
        lifeAssured.setClientId(1);
        lifeAssured.setSequenceNo(0);
        lifeAssured.setProposer(true);

        //Init the riders list in the life assured object which can have a dynamic size
        lifeAssured.setRiders(new ArrayList<>());

        //Init the plans list in the life assured object
        lifeAssured.setPlans(new ArrayList<>(1));
        SQSProductPlan plan = new SQSProductPlan();

        //Set hardcoded variables in the plan object
        plan.setPlanId(1);
        plan.setPlanType("BASIC");
        plan.setBenefit(0);
        plan.setDuration(64);
        //Set the payment method
        plan.setPaymentMethod(paymentMethodVal);
        plan.setCwAttached(false);
        plan.setPremiumDueDate("");
        plan.setType("");

        //Set non hardcoded value in the plan object
        if (basicComponent != null) {
            plan.setPlanCode(basicComponent.getCompoCode());
            plan.setSumAssured(basicComponent.getSumAssured());
            plan.setPremium(Math.round(SP_PROD_TYPES.contains(customerApp.getProductType()) || SP_PROD_CODES.contains(prodCode.toUpperCase()) ? basicComponent.getSinglePremium() * 100 : basicComponent.getPremium() * 100) / 100.00);
            plan.setSinglePremium(SP_PROD_TYPES.contains(customerApp.getProductType()) || SP_PROD_CODES.contains(prodCode.toUpperCase()) ? Math.round(basicComponent.getSinglePremium() * 100) / 100.00 : 0);
            plan.setPremiumTerm(customerApp.getProductType().equals("PGP") ? basicComponent.getTerm() : basicComponent.getPremiumTerm());
            plan.setPolicyTerm(basicComponent.getTerm());
            plan.setPremiumYearly(Math.round(basicComponent.getYearlyPremium() * 100) / 100.00);
            plan.setPremiumHalfYearly(Math.round(basicComponent.getHalfYearlyPremium() * 100) / 100.00);
            plan.setPremiumQuarterly(Math.round(basicComponent.getQuarterlyPremium() * 100) / 100.00);
            plan.setPremiumMonthly(Math.round(basicComponent.getMonthlyPremium() * 100) / 100.00);
            if (basicComponent.getSelectedCompoPlanOption() != null) {
                plan.setOptionCode(basicComponent.getSelectedCompoPlanOption().getOptCode());
            } else {
                plan.setOptionCode("");
            }
            if (basicComponent.getSelectedTermOption() != null && (customerApp.getProductType().equals("PM") || customerApp.getProductType().equals("PL")))
                plan.setSelectedTermOption(basicComponent.getSelectedTermOption().getOptValue());
            else
                plan.setSelectedTermOption("");
        }
        plan.setProductCategoryCode(prodCode);
        plan.setPaymentMode(paymentModeVal);
        //Set the plan object in the lif assured object at the first position in the list
        lifeAssured.getPlans().add(0, plan);

        if (logger.isDebugEnabled() && null != basicComponent) {
            logger.debug("esubRequest basicComponent: {}", convertObjectToJsonFormat(basicComponent));
        }

        //For SGP LOCAL/SPR rider placeholder, treat rider as a new plan
        List<SQSProductPlan> additionalEsubPlan = new ArrayList<>();

        //Set the riders (hardcoded and non hardcoded data) in the lifeAssured object
        SQSProductPlan productPlan = null;
                List<Component> riders = computeAllResponse.getSelectedSQSProducts().get(0).getComponents();
        for (Component component : riders) {
            if (!component.getIsBasic()) {
                productPlan = new SQSProductPlan();
                productPlan.setPlanId(1);
                productPlan.setPlanType("RIDER");
                productPlan.setProductCategoryCode("");
                productPlan.setBenefit(0);
                productPlan.setPlanCode(component.getCompoCode());
                productPlan.setDuration(0);
                productPlan.setPaymentMethod(paymentMethodVal);
                productPlan.setPaymentMode(paymentModeVal);
                productPlan.setSumAssured(component.getSumAssured());
                productPlan.setPremium(component.getPremium());
                productPlan.setPremiumYearly(component.getYearlyPremium());
                productPlan.setDiscountedPremium(component.getDiscountedPremium());
                productPlan.setPremiumHalfYearly(Math.round(component.getHalfYearlyPremium() * 100) / 100.00);
                productPlan.setPremiumQuarterly(Math.round(component.getQuarterlyPremium() * 100) / 100.00);
                productPlan.setPremiumMonthly(Math.round(component.getMonthlyPremium() * 100) / 100.00);
                productPlan.setPremiumTerm(component.getTerm());
                productPlan.setPolicyTerm(component.getTerm());
                if (component.getSelectedCompoPlanOption() != null) {
                    productPlan.setOptionCode(component.getSelectedCompoPlanOption().getOptCode());
                } else {
                    productPlan.setOptionCode("");
                }
                productPlan.setCwAttached(false);
                productPlan.setPremiumDueDate("");
                productPlan.setType(null);
                if("PM1".equals(prodCode)){
                    additionalEsubPlan.add(productPlan);
                } else {
                    lifeAssured.getRiders().add(productPlan);
                }
            }
        }

        if (logger.isDebugEnabled() && null != productPlan) {
            logger.debug("esubRequest productPlan: {}", convertObjectToJsonFormat(productPlan));
        }
        //Set the life assured object in the list which is containing only on object
        sqsProduct.getLifeAssureds().add(0, lifeAssured);

        //Set sqs product in the payload of the request
        compute.getPayload().setSqs(sqsProduct);

        //Init the proposal object
        Proposal proposal = new Proposal();

        //Set hardcoded value in the proposal object
        proposal.setCompanyNo("2");
        proposal.setClientId("1");

        //Set non hardcoded value in the proposal object
        proposal.setMercRefNo(ref);
        proposal.seteRefNo(ref);

        //Set PDPA value from a variable sent by the front-end
        proposal.setPdpa(computeRequest.getPayload().getProposal().isPdpa());

        //Init the plan detail object which has to be set in the proposal object
        PlanDetail planDetail = new PlanDetail();

        //Set hardcoded values in the plan detail object
        planDetail.setPolicyDocumentDelivery("E");
        planDetail.setAcknowledgeShieldPlan(true);
        planDetail.setAcknowledgeMedicalCondition(true);
        planDetail.setAcknowledgePayHigher(true);
        planDetail.setPayoutBankName("");
        planDetail.setPayoutRelToProposer("");
        planDetail.setPayoutAccName("");
        planDetail.setPayoutAccNo("");
        planDetail.setAckOption1(true);
        planDetail.setAckOption2(true);
        planDetail.setAckOption3(false);
        planDetail.setAckOption4(false);
        planDetail.setPsAckOption1(false);
        planDetail.setPsAckOption2(false);
        planDetail.setPsAckOption3(false);
        planDetail.setPortfolioSolution(false);
        planDetail.setDirectIncomeOption(false);
        planDetail.setPayoutAmtDIO(0);

        //Set the plan detail object in the proposal object
        proposal.setPlanDetail(planDetail);

        //Medisave without rider will not insert in D2C cybersource table, instantiate ApplicationCybData object
        boolean ccPayment = isPrushieldPromoValid ? basicComponent.getDiscountedCashOutlayYearly() == 0  : basicComponent.getCashOutlayYearly() == 0;
        if("PS".equals(customerApp.getProductType()) && SQSEngineServiceImpl.isMedisave(plan.getPlanCode())
                && ccPayment){
            appCybData = new ApplicationCybData();
        }

        //Init the payment object
        Payment payment = new Payment();

        //Set hardcoded values in the payment object
        payment.setTotalPrem(0);
        payment.setPaymentModeX("");
        payment.setPaymentMethodX("");
        payment.setPayFor("");
        payment.setCardType("");
        payment.setNameOfCardholder("");
        payment.setCardholderRelToProposer("");
        payment.setCardTypeX("");
        payment.setNameOfCardholderX("");
        payment.setCardholderRelToProposerX("");
        payment.setFirstPremAmt(0);
        payment.setInstallPremAmt(0);
        payment.setInstallPremAmtX(0);
        payment.setMaturityPolNo("");
        payment.setCpfAccountNoOA("");
        payment.setCpfAccountNoSA("");
        payment.setCpfAccountNoSRS("");
        payment.setCpfAgentBank("");
        payment.setInvAccountNo("");
        payment.setGatewayErrorCode("");
        payment.setGatewayErrorMsg("");
        payment.setMaskedCreditCardNum("");
        payment.setCreditCardNumX("");
        payment.setMaskedCreditCardNumX("");
        payment.setCreditCardExpirationX("");
        payment.setRespSignature("");
        payment.setEci("");
        payment.setCavv("");
        payment.setXid("");
        payment.setOrigRefNo("");
        payment.setOrigPayType("");
        payment.setValidFlag(1);
        payment.setTydes("NBZ");
        payment.setRecupDate("");
        payment.setRemark("");
        payment.setItemPymtAmt(0);
        payment.setPremDue(0);
        payment.setOrigPrem(0);

        //Set the non hardcoded value in the payment object
        payment.setPaymentMode(paymentModeVal);

        //Set the payment method from the front-end variable
        payment.setPaymentMethod(computeRequest.getPayload().getProposal().getPayment().getPaymentMethod());

        payment.setMercId(appCybData.getMerchantId() != null ? appCybData.getMerchantId() : "");
        payment.setMercRefNo(ref);
        payment.setCurrency(customerApp.getProductType().equals("PGP") ? currency : "SGD");
        if (appCybData.getAmount() != null)
            payment.setTransAmt(appCybData.getAmount().doubleValue());
        else
            payment.setTransAmt(0);
        payment.setPaymentType(setPaymentTypeUtil(appCybData.getCardType()));
        payment.setApprovalCode(appCybData.getBankApprovalCode() != null ? appCybData.getBankApprovalCode() : "");
        payment.setBankRetCode(appCybData.getBankResponseCode() != null ? appCybData.getBankResponseCode() : "");
        payment.setCreditCardNum(appCybData.getCardNumber() != null ? appCybData.getCardNumber() : "");
        payment.setCreditCardExpiration(appCybData.getCardExpiryDate() != null ? setCreditCardExpDateUtil(appCybData.getCardExpiryDate()) : "");
        if (appCybData.getAmount() != null)
            payment.setAmtPaid(appCybData.getAmount().doubleValue());
        else
            payment.setAmtPaid(0);
        payment.setInstallPremAmt(computeAllResponse.getSelectedSQSProducts().get(0).getTotalYearlyPremium());

        logger.debug("esubRequest product type: {}  plan.getProductCategoryCode {}",
                D2CUtils.removeCRLF(customerApp.getProductType()), D2CUtils.removeCRLF(plan.getProductCategoryCode()));
        if("PS".equals(customerApp.getProductType())){
            if("PM1".equals(plan.getProductCategoryCode()) && isPrushieldPromoValid){
                payment.setTransAmt(basicComponent.getDiscountedPremium());
                payment.setAmtPaid(basicComponent.getDiscountedPremium());
                payment.setInstallPremAmt(basicComponent.getDiscountedPremium());
            }else if("PM1".equals(plan.getProductCategoryCode())) {
                payment.setTransAmt(basicComponent.getYearlyPremium());
                payment.setAmtPaid(basicComponent.getYearlyPremium());
                payment.setInstallPremAmt(basicComponent.getYearlyPremium());
            } else if ("PM2".equals(plan.getProductCategoryCode()) && isPrushieldPromoValid) {
                payment.setInstallPremAmt(appCybData.getAmount().doubleValue());
            }
            if(SQSEngineServiceImpl.isMedisave(plan.getPlanCode())){
                logger.debug("esubRequest isMedisave component");
                payment.setTransAmt(0);
                payment.setAmtPaid(0);
                payment.setPaymentType(Constants.EMPTY_STRING);
                payment.setApprovalCode(Constants.EMPTY_STRING);
                payment.setBankRetCode(Constants.EMPTY_STRING);
                payment.setCreditCardNum(Constants.EMPTY_STRING);
                payment.setCreditCardExpiration(Constants.EMPTY_STRING);
            }
        }
        // PAS check here | ammended condition for PER [PACSDP-2845]
        boolean noCCPaymentPAS_PER = StringUtils.isEmpty(appCybData.getErefNo()) && (customerApp.getProductType().equals("PAS") || customerApp.getProductType().equals("PER"));
        payment.setPymtMethod(SQSEngineServiceImpl.isMedisave(plan.getPlanCode()) || SP_PROD_TYPES.contains(customerApp.getProductType())
                || SP_PROD_CODES.contains(prodCode.toUpperCase()) || noCCPaymentPAS_PER ? "" : "CC");

        //Set timestamps and dates
        payment.setTxnTimestamp(String.valueOf(new Date().getTime() / 1000));
        payment.setReqTimestamp(String.valueOf(new Date().getTime() / 1000));
        payment.setRespTimestamp(String.valueOf(new Date().getTime() / 1000));
        payment.setLastModifiedTimestamp(String.valueOf(new Date().getTime() / 1000));
        payment.setInstFromDate(String.valueOf(Calendar.getInstance().get(Calendar.YEAR)) + zeroize(String.valueOf(Calendar.getInstance().get(Calendar.MONTH) + 1), 2) + zeroize(String.valueOf(Calendar.getInstance().get(Calendar.DAY_OF_MONTH)), 2));
        payment.setInstToDate(String.valueOf(Calendar.getInstance().get(Calendar.YEAR) + 1) + zeroize(String.valueOf(Calendar.getInstance().get(Calendar.MONTH) + 1), 2) + zeroize(String.valueOf(Calendar.getInstance().get(Calendar.DAY_OF_MONTH)), 2));

        //Set forms in the proposal from a variable sent by the front-end
        proposal.setForms(computeRequest.getPayload().getProposal().getForms());

        //Set the payment object in the proposal object
        proposal.setPayment(payment);
        Payment extraPayment = null ;
        boolean cashOutlayExist = isPrushieldPromoValid ? basicComponent.getDiscountedCashOutlayYearly() >0  : basicComponent.getCashOutlayYearly() >0 ;
        if("PS".equals(customerApp.getProductType()) && SQSEngineServiceImpl.isMedisave(plan.getPlanCode())
            && cashOutlayExist){
            extraPayment = (Payment) payment.clone();
            extraPayment.setTransAmt(isPrushieldPromoValid ? basicComponent.getDiscountedCashOutlayYearly(): basicComponent.getCashOutlayYearly());
            extraPayment.setAmtPaid(isPrushieldPromoValid? basicComponent.getDiscountedCashOutlayYearly(): basicComponent.getCashOutlayYearly());
            extraPayment.setPymtMethod("CC");
            extraPayment.setMercId(appCybData.getMerchantId() != null ? appCybData.getMerchantId() : "");
            extraPayment.setPaymentType(setPaymentTypeUtil(appCybData.getCardType()));
            extraPayment.setApprovalCode(appCybData.getBankApprovalCode() != null ? appCybData.getBankApprovalCode() : "");
            extraPayment.setBankRetCode(appCybData.getBankResponseCode() != null ? appCybData.getBankResponseCode() : "");
            extraPayment.setCreditCardNum(appCybData.getCardNumber() != null ? appCybData.getCardNumber() : "");
            extraPayment.setCreditCardExpiration(appCybData.getCardExpiryDate() != null ? setCreditCardExpDateUtil(appCybData.getCardExpiryDate()) : "");
            proposal.setExtraPayment(extraPayment);
        }

        //Set the proposal object in the Payload
        compute.getPayload().setProposal(proposal);

        //Setting partner business source and sub source
        if(assignedAgentService.getPartnerAgentAssignmentService(customerApp.getChannel()) != null) {
            compute.getPayload().setAgentBizSource(customerApp.getBusinessSource());
            compute.getPayload().setAgentSubSource(customerApp.getBusinessSubSource());
        }

        //actual code
        if (logger.isDebugEnabled()) {
            logger.debug("esubRequest after decryption: {}", convertObjectToJsonFormat(compute));
        }
        
        ApplicationDocument appDocument = new ApplicationDocument();
		appDocument.setErefNo(ref);
		appDocument.setCustomId(customId);
		logger.debug("ApplicationDocument Eref: {} and custom id: {}", appDocument.getErefNo(), appDocument.getCustomId());
		
        ApplicationData appData = applicationDataRepository.findById(ref).orElse(null);
        Compute computeRes = null;
        if (null == appData) {
            logger.info("Target record not exist, quit now!");
        } else {
            AppDataResponse proposalData = generateAppData(appData);
            String agentNo = assignedAgentService.getAgentCodeByCustomId(appData.getCustomId());
            logger.debug("fetch agentCode info for esub {}", D2CUtils.removeCRLF(agentNo));
            compute.getPayload().setAgentCode(agentNo);
            // add proposal
            PdfFile file = new PdfFile();
            file.setFileType(NB_PROPOSAL);
            file.setFileCategory(EMPTY_STRING);
            
            String givenName = compute.getPayload().getClients().get(0).getGivenName();
            String surname = compute.getPayload().getClients().get(0).getSurname();
            
            if(givenName != null) {
            	file.setFileName(
                        PROPOSAL_FOR + givenName + EMPTY_STRING + surname + Constants.SUFFIX_PDF);
            }else {
            	file.setFileName(
                        PROPOSAL_FOR + surname + Constants.SUFFIX_PDF);
            }

            file.setMd5Checksum(proposalData.getMd5Checksum());
            file.setRawData(proposalData.getProposal());
            file.setEncryptedData(EMPTY_STRING);
            file.setSignDate(Long.toString((new Date().getTime()) / 1000));
            file.setLifeAssuredId(1);
            logger.debug("PROPOSAL is: {}", file);
            compute.getPayload().setFiles(computeRequest.getPayload().getFiles());
            compute.getPayload().getFiles().add(file);

            String productCategoryCode = computeRequest.getPayload().getSqs().getLifeAssureds().get(0).getPlans().get(0)
                    .getProductCategoryCode();
            String paddedEref = ref + SUFFIX_REFNO;
            logger.debug("mercNo is: {}", D2CUtils.removeCRLF(paddedEref), " ,ProductCategoryCode is {}", D2CUtils.removeCRLF(productCategoryCode));

            compute.getPayload().getProposal().setMercRefNo(paddedEref);
            compute.getPayload().getProposal().getPayment().setMercRefNo(paddedEref);
            if(extraPayment != null){
                compute.getPayload().getProposal().getExtraPayment().setMercRefNo(paddedEref);
            }
            compute.getPayload().getProposal().setSrcInd(customerApplicationService.getEsubChannel(appData.getCustomId()));

            //PACSDP-4359 include PS SIO indicator for PS product in the payload
            String psSIOInd=customerApp.getPsSIO();

            if(psSIOInd.equalsIgnoreCase(STRING_YES) || psSIOInd.equalsIgnoreCase(STRING_NO)){
                compute.getPayload().setPsSIO(psSIOInd);
            }

            if (computeRequest.getPayload().getClients().get(0).getPassType() != null && !computeRequest.getPayload().getClients().get(0).getPassType().trim().equals("")) {
                List<PassTypeMapping> passTypeMappingList = passTypeMappingRepository.findByDpCode(Integer.parseInt(computeRequest.getPayload().getClients().get(0).getPassType()));

                if (passTypeMappingList != null && passTypeMappingList.size() > 0) {
                    compute.getPayload().getProposal().setPassType(passTypeMappingList.get(0).getLaDesc());
                }
            }

            MyInfoData myInfo = myInfoDataRespository.findTopByUinfinOrderByTransDateDesc(customerApp.getNricFin());
            if (myInfo != null && myInfo.getStatus() == null) {
            	myInfo.setEref(ref);
        		myInfoDataRespository.save(myInfo);
        		
        		String checkMyInfoInd = myInfo.getIndicator();
        		logger.debug("MyInfoData check indicator: {}", checkMyInfoInd);
        		
        		if(checkMyInfoInd.equals(STRING_YES)) {
                	compute.getPayload().setMyInfo(STRING_YES);
                }else {
                	compute.getPayload().setMyInfo(STRING_NO);
                }

        		List <PassTypeMapping> passTypeMappingList = null;
                if (myInfo.getPassType() != null && !myInfo.getPassType().trim().equals("")) {
                    passTypeMappingList = passTypeMappingRepository.findByDpCode(Integer.parseInt(myInfo.getPassType()));
                }

                if(passTypeMappingList != null && passTypeMappingList.size()>0) {
                	compute.getPayload().getProposal().setPassType(passTypeMappingList.get(0).getLaDesc());
                }
            }

            if (logger.isDebugEnabled()) {
                logger.debug("esubRequest: {}", convertObjectToJsonFormat(compute));
            }

            writeJson("final_backend_compute1.txt", convertObjectToJsonFormat(compute));
            if ("PS".equalsIgnoreCase(customerApp.getProductType())) {
                compute.getPayload().getClients().get(0).setSmoker(isSmokeConstraintForShield(computeRequest.getPayload().getProposal().getForms()));
            }
            
            //PI, PROPORSAL, MYINFO DOCUMENTS
            applicationDocumentService.saveApplicationDocuments(compute, appDocument);
            
            computeRes = processEsubmission(compute, paddedEref, appData);

            ProductSalesInfo productSalesInfo = getProductSalesInfo(computeAllResponse, computeRes, appData.getCustomId(), ref, compute, 0);
            if(productSalesInfo != null){
                productSalesInfos.add(productSalesInfo);
            }

            if(additionalEsubPlan.size() > 0){
                /** build second plan which is cash basis always
                 * Same PI and proposal document to be tied to each of the eref folder
                 * Second esub will have new eref and proposal no
                 * Second esub will need to write to iPay file, since PM1 riders are all cash basis
                 */
                logger.info("Start additional esub call product customId: {}", D2CUtils.removeCRLF(compute.getPayload().getCustomId()));
                String nextEref = ref + "A";
                String nextErefNo = nextEref + SUFFIX_REFNO;
                SQSProductPlan additionalPlan = additionalEsubPlan.get(0);

                compute.getPayload().getSqs().getLifeAssureds().get(0).getPlans().set(0, additionalPlan);
                compute.getPayload().seteReferenceNo(nextEref);
                compute.getPayload().getProposal().setMercRefNo(nextErefNo);
                compute.getPayload().getProposal().seteRefNo(nextEref);

                compute.getPayload().getProposal().getPayment().setMercRefNo(nextErefNo);
                if(isPrushieldPromoValid){
                    compute.getPayload().getProposal().getPayment().setTransAmt(additionalPlan.getDiscountedPremium());
                    compute.getPayload().getProposal().getPayment().setAmtPaid(additionalPlan.getDiscountedPremium());
                    compute.getPayload().getProposal().getPayment().setInstallPremAmt(additionalPlan.getDiscountedPremium());
                }else{
                    compute.getPayload().getProposal().getPayment().setTransAmt(additionalPlan.getPremiumYearly());
                    compute.getPayload().getProposal().getPayment().setAmtPaid(additionalPlan.getPremiumYearly());
                    compute.getPayload().getProposal().getPayment().setInstallPremAmt(additionalPlan.getPremiumYearly());
                }
                ApplicationCybData appCybDataRider = applicationCybDataRepository.findByCustomId(customId);
                compute.getPayload().getProposal().getPayment().setMercId(appCybDataRider.getMerchantId() != null ? appCybDataRider.getMerchantId() : "");
                compute.getPayload().getProposal().getPayment().setPaymentType(setPaymentTypeUtil(appCybDataRider.getCardType()));
                compute.getPayload().getProposal().getPayment().setApprovalCode(appCybDataRider.getBankApprovalCode() != null ? appCybDataRider.getBankApprovalCode() : "");
                compute.getPayload().getProposal().getPayment().setBankRetCode(appCybDataRider.getBankResponseCode() != null ? appCybDataRider.getBankResponseCode() : "");
                compute.getPayload().getProposal().getPayment().setCreditCardNum(appCybDataRider.getCardNumber() != null ? appCybDataRider.getCardNumber() : "");
                compute.getPayload().getProposal().getPayment().setCreditCardExpiration(appCybDataRider.getCardExpiryDate() != null ? setCreditCardExpDateUtil(appCybDataRider.getCardExpiryDate()) : "");
                compute.getPayload().getProposal().getPayment().setPymtMethod("CC");
                compute.getPayload().getProposal().setExtraPayment(null);

                writeJson("final_backend_compute2.txt", convertObjectToJsonFormat(compute));

                Compute computeRes1 = processEsubmission(compute, nextErefNo, appData);

                ProductSalesInfo productSalesInfo1 = getProductSalesInfo(computeAllResponse, computeRes1, appData.getCustomId(), nextEref, compute, 1);
                if(productSalesInfo1 != null){
                    productSalesInfos.add(productSalesInfo1);
                }
            }

            // save result to DB
            //Populate response with multiple proposal/eref information if any
            String esubStatus = Constants.STRING_NO;
            if (computeRes != null && !StringUtils.isEmpty(computeRes.getSystem())
                    && !StringUtils.isEmpty(computeRes.getPayload())
                    && Constants.SUCCESS_STATUS.equalsIgnoreCase(computeRes.getSystem().getStatus())) {
                esubStatus = Constants.STRING_YES;
                String policyNo = null;
                Policy policy = computeRes.getPayload().getPolicies().get(0);
                if (policy != null && !StringUtils.isEmpty(policy.getPolicyNo())) {
                    policyNo = policy.getPolicyNo();
                }
                customerApplicationService.updateStepStatusAndPolicyNo(Constants.SAVE_ESUB_SUCCESS_STATUS, policyNo, appData.getCustomId());

                if (policy != null) {
                    policy.seteReferenceNo(computeRes.getPayload().geteReferenceNo());

                    if (!org.springframework.util.CollectionUtils.isEmpty(productSalesInfos)) {

                        for (int i = 1; i < productSalesInfos.size(); i++) {
                            Policy subPolicy = new Policy();
                            subPolicy.setPolicyNo(productSalesInfos.get(i).getProposalNo());
                            subPolicy.seteReferenceNo(productSalesInfos.get(i).getErefNo());
                            computeRes.getPayload().getPolicies().add(subPolicy);
                        }
                    }
                }
            }
            applicationDataRepository.updateEsubStatus(esubStatus, ref);
        }

        customerApplicationService.saveProductSalesInfo(productSalesInfos);

        logger.warn("end submitEsub()");

        return computeRes;
    }

    @SuppressWarnings("deprecation")
	private String getFormattedPhoneNumber(MailList mail) {
        if(StringUtils.isEmpty(mail.getMobilePhone())){
            return EMPTY_STRING;
        }
        String phoneIDD = org.apache.commons.lang3.StringUtils.defaultIfEmpty(mail.getPhoneIDD(),"65");
        String mobilePhone = org.apache.commons.lang3.StringUtils.removeStart(mail.getMobilePhone(),"+");
        mobilePhone = org.apache.commons.lang3.StringUtils.removeStart(mobilePhone, phoneIDD);
        String homePhoneArea = phoneIDD + "-" + mobilePhone;
        return homePhoneArea;
    }

    private ProductSalesInfo getProductSalesInfo(ComputeResponsePayload computeAllResponsePayLoad, Compute eSubmitResponse, String customId, String erefNo, Compute eSubRequest, int index) {
        try {
            if (computeAllResponsePayLoad != null && eSubmitResponse != null && eSubRequest != null &&
                    org.apache.commons.lang.StringUtils.isNotBlank(customId) && org.apache.commons.lang.StringUtils.isNotBlank(erefNo) &&
                    eSubmitResponse.getPayload() != null && eSubmitResponse.getSystem() != null &&
                    org.apache.commons.lang.StringUtils.equalsIgnoreCase(Constants.SUCCESS_STATUS, eSubmitResponse.getSystem().getStatus()) &&
                    CollectionUtils.isNotEmpty(eSubmitResponse.getPayload().getPolicies()) &&
                    org.apache.commons.lang.StringUtils.isNotBlank(eSubmitResponse.getPayload().getPolicies().get(0).getPolicyNo()) &&
                    CollectionUtils.isNotEmpty(computeAllResponsePayLoad.getSelectedSQSProducts()) &&
                    org.apache.commons.lang.StringUtils.isNotBlank(computeAllResponsePayLoad.getSelectedSQSProducts().get(0).getProdCode()) &&
                    org.apache.commons.lang.StringUtils.isNotBlank(computeAllResponsePayLoad.getSelectedSQSProducts().get(0).getProdDesc()) &&
                    CollectionUtils.isNotEmpty(computeAllResponsePayLoad.getSelectedSQSProducts().get(0).getComponents()) &&
                    computeAllResponsePayLoad.getSelectedSQSProducts().get(0).getComponents().get(index) != null &&
                    org.apache.commons.lang.StringUtils.isNotBlank(computeAllResponsePayLoad.getSelectedSQSProducts().get(0).getComponents().get(index).getCompoCode()) &&
                    eSubRequest.getPayload() != null && eSubRequest.getPayload().getProposal() != null && eSubRequest.getPayload().getProposal().getPayment() != null
            ) {
                Product product = computeAllResponsePayLoad.getSelectedSQSProducts().get(0);
                Component component = product.getComponents().get(index);
                String YEARLY = "- Yearly";
                ProductSalesInfo productSalesInfo = new ProductSalesInfo();
                productSalesInfo.setCreatedDate(new Date());
                productSalesInfo.setCustomId(customId);
                productSalesInfo.setComponentCode(component.getCompoCode());
                if (org.apache.commons.lang.StringUtils.endsWith(component.getCompoDesc(), YEARLY)) {
                    productSalesInfo.setComponentDesc(org.apache.commons.lang.StringUtils.replace(component.getCompoDesc(),YEARLY,""));
                }else{
                    productSalesInfo.setComponentDesc(component.getCompoDesc());
                }
                if("PM1".equalsIgnoreCase(product.getProdCode())){
                    productSalesInfo.setTotalPremium(component.getPremium());
                } else {
                    productSalesInfo.setTotalPremium(product.getTotalPremium());
                }
                productSalesInfo.setErefNo(erefNo);
                productSalesInfo.setProposalNo(eSubmitResponse.getPayload().getPolicies().get(0).getPolicyNo());
                return productSalesInfo;
            }
        } catch (Exception exception) {
            logger.error("Exception occurred while prepare Product Sales info: " + exception.getMessage(), exception);
        }
        return null;
    }

    private boolean isSmokeConstraintForShield(List<Form> forms){
        for (Form questionFormVal : forms) {
            for (QuestionnaireForm questionaire : questionFormVal.getQuestionnaireForms()) {
                for (Question question : questionaire.getQuestions()) {
                    if ("QPS005".equalsIgnoreCase(question.getQuestionCode().toUpperCase())
                            && question.getAnswerValue() != null && question.getAnswerValue().equals(Constants.VALUE_NUM_1)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private Compute processEsubmission(Compute compute, String erefNo, ApplicationData appData){

        HttpHeaders headers = getHeaders();
        HttpEntity<Compute> entityReq = new HttpEntity<>(compute, headers);

        Date date1 = new Date();
        String date1Format = getDf().format(date1);
        logger.debug("call url: {} on {}", configProperties.getEsubUrl(), date1Format);

        Compute computeResponse = callEsub(compute, erefNo, appData, restTemplate, entityReq);

        Date date2 = new Date();
        if (logger.isDebugEnabled()) {
            logger.debug("end service on " + getDf().format(date2) + " and cost time: "
                    + (date2.getTime() - date1.getTime()));
            logger.debug("esubResponse:", convertObjectToJsonFormat(computeResponse));
        }
        return computeResponse;
    }

    private Compute callEsub(Compute compute, String erefNo, ApplicationData appData, RestTemplate restTemplate, HttpEntity<Compute> entityReq) {
        Compute computeRes = null;
        try {
            computeRes = restTemplate.postForObject(configProperties.getEsubUrl(), entityReq, Compute.class);
        } catch (Exception e1) {
            logger.error("First time EsubUrl service gets exception:", e1);
            try {
                computeRes = restTemplate.postForObject(configProperties.getEsubUrl(), entityReq, Compute.class);
            } catch (Exception e2) {
                logger.error("Second time EsubUrl service gets exception:", e2);
                ObjectMapper mapper = new ObjectMapper();
                List<PdfFile> pdflist = compute.getPayload().getFiles();
                try {
                    if(null != pdflist && !pdflist.isEmpty()){
                        String pdfJson = mapper.writeValueAsString(pdflist);
                        mailService.saveMailDataforEsubFailed(erefNo, new SerialBlob(pdfJson.getBytes()),
                                appData.getCustomId(), true);
                    }
                } catch (Exception e) {
                    logger.error("saveMailDataforEsubFailed failed:" + e);
                    throw new D2CException("saveMailDataforEsubFailed failed", e);
                }
            }
        }
        return computeRes;
    }

    @SuppressWarnings("unused")
	private double setPruShieldMainPlanAmt(String planCode, Component basicComponent){
        if(SQSEngineServiceImpl.isMedisave(planCode)){
            return basicComponent.getPremium();
        } else {
            return basicComponent.getPremium();
        }
    }

    /**
     * Invoke agent assignment during sale completion.
     *
     * @param customId
     * @param customerApplication
     */
    private void invokeSaleCompleteAA(String customId, CustomerApplication customerApplication,
                                      ComputeResponsePayload computeResponsePayload) {
        AgentAssignmentService agentAssignmentClass = assignedAgentService.getAgentAssignmentClass(customerApplication.getChannel());
        if (agentAssignmentClass == null || !agentAssignmentClass.isSaleCompletionAgentAssignmentCallRequired()) {
            return;
        }

        MailList existingAgentData = assignedAgentService.getMailListForSale(customId, customerApplication, computeResponsePayload);
        AgentDetails agentDetail = agentDetailsRepository.findOneByCustId(customId);
        if( agentDetail == null) {
            return;
        }
        existingAgentData.setAgentCode(agentDetail.getAgentCode());
        existingAgentData.setAgentMail(agentDetail.getEmailAddress());
        existingAgentData.setAgentName(agentDetail.getAgentName());
        existingAgentData.setAgentMobile(agentDetail.getMobileNumber());
        existingAgentData.setAgentChannelCode(agentDetail.getAgentChannelCode());
        customerApplicationRepository.updateBSourceAndBSubSource(agentDetail.getBusinessSource(), agentDetail.getBusinessSubSource(), customId);
        customerApplication.setBusinessSource(agentDetail.getBusinessSource());
        customerApplication.setBusinessSubSource(agentDetail.getBusinessSubSource());
        mailListRepository.save(existingAgentData);
    }

    @SuppressWarnings("deprecation")
	public static String setDefaultEmptyVal(String str) {
        if (StringUtils.isEmpty(str)) {
            return Constants.EMPTY_STRING;
        }
        return str;
    }

    @SuppressWarnings("deprecation")
	public static String setPaymentTypeUtil(String cardType) {
        String paymentType = Constants.EMPTY_STRING;
        if (!isEmpty(cardType)) {
            switch (cardType) {
                case CYB_VISA_CARD:
                    paymentType = ESUB_VISA_CARD;
                    break;
                case CYB_MASTER_CARD:
                    paymentType = ESUB_MASTER_CARD;
                    break;
                default:
                    paymentType = ESUB_ENETS;
                    break;
            }
        }
        return paymentType;
    }

    public static String setCreditCardExpDateUtil(String expiryDate) {
        if (expiryDate != null && expiryDate.contains("-")) {
            expiryDate = expiryDate.substring(5, 7) + expiryDate.substring(0, 2);
        }
        return expiryDate;
    }

    public void writeJson(String fileName, String json) throws IOException {
        if (Constants.ESUBMISSION_JSON_WRITE_ENABLED == configProperties.getEsubJsonLogEnabled()) {
            String filePath = new StringBuilder().append(esub_json_log_path).
                    append(productCodeForLogger).append(HYPHEN).append(timeStampForLogger).append(HYPHEN).append(fileName).toString();
            BufferedWriter writer = new BufferedWriter(new FileWriter(filePath));
            writer.write(json);
            writer.close();
        }
    }

    private String zeroize(String value, int length) {
        String zeros = "";
        for (int i = value.length(); i < length; i++) {
            zeros += "0";
        }
        return zeros + value;
    }

    /**
     * This method is used to query application data
     *
     * @param
     * @return
     * @throws Exception
     */
    @SuppressWarnings("deprecation")
	@RequestMapping(
            value = "/fetchAppData",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public AppDataResponse fetchAppData(@RequestBody ErefAuth erefAuth, HttpServletRequest  httpServletRequest) {
        logger.info("call fetchAppData");
        if (logger.isDebugEnabled()) {
            logger.debug("applicationData", convertObjectToJsonFormat(erefAuth));
        }
        AppDataResponse res = new AppDataResponse();
        String jwtCustomId = jwtService.getJwtCustomId(httpServletRequest);
        ApplicationData appData = applicationDataRepository.findByCustomId(jwtCustomId);
        try {
            if (!StringUtils.isEmpty(appData.getErefNo())) {
                if (!StringUtils.isEmpty(appData)) {
                    // get byte[]
                    Blob blob = appData.getProposal();

                    int blobLength = (int) blob.length();
                    byte[] blobAsBytes = blob.getBytes(1, blobLength);
                    // generate base64
                    String pdfPaBase64 = new String(Base64.getEncoder().encode(blobAsBytes));
                    // generate MD5
                    byte[] hash = MessageDigest.getInstance(Constants.SHA256_ALGORITHM).digest(blobAsBytes);
                    String actual = DatatypeConverter.printHexBinary(hash);
                    logger.info("MD5 actual: {}", actual);

                    res.setErefNo(appData.getErefNo());
                    res.setPayRequest(appData.getPayRequest());
                    res.setPayResponse(appData.getPayResponse());
                    res.setProposal(pdfPaBase64);
                    res.setMd5Checksum(actual);
                } else {
                    res.setSuccess(false);
                    res.setMessage("loading.");
                }
            } else {
                logger.info("erefNO shouldn't be empty!");
            }

        } catch (Exception e) {
            throw new D2CException("fetchAppData failed", e);
        }
        logger.info("{}", res);
        logger.warn("end fetchAppData");
        return res;

    }

    public AppDataResponse generateAppData(ApplicationData appData) {
        AppDataResponse res = new AppDataResponse();
        try {
            // get byte[]
            Blob blob = appData.getProposal();

            int blobLength = (int) blob.length();
            byte[] blobAsBytes = blob.getBytes(1, blobLength);
            // generate base64
            String pdfPaBase64 = new String(Base64.getEncoder().encode(blobAsBytes));
            // generate MD5
            byte[] hash = MessageDigest.getInstance(Constants.SHA256_ALGORITHM).digest(blobAsBytes);
            String actual = DatatypeConverter.printHexBinary(hash);

            res.setProposal(pdfPaBase64);
            res.setMd5Checksum(actual);

            logger.debug("generateAppData Response: {}", res);

        } catch (Exception e) {
            throw new D2CException("generateAppData failed", e);
        }
        return res;

    }

    private Compute generatePFCComputeAllRequest(D2CRequest computeRequest, boolean generatePdf) {

        Compute compute = new Compute();
        Integer term = Integer.valueOf(computeRequest.getSelectedTerm());
        Double monthlyPremium = Double.valueOf(computeRequest.getMonthlyPremium());
        // add System
        compute.setSystem(getComputeSystem());

        List<LifeProfile> lifeProfiles = new ArrayList<>();
        lifeProfiles.add(generateLifeProfile(computeRequest));
        Payload payload = new Payload();
        payload.setTransactionId(EncryptedIdsUtil.generateTransactionId(18));
        payload.setGeneratePDF(generatePdf);
        payload.setLifeProfiles(lifeProfiles);

        SelectedSQSProductComponent component1 = new SelectedSQSProductComponent(COMPOCODE_ENP7, true, true, CLIENT_ML, term,
                term, term, term, monthlyPremium, DEFAULT_VALUE, DEFAULT_VALUE, EMPTY_STRING, SEQUENCE_1);
        SelectedSQSProductComponent component2 = new SelectedSQSProductComponent(COMPOCODE_DAN7, false, true, CLIENT_ML, term,
                term, term, term, monthlyPremium, DEFAULT_VALUE, DEFAULT_VALUE, EMPTY_STRING, SEQUENCE_2);

        List<SelectedSQSProductComponent> components = new ArrayList<>();
        if (generatePdf) {
            component1.setPremium(DEFAULT_VALUE);
            component1.setPremium(DEFAULT_VALUE);
            component1.setSumAssured(computeRequest.getSumAssured());
            component2.setSumAssured(computeRequest.getSumAssured());
        }
        components.add(component1);
        components.add(component2);

        SelectedSQSProduct selectedSQSProduct = new SelectedSQSProduct();
        selectedSQSProduct.setDocId(DOC_ID_EC7);
        selectedSQSProduct.setProdCode(PRODUCT_EC7);
        if (generatePdf) {
            selectedSQSProduct.setPaymentMode(PAYMENT_MODE_Y);
        } else {
            selectedSQSProduct.setPaymentMode(PAYMENT_MODE_M);
        }
        selectedSQSProduct.setCurrency(CURRENCY_SGD);
        selectedSQSProduct.setTotalPremium(0);
        selectedSQSProduct.setTotalHalfYearlyPremium(0);
        selectedSQSProduct.setTotalQuarterlyPremium(0);
        selectedSQSProduct.setTotalMonthlyPremium(0);
        selectedSQSProduct.setTotalYearlyPremium(0);
        selectedSQSProduct.setComponents(components);

        List<SelectedSQSProduct> selectedSQSProducts = new ArrayList<>();
        selectedSQSProducts.add(selectedSQSProduct);
        payload.setSelectedSQSProducts(selectedSQSProducts);

        compute.setPayload(payload);

        return compute;
    }

    @SuppressWarnings("deprecation")
	private D2CRequest getPAPremiums(D2CRequest computeRequest) {
        String occupationCode = computeRequest.getOccupation();
        String residencyCode;

        switch (computeRequest.getNationality()) {
            case Constants.SINGAPOREAN:
                residencyCode = Constants.SINGAPOREAN_CODE;
                break;

            case Constants.PERMANENT_RESIDENT:
                residencyCode = Constants.PERMANENT_RESIDENT_CODE;
                break;

            default:
                residencyCode = Constants.OTHER_CODE;
                break;
        }

        Integer age = computeRequest.getAge();
        String reqType = computeRequest.getReqType();

        String planCode = computeRequest.getPlanCode();
        String planRA = computeRequest.getPlanRA();
        String planFCPA = computeRequest.getPlanFCPA();

        String premiumPA = Constants.START_POLICY_STATUS;
        String premiumRA = Constants.START_POLICY_STATUS;
        String premiumPAFE = Constants.START_POLICY_STATUS;
        String SumAssuredPA = Constants.START_POLICY_STATUS;
        String SumAssuredRA = Constants.START_POLICY_STATUS;
        String SumAssuredPAFE = Constants.START_POLICY_STATUS;

        if (Constants.PRUPERSONAL_ACCIDENT.equalsIgnoreCase(reqType)) {

            if (!StringUtils.isEmpty(planCode)) {
                final Quotation quotPA = quotationRepository
                        .findByTypeAndOccupationClassAndPlanAndFirstAgeLessThanEqualAndLastAgeGreaterThanEqualAndResidency(
                                Constants.PRUPERSONAL_ACCIDENT, occupationCode, planCode, age, age, residencyCode);

                premiumPA = quotPA.getMainValue().replaceAll(Constants.DOLLAR_IN_BRACKET, EMPTY_STRING);
                SumAssuredPA = quotPA.getSumAssured().replaceAll(Constants.DOLLAR_IN_BRACKET, EMPTY_STRING);
                computeRequest.setPremiumPA(String.valueOf(Double.valueOf(premiumPA)));
                computeRequest.setSumAssuredPA(String.valueOf(Double.valueOf(SumAssuredPA)));

            }
            if (!StringUtils.isEmpty(planRA)) {
                final Quotation quotRA = quotationRepository
                        .findByTypeAndOccupationClassAndPlan(Constants.RECOVERY_AID, occupationCode, planRA);
                premiumRA = quotRA.getMainValue().replaceAll(Constants.DOLLAR_IN_BRACKET, EMPTY_STRING);
                SumAssuredRA = quotRA.getSumAssured().replaceAll(Constants.DOLLAR_IN_BRACKET, EMPTY_STRING);
                computeRequest.setPremiumRA(String.valueOf(Double.valueOf(premiumRA)));
                computeRequest.setSumAssuredRA(String.valueOf(Double.valueOf(SumAssuredRA)));

            }
            if (!StringUtils.isEmpty(planFCPA)) {
                final Quotation quotFCPA = quotationRepository
                        .findByTypeAndOccupationClassAndPlanAndFirstAgeLessThanEqualAndLastAgeGreaterThanEqualAndResidency(
                                Constants.FRACTURE_CARE_PA, occupationCode, planFCPA, age, age, residencyCode);
                premiumPAFE = quotFCPA.getMainValue().replaceAll(Constants.DOLLAR_IN_BRACKET, EMPTY_STRING);
                SumAssuredPAFE = quotFCPA.getSumAssured().replaceAll(Constants.DOLLAR_IN_BRACKET, EMPTY_STRING);
                computeRequest.setPremiumPAFE(String.valueOf(Double.valueOf(premiumPAFE)));
                computeRequest.setSumAssuredPAFE(String.valueOf(Double.valueOf(SumAssuredPAFE)));

            }

            computeRequest.setTotalYearlyPremium(String.valueOf(Double.valueOf(premiumPA) + Double.valueOf(premiumRA) + Double.valueOf(premiumPAFE)));

        }


        return computeRequest;
    }


    protected boolean isPremiumModified(D2CRequest computeRequest){
        logger.debug("Invoking isPremiumModified : " + computeRequest.toString());
        String befreSumAssuredPA = computeRequest.getSumAssuredPA();
        String befrePremiumPA = computeRequest.getPremiumPA();
        String befreSumAssuredRA = computeRequest.getSumAssuredRA();
        String befrePremiumRA = computeRequest.getPremiumRA();
        String befreSumAssuredPAFE = computeRequest.getSumAssuredPAFE();
        String befrePremiumPAFE = computeRequest.getPremiumPAFE();
        String befreTotalYearlyPremium = computeRequest.getTotalYearlyPremium();

        computeRequest.setPremiumPA(Constants.START_POLICY_STATUS);
        computeRequest.setSumAssuredPA(Constants.START_POLICY_STATUS);
        computeRequest.setPremiumRA(Constants.START_POLICY_STATUS);
        computeRequest.setSumAssuredRA(Constants.START_POLICY_STATUS);
        computeRequest.setPremiumPAFE(Constants.START_POLICY_STATUS);
        computeRequest.setSumAssuredPAFE(Constants.START_POLICY_STATUS);

        computeRequest = getPAPremiums(computeRequest);

        logger.info("Values of pre-before premiums : " + D2CUtils.removeCRLF(befrePremiumPA) +
                D2CUtils.removeCRLF(befreSumAssuredRA) + "  " + D2CUtils.removeCRLF(befrePremiumRA) + "  " +
                D2CUtils.removeCRLF(befreSumAssuredPAFE) +"  " + D2CUtils.removeCRLF(befrePremiumPAFE) +" "+
                D2CUtils.removeCRLF(befreTotalYearlyPremium));

        if (befreSumAssuredRA == null) befreSumAssuredRA = "0";
        if (befrePremiumRA == null) befrePremiumRA = "0";
        if (befreSumAssuredPAFE == null) befreSumAssuredPAFE = "0";
        if (befrePremiumPAFE == null) befrePremiumPAFE = "0";
        if (befreTotalYearlyPremium == null) befreTotalYearlyPremium = "0";

        logger.info("Values of before premiums : " + D2CUtils.removeCRLF(befreSumAssuredRA) +"  " +
                D2CUtils.removeCRLF(befrePremiumRA) +"  " + D2CUtils.removeCRLF(befreSumAssuredPAFE) +"  " +
                D2CUtils.removeCRLF(befrePremiumPAFE) +" "+ D2CUtils.removeCRLF(befreTotalYearlyPremium));

        if (!(String.valueOf(Double.valueOf(computeRequest.getSumAssuredRA()))).equalsIgnoreCase(String.valueOf(Double.valueOf(befreSumAssuredRA)))) {
            logger.info("check getSumAssuredRA()");
            return false;
        }

        if (!(String.valueOf(Double.valueOf(computeRequest.getPremiumRA()))).equalsIgnoreCase(String.valueOf(Double.valueOf(befrePremiumRA)))) {
            logger.info("check getPremiumRA");
            return false;
        }

        if (!(String.valueOf(Double.valueOf(computeRequest.getSumAssuredPAFE()))).equalsIgnoreCase(String.valueOf(Double.valueOf(befreSumAssuredPAFE)))) {
            logger.info("check getSumAssuredPAFE");
            return false;
        }

        if (!(String.valueOf(Double.valueOf(computeRequest.getPremiumPAFE()))).equalsIgnoreCase(String.valueOf(Double.valueOf(befrePremiumPAFE)))) {
            logger.info("check getPremiumPAFE");
            return false;
        }


        if (!(String.valueOf(Double.valueOf(computeRequest.getSumAssuredPA()))).equalsIgnoreCase(String.valueOf(Double.valueOf(befreSumAssuredPA)))) {
            logger.info("check getSumAssuredPA");
            return false;
        }

        if (!(String.valueOf(Double.valueOf(computeRequest.getPremiumPA()))).equalsIgnoreCase(String.valueOf(Double.valueOf(befrePremiumPA)))) {
            logger.info("check getPremiumPA");
            return false;
        }

        return true;
    }


    private boolean validateLifeProfileForExistingCustomer(D2CRequest computeRequest , ClientInfo clientInfo){
            LifeProfile lifeProfile = new LifeProfile();
            lifeProfile.setGender(computeRequest.getGender());
            lifeProfile.setDob(computeRequest.getDob());
            lifeProfile.setAge(computeRequest.getAge());
            return sqsEngineService.isValidLifeProfile(lifeProfile, null, clientInfo);
    }


    private void setDecryptedNameInComputeReq(D2CRequest computeRequest){
            String decryptedName = D2CUtils.decrypt(computeRequest.getName() , configProperties , logger);
            computeRequest.setName(decryptedName);
    }

    @SuppressWarnings("deprecation")
	private Compute generatePAComputeRequest(D2CRequest computeRequest) {
        Integer term = 10;

        Double premiumTotal = StringUtils.isEmpty(computeRequest.getTotalYearlyPremium()) ? null
                : Double.valueOf(computeRequest.getTotalYearlyPremium());
        Double sumAssuredPA = StringUtils.isEmpty(computeRequest.getSumAssuredPA()) ? null
                : Double.valueOf(computeRequest.getSumAssuredPA());
        Double sumAssuredRA = StringUtils.isEmpty(computeRequest.getSumAssuredRA()) ? null
                : Double.valueOf(computeRequest.getSumAssuredRA());
        Double sumAssuredPAFE = StringUtils.isEmpty(computeRequest.getSumAssuredPAFE()) ? null
                : Double.valueOf(computeRequest.getSumAssuredPAFE());

        Compute compute = new Compute();
        // add system
        compute.setSystem(getComputeSystem());

        List<LifeProfile> lifeProfiles = new ArrayList<>();
        lifeProfiles.add(generateLifeProfile(computeRequest));
        Payload payload = new Payload();
        payload.setTransactionId(EncryptedIdsUtil.generateTransactionId(18));
        payload.setGeneratePDF(true);
        payload.setLifeProfiles(lifeProfiles);
        List<SelectedSQSProductComponent> components = new ArrayList<>();
        if (!StringUtils.isEmpty(computeRequest.getPremiumPA())) {
            Double premiumPA = Double.valueOf(computeRequest.getPremiumPA());
            String componentCode = (!StringUtils.isEmpty(computeRequest.getAge()) && computeRequest.getAge() > 50) ? "XAD9" : "XAD8";
            SelectedSQSProductComponent componentPA = new SelectedSQSProductComponent(componentCode, true, false,
                    CLIENT_ML, term, term, term, term, premiumPA, premiumPA, sumAssuredPA, "PruPersonal Accident", 1);
            SelectedPolicyOption selectedCompoPlanOption = computeRequest.getSelectedCompoPlanOption();
            componentPA.setSelectedCompoPlanOption(selectedCompoPlanOption);
            components.add(componentPA);
        }
        if (!StringUtils.isEmpty(computeRequest.getPremiumRA()) && !computeRequest.getPremiumRA().equalsIgnoreCase("0")) {
            Double premiumRA = Double.valueOf(computeRequest.getPremiumRA());
            String componentCode = (!StringUtils.isEmpty(computeRequest.getAge()) && computeRequest.getAge() > 50) ? "XHI2" : "XHI1";
            SelectedSQSProductComponent componentRA = new SelectedSQSProductComponent(componentCode, false, false,
                    CLIENT_ML, term, term, term, term, premiumRA, premiumRA, sumAssuredRA, "Recovery Aid Benefit", 2);
            SelectedPolicyOption selectedCompoPlanOption = computeRequest.getSelectedCompoPlanOption();
            componentRA.setSelectedCompoPlanOption(selectedCompoPlanOption);
            components.add(componentRA);
        }
        if (!StringUtils.isEmpty(computeRequest.getPremiumPAFE()) && !computeRequest.getPremiumPAFE().equalsIgnoreCase("0")) {
            Double premiumPAFE = Double.valueOf(computeRequest.getPremiumPAFE());
            SelectedSQSProductComponent componentPAFE = new SelectedSQSProductComponent("PAFE", false, false, CLIENT_ML,
                    term, term, term, term, premiumPAFE, premiumPAFE, sumAssuredPAFE, "Fracture Care PA", 3);
            SelectedPolicyOption selectedCompoPlanOption = computeRequest.getSelectedCompoOption();
            componentPAFE.setSelectedCompoPlanOption(selectedCompoPlanOption);
            componentPAFE.setMaxSumAssured(100000.0);
            components.add(componentPAFE);
        }

        SelectedSQSProduct selectedSQSProduct = new SelectedSQSProduct();
        selectedSQSProduct.setDocId("id_prod_pau");
        selectedSQSProduct.setProdCode("PAU");
        selectedSQSProduct.setProdDesc("PRUpersonal accident");
        selectedSQSProduct.setPaymentTypeIndicator(PAYMENY_TYPE_INDICATOR_R);
        selectedSQSProduct.setPaymentMode(PAYMENT_MODE_Y);
        selectedSQSProduct.setCurrency(CURRENCY_SGD);
        selectedSQSProduct.setTotalPremium(premiumTotal);
        selectedSQSProduct.setTotalYearlyPremium(premiumTotal);
        selectedSQSProduct.setComponents(components);

        List<SelectedSQSProduct> selectedSQSProducts = new ArrayList<>();
        selectedSQSProducts.add(selectedSQSProduct);
        payload.setSelectedSQSProducts(selectedSQSProducts);

        compute.setPayload(payload);

        return compute;
    }

    @SuppressWarnings("deprecation")
	private Compute generatePSComputeRequest(D2CRequest computeRequest) {

        Double premiumTotal = StringUtils.isEmpty(computeRequest.getTotalYearlyPremium()) ? null
                : Double.valueOf(computeRequest.getTotalYearlyPremium());

        Compute compute = new Compute();
        // add system
        compute.setSystem(getComputeSystem());

        List<LifeProfile> lifeProfiles = new ArrayList<>();
        lifeProfiles.add(generateLifeProfile(computeRequest));
        Payload payload = new Payload();
        payload.setTransactionId(EncryptedIdsUtil.generateTransactionId(18));
        payload.setGeneratePDF(true);
        payload.setLifeProfiles(lifeProfiles);

        SelectedSQSProductComponent component1 = new SelectedSQSProductComponent("PMR1", false, false, "", 0, 0, 0, 0,
                premiumTotal, 0.0, 0.0, "PRUshield Premier", 0);
        component1.setBenefitsDesc(BENEFITS_DESCRIPTION);
        component1.setRisksDesc(RISK_DESCRIPTION);
        List<SelectedSQSProductComponent> components1 = new ArrayList<>();
        components1.add(component1);

        SelectedSQSProduct selectedSQSProduct1 = new SelectedSQSProduct();
        selectedSQSProduct1.setDocId("id_prod_spm1");
        selectedSQSProduct1.setProdCode("PM1");
        selectedSQSProduct1.setProdDesc("PRUshield");
        selectedSQSProduct1.setPaymentTypeIndicator(PAYMENY_TYPE_INDICATOR_R);
        selectedSQSProduct1.setCurrency(CURRENCY_SGD);
        selectedSQSProduct1.setTotalPremium(premiumTotal);
        selectedSQSProduct1.setTotalYearlyPremium(premiumTotal);
        selectedSQSProduct1.setComponents(components1);

        List<SelectedSQSProduct> selectedSQSProducts = new ArrayList<>();
        selectedSQSProducts.add(selectedSQSProduct1);
        payload.setSelectedSQSProducts(selectedSQSProducts);

        compute.setPayload(payload);

        return compute;
    }

    @SuppressWarnings("deprecation")
	private LifeProfile generateLifeProfile(D2CRequest computeRequest) {

        LifeProfile lifeProfile = new LifeProfile();
        lifeProfile.setAge(computeRequest.getAge());
        lifeProfile.setGender(computeRequest.getGender());
        lifeProfile.setSmoker(computeRequest.isSmoker());
        lifeProfile.setIsSmoker(computeRequest.isSmoker());
        lifeProfile.setOccupationCode(computeRequest.getOccupationCode());
        lifeProfile.setOccupation(computeRequest.getOccupation());
        lifeProfile.setOccupationDesc(computeRequest.getOccupationDesc());
        lifeProfile.setNumberOfLife(1);
        lifeProfile.setClientType(CLIENT_ML);
        lifeProfile.setCountryCode(COUNTRY_CODE_SG);
        lifeProfile.setResidentStatus("C");

        if (computeRequest.getDob() == null) {
            Date date = new Date();
            Calendar cal = Calendar.getInstance();
            cal.setTime(date);
            Integer year = cal.get(Calendar.YEAR);
            cal.set(Calendar.YEAR, year - lifeProfile.getAge());
            lifeProfile.setDob(new java.sql.Date(cal.getTimeInMillis()));
        } else {
            lifeProfile.setDob(computeRequest.getDob());
        }
        if (StringUtils.isEmpty(computeRequest.getName())) {
            lifeProfile.setName("D2CUser (Life Assured)");
        } else {
            String fullName = D2CUtils.decrypt(computeRequest.getName(), configProperties, logger) + " (Life Assured)";
            lifeProfile.setName(fullName);
        }
        if (!StringUtils.isEmpty(computeRequest.getNric())) {
            lifeProfile.setNric(D2CUtils.decrypt(computeRequest.getNric(), configProperties, logger));
            LifeProfileProposal proposal = new LifeProfileProposal();
            LifeProfileProposalContact contact = new LifeProfileProposalContact();
            String phone = D2CUtils.decrypt(computeRequest.getPhoneNo(), configProperties, logger);
            contact.setHomePhoneNo(phone);
            contact.setMobilePhoneNo(phone);
            contact.setOfficePhoneNo(phone);
            proposal.setContact(contact);
            if (!StringUtils.isEmpty(computeRequest.getHomeAddress())) {
                LifeProfileProposalAddress homeAddressRequest = computeRequest.getHomeAddress();
                LifeProfileProposalAddress homeAddress = new LifeProfileProposalAddress();
                homeAddress.setBuilding(D2CUtils.decrypt(homeAddressRequest.getBuilding(), configProperties, logger));
                homeAddress.setCity(D2CUtils.decrypt(homeAddressRequest.getCity(), configProperties, logger));
                homeAddress.setCountryCode(
                        D2CUtils.decrypt(homeAddressRequest.getCountryCode(), configProperties, logger));
                homeAddress.setHouseNo(D2CUtils.decrypt(homeAddressRequest.getHouseNo(), configProperties, logger));
                homeAddress.setPostcode(D2CUtils.decrypt(homeAddressRequest.getPostcode(), configProperties, logger));
                homeAddress.setStreet(D2CUtils.decrypt(homeAddressRequest.getStreet(), configProperties, logger));
                homeAddress.setUnitNo(D2CUtils.decrypt(homeAddressRequest.getUnitNo(), configProperties, logger));
                proposal.setHomeAddress(homeAddress);
            }
            if (computeRequest.getIsMailingAddressSameAsHomeAddress()) {
                proposal.setMailingAddress(proposal.getHomeAddress());
                proposal.setIsMailingAddressSameAsHomeAddress(true);
            } else {
                if (!StringUtils.isEmpty(computeRequest.getMailingAddress())) {
                    LifeProfileProposalAddress mailingAddressRequest = computeRequest.getMailingAddress();
                    LifeProfileProposalAddress mailingAddress = new LifeProfileProposalAddress();
                    mailingAddress.setBuilding(
                            D2CUtils.decrypt(mailingAddressRequest.getBuilding(), configProperties, logger));
                    mailingAddress.setCity(D2CUtils.decrypt(mailingAddressRequest.getCity(), configProperties, logger));
                    mailingAddress.setCountryCode(
                            D2CUtils.decrypt(mailingAddressRequest.getCountryCode(), configProperties, logger));
                    mailingAddress
                            .setHouseNo(D2CUtils.decrypt(mailingAddressRequest.getHouseNo(), configProperties, logger));
                    mailingAddress.setPostcode(
                            D2CUtils.decrypt(mailingAddressRequest.getPostcode(), configProperties, logger));
                    mailingAddress
                            .setStreet(D2CUtils.decrypt(mailingAddressRequest.getStreet(), configProperties, logger));
                    mailingAddress
                            .setUnitNo(D2CUtils.decrypt(mailingAddressRequest.getUnitNo(), configProperties, logger));
                    proposal.setMailingAddress(mailingAddress);
                }
            }
            lifeProfile.setProposal(proposal);
            lifeProfile.setNationality(computeRequest.getNationality());
        } else {
            lifeProfile.setNric(EMPTY_STRING);
        }

        return lifeProfile;

    }

    @SuppressWarnings("deprecation")
	private SelectedPolicyOption generateSelectedPolicyOption(D2CRequest computeRequest) {
        SelectedPolicyOption selectedPolicyOption = new SelectedPolicyOption();
        String code = computeRequest.getSelectedOptionCode();
        if (!StringUtils.isEmpty(code)) {

            String desc;

            switch (code) {
                case OPTION_CODE_1:
                    desc = BENEFIT_DESCRIPTION_OPTION_1;
                    break;
                case OPTION_CODE_2:
                    desc = BENEFIT_DESCRIPTION_OPTION_2;
                    break;
                case OPTION_CODE_3:
                    desc = BENEFIT_DESCRIPTION_OPTION_3;
                    break;
                default:
                    desc = BENEFIT_DESCRIPTION_OPTION_3;
                    break;
            }

            selectedPolicyOption.setOptCode(code);
            selectedPolicyOption.setOptValue(computeRequest.getSelectedOptionVal());
            selectedPolicyOption.setOptDescp(desc);
        }

        return selectedPolicyOption;
    }

    /**
     * @return the computeSystem
     */
    public ComputeSystem getComputeSystem() {
        ComputeSystem computeSystem = new ComputeSystem();

        computeSystem.setAppVersion(Constants.APPVERSION);
        computeSystem.setAppKey(configProperties.getAppkey());
        computeSystem.setClientIP(EncryptedIdsUtil.getServerIP());
        computeSystem.setAppName(Constants.APPNAME);
        computeSystem.setClientUdid(EMPTY_STRING);
        computeSystem.setIsPayloadEncrypted(false);
        computeSystem.setEncryptionKey(EMPTY_STRING);

        return computeSystem;
    }

    /**
     * @return the headers
     */
    public HttpHeaders getHeaders() {
        HttpHeaders headers = new HttpHeaders();
        MediaType[] mediaTypes = new MediaType[]{MediaType.APPLICATION_JSON};
        headers.setAccept(asList(mediaTypes));
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setContentLength(1034);
        headers.setDate(new Date().getTime());
        return headers;
    }

    /**
     * @return the df
     */
    public SimpleDateFormat getDf() {
        return new SimpleDateFormat(Constants.DATEFORMAT);
    }

}
