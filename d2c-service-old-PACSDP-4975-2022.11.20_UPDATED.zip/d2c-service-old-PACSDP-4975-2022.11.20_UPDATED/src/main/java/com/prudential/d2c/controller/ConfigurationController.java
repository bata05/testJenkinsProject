package com.prudential.d2c.controller;

import com.prudential.d2c.common.Constants;
import com.prudential.d2c.entity.D2CResponse;
import com.prudential.d2c.entity.Response;
import com.prudential.d2c.entity.SIOResponse;
import com.prudential.d2c.entity.dto.ConfigureProperties;
import com.prudential.d2c.repository.ConfigurePropertiesRepository;
import com.prudential.d2c.repository.CountryIDDRepository;
import com.prudential.d2c.security.JwtProvider;
import com.prudential.d2c.service.SIOCampaignService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@EnableAutoConfiguration
public class ConfigurationController extends BaseController {

    @Autowired
    private CountryIDDRepository countryIDDRepository;
    @Autowired
    private ConfigurePropertiesRepository configurePropertiesRepository;
    @Autowired
    private JwtProvider jwtProvider;

    @Autowired
    private SIOCampaignService sioCampaignService;

    @RequestMapping(value = "/currentEnv", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object getPGPSaveYears() {
        return new Response(configProperties.getServerEnvironment());
    }

    @RequestMapping(value = "/getLeadGenListStatus", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<ConfigureProperties> getLeadGentStatus() {
        return configurePropertiesRepository.findByConNameIgnoreCaseContaining(Constants.LEAD_GEN_FLAG_LIKE_SQL);
    }

    @RequestMapping(value = "/getCountryIdd", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object getCountryIDD() {
        return countryIDDRepository.findAll();
    }

    @RequestMapping(value = "/refreshToken", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object generateNewRefreshToken(HttpServletRequest request) {
        return new D2CResponse("Success", 200, "", null,  jwtProvider.createJwtWithExisting(jwtProvider.resolveToken(request)));
    }

    @RequestMapping(value = "/getSIOCampaign/{prodCode}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ResponseEntity<SIOResponse> getSIOCampaign(@PathVariable String prodCode) {
        return sioCampaignService.checkValidSIO(prodCode);
    }

}
