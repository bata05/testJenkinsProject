package com.prudential.d2c.controller;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import com.prudential.d2c.common.ConfigProperties;
import com.prudential.d2c.entity.dto.ApplicationCybData;
import com.prudential.d2c.entity.micro.Compute;
import com.prudential.d2c.service.AssignedAgentService;
import com.prudential.d2c.utils.D2CUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.text.StrSubstitutor;
import org.apache.commons.lang.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Service;

import com.prudential.d2c.common.Constants;
import com.prudential.d2c.common.ProposalConstants;
import com.prudential.d2c.entity.ProposalPDFData;
import com.prudential.d2c.entity.QuestionnaireDetails;
import com.prudential.d2c.entity.SuccessStatus;
import com.prudential.d2c.entity.dto.ApplicationData;
import com.prudential.d2c.entity.dto.CustomerApplication;
import com.prudential.d2c.exception.D2CException;
import com.prudential.d2c.repository.ApplicationDataRepository;
import com.prudential.d2c.service.CustomerApplicationService;
import com.prudential.d2c.service.PdfService;
import com.prudential.d2c.utils.AddressFormatter;
import com.prudential.d2c.utils.DecryptionUtil;
import com.prudential.d2c.utils.StaticFileUtil;

import javax.servlet.http.HttpServletRequest;

import static com.prudential.d2c.common.Constants.*;
import static org.apache.commons.lang3.StringUtils.isNumeric;

@Service
@EnableAutoConfiguration
public class CreatePaPdfService {

    // Define the logger object for this class
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private static final String PA_TEMPLATE_LOCATION = "pa/tplPg";
    private static final int NO_OF_PAGES = 6;

    @Autowired
    protected HttpServletRequest request;

    @Autowired
    protected ConfigProperties configProperties;

    @Autowired
    protected AssignedAgentService assignedAgentService;

    @Autowired
    private ApplicationDataRepository applicationDataRepository;

    @Autowired
    private CustomerApplicationService customerApplicationService;

    @Autowired
    private PdfService pdfService;

    public Object submit(ProposalPDFData paData) {
        StopWatch sw = new StopWatch();
        sw.start();
        logger.debug("PaData : {} ", StaticFileUtil.convertObjectToJsonFormat(paData));
        byte[] contents = createPDF(paData);
        // add footer
        ByteArrayOutputStream out = pdfService.addFooterToPDF(contents,Constants.PRU_FOOTER);
        // save to database
        ApplicationData appData = new ApplicationData();
        appData.setErefNo(paData.getErefCode());
        appData.setCustomId(paData.getCustomId());
        Blob blob;
        try {
            blob = new javax.sql.rowset.serial.SerialBlob(out.toByteArray());
        } catch (SQLException e) {
            logger.error("Create Pdf submit error", e);
            throw new D2CException("Create Pdf submit error");
        }
        appData.setProposal(blob);
        applicationDataRepository.save(appData);

        sw.stop();
        logger.warn("createPaPDF cost time : {}; pdfEref: {}", sw.getTime(), D2CUtils.removeCRLF(paData.getErefCode()));
        return new SuccessStatus();
    }

    private byte[] createPDF(ProposalPDFData paData) {

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try {
            baos = createPdfBytes(paData);
            return baos.toByteArray();
        } catch (Exception e) {
            logger.error("Unable to load data for customID: " + D2CUtils.removeCRLF(paData.getCustomId()), e);
            throw new D2CException("Create Pdf bytes error");
        }
    }

    /**
     * Creates PDF
     * 
     * @param paData
     * @return
     */
    public ByteArrayOutputStream createPdfBytes(ProposalPDFData paData) {
        CustomerApplication customerAppData = new CustomerApplication();
        try {
            customerAppData = customerApplicationService.findCustomerApplicationByCustomId(paData.getCustomId());
        } catch (Exception e) {
            logger.error("FindCustomerApplicationByCustomId", e);
            throw new D2CException("Find customer error");
        }

        Document document = new Document(PageSize.A4); // A4 size
        document.setMargins(29, 29, 29, 29);
        document.addTitle("PRUaccess Summary");

        ByteArrayOutputStream bos = new ByteArrayOutputStream();

        try {
            PdfCopy copy = new PdfCopy(document, bos);
            document.open();
            PdfReader reader;

            for (int i = 1; i <= NO_OF_PAGES; i++) {
                InputStream is = StaticFileUtil.generatePdfInputStream(PA_TEMPLATE_LOCATION + i + Constants.SUFFIX_HTML);
                String fileContent = IOUtils.toString(is, Constants.ENCODING_UTF8);
                String resolvedString = replaceVarInTemplate(fileContent, i, paData, customerAppData);

                reader = new PdfReader(pdfService.parseHtml(resolvedString));
                copy.addDocument(reader);
                reader.close();
                is.close();
            }
        } catch (Exception e) {
            logger.error("Create PDF failed..");
            throw new D2CException("Create PDF failed due to exception ", e);
        } finally {
            document.close();
        }

        return bos;
    }

    /**
     * Replace variables with actual values
     * 
     * @param content
     * @param pageIndex
     * @param paData
     * @param customerAppData
     * @return
     */
    private String replaceVarInTemplate(String content, int pageIndex, ProposalPDFData paData,
        CustomerApplication customerAppData) {
        Map<String, String> valuesMap = new HashMap<>();
        replaceERef(valuesMap, paData.getErefCode());
        switch (pageIndex) {
        case 1:
            getPage1Values(valuesMap, paData, customerAppData);
            break;
        case 2:
            getPage2Values(valuesMap, customerAppData);
            break;
        case 3:
            getPage3Values(valuesMap, paData);
            break;
        case 6:
            getPage6Values(valuesMap, paData);
            break;
        default:
            break;
        }
        StrSubstitutor sub = new StrSubstitutor(valuesMap);
        return sub.replace(content);
    }

    /**
     * Map for Page One values
     * 
     * @param map
     * @param paData
     * @param customerAppData
     */
    private void getPage1Values(Map<String, String> map, ProposalPDFData paData, CustomerApplication customerAppData) {
        try {
            map.put(ProposalConstants.KEY_IMAGE,
                pdfService.getLogoImageData(request.getServletContext(), Constants.LOGO_IMG_NAME));
        } catch (IOException e) {
            logger.error("Error happend while get logo image", e);
            throw new D2CException("Error happend while get logo image", e.getCause());
        }

        String agencyNo;
        String businessSource;

        // Personal Detials
        String fullName = NOT_APPLICABLE;
        String gender = NOT_APPLICABLE;
        String dob = NOT_APPLICABLE;
        String nric = NOT_APPLICABLE;
        String currResStatus = NOT_APPLICABLE;
        String nationality = NOT_APPLICABLE;
        String countryOfBirth = Constants.COUNTRY_OF_BIRTH_NON_US;

        // Deployment Details
        String occupationClass = NOT_APPLICABLE;
        String occupationDescription = Constants.EMPTY_STRING;
        String annualIncome = AMOUNT_ZERO;
        String highestEdu = NOT_APPLICABLE;
        String industry = NOT_APPLICABLE;
        String employerName = NOT_APPLICABLE;
        String designation = NOT_APPLICABLE;

        // Plan Details
        String planName = "PRUpersonal accident";
        String sAPlanType = NOT_APPLICABLE;
        String term = NOT_APPLICABLE;
        String premium = AMOUNT_ZERO;

        String raPlanName = "Recovery Aid";
        String raSAPlanType = NOT_APPLICABLE;
        String raTerm = NOT_APPLICABLE;
        String raPremium = AMOUNT_ZERO;

        String pafePlanName = "Fracture Care";
        String pafeSAPlanType = NOT_APPLICABLE;
        String pafeTerm = NOT_APPLICABLE;
        String pafePremium = AMOUNT_ZERO;

        String totalPremium; // premium + raPremium + pafePremium

        // Personal Details
        agencyNo = assignedAgentService.getSaleCompletionAgentCode(paData.getCustomId());
        businessSource = paData.getBankCode();

        if (paData.getOccupationClass() != null) {
            occupationClass = paData.getOccupationClass();
        }
        if (paData.getOccupationDescription() != null) {
            occupationDescription = paData.getOccupationDescription();
        }

        if (customerAppData != null) {
            // Personal Details
            nric = decrypt(customerAppData.getNricFin());
            if (customerAppData.getGivenName() != null) {
                fullName = decrypt(customerAppData.getGivenName()) + SPACE_STRING
                    + decrypt(customerAppData.getSurName());
            } else {
                fullName = decrypt(customerAppData.getSurName());
            }
            fullName = StringEscapeUtils.escapeHtml(fullName);
            gender = customerAppData.getGender();
            dob = customerAppData.getDob();
            nationality = customerApplicationService.findNationalityName(customerAppData.getNationality());
            annualIncome = Constants.DOLLAR_WITH_SPACE + customerAppData.getAnnualIncome();

            if (Constants.RESIDENCY_SC_AB.equalsIgnoreCase(customerAppData.getResidencyStatus())) {
                currResStatus = Constants.RESIDENCY_SC_FULL;
            } else if (Constants.RESIDENCY_SPR_AB.equalsIgnoreCase(customerAppData.getResidencyStatus())) {
                currResStatus = Constants.RESIDENCY_SPR_FULL;
            } else if (Constants.RESIDENCY_OTHER_AB.equalsIgnoreCase(customerAppData.getResidencyStatus())) {
                currResStatus = Constants.RESIDENCY_OTHER_FULL;
            }

            QuestionnaireDetails[] mAYQuestions = pdfService
                    .extractQuestionnaire(customerAppData.getQmayQuestionnaires());

            if (mAYQuestions != null) {
                for (QuestionnaireDetails questionnaireDetails : mAYQuestions) {
                    if (questionnaireDetails.getQuestion() != null && questionnaireDetails.getAnswer() != null) {
                        String code = questionnaireDetails.getQuestion().getCode();
                        String answer = questionnaireDetails.getAnswer().getLabel();
                        String description = questionnaireDetails.getQuestion().getDescription();
                        if (ProposalConstants.QMAY001.equalsIgnoreCase(code) && answer != null) {
                            if (STRING_YES.equalsIgnoreCase(answer)) {
                                countryOfBirth = Constants.COUNTRY_OF_BIRTH_US;
                            } else {
                                countryOfBirth = Constants.COUNTRY_OF_BIRTH_NON_US;
                            }
                        }
                        if (ProposalConstants.QMAY018.equalsIgnoreCase(code) && answer != null) {
                            highestEdu = answer;
                        }
                        if (ProposalConstants.QMAY021.equalsIgnoreCase(code) && answer != null) {
                            String industryCodeSeqStr  = questionnaireDetails.getAnswer().getValue();
                            if(isNumeric(industryCodeSeqStr)){
                                int industryCode = Integer.parseInt(industryCodeSeqStr);
                                industry =  industryCode < 10 ? answer : NOT_APPLICABLE ;
                            }

                        }
                        if (ProposalConstants.QMAY0210101.equalsIgnoreCase(code) && answer != null) {
                            employerName = answer;
                        }
                        if (ProposalConstants.QMAY0210103.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210104.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210105.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210106.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        }
                        if (ProposalConstants.QMAY0210201.equalsIgnoreCase(code) && answer != null) {
                            employerName = answer;
                        }
                        if (ProposalConstants.QMAY0210203.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210204.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210205.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210206.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        }

                        if (ProposalConstants.QMAY0210301.equalsIgnoreCase(code) && answer != null) {
                            employerName = answer;
                        }
                        if (ProposalConstants.QMAY0210303.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210304.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210305.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210306.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        }

                        if (ProposalConstants.QMAY0210401.equalsIgnoreCase(code) && answer != null) {
                            employerName = answer;
                        }
                        if (ProposalConstants.QMAY0210403.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210404.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210405.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210406.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        }

                        if (ProposalConstants.QMAY0210501.equalsIgnoreCase(code) && answer != null) {
                            employerName = answer;
                        }
                        if (ProposalConstants.QMAY0210503.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210504.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210505.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210506.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        }

                        if (ProposalConstants.QMAY0210601.equalsIgnoreCase(code) && answer != null) {
                            employerName = answer;
                        }
                        if (ProposalConstants.QMAY0210603.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210604.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210605.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210606.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        }

                        if (ProposalConstants.QMAY0210701.equalsIgnoreCase(code) && answer != null) {
                            employerName = answer;
                        }
                        if (ProposalConstants.QMAY0210703.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210704.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210705.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210706.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        }

                        if (ProposalConstants.QMAY0210801.equalsIgnoreCase(code) && answer != null) {
                            employerName = answer;
                        }
                        if (ProposalConstants.QMAY0210803.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210804.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210805.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210806.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        }

                        if (ProposalConstants.QMAY0210901.equalsIgnoreCase(code) && answer != null) {
                            employerName = answer;
                        }
                        if (ProposalConstants.QMAY0210903.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210904.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210905.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210906.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        }
                    }
                }
            }
        }

        map.put(ProposalConstants.KEY_AGENTCODE, agencyNo);
        map.put(ProposalConstants.KEY_BUSINESSSOURCE, businessSource);
        map.put(ProposalConstants.KEY_FULLNAME, fullName);
        map.put(ProposalConstants.KEY_NRIC, nric);
        map.put(ProposalConstants.KEY_GENDER, gender);
        map.put(ProposalConstants.KEY_DOB, dob);
        map.put(ProposalConstants.KEY_HIGHESTEDU, highestEdu);
        map.put(ProposalConstants.KEY_NATIONALITY, nationality);
        map.put(ProposalConstants.KEY_COUNTRYOFBIRTH, countryOfBirth);
        map.put(ProposalConstants.KEY_CURRRESSTATUS, currResStatus);
        map.put(ProposalConstants.KEY_OCCUPATIONCLASS, occupationClass);
        map.put(ProposalConstants.KEY_OCCUPATIONDESCRIPTION, occupationDescription);
        map.put(ProposalConstants.KEY_ANNUALINCOME, annualIncome);
        map.put(ProposalConstants.KEY_INDUSTRY, industry);
        map.put(ProposalConstants.KEY_EMPLOYERNAME, employerName);
        map.put(ProposalConstants.KEY_DESIGNATION, designation);

        // Plan details
        if (paData.getBasicPlanDetails() != null) {
            planName = paData.getBasicPlanDetails().getPlanName();
            sAPlanType = paData.getBasicPlanDetails().getSumAssured() + SLASH_SPACE
                + paData.getBasicPlanDetails().getPlanType();
            premium = DOLLAR_WITH_SPACE + paData.getBasicPlanDetails().getPremium();
        }
        if (paData.getRaPlanDetails() != null) {
            raPlanName = paData.getRaPlanDetails().getPlanName();
            raSAPlanType = paData.getRaPlanDetails().getSumAssured() + SLASH_SPACE
                + paData.getRaPlanDetails().getPlanType();
            raPremium = DOLLAR_WITH_SPACE + paData.getRaPlanDetails().getPremium();
        }
        if (paData.getFcaPlanDetails() != null) {
            pafePlanName = paData.getFcaPlanDetails().getPlanName();
            pafeSAPlanType = paData.getFcaPlanDetails().getSumAssured() + SLASH_SPACE
                + paData.getFcaPlanDetails().getPlanType();
            pafePremium = DOLLAR_WITH_SPACE + paData.getFcaPlanDetails().getPremium();
        }
        totalPremium = DOLLAR_WITH_SPACE + paData.getTotalPremium();

        // Plan Details
        map.put(ProposalConstants.KEY_PLANNAME, planName);
        map.put(ProposalConstants.KEY_SAPLANTYPE, sAPlanType);
        map.put(ProposalConstants.KEY_TERM, term);
        map.put(ProposalConstants.KEY_PREMIUM, premium);
        map.put(ProposalConstants.KEY_RAPLANNAME, raPlanName);
        map.put(ProposalConstants.KEY_RASAPLANTYPE, raSAPlanType);
        map.put(ProposalConstants.KEY_RATERM, raTerm);
        map.put(ProposalConstants.KEY_RAPREMIUM, raPremium);
        map.put(ProposalConstants.KEY_PAFEPLANNAME, pafePlanName);
        map.put(ProposalConstants.KEY_PAFESAPLANTYPE, pafeSAPlanType);
        map.put(ProposalConstants.KEY_PAFETERM, pafeTerm);
        map.put(ProposalConstants.KEY_PAFEPREMIUM, pafePremium);
        map.put(ProposalConstants.KEY_TOTALPREMIUM, totalPremium);

    }

    /**
     * Map for Page Two values
     * 
     * @param map
     * @param customerAppData
     */
    private void getPage2Values(Map<String, String> map, CustomerApplication customerAppData) {
        String mobileNumber = NOT_APPLICABLE;
        String email = NOT_APPLICABLE;
        String resAddr = NOT_APPLICABLE;
        String mailingAddr = NOT_APPLICABLE;
        String addressChangeContent = "My residential address has not changed since (MM/YYYY).";
        String addressChangeAnswer = NOT_APPLICABLE;

        String singaporeCitizen = NOT_APPLICABLE;
        String singaporePermRes = NOT_APPLICABLE;
        String shortTermPass = NOT_APPLICABLE;

        // Previous Insurance Details
        String isReplacePolicy = NOT_APPLICABLE;
        String over5MioPolicy = NOT_APPLICABLE;
        String lastInsurDate = NOT_APPLICABLE;
        String totalValue = NOT_APPLICABLE;

        if (customerAppData != null) {
            // Contact Details
            email = decrypt(customerAppData.getCustomerEmail());
            mobileNumber = decrypt(customerAppData.getMobilePhone());

            resAddr = AddressFormatter.formatResAddr(customerAppData, configProperties);
            mailingAddr = AddressFormatter.formatMailingAddr(customerAppData, configProperties);

            QuestionnaireDetails[] mAYQuestions = pdfService
                    .extractQuestionnaire(customerAppData.getQmayQuestionnaires());

            if (mAYQuestions != null) {
                for (QuestionnaireDetails questionnaireDetails : mAYQuestions) {
                    if (questionnaireDetails.getQuestion() != null && questionnaireDetails.getAnswer() != null) {
                        String code = questionnaireDetails.getQuestion().getCode();
                        String description = questionnaireDetails.getQuestion().getDescription();
                        String answer = questionnaireDetails.getAnswer().getLabel();

                        if (ProposalConstants.QMAY010.equalsIgnoreCase(code) && answer != null) {
                            addressChangeContent = description;
                            addressChangeAnswer = answer;

                        }
                        if (ProposalConstants.QMAY003A.equalsIgnoreCase(code) && answer != null) {
                            singaporeCitizen = answer.toUpperCase();
                        }
                        if (ProposalConstants.QMAY003B.equalsIgnoreCase(code) && answer != null) {
                            singaporePermRes = answer.toUpperCase();
                        }
                        if (ProposalConstants.QMAY003C.equalsIgnoreCase(code) && answer != null) {
                            shortTermPass = answer.toUpperCase();
                        }

                        if (ProposalConstants.QMAY026.equalsIgnoreCase(code) && answer != null) {
                            isReplacePolicy = answer.toUpperCase();
                        }
                        if (ProposalConstants.QMAY027.equalsIgnoreCase(code) && answer != null) {
                            over5MioPolicy = answer.toUpperCase();
                        }
                        if (ProposalConstants.QMAY02701.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                            lastInsurDate = description;
                        } else if (ProposalConstants.QMAY02702.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            lastInsurDate = description;
                        } else if (ProposalConstants.QMAY02703.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            lastInsurDate = description;
                        }
                        if (ProposalConstants.QMAY02705.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                            totalValue = description;
                        } else if (ProposalConstants.QMAY02706.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            totalValue = description;
                        } else if (ProposalConstants.QMAY02707.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            totalValue = description;
                        } else if (ProposalConstants.QMAY02708.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            totalValue = description;
                        } else if (ProposalConstants.QMAY02709.equalsIgnoreCase(code)
                            && !STRING_NO.equalsIgnoreCase(answer)) {
                            totalValue = answer.split(Constants.HYPHEN)[1];
                        }
                    }
                }

            }
        }

        map.put(ProposalConstants.KEY_MOBILENUMBER, mobileNumber);
        map.put(ProposalConstants.KEY_EMAIL, email);
        map.put(ProposalConstants.KEY_RESADDR, resAddr);
        map.put(ProposalConstants.KEY_MAILINGADDR, mailingAddr);
        map.put(ProposalConstants.KEY_ADDRESSCHANGECONTENT, addressChangeContent);
        map.put(ProposalConstants.KEY_ADDRESSCHANGEANSWER, addressChangeAnswer);

        map.put(ProposalConstants.KEY_SINGAPORECITIZEN, singaporeCitizen);
        map.put(ProposalConstants.KEY_SINGAPOREPERMRES, singaporePermRes);
        map.put(ProposalConstants.KEY_SHORTTERMPASS, shortTermPass);

        // Previous Insurance Details
        map.put(ProposalConstants.KEY_ISREPLACEPOLICY, isReplacePolicy);
        map.put(ProposalConstants.KEY_OVER5MIOPOLICY, over5MioPolicy);
        map.put(ProposalConstants.KEY_LASTINSURDATE, lastInsurDate);
        map.put(ProposalConstants.KEY_TOTALVALUE, totalValue);

    }

    private void getPage3Values(Map<String, String> map, ProposalPDFData paData) {
        String consultationReq = NOT_APPLICABLE;

        if (Constants.SHORT_YES.equalsIgnoreCase(paData.getConsultationReq())) {
            consultationReq = STRING_YES;
        } else if (Constants.SHORT_NO.equalsIgnoreCase(paData.getConsultationReq())) {
            consultationReq = STRING_NO;
        }
        map.put(ProposalConstants.KEY_CONSULTATIONREQ, consultationReq);
    }

    /**
     * Map for Page Six values
     * 
     * @param map
     * @param paData
     */
    private void getPage6Values(Map<String, String> map, ProposalPDFData paData) {
        // Consent
        String receiveMarketingInfo = NOT_APPLICABLE;

        if (Constants.SHORT_YES.equalsIgnoreCase(paData.getReceiveMarketing())) {
            receiveMarketingInfo = STRING_YES;
        } else if (Constants.SHORT_NO.equalsIgnoreCase(paData.getReceiveMarketing())) {
            receiveMarketingInfo = STRING_NO;
        }

        map.put(ProposalConstants.KEY_READDECLARATION, STRING_YES);
        map.put(ProposalConstants.KEY_RECEIVEMARKETINGINFO, receiveMarketingInfo);
    }

    /**
     * Replace eRef
     * 
     * @param map
     * @param eRef
     */
    private void replaceERef(Map<String, String> map, String eRef) {
        map.put(ProposalConstants.KEY_EREF, eRef);
    }

    private String decrypt(String req) {
        return DecryptionUtil.decryption(req, configProperties);
    }

    public ProposalPDFData addProductSpecificDetails(ProposalPDFData proposalData, ApplicationCybData appCybData, Compute compute, CustomerApplication customerApp) {
        return null;
    };
}
