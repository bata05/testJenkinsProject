package com.prudential.d2c.controller;

import static com.prudential.d2c.utils.StaticFileUtil.convertObjectToJsonFormat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.prudential.d2c.entity.ProposalPDFData;
import com.prudential.d2c.service.CustomerApplicationService;
import com.prudential.d2c.service.ProposalDataService;

@RestController
@EnableAutoConfiguration
public class CreatePdfController extends BaseController {

    @Autowired
    CustomerApplicationService csa;

    @Autowired
    ProposalDataService proposalDataService;

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @RequestMapping(
            value = "/generateProposalPDF",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public Object submit(@RequestBody ProposalPDFData proposalPDFData) {

        logger.info("Invoking /generateProposalPDF.");

        logger.debug("request : {}", convertObjectToJsonFormat(proposalPDFData));

        return proposalDataService.generateProposalPDF(proposalPDFData);
    }

    @RequestMapping(
            value = "/generateProposalPDFForPA",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public Object submitPA(@RequestBody ProposalPDFData proposalPDFData) {

        return proposalDataService.generateProposalPDFForPA(proposalPDFData);
    }
    
}
