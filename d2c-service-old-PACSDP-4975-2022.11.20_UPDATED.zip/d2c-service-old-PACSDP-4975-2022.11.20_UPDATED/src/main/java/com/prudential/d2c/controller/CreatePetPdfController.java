/**
 * 
 */
package com.prudential.d2c.controller;

import static com.prudential.d2c.common.Constants.AMOUNT_ZERO;
import static com.prudential.d2c.common.Constants.DOLLAR_WITH_SPACE;
import static com.prudential.d2c.common.Constants.EMPTY_STRING;
import static com.prudential.d2c.common.Constants.NOT_APPLICABLE;
import static com.prudential.d2c.common.Constants.SPACE_STRING;
import static com.prudential.d2c.common.Constants.STRING_NO;
import static com.prudential.d2c.common.Constants.STRING_YES;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.text.StrSubstitutor;
import org.apache.commons.lang.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.itextpdf.text.Document;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfCopy;
import com.itextpdf.text.pdf.PdfReader;
import com.prudential.d2c.common.Constants;
import com.prudential.d2c.common.ProposalConstants;
import com.prudential.d2c.entity.Component;
import com.prudential.d2c.entity.PlanDetails;
import com.prudential.d2c.entity.Product;
import com.prudential.d2c.entity.ProductEnum;
import com.prudential.d2c.entity.ProposalPDFData;
import com.prudential.d2c.entity.QuestionnaireDetails;
import com.prudential.d2c.entity.SuccessStatus;
import com.prudential.d2c.entity.dto.ApplicationCybData;
import com.prudential.d2c.entity.dto.ApplicationData;
import com.prudential.d2c.entity.dto.CustomerApplication;
import com.prudential.d2c.entity.micro.payload.ComputeResponsePayload;
import com.prudential.d2c.exception.D2CException;
import com.prudential.d2c.repository.ApplicationDataRepository;
import com.prudential.d2c.service.CustomerApplicationService;
import com.prudential.d2c.service.PdfService;
import com.prudential.d2c.service.ProposalPDFGenerator;
import com.prudential.d2c.utils.AddressFormatter;
import com.prudential.d2c.utils.D2CUtils;
import com.prudential.d2c.utils.DecryptionUtil;
import com.prudential.d2c.utils.StaticFileUtil;

/**
 * @author rprasad017
 *
 */
@RestController
@EnableAutoConfiguration
public class CreatePetPdfController extends BaseController implements ProposalPDFGenerator {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private static final String PET_TEMPLATE_LOCATION = "pet/tplPg";
    private static final int NO_OF_PAGES = 9;

    @Autowired
    private ApplicationDataRepository applicationDataRepository;

    @Autowired
    private CustomerApplicationService customerApplicationService;

    @Autowired
    private PdfService pdfService;

    public Object submit(@RequestBody ProposalPDFData petData, ProposalPDFGenerator proposalPDFGenerator) {
        StopWatch sw = new StopWatch();
        sw.start();


        logger.debug("PetData : {} ", StaticFileUtil.convertObjectToJsonFormat(petData));
        

        byte[] contents = createPDF(petData);

        ApplicationData appData = new ApplicationData();
        appData.setErefNo(petData.getErefCode());
        appData.setCustomId(petData.getCustomId());
        Blob blob;
        try {
            blob = new javax.sql.rowset.serial.SerialBlob(contents);
        } catch (SQLException e) {
            logger.error("Create Pdf submit error", e);
            throw new D2CException("Create Pdf submit error");
        }
        appData.setProposal(blob);
        applicationDataRepository.save(appData);

        // // Save for Cybersource payment in DB

        sw.stop();
        logger.info("createPetPDF cost time : {}; createPetPDF: {}", sw.getTime(), D2CUtils.removeCRLF(petData.getErefCode()));
        return new SuccessStatus();
    }
    

	@Override
	public String getProdType() {
		return ProductEnum.ET.name();
	}

	@Override
	public ProposalPDFData addProductSpecificDetails(ProposalPDFData proposalPDFData, ApplicationCybData appCybData,
			ComputeResponsePayload computeAllResponse, CustomerApplication customerApp) {
		Product product = computeAllResponse.getSelectedSQSProducts().get(0);
		String planName = product.getProdDesc();
		if(product.getComponents().get(0).getSelectedCompoPlanOption() != null) {
			planName = planName + " - " + product.getComponents().get(0).getSelectedCompoPlanOption().getOptDescp();
		}
		proposalPDFData.getBasicPlanDetails().setPlanName(planName);
        PlanDetails riderPlanDetails = proposalPDFData.getRiderPlanDetails();
        if(riderPlanDetails == null){
            riderPlanDetails = new PlanDetails();
        }
        for(Component component : product.getComponents()){
        	if(product.getComponents().size() == 1) break;
        	if("DAQ2".equals(component.getCompoCode())) {
	            riderPlanDetails.setPlanName(component.getCompoDesc());
	            riderPlanDetails.setPlanType(component.getCompoCode());
	            riderPlanDetails.setTerm(String.valueOf(component.getTerm()));
	            riderPlanDetails.setSumAssured(String.valueOf(component.getSumAssured()));
	            riderPlanDetails.setPremium(String.valueOf(component.getPremium()));
	            proposalPDFData.setRiderPlanDetails(riderPlanDetails);//set only if the rider exist, else will show null in PDF
        	}
        }
        return proposalPDFData;
	}

    /**
     * Retrieves required data from database and creates PDF bytes
     *
     * @param petData
     * @return
     */
    private byte[] createPDF(ProposalPDFData petData) {

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try {

            baos = createPdfBytes(petData);
        } catch (Exception e) {
            logger.error("Unable to load data", e);
            throw new D2CException("Create Pdf bytes error");
        }
        return baos.toByteArray();
    }

    /**
     * Creates PDF bytes
     *
     * @param petData
     * @return
     */
    private ByteArrayOutputStream createPdfBytes(ProposalPDFData petData) {
        CustomerApplication customerAppData = new CustomerApplication();

        try {
            customerAppData = customerApplicationService.findCustomerApplicationByCustomId(petData.getCustomId());
        } catch (Exception e) {
            logger.error("FindCustomerApplicationByCustomId", e);
            throw new D2CException("Find customer error");
        }

        Document document = new Document(PageSize.A4); // A4 size
        document.setMargins(29, 29, 29, 29);
        document.addTitle("PruEasyTerm Summary");

        ByteArrayOutputStream bos = new ByteArrayOutputStream();

        try {
            PdfCopy copy = new PdfCopy(document, bos);
            document.open();
            PdfReader reader;

            for (int i = 1; i <= NO_OF_PAGES; i++) {
                DecimalFormat formatter = new DecimalFormat("00");
                String pageNumber = formatter.format(i);

                InputStream is = StaticFileUtil.generatePdfInputStream(PET_TEMPLATE_LOCATION + pageNumber + Constants.SUFFIX_HTML);
                String fileContent = IOUtils.toString(is, Constants.ENCODING_UTF8);
                String resolvedString = replaceVarInTemplate(fileContent, i, petData, customerAppData);

                reader = new PdfReader(pdfService.parseHtml(resolvedString));
                copy.addDocument(reader);
                reader.close();
                is.close();
            }
        } catch (Exception e) {
            logger.error("createPdfBytes");
            throw new D2CException("Create Pdf bytes error");
        } finally {
            document.close();
        }

        return bos;
    }

    /**
     * Replace variables with actual values
     *
     * @param content
     * @param pageIndex
     * @param petData
     * @param customerAppData
     * @return
     */
    public String replaceVarInTemplate(String content, int pageIndex, ProposalPDFData petData,
        CustomerApplication customerAppData) {
        Map<String, String> valuesMap = new HashMap<>();
        valuesMap.put(ProposalConstants.KEY_EREF, petData.getErefCode());

        QuestionnaireDetails[] mayQuestions = null;
        QuestionnaireDetails[] psQuestions = null;

        try {
            if (customerAppData != null) {
                mayQuestions = pdfService.extractQuestionnaire(customerAppData.getQmayQuestionnaires());
                psQuestions = pdfService.extractQuestionnaire(customerAppData.getQpsQuestionnaires());
            }
        } catch (Exception e) {
            logger.error("Error while executing replaceVarInTemplate", e);
        }

        switch (pageIndex) {
        case 1:
            getPage1Values(valuesMap, petData, customerAppData);
            break;
        case 2:
            getPage2Values(valuesMap, customerAppData);
            break;
        case 3:
            getPage3Values(valuesMap, mayQuestions);
            break;
        case 4:
            getPage4Values(valuesMap, petData, mayQuestions, psQuestions);
            break;
        case 9:
            getPage9Values(valuesMap, petData);
            break;
        default:
            break;
        }
        StrSubstitutor sub = new StrSubstitutor(valuesMap);

        return sub.replace(content);
    }

    /**
     * Constructs map for Page One values
     *
     * @param map
     * @param petData
     * @param customerAppData
     */
    private void getPage1Values(Map<String, String> map, ProposalPDFData petData, CustomerApplication customerAppData) {
        try {
            map.put(ProposalConstants.KEY_IMAGE,
                pdfService.getLogoImageData(request.getServletContext(), Constants.LOGO_IMG_NAME));
        } catch (IOException e) {
            logger.error("Error happend while get logo image", e);
            throw new D2CException("Error happend while get logo image", e.getCause());
        }

        String agencyNo;
        String businessSource;

        // Plan Details
        String basicPlanName = "PRUeasy term";
        String basicSumAssured = AMOUNT_ZERO;
        String basicTerm = NOT_APPLICABLE;
        String basicYearlyPremium = AMOUNT_ZERO;

        String riderPlanName = "Accelerated Disability";
        String riderSumAssured = AMOUNT_ZERO;
        String riderTerm = NOT_APPLICABLE;
        String riderYearlyPremium = AMOUNT_ZERO;

        String totalPremium;

        // Personal Details
        String fullName = NOT_APPLICABLE;
        String gender = NOT_APPLICABLE;
        String dob = NOT_APPLICABLE;
        String nric = NOT_APPLICABLE;
        String currResStatus = NOT_APPLICABLE;
        String nationality = NOT_APPLICABLE;
        String countryOfBirth = Constants.COUNTRY_OF_BIRTH_NON_US;
        String heightCm = NOT_APPLICABLE;
        String weightKg = NOT_APPLICABLE;
        String highestEdu = NOT_APPLICABLE;

        String mobileNumber = NOT_APPLICABLE;
        String email = NOT_APPLICABLE;
        String resAddr = NOT_APPLICABLE;
        String mailingAddr = NOT_APPLICABLE;

        String addressChangeContent = "My residential address has not changed since (MM/YYYY).";
        String addressChangeAnswer = NOT_APPLICABLE;

        agencyNo = assignedAgentService.getSaleCompletionAgentCode(petData.getCustomId());
        businessSource = petData.getBankCode();

        if (petData.getBasicPlanDetails() != null) {
            basicPlanName = petData.getBasicPlanDetails().getPlanName();
            basicSumAssured = DOLLAR_WITH_SPACE + petData.getBasicPlanDetails().getSumAssured();
            basicTerm = petData.getBasicPlanDetails().getTerm();
            basicYearlyPremium = DOLLAR_WITH_SPACE + petData.getBasicPlanDetails().getPremium();
        }
        if (petData.getRiderPlanDetails() != null) {
            riderPlanName = petData.getRiderPlanDetails().getPlanName();
            riderSumAssured = DOLLAR_WITH_SPACE + petData.getRiderPlanDetails().getSumAssured();
            riderTerm = petData.getRiderPlanDetails().getTerm();
            riderYearlyPremium = DOLLAR_WITH_SPACE + petData.getRiderPlanDetails().getPremium();
        }
        totalPremium = DOLLAR_WITH_SPACE + petData.getTotalPremium();

        if (customerAppData != null) {
            if (customerAppData.getGivenName() != null) {
                fullName = decrypt(customerAppData.getGivenName()) + SPACE_STRING
                    + decrypt(customerAppData.getSurName());
            } else {
                fullName = decrypt(customerAppData.getSurName());
            }
            fullName = StringEscapeUtils.escapeHtml(fullName);
            gender = customerAppData.getGender();
            dob = customerAppData.getDob();
            nric = decrypt(customerAppData.getNricFin());
            nationality = customerApplicationService.findNationalityName(customerAppData.getNationality());
            heightCm = customerAppData.getHeight();
            weightKg = customerAppData.getWeight();

            if (Constants.RESIDENCY_SC_AB.equalsIgnoreCase(customerAppData.getResidencyStatus())) {
                currResStatus = Constants.RESIDENCY_SC_FULL;
            } else if (Constants.RESIDENCY_SPR_AB.equals(customerAppData.getResidencyStatus())) {
                currResStatus = Constants.RESIDENCY_SPR_FULL;
            } else if (Constants.RESIDENCY_OTHER_AB.equals(customerAppData.getResidencyStatus())) {
                currResStatus = Constants.RESIDENCY_OTHER_FULL;
            }

            mobileNumber = decrypt(customerAppData.getMobilePhone());
            email = decrypt(customerAppData.getCustomerEmail());
            resAddr = AddressFormatter.formatResAddr(customerAppData, configProperties);
            mailingAddr = AddressFormatter.formatMailingAddr(customerAppData, configProperties);

            QuestionnaireDetails[] mayQuestions = pdfService
                    .extractQuestionnaire(customerAppData.getQmayQuestionnaires());

            if (mayQuestions != null) {
                for (QuestionnaireDetails questionnaireDetails : mayQuestions) {
                    if (questionnaireDetails.getQuestion() != null && questionnaireDetails.getAnswer() != null) {
                        String code = questionnaireDetails.getQuestion().getCode();
                        String description = questionnaireDetails.getQuestion().getDescription();
                        String answer = questionnaireDetails.getAnswer().getLabel();
                       
                        if (ProposalConstants.QMAY018.equalsIgnoreCase(code) && answer != null) {
                            highestEdu = answer;
                        }
                        if (ProposalConstants.QMAY001.equalsIgnoreCase(code) && answer != null) {
                            if (STRING_YES.equalsIgnoreCase(answer)) {
                                countryOfBirth = Constants.COUNTRY_OF_BIRTH_US;
                            } else {
                                countryOfBirth = Constants.COUNTRY_OF_BIRTH_NON_US;
                            }
                        }

                        if (ProposalConstants.QMAY010.equalsIgnoreCase(code) && answer != null) {
                            addressChangeContent = description;
                            addressChangeAnswer = answer;

                        }
                    }
                }

            }
        }

        // Basic Plan Details
        map.put(ProposalConstants.KEY_BASICPLANNAME, basicPlanName);
        map.put(ProposalConstants.KEY_BASICSUMASSURED, basicSumAssured);
        map.put(ProposalConstants.KEY_BASICTERM, basicTerm);
        map.put(ProposalConstants.KEY_BASICYEARLYPREMIUM, basicYearlyPremium);

        // Rider Plan Details
        map.put(ProposalConstants.KEY_RIDERPLANNAME, riderPlanName);
        map.put(ProposalConstants.KEY_RIDERSUMASSURED, riderSumAssured);
        map.put(ProposalConstants.KEY_RIDERTERM, riderTerm);
        map.put(ProposalConstants.KEY_RIDERYEARLYPREMIUM, riderYearlyPremium);

        map.put(ProposalConstants.KEY_TOTALPREMIUM, totalPremium);

        map.put(ProposalConstants.KEY_AGENTCODE, agencyNo);
        map.put(ProposalConstants.KEY_BUSINESSSOURCE, businessSource);
        map.put(ProposalConstants.KEY_FULLNAME, fullName);
        map.put(ProposalConstants.KEY_NRIC, nric);
        map.put(ProposalConstants.KEY_GENDER, gender);
        map.put(ProposalConstants.KEY_DOB, dob);
        map.put(ProposalConstants.KEY_NATIONALITY, nationality);
        map.put(ProposalConstants.KEY_COUNTRYOFBIRTH, countryOfBirth);
        map.put(ProposalConstants.KEY_CURRRESSTATUS, currResStatus);
        map.put(ProposalConstants.KEY_HEIGHTCM, heightCm);
        map.put(ProposalConstants.KEY_WEIGHTKG, weightKg);
        map.put(ProposalConstants.KEY_HIGHESTEDU, highestEdu);

        map.put(ProposalConstants.KEY_MOBILENUMBER, mobileNumber);
        map.put(ProposalConstants.KEY_EMAIL, email);
        map.put(ProposalConstants.KEY_RESADDR, resAddr);
        map.put(ProposalConstants.KEY_MAILINGADDR, mailingAddr);

        map.put(ProposalConstants.KEY_ADDRESSCHANGECONTENT, addressChangeContent);
        map.put(ProposalConstants.KEY_ADDRESSCHANGEANSWER, addressChangeAnswer);

    }

    /**
     * Constructs map for Page Two values
     *
     * @param map
     * @param customerAppData
     */
    private void getPage2Values(Map<String, String> map, CustomerApplication customerAppData) {
        String occupationClass = NOT_APPLICABLE;
        String occupationDescription = EMPTY_STRING;
        String annualIncome = AMOUNT_ZERO;
        String highestEdu = NOT_APPLICABLE;
        String industry = NOT_APPLICABLE;
        String employerName = NOT_APPLICABLE;
        String designation = NOT_APPLICABLE;

        String singaporeCitizen = NOT_APPLICABLE;
        String singaporePermRes = NOT_APPLICABLE;
        String shortTermPass = NOT_APPLICABLE;

        // Previous Insurance Details
        String isReplacePolicy = NOT_APPLICABLE;
        String over5MioPolicy = NOT_APPLICABLE;
        String lastInsurDate = NOT_APPLICABLE;
        String totalValue = NOT_APPLICABLE;

        if (customerAppData != null) {
            annualIncome = DOLLAR_WITH_SPACE + customerAppData.getAnnualIncome();

            QuestionnaireDetails[] mayQuestions = pdfService
                    .extractQuestionnaire(customerAppData.getQmayQuestionnaires());
            if (mayQuestions != null) {
                for (QuestionnaireDetails questionnaireDetails : mayQuestions) {
                    if (questionnaireDetails.getQuestion() != null && questionnaireDetails.getAnswer() != null) {
                        String code = questionnaireDetails.getQuestion().getCode();
                        String answer = questionnaireDetails.getAnswer().getLabel();
                        String description = questionnaireDetails.getQuestion().getDescription();
                        if (ProposalConstants.QMAY018.equalsIgnoreCase(code) && answer != null) {
                            highestEdu = answer;
                        }
                        if (ProposalConstants.QMAY01901.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                            occupationClass = description;
                            occupationDescription = questionnaireDetails.getQuestion().getDetails();
                        } else if (ProposalConstants.QMAY01902.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            occupationClass = description;
                            occupationDescription = questionnaireDetails.getQuestion().getDetails();
                        } else if (ProposalConstants.QMAY01903.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            occupationClass = description;
                            occupationDescription = questionnaireDetails.getQuestion().getDetails();
                        } else if (ProposalConstants.QMAY01904.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            occupationClass = description;
                            occupationDescription = questionnaireDetails.getQuestion().getDetails();
                        }
                        if (ProposalConstants.QMAY02101.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                            industry = description;
                        }
                        if (ProposalConstants.QMAY0210101.equalsIgnoreCase(code) && answer != null) {
                            employerName = answer;
                        }
                        if (ProposalConstants.QMAY0210103.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210104.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210105.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210106.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        }
                        if (ProposalConstants.QMAY02102.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                            industry = description;
                        }

                        if (ProposalConstants.QMAY0210201.equalsIgnoreCase(code) && answer != null) {
                            employerName = answer;
                        }
                        if (ProposalConstants.QMAY0210203.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210204.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210205.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210206.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        }

                        if (ProposalConstants.QMAY02103.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                            industry = description;
                        }
                        if (ProposalConstants.QMAY0210301.equalsIgnoreCase(code) && answer != null) {
                            employerName = answer;
                        }
                        if (ProposalConstants.QMAY0210303.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210304.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210305.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210306.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        }

                        if (ProposalConstants.QMAY02104.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                            industry = description;
                        }
                        if (ProposalConstants.QMAY0210401.equalsIgnoreCase(code) && answer != null) {
                            employerName = answer;
                        }
                        if (ProposalConstants.QMAY0210403.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210404.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210405.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210406.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        }

                        if (ProposalConstants.QMAY02105.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                            industry = description;
                        }
                        if (ProposalConstants.QMAY0210501.equalsIgnoreCase(code) && answer != null) {
                            employerName = answer;
                        }
                        if (ProposalConstants.QMAY0210503.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210504.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210505.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210506.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        }

                        if (ProposalConstants.QMAY02106.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                            industry = description;
                        }
                        if (ProposalConstants.QMAY0210601.equalsIgnoreCase(code) && answer != null) {
                            employerName = answer;
                        }
                        if (ProposalConstants.QMAY0210603.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210604.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210605.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210606.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        }

                        if (ProposalConstants.QMAY02107.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                            industry = description;
                        }
                        if (ProposalConstants.QMAY0210701.equalsIgnoreCase(code) && answer != null) {
                            employerName = answer;
                        }
                        if (ProposalConstants.QMAY0210703.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210704.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210705.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210706.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        }

                        if (ProposalConstants.QMAY02108.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                            industry = description;
                        }
                        if (ProposalConstants.QMAY0210801.equalsIgnoreCase(code) && answer != null) {
                            employerName = answer;
                        }
                        if (ProposalConstants.QMAY0210803.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210804.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210805.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210806.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        }

                        if (ProposalConstants.QMAY02109.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                            industry = description;
                        }
                        if (ProposalConstants.QMAY0210901.equalsIgnoreCase(code) && answer != null) {
                            employerName = answer;
                        }
                        if (ProposalConstants.QMAY0210903.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210904.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210905.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        } else if (ProposalConstants.QMAY0210906.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            designation = description;
                        }
                        if (ProposalConstants.QMAY02110.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                            industry = "None";
                        }

                        if (ProposalConstants.QMAY003A.equalsIgnoreCase(code) && answer != null) {
                            singaporeCitizen = answer.toUpperCase();
                        }
                        if (ProposalConstants.QMAY003B.equalsIgnoreCase(code) && answer != null) {
                            singaporePermRes = answer.toUpperCase();
                        }
                        if (ProposalConstants.QMAY003C.equalsIgnoreCase(code) && answer != null) {
                            shortTermPass = answer.toUpperCase();
                        }

                        if (ProposalConstants.QMAY026.equalsIgnoreCase(code) && answer != null) {
                            isReplacePolicy = answer.toUpperCase();
                        }
                        if (ProposalConstants.QMAY027.equalsIgnoreCase(code) && answer != null) {
                            over5MioPolicy = answer.toUpperCase();
                        }
                        if (ProposalConstants.QMAY02701.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                            lastInsurDate = description;
                        } else if (ProposalConstants.QMAY02702.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            lastInsurDate = description;
                        } else if (ProposalConstants.QMAY02703.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            lastInsurDate = description;
                        }
                        if (ProposalConstants.QMAY02705.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                            totalValue = description;
                        } else if (ProposalConstants.QMAY02706.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            totalValue = description;
                        } else if (ProposalConstants.QMAY02707.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            totalValue = description;
                        } else if (ProposalConstants.QMAY02708.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                            totalValue = description;
                        } else if (ProposalConstants.QMAY02709.equalsIgnoreCase(code)
                            && !STRING_NO.equalsIgnoreCase(answer)) {
                            totalValue = answer.split("-")[1];
                        }
                    }
                }
            }
        }

        map.put(ProposalConstants.KEY_OCCUPATIONCLASS, occupationClass);
        map.put(ProposalConstants.KEY_OCCUPATIONDESCRIPTION, occupationDescription);
        map.put(ProposalConstants.KEY_ANNUALINCOME, annualIncome);
        map.put(ProposalConstants.KEY_HIGHESTEDU, highestEdu);
        map.put(ProposalConstants.KEY_INDUSTRY, industry);
        map.put(ProposalConstants.KEY_EMPLOYERNAME, employerName);
        map.put(ProposalConstants.KEY_DESIGNATION, designation);

        map.put(ProposalConstants.KEY_SINGAPORECITIZEN, singaporeCitizen);
        map.put(ProposalConstants.KEY_SINGAPOREPERMRES, singaporePermRes);
        map.put(ProposalConstants.KEY_SHORTTERMPASS, shortTermPass);

        // Previous Insurance Details
        map.put(ProposalConstants.KEY_ISREPLACEPOLICY, isReplacePolicy);
        map.put(ProposalConstants.KEY_OVER5MIOPOLICY, over5MioPolicy);
        map.put(ProposalConstants.KEY_LASTINSURDATE, lastInsurDate);
        map.put(ProposalConstants.KEY_TOTALVALUE, totalValue);

    }

    /**
     * Constructs map for Page Three values
     * 
     * @param map
     * @param mayQuestions
     */
    private void getPage3Values(Map<String, String> map, QuestionnaireDetails[] mayQuestions) {
        // Source of Wealth and Funds
        String payByYou = NOT_APPLICABLE;
        String payerName = NOT_APPLICABLE;
        String payerGivenName = EMPTY_STRING;
        String payerSurName = EMPTY_STRING;
        String payerNric = NOT_APPLICABLE;
        String payerRelationship = NOT_APPLICABLE;
        String howToPay = NOT_APPLICABLE;
        List<String> payWays = new ArrayList<>();
        String otherPayWay = NOT_APPLICABLE;

        // Beneficial Owners
        String isBeneficialOwners = NOT_APPLICABLE;

        String boName = NOT_APPLICABLE;
        String boGivenName = EMPTY_STRING;
        String boSurName = EMPTY_STRING;
        String boNric = NOT_APPLICABLE;
        String boDob = NOT_APPLICABLE;
        String boNationality = NOT_APPLICABLE;
        String boResCountry = NOT_APPLICABLE;
        String boRelationship = NOT_APPLICABLE;

        if (mayQuestions != null) {
            for (QuestionnaireDetails questionnaireDetails : mayQuestions) {
                if (questionnaireDetails.getQuestion() != null && questionnaireDetails.getAnswer() != null) {
                    String code = questionnaireDetails.getQuestion().getCode();
                    String answer = questionnaireDetails.getAnswer().getLabel();
                    String description = questionnaireDetails.getQuestion().getDescription();
                    if (ProposalConstants.QMAY031.equalsIgnoreCase(code) && answer != null) { // Source of wealth and funds
                        payByYou = answer;
                    } else if (ProposalConstants.QMAY03101.equalsIgnoreCase(code) && answer != null) { // Get details of person who is paying
                                                                                                       // premium
                        payerSurName = answer;
                    } else if (ProposalConstants.QMAY03102.equalsIgnoreCase(code) && answer != null) {
                        payerGivenName = answer;
                    } else if (ProposalConstants.QMAY03103.equalsIgnoreCase(code) && answer != null) {
                        payerNric = answer;
                    } else if (ProposalConstants.QMAY03104.equalsIgnoreCase(code) && answer != null) {
                        payerRelationship = answer;
                    } else if (ProposalConstants.QMAY03201.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        payWays.add(description);
                    } else if (ProposalConstants.QMAY03202.equalsIgnoreCase(code) && answer != null
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        payWays.add(description);
                    } else if (ProposalConstants.QMAY03203.equalsIgnoreCase(code) && answer != null
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        payWays.add(description);
                    } else if (ProposalConstants.QMAY03204.equalsIgnoreCase(code) && answer != null
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        payWays.add(description);
                    } else if (ProposalConstants.QMAY03205.equalsIgnoreCase(code) && answer != null
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        payWays.add(description);
                    }
                    if (ProposalConstants.QMAY03206.equalsIgnoreCase(code) && answer != null) {
                        howToPay = "None";
                    }
                    if (ProposalConstants.QMAY0320601.equalsIgnoreCase(code) && answer != null) {
                        otherPayWay = questionnaireDetails.getAnswer().getValue();
                    } else if (ProposalConstants.QMAY033.equalsIgnoreCase(code) && answer != null) { // Beneficial Owners
                        isBeneficialOwners = answer.toUpperCase();
                    } else if (ProposalConstants.QMAY03301.equalsIgnoreCase(code) && answer != null) {
                        boSurName = answer;
                    } else if (ProposalConstants.QMAY03302.equalsIgnoreCase(code) && answer != null) {
                        boGivenName = answer;
                    } else if (ProposalConstants.QMAY03303.equalsIgnoreCase(code) && answer != null) {
                        boNric = answer;
                    } else if (ProposalConstants.QMAY03304.equalsIgnoreCase(code) && answer != null) {
                        boDob = answer;
                    } else if (ProposalConstants.QMAY03305.equalsIgnoreCase(code) && answer != null) {
                        boNationality = answer;
                    } else if (ProposalConstants.QMAY03306.equalsIgnoreCase(code) && answer != null) {
                        boResCountry = answer;
                    } else if (ProposalConstants.QMAY03307.equalsIgnoreCase(code) && answer != null) {
                        boRelationship = answer;
                    }
                }
            }
        }

        // Source of wealth and funds
        map.put(ProposalConstants.KEY_PAYBYYOU, payByYou);
        if (StringUtils.isNotEmpty(payerGivenName) || StringUtils.isNotEmpty(payerSurName)) {
            payerName = payerGivenName + SPACE_STRING + payerSurName;
        }
        map.put(ProposalConstants.KEY_PAYERNAME, payerName);
        map.put(ProposalConstants.KEY_PAYERNRIC, payerNric);
        map.put(ProposalConstants.KEY_PAYERRELATIONSHIP, payerRelationship);

        // Source of wealth derived from

        if (payWays.size() > 0) {
            howToPay = D2CUtils.listToString(payWays, Constants.COMMA_SIGN);
        }
        map.put(ProposalConstants.KEY_HOWTOPAY, howToPay);
        map.put(ProposalConstants.KEY_OTHERPAYWAY, otherPayWay);

        map.put(ProposalConstants.KEY_ISBENEFICIALOWNERS, isBeneficialOwners);
        if (StringUtils.isNotEmpty(boGivenName) || StringUtils.isNotEmpty(boSurName)) {
            boName = boGivenName + SPACE_STRING + boSurName;
        }
        map.put(ProposalConstants.KEY_BONAME, boName);
        map.put(ProposalConstants.KEY_BONRIC, boNric);
        map.put(ProposalConstants.KEY_BODOB, boDob);
        map.put(ProposalConstants.KEY_BONATIONALITY, boNationality);
        map.put(ProposalConstants.KEY_BORESCOUNTRY, boResCountry);
        map.put(ProposalConstants.KEY_BORELATIONSHIP, boRelationship);
    }

    /**
     * Constructs map for Page Four values
     * 
     * @param map
     * @param petData
     * @param mayQuestions
     * @param psQuestions
     */
    private void getPage4Values(Map<String, String> map, ProposalPDFData petData, QuestionnaireDetails[] mayQuestions,
        QuestionnaireDetails[] psQuestions) {

        // PEP Declaration
        String isPEP = NOT_APPLICABLE;
        String pepName = NOT_APPLICABLE;
        String pepSurname = EMPTY_STRING;
        String pepGivenname = EMPTY_STRING;
        String pepNric = NOT_APPLICABLE;
        String pepDob = NOT_APPLICABLE;
        String pepNationality = NOT_APPLICABLE;
        String pepResCountry = NOT_APPLICABLE;
        String pepNature = NOT_APPLICABLE;
        String pepRelationship = NOT_APPLICABLE;

        String isSmoker = NOT_APPLICABLE;
        String smokedYears = NOT_APPLICABLE;
        String cigaretteNumber = NOT_APPLICABLE;
        String adviceReceived = NOT_APPLICABLE;
        String medicalConsulted = NOT_APPLICABLE;

        String financialConsult = NOT_APPLICABLE;

        if (mayQuestions != null) {
            for (QuestionnaireDetails questionnaireDetails : mayQuestions) {
                if (questionnaireDetails.getQuestion() != null && questionnaireDetails.getAnswer() != null) {
                    String code = questionnaireDetails.getQuestion().getCode();
                    String answer = questionnaireDetails.getAnswer().getLabel();
                    if (ProposalConstants.QMAY034.equalsIgnoreCase(code)) {
                        isPEP = answer.toUpperCase();
                    } else if (ProposalConstants.QMAY03401.equalsIgnoreCase(code)) {
                        pepSurname = answer;
                    } else if (ProposalConstants.QMAY03402.equalsIgnoreCase(code)) {
                        pepGivenname = answer;
                    } else if (ProposalConstants.QMAY03403.equalsIgnoreCase(code)) {
                        pepNric = answer;
                    } else if (ProposalConstants.QMAY03404.equalsIgnoreCase(code)) {
                        pepDob = answer;
                    } else if (ProposalConstants.QMAY03405.equalsIgnoreCase(code)) {
                        pepNationality = answer;
                    } else if (ProposalConstants.QMAY03406.equalsIgnoreCase(code)) {
                        pepResCountry = answer;
                    } else if (ProposalConstants.QMAY03407.equalsIgnoreCase(code)) {
                        pepRelationship = answer;
                    } else if (ProposalConstants.QMAY03408.equalsIgnoreCase(code)) {
                        pepNature = answer;
                    }
                }
            }
        }

        if (psQuestions != null) {
            for (QuestionnaireDetails questionnaireDetails : psQuestions) {
                if (questionnaireDetails.getQuestion() != null && questionnaireDetails.getAnswer() != null) {
                    String code = questionnaireDetails.getQuestion().getCode();
                    String answer = questionnaireDetails.getAnswer().getLabel();
                    if (ProposalConstants.QPS005.equalsIgnoreCase(code) && answer != null) {
                        isSmoker = answer.toUpperCase();
                    } else if (ProposalConstants.QPS00501.equalsIgnoreCase(code) && answer != null) {
                        smokedYears = answer.toUpperCase();
                    } else if (ProposalConstants.QPS00502.equalsIgnoreCase(code) && answer != null) {
                        cigaretteNumber = answer.toUpperCase();
                    }
                    if (ProposalConstants.QPS015.equalsIgnoreCase(code) && answer != null) {
                        adviceReceived = answer.toUpperCase();
                    } else if (ProposalConstants.QPS016.equalsIgnoreCase(code) && answer != null) {
                        medicalConsulted = answer.toUpperCase();
                    }
                }
            }
        }

        map.put(ProposalConstants.KEY_ISPEP, isPEP);
        if (StringUtils.isNotEmpty(pepSurname) || StringUtils.isNotEmpty(pepGivenname)) {
            pepName = pepGivenname + SPACE_STRING + pepSurname;
        }
        map.put(ProposalConstants.KEY_PEPNAME, pepName);
        map.put(ProposalConstants.KEY_PEPNRIC, pepNric);
        map.put(ProposalConstants.KEY_PEPDOB, pepDob);
        map.put(ProposalConstants.KEY_PEPNATIONALITY, pepNationality);
        map.put(ProposalConstants.KEY_PEPRESCOUNTRY, pepResCountry);
        map.put(ProposalConstants.KEY_PEPNATURE, pepNature);
        map.put(ProposalConstants.KEY_PEPRELATIONSHIP, pepRelationship);

        // Health and Lifestyle details
        map.put(ProposalConstants.KEY_ADVICERECEIVED, adviceReceived);
        map.put(ProposalConstants.KEY_MEDICALCONSULTED, medicalConsulted);
        map.put(ProposalConstants.KEY_ISSMOKER, isSmoker);
        map.put(ProposalConstants.KEY_SMOKEDYEARS, smokedYears);
        map.put(ProposalConstants.KEY_CIGARETTENUMBER, cigaretteNumber);

        if (Constants.SHORT_YES.equalsIgnoreCase(petData.getConsultationReq())) {
            financialConsult = STRING_YES;
        } else if (Constants.SHORT_NO.equalsIgnoreCase(petData.getConsultationReq())) {
            financialConsult = STRING_NO;
        }
        map.put(ProposalConstants.KEY_FINANCIALCONSULT, financialConsult);

    }

    /**
     * Constructs map for Page Ten values
     * 
     * @param map
     * @param petData
     */
    private void getPage9Values(Map<String, String> map, ProposalPDFData petData) {
        // Consent
        String receiveMarketingInfo = NOT_APPLICABLE;

        if (Constants.SHORT_YES.equalsIgnoreCase(petData.getReceiveMarketing())) {
            receiveMarketingInfo = STRING_YES;
        } else if (Constants.SHORT_NO.equalsIgnoreCase(petData.getReceiveMarketing())) {
            receiveMarketingInfo = STRING_NO;
        }
        map.put(ProposalConstants.KEY_READDECLARATION, STRING_YES);
        map.put(ProposalConstants.KEY_RECEIVEMARKETINGINFO, receiveMarketingInfo);
    }

    private String decrypt(String req) {
        return DecryptionUtil.decryption(req, configProperties);
    }

}
