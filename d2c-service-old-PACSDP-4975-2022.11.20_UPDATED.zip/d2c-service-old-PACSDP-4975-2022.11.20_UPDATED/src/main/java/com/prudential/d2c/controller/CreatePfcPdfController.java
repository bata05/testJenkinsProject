package com.prudential.d2c.controller;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.text.StrSubstitutor;
import org.apache.commons.lang.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.itextpdf.text.Document;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfCopy;
import com.itextpdf.text.pdf.PdfReader;
import com.prudential.d2c.common.Constants;
import com.prudential.d2c.common.ProposalConstants;
import com.prudential.d2c.entity.ProposalPDFData;
import com.prudential.d2c.entity.QuestionnaireDetails;
import com.prudential.d2c.entity.SuccessStatus;
import com.prudential.d2c.entity.dto.ApplicationData;
import com.prudential.d2c.entity.dto.CustomerApplication;
import com.prudential.d2c.exception.D2CException;
import com.prudential.d2c.repository.ApplicationDataRepository;
import com.prudential.d2c.service.CustomerApplicationService;
import com.prudential.d2c.service.PdfService;
import com.prudential.d2c.utils.AddressFormatter;
import com.prudential.d2c.utils.D2CUtils;
import com.prudential.d2c.utils.DecryptionUtil;
import com.prudential.d2c.utils.StaticFileUtil;
import static com.prudential.d2c.common.Constants.NOT_APPLICABLE;
import static com.prudential.d2c.common.Constants.EMPTY_STRING;
import static com.prudential.d2c.common.Constants.STRING_YES;
import static com.prudential.d2c.common.Constants.STRING_NO;
import static com.prudential.d2c.common.Constants.AMOUNT_ZERO;
import static com.prudential.d2c.common.Constants.DOLLAR_WITH_SPACE;
import static com.prudential.d2c.common.Constants.SPACE_STRING;
import static com.prudential.d2c.common.Constants.COMMA_SIGN;

@RestController
@EnableAutoConfiguration
public class CreatePfcPdfController extends BaseController {
    // Define the logger object for this class
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private static final String PFC_TEMPLATE_LOCATION = "pfc/tplPg";
    private static final int NO_OF_PAGES = 11;

    @Autowired
    private ApplicationDataRepository applicationDataRepository;

    @Autowired
    private CustomerApplicationService customerApplicationService;

    @Autowired
    private PdfService pdfService;

    @RequestMapping(
        value = "/createPfc",
        method = RequestMethod.POST,
        consumes = MediaType.APPLICATION_JSON_VALUE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    public Object submit(@RequestBody ProposalPDFData pfcData) {
        StopWatch sw = new StopWatch();
        sw.start();
        logger.warn("Reading pfcData Json file for eref: {}", D2CUtils.removeCRLF(pfcData.getErefCode()));


        logger.debug("pfcData : {} ", StaticFileUtil.convertObjectToJsonFormat(pfcData));
        

        byte[] contents = createPDF(pfcData);

        // save to database
        ApplicationData appData = new ApplicationData();
        appData.setErefNo(pfcData.getErefCode());
        appData.setCustomId(pfcData.getCustomId());
        Blob blob;
        try {
            blob = new javax.sql.rowset.serial.SerialBlob(contents);
        } catch (SQLException e) {
            logger.error("Create Pdf submit error", e);
            throw new D2CException("Create Pdf submit error");
        }
        appData.setProposal(blob);
        applicationDataRepository.save(appData);

        sw.stop();
        logger.warn("createPfcPDF cost time : {}; pfcData: {}", sw.getTime(), D2CUtils.removeCRLF(pfcData.getErefCode()));
        return new SuccessStatus();
    }

    private byte[] createPDF(ProposalPDFData pfcData) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try {
            baos = createPdfBytes(pfcData);
            return baos.toByteArray();
        } catch (Exception e) {
            logger.error("Unable to load data for customID: " + D2CUtils.removeCRLF(pfcData.getCustomId()), e);
            throw new D2CException("Create Pdf bytes error");
        }

    }

    /**
     * Creates PDF
     * 
     * @param pfcData
     * @return
     */
    private ByteArrayOutputStream createPdfBytes(ProposalPDFData pfcData) {
        CustomerApplication customerAppData = new CustomerApplication();

        try {
            customerAppData = customerApplicationService.findCustomerApplicationByCustomId(pfcData.getCustomId());
        } catch (Exception e) {
            logger.error("FindCustomerApplicationByCustomId", e);
            throw new D2CException("Find customer error");
        }

        Document document = new Document(PageSize.A4); // A4 size
        document.setMargins(29, 29, 29, 29);
        document.addTitle("PRUflexicash Summary");

        ByteArrayOutputStream bos = new ByteArrayOutputStream();

        try {
            PdfCopy copy = new PdfCopy(document, bos);
            document.open();
            PdfReader reader;

            for (int i = 1; i <= NO_OF_PAGES; i++) {
                DecimalFormat formatter = new DecimalFormat("00");
                String pageNumber = formatter.format(i);

                InputStream is = StaticFileUtil.generatePdfInputStream(PFC_TEMPLATE_LOCATION + pageNumber + Constants.SUFFIX_HTML);
                String fileContent = IOUtils.toString(is, Constants.ENCODING_UTF8);
                String resolvedString = replaceVarInTemplate(fileContent, i, pfcData, customerAppData);

                reader = new PdfReader(pdfService.parseHtml(resolvedString));
                copy.addDocument(reader);
                reader.close();
                is.close();
            }
        } catch (Exception e) {
            logger.error("Create Pdf Bytes error");
            throw new D2CException("Create Pdf Bytes error");
        } finally {
            document.close();
        }

        return bos;
    }

    /**
     * Replace variables with actual values
     * 
     * @param content
     * @param pageIndex
     * @param pfcData
     * @param customerAppData
     * @return
     */
    private String replaceVarInTemplate(String content, int pageIndex, ProposalPDFData pfcData,
        CustomerApplication customerAppData) {
        QuestionnaireDetails[] mayQuestions = null;
        QuestionnaireDetails[] psQuestions = null;

        try {
            if (customerAppData != null) {
                mayQuestions = pdfService.extractQuestionnaire(customerAppData.getQmayQuestionnaires());
                psQuestions = pdfService.extractQuestionnaire(customerAppData.getQpsQuestionnaires());
            }
        } catch (Exception e) {
            logger.error("Error while executing replaceVarInTemplate", e);
        }

        Map<String, String> valuesMap = new HashMap<>();
        valuesMap.put(ProposalConstants.KEY_EREF, pfcData.getErefCode());
        switch (pageIndex) {
        case 1:
            getPage1Values(valuesMap, pfcData, customerAppData, mayQuestions);
            break;
        case 2:
            getPage2Values(valuesMap, customerAppData, mayQuestions);
            break;
        case 3:
            getPage3Values(valuesMap, mayQuestions);
            break;
        case 4:
            getPage4Values(valuesMap, mayQuestions);
            break;
        case 5:
            getPage5Values(valuesMap, mayQuestions, psQuestions);
            break;
        case 6:
            getPage6Values(valuesMap, psQuestions);
            break;
        case 7:
            getPage7Values(valuesMap, pfcData, psQuestions);
            break;
        case 11:
            getPage11Values(valuesMap, pfcData);
            break;
        default:
            break;
        }
        StrSubstitutor sub = new StrSubstitutor(valuesMap);

        return sub.replace(content);
    }

    /**
     * Map for Page One values
     * 
     * @param map
     * @param customerAppData
     * @param pfcData
     */
    private void getPage1Values(Map<String, String> map, ProposalPDFData pfcData, CustomerApplication customerAppData,
        QuestionnaireDetails[] mayQuestions) {
        try {
            map.put(ProposalConstants.KEY_IMAGE,
                pdfService.getLogoImageData(request.getServletContext(), Constants.LOGO_IMG_NAME));
        } catch (IOException e) {
            logger.error("Error happend while get logo image", e);
            throw new D2CException("Error happend while get logo image", e.getCause());
        }

        String planName;
        String sumAssured;
        String term;
        String yearlyPremium;
        String optForCashBenft;
        String defferedYrs;
        String riders = "Coverage for death and total permanent disability";

        // Plan Details
        planName = pfcData.getBasicPlanDetails().getPlanName();
        sumAssured = DOLLAR_WITH_SPACE + pfcData.getBasicPlanDetails().getSumAssured();
        term = pfcData.getBasicPlanDetails().getTerm();
        yearlyPremium = DOLLAR_WITH_SPACE + pfcData.getTotalPremium();
        optForCashBenft = pfcData.getBasicPlanDetails().getBenefit();
        if ("In Cash".equalsIgnoreCase(optForCashBenft) || "Accumulate".equalsIgnoreCase(optForCashBenft)) {
            defferedYrs = NOT_APPLICABLE;
        } else {
            defferedYrs = pfcData.getBasicPlanDetails().getDifferedYear();
        }
        map.put(ProposalConstants.KEY_PLANNAME, planName);
        map.put(ProposalConstants.KEY_SUMASSURED, sumAssured);
        map.put(ProposalConstants.KEY_TERM, term);
        map.put(ProposalConstants.KEY_YEARLYPREMIUM, yearlyPremium);
        map.put(ProposalConstants.KEY_OPTFORCASHBENFT, optForCashBenft);
        map.put(ProposalConstants.KEY_DEFFEREDYRS, defferedYrs);
        map.put(ProposalConstants.KEY_RIDERS, riders);

        // Personal Details
        String agencyNo;
        String businessSource;

        String fullName = NOT_APPLICABLE;
        String gender = NOT_APPLICABLE;
        String dob = NOT_APPLICABLE;
        String nric = NOT_APPLICABLE;
        String currResStatus = NOT_APPLICABLE;
        String nationality = NOT_APPLICABLE;
        String countryOfBirth = "Non US";
        String heightCm = NOT_APPLICABLE;
        String weightKg = NOT_APPLICABLE;
        String highestEdu = NOT_APPLICABLE;

        // Contact Details
        String mobileNumber = NOT_APPLICABLE;
        String email = NOT_APPLICABLE;
        String resAddr = NOT_APPLICABLE;
        String mailingAddr = NOT_APPLICABLE;
        String addressChangeContent = "My residential address has not changed since (MM/YYYY).";
        String addressChangeAnswer = Constants.NOT_APPLICABLE;

        agencyNo = assignedAgentService.getSaleCompletionAgentCode(pfcData.getCustomId());

        businessSource = pfcData.getBankCode();

        if (customerAppData != null) {
            if (customerAppData.getGivenName() != null) {
                fullName = decrypt(customerAppData.getGivenName()) + SPACE_STRING
                    + decrypt(customerAppData.getSurName());
            } else {
                fullName = decrypt(customerAppData.getSurName());
            }
            fullName = StringEscapeUtils.escapeHtml(fullName);
            gender = customerAppData.getGender();
            dob = customerAppData.getDob();
            nric = decrypt(customerAppData.getNricFin());
            nationality = customerApplicationService.findNationalityName(customerAppData.getNationality());
            heightCm = customerAppData.getHeight();
            weightKg = customerAppData.getWeight();

            if (Constants.RESIDENCY_SC_AB.equalsIgnoreCase(customerAppData.getResidencyStatus())) {
                currResStatus = Constants.RESIDENCY_SC_FULL;
            } else if (Constants.RESIDENCY_SPR_AB.equals(customerAppData.getResidencyStatus())) {
                currResStatus = Constants.RESIDENCY_SPR_FULL;
            } else if (Constants.RESIDENCY_OTHER_AB.equals(customerAppData.getResidencyStatus())) {
                currResStatus = Constants.RESIDENCY_OTHER_FULL;
            }

            mobileNumber = decrypt(customerAppData.getMobilePhone());
            email = decrypt(customerAppData.getCustomerEmail());
            resAddr = AddressFormatter.formatResAddr(customerAppData, configProperties);
            mailingAddr = AddressFormatter.formatMailingAddr(customerAppData, configProperties);
        }

        if (mayQuestions != null) {
            for (QuestionnaireDetails questionnaireDetails : mayQuestions) {
                if (questionnaireDetails.getQuestion() != null && questionnaireDetails.getAnswer() != null) {
                    String code = questionnaireDetails.getQuestion().getCode();
                    String description = questionnaireDetails.getQuestion().getDescription();
                    String answer = questionnaireDetails.getAnswer().getLabel();
                    if (ProposalConstants.QMAY018.equalsIgnoreCase(code) && answer != null) {
                        highestEdu = answer;
                    }
                    if (ProposalConstants.QMAY001.equalsIgnoreCase(code) && answer != null) {
                        if (STRING_YES.equalsIgnoreCase(answer)) {
                            countryOfBirth = Constants.COUNTRY_OF_BIRTH_US;
                        } else {
                            countryOfBirth = Constants.COUNTRY_OF_BIRTH_NON_US;
                        }

                    }
                    if (ProposalConstants.QMAY010.equalsIgnoreCase(code) && answer != null) {
                        addressChangeContent = description;
                        addressChangeAnswer = answer;

                    }
                }
            }

        }

        map.put(ProposalConstants.KEY_AGENTCODE, agencyNo);
        map.put(ProposalConstants.KEY_BUSINESSSOURCE, businessSource);

        map.put(ProposalConstants.KEY_FULLNAME, fullName);
        map.put(ProposalConstants.KEY_GENDER, gender);
        map.put(ProposalConstants.KEY_DOB, dob);
        map.put(ProposalConstants.KEY_NRIC, nric);
        map.put(ProposalConstants.KEY_CURRRESSTATUS, currResStatus);
        map.put(ProposalConstants.KEY_NATIONALITY, nationality);
        map.put(ProposalConstants.KEY_COUNTRYOFBIRTH, countryOfBirth);
        map.put(ProposalConstants.KEY_HEIGHTCM, heightCm);
        map.put(ProposalConstants.KEY_WEIGHTKG, weightKg);
        map.put(ProposalConstants.KEY_HIGHESTEDU, highestEdu);

        map.put(ProposalConstants.KEY_MOBILENUMBER, mobileNumber);
        map.put(ProposalConstants.KEY_EMAIL, email);
        map.put(ProposalConstants.KEY_RESADDR, resAddr);
        map.put(ProposalConstants.KEY_MAILINGADDR, mailingAddr);

        map.put(ProposalConstants.KEY_ADDRESSCHANGECONTENT, addressChangeContent);
        map.put(ProposalConstants.KEY_ADDRESSCHANGEANSWER, addressChangeAnswer);
    }

    /**
     * Map for Page Two values
     * 
     * @param map
     * @param customerAppData
     *
     */
    private void getPage2Values(Map<String, String> map, CustomerApplication customerAppData,
        QuestionnaireDetails[] mayQuestions) {
        String occupationClass = NOT_APPLICABLE;
        String occupationDescription = EMPTY_STRING;
        String annualIncome = AMOUNT_ZERO;
        String highestEdu = NOT_APPLICABLE;
        String industry = NOT_APPLICABLE;
        String employerName = NOT_APPLICABLE;
        String designation = NOT_APPLICABLE;

        String singaporeCitizen = NOT_APPLICABLE;
        String singaporePermRes = NOT_APPLICABLE;
        String shortTermPass = NOT_APPLICABLE;

        // Previous Insurance Details
        String isReplacePolicy = NOT_APPLICABLE;
        String over5MioPolicy = NOT_APPLICABLE;
        String lastInsurDate = NOT_APPLICABLE;
        String totalValue = NOT_APPLICABLE;

        if (customerAppData != null) {
            annualIncome = Constants.DOLLAR_WITH_SPACE + customerAppData.getAnnualIncome();
        }

        if (mayQuestions != null) {
            for (QuestionnaireDetails questionnaireDetails : mayQuestions) {
                if (questionnaireDetails.getQuestion() != null && questionnaireDetails.getAnswer() != null) {
                    String code = questionnaireDetails.getQuestion().getCode();
                    String answer = questionnaireDetails.getAnswer().getLabel();
                    String description = questionnaireDetails.getQuestion().getDescription();
                    if (ProposalConstants.QMAY018.equalsIgnoreCase(code) && answer != null) {
                        highestEdu = answer;
                    }
                    if (ProposalConstants.QMAY01901.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        occupationClass = description;
                        occupationDescription = questionnaireDetails.getQuestion().getDetails();
                    } else if (ProposalConstants.QMAY01902.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        occupationClass = description;
                        occupationDescription = questionnaireDetails.getQuestion().getDetails();
                    } else if (ProposalConstants.QMAY01903.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        occupationClass = description;
                        occupationDescription = questionnaireDetails.getQuestion().getDetails();
                    } else if (ProposalConstants.QMAY01904.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        occupationClass = description;
                        occupationDescription = questionnaireDetails.getQuestion().getDetails();
                    }
                    if (ProposalConstants.QMAY02101.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        industry = description;
                    }
                    if (ProposalConstants.QMAY0210101.equalsIgnoreCase(code) && answer != null) {
                        employerName = answer;
                    }
                    if (ProposalConstants.QMAY0210103.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210104.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210105.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210106.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    }
                    if (ProposalConstants.QMAY02102.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        industry = description;
                    }

                    if (ProposalConstants.QMAY0210201.equalsIgnoreCase(code) && answer != null) {
                        employerName = answer;
                    }
                    if (ProposalConstants.QMAY0210203.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210204.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210205.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210206.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    }

                    if (ProposalConstants.QMAY02103.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        industry = description;
                    }
                    if (ProposalConstants.QMAY0210301.equalsIgnoreCase(code) && answer != null) {
                        employerName = answer;
                    }
                    if (ProposalConstants.QMAY0210303.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210304.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210305.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210306.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    }

                    if (ProposalConstants.QMAY02104.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        industry = description;
                    }
                    if (ProposalConstants.QMAY0210401.equalsIgnoreCase(code) && answer != null) {
                        employerName = answer;
                    }
                    if (ProposalConstants.QMAY0210403.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210404.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210405.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210406.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    }

                    if (ProposalConstants.QMAY02105.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        industry = description;
                    }
                    if (ProposalConstants.QMAY0210501.equalsIgnoreCase(code) && answer != null) {
                        employerName = answer;
                    }
                    if (ProposalConstants.QMAY0210503.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210504.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210505.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210506.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    }

                    if (ProposalConstants.QMAY02106.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        industry = description;
                    }
                    if (ProposalConstants.QMAY0210601.equalsIgnoreCase(code) && answer != null) {
                        employerName = answer;
                    }
                    if (ProposalConstants.QMAY0210603.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210604.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210605.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210606.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    }

                    if (ProposalConstants.QMAY02107.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        industry = description;
                    }
                    if (ProposalConstants.QMAY0210701.equalsIgnoreCase(code) && answer != null) {
                        employerName = answer;
                    }
                    if (ProposalConstants.QMAY0210703.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210704.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210705.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210706.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    }

                    if (ProposalConstants.QMAY02108.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        industry = description;
                    }
                    if (ProposalConstants.QMAY0210801.equalsIgnoreCase(code) && answer != null) {
                        employerName = answer;
                    }
                    if (ProposalConstants.QMAY0210803.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210804.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210805.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210806.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    }

                    if (ProposalConstants.QMAY02109.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        industry = description;
                    }
                    if (ProposalConstants.QMAY0210901.equalsIgnoreCase(code) && answer != null) {
                        employerName = answer;
                    }
                    if (ProposalConstants.QMAY0210903.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210904.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210905.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210906.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    }
                    if (ProposalConstants.QMAY02110.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        industry = "None";
                    }
                    if (ProposalConstants.QMAY003A.equalsIgnoreCase(code) && answer != null) {
                        singaporeCitizen = answer.toUpperCase();
                    }
                    if (ProposalConstants.QMAY003B.equalsIgnoreCase(code) && answer != null) {
                        singaporePermRes = answer.toUpperCase();
                    }
                    if (ProposalConstants.QMAY003C.equalsIgnoreCase(code) && answer != null) {
                        shortTermPass = answer.toUpperCase();
                    }

                    if (ProposalConstants.QMAY026.equalsIgnoreCase(code) && answer != null) {
                        isReplacePolicy = answer.toUpperCase();
                    }
                    if (ProposalConstants.QMAY027.equalsIgnoreCase(code) && answer != null) {
                        over5MioPolicy = answer.toUpperCase();
                    }
                    if (ProposalConstants.QMAY02701.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        lastInsurDate = description;
                    } else if (ProposalConstants.QMAY02702.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        lastInsurDate = description;
                    } else if (ProposalConstants.QMAY02703.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        lastInsurDate = description;
                    }
                    if (ProposalConstants.QMAY02705.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        totalValue = description;
                    } else if (ProposalConstants.QMAY02706.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        totalValue = description;
                    } else if (ProposalConstants.QMAY02707.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        totalValue = description;
                    } else if (ProposalConstants.QMAY02708.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        totalValue = description;
                    } else if (ProposalConstants.QMAY02709.equalsIgnoreCase(code)
                        && !STRING_NO.equalsIgnoreCase(answer)) {
                        totalValue = answer.split(Constants.HYPHEN)[1];
                    }
                }
            }
        }

        map.put(ProposalConstants.KEY_OCCUPATIONCLASS, occupationClass);
        map.put(ProposalConstants.KEY_OCCUPATIONDESCRIPTION, occupationDescription);
        map.put(ProposalConstants.KEY_ANNUALINCOME, annualIncome);
        map.put(ProposalConstants.KEY_HIGHESTEDU, highestEdu);
        map.put(ProposalConstants.KEY_INDUSTRY, industry);
        map.put(ProposalConstants.KEY_EMPLOYERNAME, employerName);
        map.put(ProposalConstants.KEY_DESIGNATION, designation);

        map.put(ProposalConstants.KEY_SINGAPORECITIZEN, singaporeCitizen);
        map.put(ProposalConstants.KEY_SINGAPOREPERMRES, singaporePermRes);
        map.put(ProposalConstants.KEY_SHORTTERMPASS, shortTermPass);

        // Previous Insurance Details
        map.put(ProposalConstants.KEY_ISREPLACEPOLICY, isReplacePolicy);
        map.put(ProposalConstants.KEY_OVER5MIOPOLICY, over5MioPolicy);
        map.put(ProposalConstants.KEY_LASTINSURDATE, lastInsurDate);
        map.put(ProposalConstants.KEY_TOTALVALUE, totalValue);
    }

    /**
     * Map for Page Three values
     * 
     * @param map
     * @param mayQuestions
     */
    private void getPage3Values(Map<String, String> map, QuestionnaireDetails[] mayQuestions) {
        String fileTaxInUS = NOT_APPLICABLE;
        String taxResidentOfSing = NOT_APPLICABLE;

        String defaultTin = EMPTY_STRING;
        String country1 = NOT_APPLICABLE;
        String tax1 = NOT_APPLICABLE;
        String reason1 = NOT_APPLICABLE;
        String explanation1 = NOT_APPLICABLE;
        String country2 = NOT_APPLICABLE;
        String tax2 = NOT_APPLICABLE;
        String reason2 = NOT_APPLICABLE;
        String explanation2 = NOT_APPLICABLE;
        String country3 = NOT_APPLICABLE;
        String tax3 = NOT_APPLICABLE;
        String reason3 = NOT_APPLICABLE;
        String explanation3 = NOT_APPLICABLE;

        String taxResidenceReason = NOT_APPLICABLE;

        if (mayQuestions != null) {
            for (QuestionnaireDetails questionnaireDetails : mayQuestions) {
                if (questionnaireDetails.getQuestion() != null && questionnaireDetails.getAnswer() != null) {
                    String code = questionnaireDetails.getQuestion().getCode();
                    String answer = questionnaireDetails.getAnswer().getLabel();
                    String description = questionnaireDetails.getQuestion().getDescription();
                    if (ProposalConstants.QMAY025.equalsIgnoreCase(code) && answer != null) {
                        fileTaxInUS = answer.toUpperCase();
                    }
                    if (ProposalConstants.QMAY023.equalsIgnoreCase(code) && answer != null) {
                        taxResidentOfSing = answer.toUpperCase();
                    }
                    if (ProposalConstants.QMAY023A.equalsIgnoreCase(code) && answer != null) {
                        defaultTin = answer;
                    }
                    if (ProposalConstants.QMAY023021.equalsIgnoreCase(code) && answer != null && !answer.isEmpty()) {
                        country1 = answer;
                    }
                    if (ProposalConstants.QMAY023031.equalsIgnoreCase(code) && answer != null && !answer.isEmpty()) {
                        tax1 = answer;
                    }
                    if (ProposalConstants.QMAY023041.equalsIgnoreCase(code) && answer != null && !answer.isEmpty()) {
                        reason1 = questionnaireDetails.getAnswer().getValue();
                    }
                    if (ProposalConstants.QMAY02304011.equalsIgnoreCase(code) && answer != null && !answer.isEmpty()) {
                        explanation1 = answer;
                    }

                    if (ProposalConstants.QMAY023022.equalsIgnoreCase(code) && answer != null && !answer.isEmpty()) {
                        country2 = answer;
                    }
                    if (ProposalConstants.QMAY023032.equalsIgnoreCase(code) && answer != null && !answer.isEmpty()) {
                        tax2 = answer;
                    }
                    if (ProposalConstants.QMAY023042.equalsIgnoreCase(code) && answer != null && !answer.isEmpty()) {
                        reason2 = questionnaireDetails.getAnswer().getValue();
                    }
                    if (ProposalConstants.QMAY02304012.equalsIgnoreCase(code) && answer != null && !answer.isEmpty()) {
                        explanation2 = answer;
                    }
                    if (ProposalConstants.QMAY023023.equalsIgnoreCase(code) && answer != null && !answer.isEmpty()) {
                        country3 = answer;
                    }
                    if (ProposalConstants.QMAY023033.equalsIgnoreCase(code) && answer != null && !answer.isEmpty()) {
                        tax3 = answer;
                    }
                    if (ProposalConstants.QMAY023043.equalsIgnoreCase(code) && answer != null && !answer.isEmpty()) {
                        reason3 = questionnaireDetails.getAnswer().getValue();
                    }
                    if (ProposalConstants.QMAY02304013.equalsIgnoreCase(code) && answer != null && !answer.isEmpty()) {
                        explanation3 = answer;
                    }

                    if (ProposalConstants.QMAY02401.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        taxResidenceReason = description;
                    }
                    if (ProposalConstants.QMAY02402.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        taxResidenceReason = description;
                    }
                    if (ProposalConstants.QMAY02403.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        taxResidenceReason = description;
                    }
                    if (ProposalConstants.QMAY02404.equalsIgnoreCase(code) && !STRING_NO.equalsIgnoreCase(answer)) {
                        taxResidenceReason = answer.split(Constants.HYPHEN)[1];
                    }
                }
            }
        }

        map.put(ProposalConstants.KEY_FILETAXINUS, fileTaxInUS);
        map.put(ProposalConstants.KEY_TAXRESIDENTOFSING, taxResidentOfSing);

        if (STRING_YES.equalsIgnoreCase(taxResidentOfSing)) {
            country1 = "Singapore";
            tax1 = defaultTin;
        }
        if (!NOT_APPLICABLE.equalsIgnoreCase(country1)) {
            if (NOT_APPLICABLE.equalsIgnoreCase(tax1)) {
                tax1 = EMPTY_STRING;
            }
            if (NOT_APPLICABLE.equalsIgnoreCase(reason1)) {
                reason1 = EMPTY_STRING;
                explanation1 = EMPTY_STRING;
            }
        }
        if (!NOT_APPLICABLE.equalsIgnoreCase(country2)) {
            if (NOT_APPLICABLE.equalsIgnoreCase(tax2)) {
                tax2 = EMPTY_STRING;
            }
            if (NOT_APPLICABLE.equalsIgnoreCase(reason2)) {
                reason2 = EMPTY_STRING;
                explanation2 = EMPTY_STRING;
            }
        }
        if (!NOT_APPLICABLE.equalsIgnoreCase(country3)) {
            if (NOT_APPLICABLE.equalsIgnoreCase(tax3)) {
                tax3 = EMPTY_STRING;
            }
            if (NOT_APPLICABLE.equalsIgnoreCase(reason3)) {
                reason3 = EMPTY_STRING;
                explanation3 = EMPTY_STRING;
            }
        }
        map.put(ProposalConstants.KEY_COUNTRY1, country1);
        map.put(ProposalConstants.KEY_TAX1, tax1);
        map.put(ProposalConstants.KEY_REASON1, reason1);
        map.put(ProposalConstants.KEY_EXPLANATION1, explanation1);
        map.put(ProposalConstants.KEY_COUNTRY2, country2);
        map.put(ProposalConstants.KEY_TAX2, tax2);
        map.put(ProposalConstants.KEY_REASON2, reason2);
        map.put(ProposalConstants.KEY_EXPLANATION2, explanation2);
        map.put(ProposalConstants.KEY_COUNTRY3, country3);
        map.put(ProposalConstants.KEY_TAX3, tax3);
        map.put(ProposalConstants.KEY_REASON3, reason3);
        map.put(ProposalConstants.KEY_EXPLANATION3, explanation3);

        map.put(ProposalConstants.KEY_TAXRESIDENCEREASON, taxResidenceReason);
    }

    /**
     * Map for Page Four values
     * 
     * @param map
     * @param mayQuestions
     */
    private void getPage4Values(Map<String, String> map, QuestionnaireDetails[] mayQuestions) {
        // Source of Wealth and Funds
        String payByYou = NOT_APPLICABLE;
        String payerName = NOT_APPLICABLE;
        String payerGivenName = EMPTY_STRING;
        String payerSurName = EMPTY_STRING;
        String payerNric = NOT_APPLICABLE;
        String payerRelationship = NOT_APPLICABLE;
        String howToPay = NOT_APPLICABLE;
        List<String> payWays = new ArrayList<>();
        String otherPayWay = NOT_APPLICABLE;

        // Beneficial Owners
        String isBeneficialOwners = NOT_APPLICABLE;

        String boName = NOT_APPLICABLE;
        String boGivenName = EMPTY_STRING;
        String boSurName = EMPTY_STRING;
        String boNric = NOT_APPLICABLE;
        String boDob = NOT_APPLICABLE;
        String boNationality = NOT_APPLICABLE;
        String boResCountry = NOT_APPLICABLE;
        String boRelationship = NOT_APPLICABLE;

        if (mayQuestions != null) {
            for (QuestionnaireDetails questionnaireDetails : mayQuestions) {
                if (questionnaireDetails.getQuestion() != null && questionnaireDetails.getAnswer() != null) {
                    String code = questionnaireDetails.getQuestion().getCode();
                    String answer = questionnaireDetails.getAnswer().getLabel();
                    String description = questionnaireDetails.getQuestion().getDescription();
                    if (ProposalConstants.QMAY031.equalsIgnoreCase(code) && answer != null) { // Source of wealth and funds
                        payByYou = answer;
                    } else if (ProposalConstants.QMAY03101.equalsIgnoreCase(code) && answer != null) { // Get details of person who is paying
                                                                                                       // premium
                        payerSurName = answer;
                    } else if (ProposalConstants.QMAY03102.equalsIgnoreCase(code) && answer != null) {
                        payerGivenName = answer;
                    } else if (ProposalConstants.QMAY03103.equalsIgnoreCase(code) && answer != null) {
                        payerNric = answer;
                    } else if (ProposalConstants.QMAY03104.equalsIgnoreCase(code) && answer != null) {
                        payerRelationship = answer;
                    } else if (ProposalConstants.QMAY03201.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        payWays.add(description);
                    } else if (ProposalConstants.QMAY03202.equalsIgnoreCase(code) && answer != null
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        payWays.add(description);
                    } else if (ProposalConstants.QMAY03203.equalsIgnoreCase(code) && answer != null
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        payWays.add(description);
                    } else if (ProposalConstants.QMAY03204.equalsIgnoreCase(code) && answer != null
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        payWays.add(description);
                    } else if (ProposalConstants.QMAY03205.equalsIgnoreCase(code) && answer != null
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        payWays.add(description);
                    }
                    if (ProposalConstants.QMAY03206.equalsIgnoreCase(code) && answer != null) {
                        howToPay = "None";
                    }
                    if (ProposalConstants.QMAY0320601.equalsIgnoreCase(code) && answer != null) {
                        otherPayWay = questionnaireDetails.getAnswer().getValue();
                    } else if (ProposalConstants.QMAY033.equalsIgnoreCase(code) && answer != null) { // Beneficial Owners
                        isBeneficialOwners = answer.toUpperCase();
                    } else if (ProposalConstants.QMAY03301.equalsIgnoreCase(code) && answer != null) {
                        boSurName = answer;
                    } else if (ProposalConstants.QMAY03302.equalsIgnoreCase(code) && answer != null) {
                        boGivenName = answer;
                    } else if (ProposalConstants.QMAY03303.equalsIgnoreCase(code) && answer != null) {
                        boNric = answer;
                    } else if (ProposalConstants.QMAY03304.equalsIgnoreCase(code) && answer != null) {
                        boDob = answer;
                    } else if (ProposalConstants.QMAY03305.equalsIgnoreCase(code) && answer != null) {
                        boNationality = answer;
                    } else if (ProposalConstants.QMAY03306.equalsIgnoreCase(code) && answer != null) {
                        boResCountry = answer;
                    } else if (ProposalConstants.QMAY03307.equalsIgnoreCase(code) && answer != null) {
                        boRelationship = answer;
                    }
                }
            }
        }

        // Source of wealth and funds
        map.put(ProposalConstants.KEY_PAYBYYOU, payByYou);
        if (StringUtils.isNotEmpty(payerGivenName) || StringUtils.isNotEmpty(payerSurName)) {
            payerName = payerGivenName + " " + payerSurName;
        }
        map.put(ProposalConstants.KEY_PAYERNAME, payerName);
        map.put(ProposalConstants.KEY_PAYERNRIC, payerNric);
        map.put(ProposalConstants.KEY_PAYERRELATIONSHIP, payerRelationship);

        // Source of wealth derived from

        if (!payWays.isEmpty()) {
            howToPay = D2CUtils.listToString(payWays, COMMA_SIGN);
        }
        map.put(ProposalConstants.KEY_HOWTOPAY, howToPay);
        map.put(ProposalConstants.KEY_OTHERPAYWAY, otherPayWay);

        map.put(ProposalConstants.KEY_ISBENEFICIALOWNERS, isBeneficialOwners);
        if (StringUtils.isNotEmpty(boGivenName) || StringUtils.isNotEmpty(boSurName)) {
            boName = boGivenName + " " + boSurName;
        }
        map.put(ProposalConstants.KEY_BONAME, boName);
        map.put(ProposalConstants.KEY_BONRIC, boNric);
        map.put(ProposalConstants.KEY_BODOB, boDob);
        map.put(ProposalConstants.KEY_BONATIONALITY, boNationality);
        map.put(ProposalConstants.KEY_BORESCOUNTRY, boResCountry);
        map.put(ProposalConstants.KEY_BORELATIONSHIP, boRelationship);
    }

    /**
     * Map for Page Five values
     * 
     * @param map
     * @param mayQuestions
     * @param psQuestions
     */
    private void getPage5Values(Map<String, String> map, QuestionnaireDetails[] mayQuestions,
        QuestionnaireDetails[] psQuestions) {
        String isPEP = NOT_APPLICABLE;
        String pepName = NOT_APPLICABLE;
        String pepSurname = EMPTY_STRING;
        String pepGivenname = EMPTY_STRING;
        String pepNric = NOT_APPLICABLE;
        String pepDob = NOT_APPLICABLE;
        String pepNationality = NOT_APPLICABLE;
        String pepResCountry = NOT_APPLICABLE;
        String pepNature = NOT_APPLICABLE;
        String pepRelationship = NOT_APPLICABLE;

        String traveledAbroad = NOT_APPLICABLE;
        String travelPlace1 = NOT_APPLICABLE;
        String travelDuration1 = NOT_APPLICABLE;
        String travelPurpose1 = NOT_APPLICABLE;
        String travelPurposeOther1 = EMPTY_STRING;
        String travelPlace2 = NOT_APPLICABLE;
        String travelDuration2 = NOT_APPLICABLE;
        String travelPurpose2 = NOT_APPLICABLE;
        String travelPurposeOther2 = EMPTY_STRING;
        String travelPlace3 = NOT_APPLICABLE;
        String travelDuration3 = NOT_APPLICABLE;
        String travelPurpose3 = NOT_APPLICABLE;
        String travelPurposeOther3 = EMPTY_STRING;

        List<String> engageInPursuits = new ArrayList<>();

        String isSmoker = STRING_NO;
        String smokedYears = NOT_APPLICABLE;
        String cigaretteNumber = NOT_APPLICABLE;
        String consumeAlcohol = STRING_NO;
        String alcoholType = NOT_APPLICABLE;
        String weeklyQuantity = NOT_APPLICABLE;
        List<String> treatAddiction = new ArrayList<>();

        if (mayQuestions != null) {
            for (QuestionnaireDetails questionnaireDetails : mayQuestions) {
                if (questionnaireDetails.getQuestion() != null && questionnaireDetails.getAnswer() != null) {
                    String code = questionnaireDetails.getQuestion().getCode();
                    String answer = questionnaireDetails.getAnswer().getLabel();
                    if (ProposalConstants.QMAY034.equalsIgnoreCase(code)) {
                        isPEP = answer.toUpperCase();
                    } else if (ProposalConstants.QMAY03401.equalsIgnoreCase(code)) {
                        pepSurname = answer;
                    } else if (ProposalConstants.QMAY03402.equalsIgnoreCase(code)) {
                        pepGivenname = answer;
                    } else if (ProposalConstants.QMAY03403.equalsIgnoreCase(code)) {
                        pepNric = answer;
                    } else if (ProposalConstants.QMAY03404.equalsIgnoreCase(code)) {
                        pepDob = answer;
                    } else if (ProposalConstants.QMAY03405.equalsIgnoreCase(code)) {
                        pepNationality = answer;
                    } else if (ProposalConstants.QMAY03406.equalsIgnoreCase(code)) {
                        pepResCountry = answer;
                    } else if (ProposalConstants.QMAY03407.equalsIgnoreCase(code)) {
                        pepRelationship = answer;
                    } else if (ProposalConstants.QMAY03408.equalsIgnoreCase(code)) {
                        pepNature = answer;
                    }
                }
            }
        }

        if (psQuestions != null) {
            for (QuestionnaireDetails questionnaireDetails : psQuestions) {
                if (questionnaireDetails.getQuestion() != null && questionnaireDetails.getAnswer() != null) {
                    String code = questionnaireDetails.getQuestion().getCode();
                    String answer = questionnaireDetails.getAnswer().getLabel();
                    String description = questionnaireDetails.getQuestion().getDescription();

                    if (ProposalConstants.QPS005.equalsIgnoreCase(code) && answer != null) {
                        isSmoker = answer.toUpperCase();
                    } else if (ProposalConstants.QPS00501.equalsIgnoreCase(code) && answer != null) {
                        smokedYears = answer.toUpperCase();
                    } else if (ProposalConstants.QPS00502.equalsIgnoreCase(code) && answer != null) {
                        cigaretteNumber = answer.toUpperCase();
                    }
                    if (ProposalConstants.QPS006.equalsIgnoreCase(code) && answer != null) {
                        consumeAlcohol = answer.toUpperCase();
                    }
                    if (ProposalConstants.QPS00601.equalsIgnoreCase(code) && answer != null) {
                        alcoholType = answer;
                    }
                    if (ProposalConstants.QPS00602.equalsIgnoreCase(code) && answer != null) {
                        weeklyQuantity = answer;
                    }
                    if (ProposalConstants.QPS00701.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        treatAddiction.add(answer);
                    }
                    if (ProposalConstants.QPS00702.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        treatAddiction.add(answer);
                    }
                    if (ProposalConstants.QPS00703.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        treatAddiction.clear();
                        treatAddiction.add(STRING_NO);
                    }

                    if (ProposalConstants.QPS003.equalsIgnoreCase(code) && answer != null) {
                        traveledAbroad = answer.toUpperCase();
                    }
                    if (ProposalConstants.QPS003011.equalsIgnoreCase(code) && answer != null && !answer.isEmpty()) {
                        travelPlace1 = answer;
                    }
                    if (ProposalConstants.QPS003021.equalsIgnoreCase(code) && answer != null && !answer.isEmpty()) {
                        travelDuration1 = answer;
                    }
                    if (ProposalConstants.QPS003031.equalsIgnoreCase(code) && answer != null && !answer.isEmpty()) {
                        travelPurpose1 = answer;
                    }
                    if (ProposalConstants.QPS00303011.equalsIgnoreCase(code) && answer != null && !answer.isEmpty()) {
                        travelPurposeOther1 = answer;
                    }
                    if (ProposalConstants.QPS003012.equalsIgnoreCase(code) && answer != null && !answer.isEmpty()) {
                        travelPlace2 = answer;
                    }
                    if (ProposalConstants.QPS003022.equalsIgnoreCase(code) && answer != null && !answer.isEmpty()) {
                        travelDuration2 = answer;
                    }
                    if (ProposalConstants.QPS003032.equalsIgnoreCase(code) && answer != null && !answer.isEmpty()) {
                        travelPurpose2 = answer;
                    }
                    if (ProposalConstants.QPS00303012.equalsIgnoreCase(code) && answer != null && !answer.isEmpty()) {
                        travelPurposeOther2 = answer;
                    }
                    if (ProposalConstants.QPS003013.equalsIgnoreCase(code) && answer != null && !answer.isEmpty()) {
                        travelPlace3 = answer;
                    }
                    if (ProposalConstants.QPS003023.equalsIgnoreCase(code) && answer != null && !answer.isEmpty()) {
                        travelDuration3 = answer;
                    }
                    if (ProposalConstants.QPS003033.equalsIgnoreCase(code) && answer != null && !answer.isEmpty()) {
                        travelPurpose3 = answer;
                    }
                    if (ProposalConstants.QPS00303013.equalsIgnoreCase(code) && answer != null && !answer.isEmpty()) {
                        travelPurposeOther3 = answer;
                    }
                    if (ProposalConstants.QPS00401.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        engageInPursuits.add(description);
                    }
                    if (ProposalConstants.QPS00402.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        engageInPursuits.add(description);
                    }
                    if (ProposalConstants.QPS00403.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        engageInPursuits.add(description);
                    }
                    if (ProposalConstants.QPS00404.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        engageInPursuits.add(description);
                    }
                    if (ProposalConstants.QPS00405.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        engageInPursuits.add(description);
                    }
                    if (ProposalConstants.QPS00406.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        engageInPursuits.add(description);
                    }
                    if (ProposalConstants.QPS00407.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        engageInPursuits.clear();
                        engageInPursuits.add(STRING_NO);
                    }
                }
            }
        }

        map.put(ProposalConstants.KEY_ISPEP, isPEP);
        if (StringUtils.isNotEmpty(pepSurname) || StringUtils.isNotEmpty(pepGivenname)) {
            pepName = pepGivenname + " " + pepSurname;
        }
        map.put(ProposalConstants.KEY_PEPNAME, pepName);
        map.put(ProposalConstants.KEY_PEPNRIC, pepNric);
        map.put(ProposalConstants.KEY_PEPDOB, pepDob);
        map.put(ProposalConstants.KEY_PEPNATIONALITY, pepNationality);
        map.put(ProposalConstants.KEY_PEPRESCOUNTRY, pepResCountry);
        map.put(ProposalConstants.KEY_PEPNATURE, pepNature);
        map.put(ProposalConstants.KEY_PEPRELATIONSHIP, pepRelationship);

        map.put(ProposalConstants.KEY_TRAVELEDABROAD, traveledAbroad);
        map.put(ProposalConstants.KEY_TRAVELPLACE1, travelPlace1);
        map.put(ProposalConstants.KEY_TRAVELDURATION1, travelDuration1);
        if (StringUtils.isNotEmpty(travelPurposeOther1)) {
            travelPurpose1 = travelPurposeOther1;
        }
        map.put(ProposalConstants.KEY_TRAVELPURPOSE1, travelPurpose1);
        map.put(ProposalConstants.KEY_TRAVELPLACE2, travelPlace2);
        map.put(ProposalConstants.KEY_TRAVELDURATION2, travelDuration2);
        if (StringUtils.isNotEmpty(travelPurposeOther2)) {
            travelPurpose2 = travelPurposeOther2;
        }
        map.put(ProposalConstants.KEY_TRAVELPURPOSE2, travelPurpose2);
        map.put(ProposalConstants.KEY_TRAVELPLACE3, travelPlace3);
        map.put(ProposalConstants.KEY_TRAVELDURATION3, travelDuration3);
        if (StringUtils.isNotEmpty(travelPurposeOther3)) {
            travelPurpose3 = travelPurposeOther3;
        }
        map.put(ProposalConstants.KEY_TRAVELPURPOSE3, travelPurpose3);

        map.put(ProposalConstants.KEY_ENGAGEINPURSUITS, D2CUtils.listToString(engageInPursuits, COMMA_SIGN));

        map.put(ProposalConstants.KEY_ISSMOKER, isSmoker);
        map.put(ProposalConstants.KEY_SMOKEDYEARS, smokedYears);
        map.put(ProposalConstants.KEY_CIGARETTENUMBER, cigaretteNumber);
        map.put(ProposalConstants.KEY_CONSUMEALCOHOL, consumeAlcohol);
        map.put(ProposalConstants.KEY_ALCOHOLTYPE, alcoholType);
        map.put(ProposalConstants.KEY_WEEKLYQUANTITY, weeklyQuantity);
        map.put(ProposalConstants.KEY_TREATADDICTION, D2CUtils.listToString(treatAddiction, COMMA_SIGN));
    }

    /**
     * Map for Page Six values
     * 
     * @param map
     * @param psQuestions
     */
    private void getPage6Values(Map<String, String> map, QuestionnaireDetails[] psQuestions) {
        String answer1301 = NOT_APPLICABLE;
        String answer1302 = NOT_APPLICABLE;
        String doctorName = NOT_APPLICABLE;
        String clinicAddress = NOT_APPLICABLE;
        String yearsKnown = NOT_APPLICABLE;
        String fullyRecovered = NOT_APPLICABLE;

        String answer1303A = NOT_APPLICABLE;
        String answer1303B = NOT_APPLICABLE;
        String answer1303C = NOT_APPLICABLE;
        String answer1303D = NOT_APPLICABLE;
        String answer1303E = NOT_APPLICABLE;

        String answer1304 = NOT_APPLICABLE;
        String answer1304A = NOT_APPLICABLE;
        String answer1304B = NOT_APPLICABLE;
        String answer1304C = NOT_APPLICABLE;
        String answer1304D = NOT_APPLICABLE;
        String answer1304E = NOT_APPLICABLE;
        String answer1304F = NOT_APPLICABLE;
        String answer1304G = NOT_APPLICABLE;

        if (psQuestions != null) {
            for (QuestionnaireDetails questionnaireDetails : psQuestions) {
                if (questionnaireDetails.getQuestion() != null && questionnaireDetails.getAnswer() != null) {
                    String code = questionnaireDetails.getQuestion().getCode();
                    String answer = questionnaireDetails.getAnswer().getLabel();
                    if (ProposalConstants.QPS008.equalsIgnoreCase(code) && answer != null) {
                        answer1301 = answer.toUpperCase();
                    }
                    if (ProposalConstants.QPS009.equalsIgnoreCase(code) && answer != null) {
                        answer1302 = answer.toUpperCase();
                    } else if (ProposalConstants.QPS0091.equalsIgnoreCase(code) && answer != null) {
                        doctorName = answer.toUpperCase();
                    } else if (ProposalConstants.QPS0092.equalsIgnoreCase(code) && answer != null) {
                        clinicAddress = answer.toUpperCase();
                    } else if (ProposalConstants.QPS0093.equalsIgnoreCase(code) && answer != null) {
                        yearsKnown = answer;
                    } else if (ProposalConstants.QPS0095.equalsIgnoreCase(code) && answer != null) {
                        fullyRecovered = answer.toUpperCase();
                    }
                    if (ProposalConstants.QPS01001.equalsIgnoreCase(code) && answer != null) {
                        answer1303A = answer.toUpperCase();
                    } else if (ProposalConstants.QPS01002.equalsIgnoreCase(code) && answer != null) {
                        answer1303B = answer.toUpperCase();
                    } else if (ProposalConstants.QPS01003.equalsIgnoreCase(code) && answer != null) {
                        answer1303C = answer.toUpperCase();
                    } else if (ProposalConstants.QPS01004.equalsIgnoreCase(code) && answer != null) {
                        answer1303D = answer.toUpperCase();
                    } else if (ProposalConstants.QPS01005.equalsIgnoreCase(code) && answer != null) {
                        answer1303E = answer.toUpperCase();
                    }
                    if (ProposalConstants.QPS01006.equalsIgnoreCase(code) && answer != null) {
                        answer1303A = STRING_NO;
                        answer1303B = STRING_NO;
                        answer1303C = STRING_NO;
                        answer1303D = STRING_NO;
                        answer1303E = STRING_NO;
                    }

                    if (ProposalConstants.QPS011.equalsIgnoreCase(code) && answer != null) {
                        answer1304 = answer.toUpperCase();
                    } else if (ProposalConstants.QPS01101.equalsIgnoreCase(code) && answer != null) {
                        answer1304A = answer.toUpperCase();
                    } else if (ProposalConstants.QPS01102.equalsIgnoreCase(code) && answer != null) {
                        answer1304B = answer.toUpperCase();
                    } else if (ProposalConstants.QPS01103.equalsIgnoreCase(code) && answer != null) {
                        answer1304C = answer.toUpperCase();
                    } else if (ProposalConstants.QPS01104.equalsIgnoreCase(code) && answer != null) {
                        answer1304D = answer.toUpperCase();
                    } else if (ProposalConstants.QPS01105.equalsIgnoreCase(code) && answer != null) {
                        answer1304E = answer.toUpperCase();
                    } else if (ProposalConstants.QPS01106.equalsIgnoreCase(code) && answer != null) {
                        answer1304F = answer.toUpperCase();
                    } else if (ProposalConstants.QPS01107.equalsIgnoreCase(code) && answer != null) {
                        answer1304G = answer.toUpperCase();
                    }
                    if (ProposalConstants.QPS01110.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        answer1304A = STRING_NO;
                        answer1304B = STRING_NO;
                        answer1304C = STRING_NO;
                        answer1304D = STRING_NO;
                        answer1304E = STRING_NO;
                        answer1304F = STRING_NO;
                        answer1304G = STRING_NO;
                    }
                }
            }
        }

        map.put(ProposalConstants.KEY_ANSWER1301, answer1301);
        map.put(ProposalConstants.KEY_ANSWER1302, answer1302);
        map.put(ProposalConstants.KEY_DOCTORNAME, doctorName);
        map.put(ProposalConstants.KEY_CLINICADDRESS, clinicAddress);
        map.put(ProposalConstants.KEY_YEARSKNOWN, yearsKnown);
        map.put(ProposalConstants.KEY_FULLYRECOVERED, fullyRecovered);

        map.put(ProposalConstants.KEY_ANSWER1303A, answer1303A);
        map.put(ProposalConstants.KEY_ANSWER1303B, answer1303B);
        map.put(ProposalConstants.KEY_ANSWER1303C, answer1303C);
        map.put(ProposalConstants.KEY_ANSWER1303D, answer1303D);
        map.put(ProposalConstants.KEY_ANSWER1303E, answer1303E);

        map.put(ProposalConstants.KEY_ANSWER1304, answer1304);
        map.put(ProposalConstants.KEY_ANSWER1304A, answer1304A);
        map.put(ProposalConstants.KEY_ANSWER1304B, answer1304B);
        map.put(ProposalConstants.KEY_ANSWER1304C, answer1304C);
        map.put(ProposalConstants.KEY_ANSWER1304D, answer1304D);
        map.put(ProposalConstants.KEY_ANSWER1304E, answer1304E);
        map.put(ProposalConstants.KEY_ANSWER1304F, answer1304F);
        map.put(ProposalConstants.KEY_ANSWER1304G, answer1304G);
    }

    /**
     * Map for Page Seven values
     * 
     * @param map
     * @param pfcData
     * @param psQuestions
     */
    private void getPage7Values(Map<String, String> map, ProposalPDFData pfcData, QuestionnaireDetails[] psQuestions) {
        String answer1304H = NOT_APPLICABLE;
        String answer1304I = NOT_APPLICABLE;
        String answer1305 = NOT_APPLICABLE;
        String answer1306 = NOT_APPLICABLE;

        String financialConsult = NOT_APPLICABLE;

        if (psQuestions != null) {
            for (QuestionnaireDetails questionnaireDetails : psQuestions) {
                if (questionnaireDetails.getQuestion() != null && questionnaireDetails.getAnswer() != null) {
                    String code = questionnaireDetails.getQuestion().getCode();
                    String answer = questionnaireDetails.getAnswer().getLabel();
                    if (ProposalConstants.QPS01108.equalsIgnoreCase(code) && answer != null) {
                        answer1304H = answer.toUpperCase();
                    } else if (ProposalConstants.QPS01109.equalsIgnoreCase(code) && answer != null) {
                        answer1304I = answer.toUpperCase();
                    }
                    if (ProposalConstants.QPS01110.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        answer1304H = STRING_NO;
                        answer1304I = STRING_NO;
                    }
                    if (ProposalConstants.QPS012.equalsIgnoreCase(code) && answer != null) {
                        answer1305 = answer.toUpperCase();
                    }
                    if (ProposalConstants.QPS01301.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        answer1306 = STRING_YES;
                    } else if (ProposalConstants.QPS01302.equalsIgnoreCase(code)
                        && STRING_YES.equalsIgnoreCase(answer)) {
                        answer1306 = STRING_NO;
                    }
                }
            }
        }

        map.put(ProposalConstants.KEY_ANSWER1304H, answer1304H);
        map.put(ProposalConstants.KEY_ANSWER1304I, answer1304I);
        map.put(ProposalConstants.KEY_ANSWER1305, answer1305);
        map.put(ProposalConstants.KEY_ANSWER1306, answer1306);

        if (Constants.SHORT_YES.equalsIgnoreCase(pfcData.getConsultationReq())) {
            financialConsult = STRING_YES;
        } else if (Constants.SHORT_NO.equalsIgnoreCase(pfcData.getConsultationReq())) {
            financialConsult = STRING_NO;
        }
        map.put(ProposalConstants.KEY_FINANCIALCONSULT, financialConsult);
    }

    /**
     * Map for Page Twelve values
     * 
     * @param map
     * @param pfcData
     */
    private void getPage11Values(Map<String, String> map, ProposalPDFData pfcData) {
        String consentConfirm = STRING_YES;
        String receiveMarketingInfo = NOT_APPLICABLE;

        if (Constants.SHORT_YES.equalsIgnoreCase(pfcData.getReceiveMarketing())) {
            receiveMarketingInfo = STRING_YES;
        } else if (Constants.SHORT_NO.equalsIgnoreCase(pfcData.getReceiveMarketing())) {
            receiveMarketingInfo = STRING_NO;
        }

        map.put(ProposalConstants.KEY_CONSENTCONFIRM, consentConfirm);
        map.put(ProposalConstants.KEY_RECEIVEMARKETINGINFO, receiveMarketingInfo);

    }

    private String decrypt(String req) {
        return DecryptionUtil.decryption(req, configProperties);
    }

}
