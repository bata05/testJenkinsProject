package com.prudential.d2c.controller;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import com.prudential.d2c.common.*;
import com.prudential.d2c.entity.Component;
import com.prudential.d2c.entity.*;
import com.prudential.d2c.entity.dto.*;
import com.prudential.d2c.entity.micro.payload.*;
import com.prudential.d2c.exception.*;
import com.prudential.d2c.repository.*;
import com.prudential.d2c.service.*;
import com.prudential.d2c.utils.*;
import org.apache.commons.io.*;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.text.*;
import org.apache.commons.lang.time.*;
import org.slf4j.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;

import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.text.*;
import java.util.*;
import java.util.List;

import static com.prudential.d2c.common.Constants.*;
import static org.apache.commons.lang3.StringUtils.isNumeric;

/**
 * @author rprasad017
 */
@Service
public class CreatePptPdfController implements ProposalPDFGenerator {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private static final String PPT_TEMPLATE_LOCATION = "ppt/tplPg";
    private static final int NO_OF_PAGES = 11;
    private static final String basicPlanName = "PRUprotect term";

    @Autowired
    protected HttpServletRequest request;

    @Autowired
    protected ConfigProperties configProperties;

    @Autowired
    protected AssignedAgentService assignedAgentService;

    @Autowired
    private ApplicationDataRepository applicationDataRepository;

    @Autowired
    private CustomerApplicationService customerApplicationService;

    @Autowired
    private PdfService pdfService;

    public Object submit(ProposalPDFData pptData, ProposalPDFGenerator proposalPDFGenerator) {
        StopWatch sw = new StopWatch();
        sw.start();
        logger.debug("pptData : {} ", StaticFileUtil.convertObjectToJsonFormat(pptData));
        byte[] contents = createPDF(pptData);
        // add footer
        ByteArrayOutputStream out = pdfService.addFooterToPDF(contents,Constants.PRU_FOOTER);
        // save to database
        ApplicationData appData = new ApplicationData();
        appData.setErefNo(pptData.getErefCode());
        appData.setCustomId(pptData.getCustomId());
        Blob blob;
        try {
            blob = new javax.sql.rowset.serial.SerialBlob(out.toByteArray());
            appData.setProposal(blob);
        } catch (SQLException e) {
            logger.error("Create Pdf submit error.", e);
            throw new D2CException("Create Pdf submit error.");
        }
        applicationDataRepository.save(appData);

        sw.stop();
        logger.info("createPptPDF cost time : {}; createPptPDF: {}", sw.getTime(), D2CUtils.removeCRLF(pptData.getErefCode()));
        return new SuccessStatus();
    }
    @Override
    public ProposalPDFData addProductSpecificDetails(ProposalPDFData proposalPDFData, ApplicationCybData appCybData,
                                                     ComputeResponsePayload computeAllResponse, CustomerApplication customerApp) {
        proposalPDFData.getBasicPlanDetails().setPlanName(basicPlanName);
        PlanDetails defaultPlanDetails = proposalPDFData.getDefaultPlanDetails();
        if (defaultPlanDetails == null) {
            defaultPlanDetails = new PlanDetails();
        }

        List<Component> components = computeAllResponse.getSelectedSQSProducts().get(0).getComponents();

        //Default plan details
        for (Component component : components) {
            if ("DAR1".equals(component.getCompoCode())|| "DAB1".equals(component.getCompoCode())|| "DAA1".equals(component.getCompoCode())) {
                defaultPlanDetails.setPlanName(component.getCompoDesc());
                defaultPlanDetails.setPlanType(component.getCompoCode());
                defaultPlanDetails.setTerm(String.valueOf(component.getTerm()));
                defaultPlanDetails.setSumAssured(String.valueOf(component.getSumAssured()));
                defaultPlanDetails.setPremium(String.valueOf(component.getPremium()));
                break;
            }
        }
        proposalPDFData.setDefaultPlanDetails(defaultPlanDetails);

        //Rider details
        PlanDetails riderPlanDetails = proposalPDFData.getRiderPlanDetails();
        if (riderPlanDetails == null) {
            riderPlanDetails = new PlanDetails();
        }
        for (Component component : components) {
            if ("CRT1".equals(component.getCompoCode())) {
                riderPlanDetails.setPlanName(component.getCompoDesc());
                riderPlanDetails.setPlanType(component.getCompoCode());
                riderPlanDetails.setTerm(String.valueOf(component.getTerm()));
                riderPlanDetails.setSumAssured(String.valueOf(component.getSumAssured()));
                riderPlanDetails.setPremium(String.valueOf(component.getPremium()));
                proposalPDFData.setRiderPlanDetails(riderPlanDetails);
                break;
            }
        }


        return proposalPDFData;
    }

    private byte[] createPDF(ProposalPDFData pptData) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try {
            baos = createPdfBytes(pptData);
        } catch (Exception e) {
            logger.error("Unable to load data: ", e);
        }
        return baos.toByteArray();
    }

    private ByteArrayOutputStream createPdfBytes(ProposalPDFData pptData) {
        CustomerApplication customerAppData = new CustomerApplication();
        try {
            customerAppData = customerApplicationService.findCustomerApplicationByCustomId(pptData.getCustomId());
        } catch (Exception e) {
            logger.error("FindCustomerApplicationByCustomId", e);
            throw new D2CException("Find customer error");
        }

        Document document = new Document(PageSize.A4); // A4 size
        document.setMargins(29, 29, 29, 29);
        document.addTitle("PruProtectTerm Summary");

        ByteArrayOutputStream bos = new ByteArrayOutputStream();

        try {
            PdfCopy copy = new PdfCopy(document, bos);

            document.open();
            PdfReader reader;
            for (int i = 1; i <= NO_OF_PAGES; i++) {
                DecimalFormat formatter = new DecimalFormat("00");
                String pageNumber = formatter.format(i);

                InputStream is = StaticFileUtil.generatePdfInputStream(PPT_TEMPLATE_LOCATION + pageNumber + Constants.SUFFIX_HTML);
                String fileContent = IOUtils.toString(is, Constants.ENCODING_UTF8);
                String resolvedString = replaceVarInTemplate(fileContent, i, pptData, customerAppData);

                reader = new PdfReader(pdfService.parseHtml(resolvedString));
                copy.addDocument(reader);
                reader.close();
                is.close();
            }
        } catch (Exception e) {
            logger.error("Error occured when creating pdf", e);
            throw new D2CException("Error occured when creating pdf", e.getCause());
        } finally {
            document.close();

        }

        return bos;
    }

    /**
     * Replace variables with actual values
     *
     * @param content
     * @param pageIndex
     * @param pptData
     * @param customerAppData
     * @return
     */
    public String replaceVarInTemplate(String content, int pageIndex, ProposalPDFData pptData,
                                        CustomerApplication customerAppData) {
        QuestionnaireDetails[] mayQuestions = null;
        QuestionnaireDetails[] psQuestions = null;

        try {
            if (customerAppData != null) {
                mayQuestions = pdfService.extractQuestionnaire(customerAppData.getQmayQuestionnaires());
                psQuestions = pdfService.extractQuestionnaire(customerAppData.getQpsQuestionnaires());
            }
        } catch (Exception e) {
            logger.error("Error while executing replaceVarInTemplate", e);
        }

        Map<String, String> valuesMap = new HashMap<>();
        valuesMap.put(ProposalConstants.KEY_EREF, pptData.getErefCode());
        switch (pageIndex) {
            case 1:
                getPage1Values(valuesMap, pptData, customerAppData, mayQuestions);
                break;
            case 2:
                getPage2Values(valuesMap, customerAppData, mayQuestions);
                break;
            case 3:
                getPage3Values(valuesMap, mayQuestions);
                break;
            case 4:
                getPage4Values(valuesMap, mayQuestions, psQuestions);
                break;
            case 5:
                getPage5Values(valuesMap, psQuestions);
                break;
            case 6:
                getPage6Values(valuesMap, pptData, psQuestions);
                break;
            case 11:
                getPage11Values(valuesMap, pptData);
                break;
            default:
                break;
        }
        StrSubstitutor sub = new StrSubstitutor(valuesMap);
        return sub.replace(content);
    }

    /**
     * Constructs Map for Page One values
     *
     * @param map
     * @param pptData
     * @param customerAppData
     * @param mayQuestions
     */
    private void getPage1Values(Map<String, String> map, ProposalPDFData pptData, CustomerApplication customerAppData,
                                QuestionnaireDetails[] mayQuestions) {

        try {
            map.put(ProposalConstants.KEY_IMAGE,
                    pdfService.getLogoImageData(request.getServletContext(), Constants.LOGO_IMG_NAME));
        } catch (IOException e) {
            logger.error("Error happend while get logo image", e);
            throw new D2CException("Error happend while get logo image", e.getCause());
        }

        String basicPlanName = "PRUprotect term";
        String basicSumAssured = NOT_APPLICABLE;
        String basicTerm = NOT_APPLICABLE;
        String basicYearlyPremium = NOT_APPLICABLE;
        String defaultPlanName = "Accelerated Disability";
        String defaultSumAssured = NOT_APPLICABLE;
        String defaultTerm = NOT_APPLICABLE;
        String defaultYearlyPremium = NOT_APPLICABLE;
        String riderPlanName = "Crisis Cover";
        String riderSumAssured = NOT_APPLICABLE;
        String riderTerm = NOT_APPLICABLE;
        String riderYearlyPremium = NOT_APPLICABLE;
        String totalPremium;

        // Plan Details
        if (pptData.getBasicPlanDetails() != null) {
            basicPlanName = pptData.getBasicPlanDetails().getPlanName();
            basicSumAssured = DOLLAR_WITH_SPACE + pptData.getBasicPlanDetails().getSumAssured();
            basicTerm = pptData.getBasicPlanDetails().getTerm();
            basicYearlyPremium = DOLLAR_WITH_SPACE + pptData.getBasicPlanDetails().getPremium();
        }
        if (pptData.getDefaultPlanDetails() != null && Integer.valueOf(pptData.getDefaultPlanDetails().getTerm())>0) {
            defaultPlanName = pptData.getDefaultPlanDetails().getPlanName();
            defaultSumAssured = DOLLAR_WITH_SPACE + pptData.getDefaultPlanDetails().getSumAssured();
            defaultTerm = pptData.getDefaultPlanDetails().getTerm();
            defaultYearlyPremium = DOLLAR_WITH_SPACE + pptData.getDefaultPlanDetails().getPremium();
        }
        if (pptData.getRiderPlanDetails() != null) {
            riderPlanName = pptData.getRiderPlanDetails().getPlanName();
            riderSumAssured = DOLLAR_WITH_SPACE + pptData.getRiderPlanDetails().getSumAssured();
            riderTerm = pptData.getRiderPlanDetails().getTerm();
            riderYearlyPremium = DOLLAR_WITH_SPACE + pptData.getRiderPlanDetails().getPremium();
        }
        totalPremium = DOLLAR_WITH_SPACE + pptData.getTotalPremium();

        String agentCode;
        String businessSource;
        // Personal Details
        String fullName = NOT_APPLICABLE;
        String gender = NOT_APPLICABLE;
        String dob = NOT_APPLICABLE;
        String nric = NOT_APPLICABLE;
        String currResStatus = NOT_APPLICABLE;
        String nationality = NOT_APPLICABLE;
        String countryOfBirth = "Non US";
        String heightCm = NOT_APPLICABLE;
        String weightKg = NOT_APPLICABLE;
        String highestEdu = NOT_APPLICABLE;

        // Contact Details
        String mobileNumber = NOT_APPLICABLE;
        String email = NOT_APPLICABLE;
        String resAddr = NOT_APPLICABLE;
        String mailingAddr = NOT_APPLICABLE;
        String addressChangeContent = "My residential address has not changed since (MM/YYYY).";
        String addressChangeAnswer = NOT_APPLICABLE;

        agentCode = assignedAgentService.getSaleCompletionAgentCode(pptData.getCustomId());
        businessSource = pptData.getBankCode();

        if (customerAppData != null) {
            if (customerAppData.getGivenName() != null) {
                fullName = decrypt(customerAppData.getGivenName()) + SPACE_STRING + decrypt(customerAppData.getSurName());
            } else {
                fullName = decrypt(customerAppData.getSurName());
            }
            fullName = StringEscapeUtils.escapeHtml(fullName);
            gender = customerAppData.getGender();
            dob = customerAppData.getDob();
            nric = decrypt(customerAppData.getNricFin());
            nationality = customerApplicationService.findNationalityName(customerAppData.getNationality());
            heightCm = customerAppData.getHeight();
            weightKg = customerAppData.getWeight();

            if (Constants.RESIDENCY_SC_AB.equalsIgnoreCase(customerAppData.getResidencyStatus())) {
                currResStatus = Constants.RESIDENCY_SC_FULL;
            } else if (Constants.RESIDENCY_SPR_AB.equals(customerAppData.getResidencyStatus())) {
                currResStatus = Constants.RESIDENCY_SPR_FULL;
            } else if (Constants.RESIDENCY_OTHER_AB.equals(customerAppData.getResidencyStatus())) {
                currResStatus = Constants.RESIDENCY_OTHER_FULL;
            }

            mobileNumber = decrypt(customerAppData.getMobilePhone());
            email = decrypt(customerAppData.getCustomerEmail());
            resAddr = AddressFormatter.formatResAddr(customerAppData, configProperties);
            mailingAddr = AddressFormatter.formatMailingAddr(customerAppData, configProperties);
        }
        if (mayQuestions != null) {
            for (QuestionnaireDetails questionnaireDetails : mayQuestions) {
                if (questionnaireDetails.getQuestion() != null && questionnaireDetails.getAnswer() != null) {
                    String code = questionnaireDetails.getQuestion().getCode();
                    String description = questionnaireDetails.getQuestion().getDescription();
                    String answer = questionnaireDetails.getAnswer().getLabel();
                    if (ProposalConstants.QMAY018.equalsIgnoreCase(code) && answer != null) {
                        highestEdu = answer;
                    }
                    if (ProposalConstants.QMAY001.equalsIgnoreCase(code) && answer != null) {
                        if (STRING_YES.equalsIgnoreCase(answer)) {
                            countryOfBirth = Constants.COUNTRY_OF_BIRTH_US;
                        } else {
                            countryOfBirth = Constants.COUNTRY_OF_BIRTH_NON_US;
                        }

                    }
                    if (ProposalConstants.QMAY010.equalsIgnoreCase(code) && answer != null) {
                        addressChangeContent = description;
                        addressChangeAnswer = answer;
                    }
                }
            }

        }

        map.put(ProposalConstants.KEY_AGENTCODE, agentCode);
        map.put(ProposalConstants.KEY_BUSINESSSOURCE, businessSource);

        map.put(ProposalConstants.KEY_BASICPLANNAME, basicPlanName);
        map.put(ProposalConstants.KEY_BASICSUMASSURED, basicSumAssured);
        map.put(ProposalConstants.KEY_BASICTERM, basicTerm);
        map.put(ProposalConstants.KEY_BASICYEARLYPREMIUM, basicYearlyPremium);
        map.put(ProposalConstants.KEY_DEFAULTPLANNAME, defaultPlanName);
        map.put(ProposalConstants.KEY_DEFAULTSUMASSURED, defaultSumAssured);
        map.put(ProposalConstants.KEY_DEFAULTTERM, defaultTerm);
        map.put(ProposalConstants.KEY_DEFAULTYEARLYPREMIUM, defaultYearlyPremium);
        map.put(ProposalConstants.KEY_RIDERPLANNAME, riderPlanName);
        map.put(ProposalConstants.KEY_RIDERSUMASSURED, riderSumAssured);
        map.put(ProposalConstants.KEY_RIDERTERM, riderTerm);
        map.put(ProposalConstants.KEY_RIDERYEARLYPREMIUM, riderYearlyPremium);
        map.put(ProposalConstants.KEY_TOTALPREMIUM, totalPremium);

        map.put(ProposalConstants.KEY_FULLNAME, fullName);
        map.put(ProposalConstants.KEY_GENDER, gender);
        map.put(ProposalConstants.KEY_DOB, dob);
        map.put(ProposalConstants.KEY_NRIC, nric);
        map.put(ProposalConstants.KEY_CURRRESSTATUS, currResStatus);
        map.put(ProposalConstants.KEY_NATIONALITY, nationality);
        map.put(ProposalConstants.KEY_COUNTRYOFBIRTH, countryOfBirth);
        map.put(ProposalConstants.KEY_HEIGHTCM, heightCm);
        map.put(ProposalConstants.KEY_WEIGHTKG, weightKg);
        map.put(ProposalConstants.KEY_HIGHESTEDU, highestEdu);

        map.put(ProposalConstants.KEY_MOBILENUMBER, mobileNumber);
        map.put(ProposalConstants.KEY_EMAIL, email);
        map.put(ProposalConstants.KEY_RESADDR, resAddr);
        map.put(ProposalConstants.KEY_MAILINGADDR, mailingAddr);

        map.put(ProposalConstants.KEY_ADDRESSCHANGECONTENT, addressChangeContent);
        map.put(ProposalConstants.KEY_ADDRESSCHANGEANSWER, addressChangeAnswer);
    }

    /**
     * Constructs Map for Page Two values
     *
     * @param map
     * @param customerAppData
     * @param mayQuestions
     */
    private void getPage2Values(Map<String, String> map, CustomerApplication customerAppData,
                                QuestionnaireDetails[] mayQuestions) {
        // Employment Details
        String occupationClass = NOT_APPLICABLE;
        String occupationDescription = EMPTY_STRING;
        String annualIncome = AMOUNT_ZERO;
        String highestEdu = NOT_APPLICABLE;
        String industry = NOT_APPLICABLE;
        String employerName = NOT_APPLICABLE;
        String designation = NOT_APPLICABLE;

        // Offshore Details
        String singaporeCitizen = NOT_APPLICABLE;
        String singaporePermRes = NOT_APPLICABLE;
        String shortTermPass = NOT_APPLICABLE;

        // Previous Insurance Details
        String isReplacePolicy = NOT_APPLICABLE;
        String over5MioPolicy = NOT_APPLICABLE;
        String lastInsurDate = NOT_APPLICABLE;
        String totalValue = NOT_APPLICABLE;

        if (customerAppData != null) {
            annualIncome = DOLLAR_WITH_SPACE + customerAppData.getAnnualIncome();
        }

        if (mayQuestions != null) {
            for (QuestionnaireDetails questionnaireDetails : mayQuestions) {
                if (questionnaireDetails.getQuestion() != null && questionnaireDetails.getAnswer() != null) {
                    String code = questionnaireDetails.getQuestion().getCode();
                    String answer = questionnaireDetails.getAnswer().getLabel();
                    String description = questionnaireDetails.getQuestion().getDescription();

                    if (ProposalConstants.QMAY018.equalsIgnoreCase(code) && answer != null) {
                        highestEdu = answer;
                    }

                    if (ProposalConstants.QMAY01901.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        occupationClass = description;
                        occupationDescription = questionnaireDetails.getQuestion().getDetails();
                    } else if (ProposalConstants.QMAY01902.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        occupationClass = description;
                        occupationDescription = questionnaireDetails.getQuestion().getDetails();
                    } else if (ProposalConstants.QMAY01903.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        occupationClass = description;
                        occupationDescription = questionnaireDetails.getQuestion().getDetails();
                    } else if (ProposalConstants.QMAY01904.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        occupationClass = description;
                        occupationDescription = questionnaireDetails.getQuestion().getDetails();
                    }

                    if (ProposalConstants.QMAY021.equalsIgnoreCase(code) && answer != null) {
                        String industryCodeSeqStr  = questionnaireDetails.getAnswer().getValue();
                        if(isNumeric(industryCodeSeqStr)){
                            int industryCode = Integer.parseInt(industryCodeSeqStr);
                            industry =  industryCode < 10 ? answer : NOT_APPLICABLE ;
                        }

                    }
                    if (ProposalConstants.QMAY0210101.equalsIgnoreCase(code) && answer != null) {
                        employerName = answer;
                    }

                    if (ProposalConstants.QMAY0210103.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210104.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210105.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210106.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    }

                    if (ProposalConstants.QMAY0210201.equalsIgnoreCase(code) && answer != null) {
                        employerName = answer;
                    }

                    if (ProposalConstants.QMAY0210203.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210204.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210205.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210206.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    }

                    if (ProposalConstants.QMAY0210301.equalsIgnoreCase(code) && answer != null) {
                        employerName = answer;
                    }

                    if (ProposalConstants.QMAY0210303.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210304.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210305.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210306.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    }

                    if (ProposalConstants.QMAY0210401.equalsIgnoreCase(code) && answer != null) {
                        employerName = answer;
                    }
                    if (ProposalConstants.QMAY0210403.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210404.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210405.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210406.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    }

                    if (ProposalConstants.QMAY0210501.equalsIgnoreCase(code) && answer != null) {
                        employerName = answer;
                    }
                    if (ProposalConstants.QMAY0210503.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210504.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210505.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210506.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    }
                    if (ProposalConstants.QMAY0210601.equalsIgnoreCase(code) && answer != null) {
                        employerName = answer;
                    }
                    if (ProposalConstants.QMAY0210603.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210604.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210605.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210606.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    }

                    if (ProposalConstants.QMAY0210701.equalsIgnoreCase(code) && answer != null) {
                        employerName = answer;
                    }
                    if (ProposalConstants.QMAY0210703.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210704.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210705.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210706.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    }


                    if (ProposalConstants.QMAY0210801.equalsIgnoreCase(code) && answer != null) {
                        employerName = answer;
                    }
                    if (ProposalConstants.QMAY0210803.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210804.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210805.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210806.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    }

                    if (ProposalConstants.QMAY0210901.equalsIgnoreCase(code) && answer != null) {
                        employerName = answer;
                    }
                    if (ProposalConstants.QMAY0210903.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210904.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210905.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    } else if (ProposalConstants.QMAY0210906.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        designation = description;
                    }
                    if (ProposalConstants.QMAY003A.equalsIgnoreCase(code) && answer != null) {
                        singaporeCitizen = answer.toUpperCase();
                    }
                    if (ProposalConstants.QMAY003B.equalsIgnoreCase(code) && answer != null) {
                        singaporePermRes = answer.toUpperCase();
                    }
                    if (ProposalConstants.QMAY003C.equalsIgnoreCase(code) && answer != null) {
                        shortTermPass = answer.toUpperCase();
                    }

                    if (ProposalConstants.QMAY026.equalsIgnoreCase(code) && answer != null) {
                        isReplacePolicy = answer.toUpperCase();
                    }
                    if (ProposalConstants.QMAY027.equalsIgnoreCase(code) && answer != null) {
                        over5MioPolicy = answer.toUpperCase();
                    }
                    if (ProposalConstants.QMAY02701.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        lastInsurDate = description;
                    } else if (ProposalConstants.QMAY02702.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        lastInsurDate = description;
                    } else if (ProposalConstants.QMAY02703.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        lastInsurDate = description;
                    }
                    if (ProposalConstants.QMAY02705.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        totalValue = description;
                    } else if (ProposalConstants.QMAY02706.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        totalValue = description;
                    } else if (ProposalConstants.QMAY02707.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        totalValue = description;
                    } else if (ProposalConstants.QMAY02708.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        totalValue = description;
                    } else if (ProposalConstants.QMAY02709.equalsIgnoreCase(code)
                            && !STRING_NO.equalsIgnoreCase(answer)) {
                        totalValue = answer.split(Constants.HYPHEN)[1];
                    }
                }
            }
        }

        map.put(ProposalConstants.KEY_OCCUPATIONCLASS, occupationClass);
        map.put(ProposalConstants.KEY_OCCUPATIONDESCRIPTION, occupationDescription);
        map.put(ProposalConstants.KEY_ANNUALINCOME, annualIncome);
        map.put(ProposalConstants.KEY_HIGHESTEDU, highestEdu);
        map.put(ProposalConstants.KEY_INDUSTRY, industry);
        map.put(ProposalConstants.KEY_EMPLOYERNAME, employerName);
        map.put(ProposalConstants.KEY_DESIGNATION, designation);

        map.put(ProposalConstants.KEY_SINGAPORECITIZEN, singaporeCitizen);
        map.put(ProposalConstants.KEY_SINGAPOREPERMRES, singaporePermRes);
        map.put(ProposalConstants.KEY_SHORTTERMPASS, shortTermPass);

        // Previous Insurance Details
        map.put(ProposalConstants.KEY_ISREPLACEPOLICY, isReplacePolicy);
        map.put(ProposalConstants.KEY_OVER5MIOPOLICY, over5MioPolicy);
        map.put(ProposalConstants.KEY_LASTINSURDATE, lastInsurDate);
        map.put(ProposalConstants.KEY_TOTALVALUE, totalValue);

    }

    /**
     * Constructs Map for Page Three values
     *
     * @param map
     * @param mayQuestions
     */
    private void getPage3Values(Map<String, String> map, QuestionnaireDetails[] mayQuestions) {
        // Source of Wealth and Funds
        String payByYou = NOT_APPLICABLE;
        String payerName = NOT_APPLICABLE;
        String payerGivenName = EMPTY_STRING;
        String payerSurName = EMPTY_STRING;
        String payerNric = NOT_APPLICABLE;
        String payerRelationship = NOT_APPLICABLE;
        
        String howToPay = NOT_APPLICABLE;
        List<String> payWays = new ArrayList<>();
        String otherPayWay = NOT_APPLICABLE;

        // Beneficial Owners
        String isBeneficialOwners = NOT_APPLICABLE;

        String boName = NOT_APPLICABLE;
        String boGivenName = EMPTY_STRING;
        String boSurName = EMPTY_STRING;
        String boNric = NOT_APPLICABLE;
        String boDob = NOT_APPLICABLE;
        String boNationality = NOT_APPLICABLE;
        String boResCountry = NOT_APPLICABLE;
        String boRelationship = NOT_APPLICABLE;

        if (mayQuestions != null) {
            for (QuestionnaireDetails questionnaireDetails : mayQuestions) {
                if (questionnaireDetails.getQuestion() != null && questionnaireDetails.getAnswer() != null) {
                    String code = questionnaireDetails.getQuestion().getCode();
                    String answer = questionnaireDetails.getAnswer().getLabel();
                    String description = questionnaireDetails.getQuestion().getDescription();
                    if (ProposalConstants.QMAY031.equalsIgnoreCase(code) && answer != null) { // Source of wealth and funds
                        payByYou = answer;
                    } else if (ProposalConstants.QMAY03101.equalsIgnoreCase(code) && answer != null) { // Get details of person who is paying
                        // premium
                        payerSurName = answer;
                    } else if (ProposalConstants.QMAY03102.equalsIgnoreCase(code) && answer != null) {
                        payerGivenName = answer;
                    } else if (ProposalConstants.QMAY03103.equalsIgnoreCase(code) && answer != null) {
                        payerNric = answer;
                    } else if (ProposalConstants.QMAY03104.equalsIgnoreCase(code) && answer != null) {
                        payerRelationship = answer;
                    } else if (ProposalConstants.QMAY03201.equalsIgnoreCase(code)
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        payWays.add(description);
                    } else if (ProposalConstants.QMAY03202.equalsIgnoreCase(code) && answer != null
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        payWays.add(description);
                    } else if (ProposalConstants.QMAY03203.equalsIgnoreCase(code) && answer != null
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        payWays.add(description);
                    } else if (ProposalConstants.QMAY03204.equalsIgnoreCase(code) && answer != null
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        payWays.add(description);
                    } else if (ProposalConstants.QMAY03205.equalsIgnoreCase(code) && answer != null
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        payWays.add(description);
                    }
                    if (ProposalConstants.QMAY03206.equalsIgnoreCase(code) && answer != null) {
                        howToPay = "None";
                    }
                    if (ProposalConstants.QMAY0320601.equalsIgnoreCase(code) && answer != null) {
                        otherPayWay = questionnaireDetails.getAnswer().getValue();
                    } else if (ProposalConstants.QMAY033.equalsIgnoreCase(code) && answer != null) { // Beneficial Owners
                        isBeneficialOwners = answer.toUpperCase();
                    } else if (ProposalConstants.QMAY03301.equalsIgnoreCase(code) && answer != null) {
                        boSurName = answer;
                    } else if (ProposalConstants.QMAY03302.equalsIgnoreCase(code) && answer != null) {
                        boGivenName = answer;
                    } else if (ProposalConstants.QMAY03303.equalsIgnoreCase(code) && answer != null) {
                        boNric = answer;
                    } else if (ProposalConstants.QMAY03304.equalsIgnoreCase(code) && answer != null) {
                        boDob = answer;
                    } else if (ProposalConstants.QMAY03305.equalsIgnoreCase(code) && answer != null) {
                        boNationality = answer;
                    } else if (ProposalConstants.QMAY03306.equalsIgnoreCase(code) && answer != null) {
                        boResCountry = answer;
                    } else if (ProposalConstants.QMAY03307.equalsIgnoreCase(code) && answer != null) {
                        boRelationship = answer;
                    }
                }
            }
        }

        // Source of wealth and funds
        map.put(ProposalConstants.KEY_PAYBYYOU, payByYou);
        if (StringUtils.isNotEmpty(payerGivenName) || StringUtils.isNotEmpty(payerSurName)) {
            payerName = payerGivenName + " " + payerSurName;
        }
        map.put(ProposalConstants.KEY_PAYERNAME, payerName);
        map.put(ProposalConstants.KEY_PAYERNRIC, payerNric);
        map.put(ProposalConstants.KEY_PAYERRELATIONSHIP, payerRelationship);
        
        // Source of wealth derived from

        if (!payWays.isEmpty()) {
            howToPay = D2CUtils.listToString(payWays, ",");
        }
        map.put(ProposalConstants.KEY_HOWTOPAY, howToPay);
        map.put(ProposalConstants.KEY_OTHERPAYWAY, otherPayWay);

        map.put(ProposalConstants.KEY_ISBENEFICIALOWNERS, isBeneficialOwners);
        if (StringUtils.isNotEmpty(boGivenName) || StringUtils.isNotEmpty(boSurName)) {
            boName = boGivenName + " " + boSurName;
        }
        map.put(ProposalConstants.KEY_BONAME, boName);
        map.put(ProposalConstants.KEY_BONRIC, boNric);
        map.put(ProposalConstants.KEY_BODOB, boDob);
        map.put(ProposalConstants.KEY_BONATIONALITY, boNationality);
        map.put(ProposalConstants.KEY_BORESCOUNTRY, boResCountry);
        map.put(ProposalConstants.KEY_BORELATIONSHIP, boRelationship);
    }

    /**
     * Constructs Map for Page Four values
     *
     * @param map
     * @param mayQuestions
     * @param psQuestions
     */
    private void getPage4Values(Map<String, String> map, QuestionnaireDetails[] mayQuestions,
                                QuestionnaireDetails[] psQuestions) {
        // PEP Declaration
        String isPEP = NOT_APPLICABLE;
        String pepName = NOT_APPLICABLE;
        String pepSurname = EMPTY_STRING;
        String pepGivenname = EMPTY_STRING;
        String pepNric = NOT_APPLICABLE;
        String pepDob = NOT_APPLICABLE;
        String pepNationality = NOT_APPLICABLE;
        String pepResCountry = NOT_APPLICABLE;
        String pepNature = NOT_APPLICABLE;
        String pepRelationship = NOT_APPLICABLE;

        // Lifestyle Details
        String traveledAbroad = NOT_APPLICABLE;
        String travelPlace1 = NOT_APPLICABLE;
        String travelDuration1 = NOT_APPLICABLE;
        String travelPurpose1 = NOT_APPLICABLE;
        String travelPurposeOther1 = EMPTY_STRING;
        String travelPlace2 = NOT_APPLICABLE;
        String travelDuration2 = NOT_APPLICABLE;
        String travelPurpose2 = NOT_APPLICABLE;
        String travelPurposeOther2 = EMPTY_STRING;
        String travelPlace3 = NOT_APPLICABLE;
        String travelDuration3 = NOT_APPLICABLE;
        String travelPurpose3 = NOT_APPLICABLE;
        String travelPurposeOther3 = EMPTY_STRING;

        List<String> engageInPursuits = new ArrayList<>();

        String isSmoker = STRING_NO;
        String smokedYears = NOT_APPLICABLE;
        String cigaretteNumber = NOT_APPLICABLE;
        String consumeAlcohol = STRING_NO;
        String alcoholType = NOT_APPLICABLE;
        String weeklyQuantity = NOT_APPLICABLE;
        List<String> treatAddiction = new ArrayList<>();

        if (mayQuestions != null) {
            for (QuestionnaireDetails questionnaireDetails : mayQuestions) {
                if (questionnaireDetails.getQuestion() != null && questionnaireDetails.getAnswer() != null) {
                    String code = questionnaireDetails.getQuestion().getCode();
                    String answer = questionnaireDetails.getAnswer().getLabel();
                    if (ProposalConstants.QMAY034.equalsIgnoreCase(code)) {
                        isPEP = answer.toUpperCase();
                    } else if (ProposalConstants.QMAY03401.equalsIgnoreCase(code)) {
                        pepSurname = answer;
                    } else if (ProposalConstants.QMAY03402.equalsIgnoreCase(code)) {
                        pepGivenname = answer;
                    } else if (ProposalConstants.QMAY03403.equalsIgnoreCase(code)) {
                        pepNric = answer;
                    } else if (ProposalConstants.QMAY03404.equalsIgnoreCase(code)) {
                        pepDob = answer;
                    } else if (ProposalConstants.QMAY03405.equalsIgnoreCase(code)) {
                        pepNationality = answer;
                    } else if (ProposalConstants.QMAY03406.equalsIgnoreCase(code)) {
                        pepResCountry = answer;
                    } else if (ProposalConstants.QMAY03407.equalsIgnoreCase(code)) {
                        pepRelationship = answer;
                    } else if (ProposalConstants.QMAY03408.equalsIgnoreCase(code)) {
                        pepNature = answer;
                    }
                }
            }
        }

        if (psQuestions != null) {
            for (QuestionnaireDetails questionnaireDetails : psQuestions) {
                if (questionnaireDetails.getQuestion() != null && questionnaireDetails.getAnswer() != null) {
                    String code = questionnaireDetails.getQuestion().getCode();
                    String answer = questionnaireDetails.getAnswer().getLabel();
                    String description = questionnaireDetails.getQuestion().getDescription();

                    if (ProposalConstants.QPS003.equalsIgnoreCase(code) && answer != null) {
                        traveledAbroad = answer.toUpperCase();
                    }
                    if (ProposalConstants.QPS003011.equalsIgnoreCase(code) && answer != null) {
                        travelPlace1 = answer;
                    }
                    if (ProposalConstants.QPS003021.equalsIgnoreCase(code) && answer != null) {
                        travelDuration1 = answer;
                    }
                    if (ProposalConstants.QPS003031.equalsIgnoreCase(code) && answer != null) {
                        travelPurpose1 = answer;
                    }
                    if (ProposalConstants.QPS00303011.equalsIgnoreCase(code) && answer != null) {
                        travelPurposeOther1 = answer;
                    }
                    if (ProposalConstants.QPS003012.equalsIgnoreCase(code) && answer != null) {
                        travelPlace2 = answer;
                    }
                    if (ProposalConstants.QPS003022.equalsIgnoreCase(code) && answer != null) {
                        travelDuration2 = answer;
                    }
                    if (ProposalConstants.QPS003032.equalsIgnoreCase(code) && answer != null) {
                        travelPurpose2 = answer;
                    }
                    if (ProposalConstants.QPS00303012.equalsIgnoreCase(code) && answer != null) {
                        travelPurposeOther2 = answer;
                    }
                    if (ProposalConstants.QPS003013.equalsIgnoreCase(code) && answer != null) {
                        travelPlace3 = answer;
                    }
                    if (ProposalConstants.QPS003023.equalsIgnoreCase(code) && answer != null) {
                        travelDuration3 = answer;
                    }
                    if (ProposalConstants.QPS003033.equalsIgnoreCase(code) && answer != null) {
                        travelPurpose3 = answer;
                    }
                    if (ProposalConstants.QPS00303013.equalsIgnoreCase(code) && answer != null) {
                        travelPurposeOther3 = answer;
                    }
                    if (ProposalConstants.QPS00401.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        engageInPursuits.add(description);
                    }
                    if (ProposalConstants.QPS00402.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        engageInPursuits.add(description);
                    }
                    if (ProposalConstants.QPS00403.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        engageInPursuits.add(description);
                    }
                    if (ProposalConstants.QPS00404.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        engageInPursuits.add(description);
                    }
                    if (ProposalConstants.QPS00405.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        engageInPursuits.add(description);
                    }
                    if (ProposalConstants.QPS00406.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        engageInPursuits.add(description);
                    }
                    if (ProposalConstants.QPS00407.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        engageInPursuits.clear();
                        engageInPursuits.add("None");
                    }

                    if (ProposalConstants.QPS005.equalsIgnoreCase(code) && answer != null) {
                        isSmoker = answer.toUpperCase();
                    } else if (ProposalConstants.QPS00501.equalsIgnoreCase(code) && answer != null) {
                        smokedYears = answer.toUpperCase();
                    } else if (ProposalConstants.QPS00502.equalsIgnoreCase(code) && answer != null) {
                        cigaretteNumber = answer.toUpperCase();
                    }
                    if (ProposalConstants.QPS006.equalsIgnoreCase(code) && answer != null) {
                        consumeAlcohol = answer.toUpperCase();
                    }
                    if (ProposalConstants.QPS00601.equalsIgnoreCase(code) && answer != null) {
                        alcoholType = answer;
                    }
                    if (ProposalConstants.QPS00602.equalsIgnoreCase(code) && answer != null) {
                        weeklyQuantity = answer;
                    }
                    if (ProposalConstants.QPS00701.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        treatAddiction.add(answer);
                    }
                    if (ProposalConstants.QPS00702.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        treatAddiction.add(answer);
                    }
                    if (ProposalConstants.QPS00703.equalsIgnoreCase(code) && STRING_YES.equalsIgnoreCase(answer)) {
                        treatAddiction.clear();
                        treatAddiction.add("NONE");
                    }
                }
            }
        }

        map.put(ProposalConstants.KEY_ISPEP, isPEP);
        if (StringUtils.isNotEmpty(pepSurname) || StringUtils.isNotEmpty(pepGivenname)) {
            pepName = pepGivenname + " " + pepSurname;
        }
        map.put(ProposalConstants.KEY_PEPNAME, pepName);
        map.put(ProposalConstants.KEY_PEPNRIC, pepNric);
        map.put(ProposalConstants.KEY_PEPDOB, pepDob);
        map.put(ProposalConstants.KEY_PEPNATIONALITY, pepNationality);
        map.put(ProposalConstants.KEY_PEPRESCOUNTRY, pepResCountry);
        map.put(ProposalConstants.KEY_PEPNATURE, pepNature);
        map.put(ProposalConstants.KEY_PEPRELATIONSHIP, pepRelationship);

        map.put(ProposalConstants.KEY_TRAVELEDABROAD, traveledAbroad);
        map.put(ProposalConstants.KEY_TRAVELPLACE1, travelPlace1);
        map.put(ProposalConstants.KEY_TRAVELDURATION1, travelDuration1);
        if (StringUtils.isNotEmpty(travelPurposeOther1)) {
            travelPurpose1 = travelPurposeOther1;
        }
        map.put(ProposalConstants.KEY_TRAVELPURPOSE1, travelPurpose1);
        map.put(ProposalConstants.KEY_TRAVELPLACE2, travelPlace2);
        map.put(ProposalConstants.KEY_TRAVELDURATION2, travelDuration2);
        if (StringUtils.isNotEmpty(travelPurposeOther2)) {
            travelPurpose2 = travelPurposeOther2;
        }
        map.put(ProposalConstants.KEY_TRAVELPURPOSE2, travelPurpose2);
        map.put(ProposalConstants.KEY_TRAVELPLACE3, travelPlace3);
        map.put(ProposalConstants.KEY_TRAVELDURATION3, travelDuration3);
        if (StringUtils.isNotEmpty(travelPurposeOther3)) {
            travelPurpose3 = travelPurposeOther3;
        }
        map.put(ProposalConstants.KEY_TRAVELPURPOSE3, travelPurpose3);

        map.put(ProposalConstants.KEY_ENGAGEINPURSUITS, D2CUtils.listToString(engageInPursuits, ","));

        map.put(ProposalConstants.KEY_ISSMOKER, isSmoker);
        map.put(ProposalConstants.KEY_SMOKEDYEARS, smokedYears);
        map.put(ProposalConstants.KEY_CIGARETTENUMBER, cigaretteNumber);
        map.put(ProposalConstants.KEY_CONSUMEALCOHOL, consumeAlcohol);
        map.put(ProposalConstants.KEY_ALCOHOLTYPE, alcoholType);
        map.put(ProposalConstants.KEY_WEEKLYQUANTITY, weeklyQuantity);
        map.put(ProposalConstants.KEY_TREATADDICTION, D2CUtils.listToString(treatAddiction, ","));
    }

    /**
     * Constructs Map for Page Five values
     *
     * @param map
     * @param psQuestions
     */
    private void getPage5Values(Map<String, String> map, QuestionnaireDetails[] psQuestions) {
        String answer1101 = NOT_APPLICABLE;
        String answer1102 = NOT_APPLICABLE;
        String doctorName = NOT_APPLICABLE;
        String clinicAddress = NOT_APPLICABLE;
        String yearsKnown = NOT_APPLICABLE;
        String fullyRecovered = NOT_APPLICABLE;

        String answer1103 = NOT_APPLICABLE;
        String answer1103A = NOT_APPLICABLE;
        String answer1103B = NOT_APPLICABLE;
        String answer1103C = NOT_APPLICABLE;
        String answer1103D = NOT_APPLICABLE;
        String answer1103E = NOT_APPLICABLE;

        String answer1104 = NOT_APPLICABLE;
        String answer1104A = NOT_APPLICABLE;
        String answer1104B = NOT_APPLICABLE;
        String answer1104C = NOT_APPLICABLE;
        String answer1104D = NOT_APPLICABLE;
        String answer1104E = NOT_APPLICABLE;
        String answer1104F = NOT_APPLICABLE;
        String answer1104G = NOT_APPLICABLE;

        if (psQuestions != null) {
            for (QuestionnaireDetails questionnaireDetails : psQuestions) {
                if (questionnaireDetails.getQuestion() != null && questionnaireDetails.getAnswer() != null) {
                    String code = questionnaireDetails.getQuestion().getCode();
                    String answer = questionnaireDetails.getAnswer().getLabel();
                    if (ProposalConstants.QPS008.equalsIgnoreCase(code) && answer != null) {
                        answer1101 = answer.toUpperCase();
                    }
                    if (ProposalConstants.QPS009.equalsIgnoreCase(code) && answer != null) {
                        answer1102 = answer.toUpperCase();
                    } else if (ProposalConstants.QPS00901.equalsIgnoreCase(code) && answer != null) {
                        doctorName = answer.toUpperCase();
                    } else if (ProposalConstants.QPS00902.equalsIgnoreCase(code) && answer != null) {
                        clinicAddress = answer.toUpperCase();
                    } else if (ProposalConstants.QPS00903.equalsIgnoreCase(code) && answer != null) {
                        yearsKnown = answer;
                    } else if (ProposalConstants.QPS00905.equalsIgnoreCase(code) && answer != null) {
                        fullyRecovered = answer.toUpperCase();
                    }
                    if (ProposalConstants.QPS010.equalsIgnoreCase(code) && answer != null) {
                        answer1103 = answer.toUpperCase();
                    } else if (ProposalConstants.QPS01001.equalsIgnoreCase(code) && answer != null) {
                        answer1103A = answer.toUpperCase();
                    } else if (ProposalConstants.QPS01002.equalsIgnoreCase(code) && answer != null) {
                        answer1103B = answer.toUpperCase();
                    } else if (ProposalConstants.QPS01003.equalsIgnoreCase(code) && answer != null) {
                        answer1103C = answer.toUpperCase();
                    } else if (ProposalConstants.QPS01004.equalsIgnoreCase(code) && answer != null) {
                        answer1103D = answer.toUpperCase();
                    } else if (ProposalConstants.QPS01005.equalsIgnoreCase(code) && answer != null) {
                        answer1103E = answer.toUpperCase();
                    }
                    if (ProposalConstants.QPS011.equalsIgnoreCase(code) && answer != null) {
                        answer1104 = answer.toUpperCase();
                    } else if (ProposalConstants.QPS01101.equalsIgnoreCase(code) && answer != null) {
                        answer1104A = answer.toUpperCase();
                    } else if (ProposalConstants.QPS01102.equalsIgnoreCase(code) && answer != null) {
                        answer1104B = answer.toUpperCase();
                    } else if (ProposalConstants.QPS01103.equalsIgnoreCase(code) && answer != null) {
                        answer1104C = answer.toUpperCase();
                    } else if (ProposalConstants.QPS01104.equalsIgnoreCase(code) && answer != null) {
                        answer1104D = answer.toUpperCase();
                    } else if (ProposalConstants.QPS01105.equalsIgnoreCase(code) && answer != null) {
                        answer1104E = answer.toUpperCase();
                    } else if (ProposalConstants.QPS01106.equalsIgnoreCase(code) && answer != null) {
                        answer1104F = answer.toUpperCase();
                    } else if (ProposalConstants.QPS01107.equalsIgnoreCase(code) && answer != null) {
                        answer1104G = answer.toUpperCase();
                    }
                }
            }
        }

        map.put(ProposalConstants.KEY_ANSWER1101, answer1101);
        map.put(ProposalConstants.KEY_ANSWER1102, answer1102);
        map.put(ProposalConstants.KEY_DOCTORNAME, doctorName);
        map.put(ProposalConstants.KEY_CLINICADDRESS, clinicAddress);
        map.put(ProposalConstants.KEY_YEARSKNOWN, yearsKnown);
        map.put(ProposalConstants.KEY_FULLYRECOVERED, fullyRecovered);

        map.put(ProposalConstants.KEY_ANSWER1103, answer1103);
        map.put(ProposalConstants.KEY_ANSWER1103A, answer1103A);
        map.put(ProposalConstants.KEY_ANSWER1103B, answer1103B);
        map.put(ProposalConstants.KEY_ANSWER1103C, answer1103C);
        map.put(ProposalConstants.KEY_ANSWER1103D, answer1103D);
        map.put(ProposalConstants.KEY_ANSWER1103E, answer1103E);

        map.put(ProposalConstants.KEY_ANSWER1104, answer1104);
        map.put(ProposalConstants.KEY_ANSWER1104A, answer1104A);
        map.put(ProposalConstants.KEY_ANSWER1104B, answer1104B);
        map.put(ProposalConstants.KEY_ANSWER1104C, answer1104C);
        map.put(ProposalConstants.KEY_ANSWER1104D, answer1104D);
        map.put(ProposalConstants.KEY_ANSWER1104E, answer1104E);
        map.put(ProposalConstants.KEY_ANSWER1104F, answer1104F);
        map.put(ProposalConstants.KEY_ANSWER1104G, answer1104G);
    }

    /**
     * Constructs Map for Page Six values
     *
     * @param map
     * @param pptData
     * @param psQuestions
     */
    private void getPage6Values(Map<String, String> map, ProposalPDFData pptData, QuestionnaireDetails[] psQuestions) {
        String answer1104H = NOT_APPLICABLE;
        String answer1104I = NOT_APPLICABLE;
        String answer1105 = STRING_NO;
        String answer1106 = STRING_NO;
        String answer1106A = STRING_NO;
        String answer1106B = STRING_NO;
        String answer1106C = STRING_NO;

        String financialConsult = NOT_APPLICABLE;

        if (psQuestions != null) {
            for (QuestionnaireDetails questionnaireDetails : psQuestions) {
                if (questionnaireDetails.getQuestion() != null && questionnaireDetails.getAnswer() != null) {
                    String code = questionnaireDetails.getQuestion().getCode();
                    String answer = questionnaireDetails.getAnswer().getLabel();
                    if (ProposalConstants.QPS01108.equalsIgnoreCase(code) && answer != null) {
                        answer1104H = answer.toUpperCase();
                    } else if (ProposalConstants.QPS01109.equalsIgnoreCase(code) && answer != null) {
                        answer1104I = answer.toUpperCase();
                    }
                    if (ProposalConstants.QPS012.equalsIgnoreCase(code) && answer != null) {
                        answer1105 = answer.toUpperCase();
                    }
                    if (ProposalConstants.QPS013.equalsIgnoreCase(code) && answer != null) {
                        answer1106 = answer.toUpperCase();
                    } else if (ProposalConstants.QPS01301.equalsIgnoreCase(code) && answer != null
                            && STRING_YES.equalsIgnoreCase(answer)) {
                        answer1106A = answer.toUpperCase();
                    }
                }
            }
        }

        map.put(ProposalConstants.KEY_ANSWER1104H, answer1104H);
        map.put(ProposalConstants.KEY_ANSWER1104I, answer1104I);
        map.put(ProposalConstants.KEY_ANSWER1105, answer1105);
        map.put(ProposalConstants.KEY_ANSWER1106, answer1106);
        map.put(ProposalConstants.KEY_ANSWER1106A, answer1106A);
        map.put(ProposalConstants.KEY_ANSWER1106B, answer1106B);
        map.put(ProposalConstants.KEY_ANSWER1106C, answer1106C);

        if (Constants.SHORT_YES.equalsIgnoreCase(pptData.getConsultationReq())) {
            financialConsult = STRING_YES;
        } else if (Constants.SHORT_NO.equalsIgnoreCase(pptData.getConsultationReq())) {
            financialConsult = STRING_NO;
        }
        map.put(ProposalConstants.KEY_FINANCIALCONSULT, financialConsult);
    }

    /**
     * Constructs Map for Page Ten values
     *
     * @param map
     * @param pptData
     */
    private void getPage11Values(Map<String, String> map, ProposalPDFData pptData) {
        String consentConfirm = STRING_YES;
        String receiveMarketingInfo = NOT_APPLICABLE;

        if (Constants.SHORT_YES.equalsIgnoreCase(pptData.getReceiveMarketing())) {
            receiveMarketingInfo = STRING_YES;
        } else if (Constants.SHORT_NO.equalsIgnoreCase(pptData.getReceiveMarketing())) {
            receiveMarketingInfo = STRING_NO;
        }

        map.put(ProposalConstants.KEY_CONSENTCONFIRM, consentConfirm);
        map.put(ProposalConstants.KEY_RECEIVEMARKETINGINFO, receiveMarketingInfo);
    }

    private String decrypt(String req) {
        return DecryptionUtil.decryption(req, configProperties);
    }

    @Override
    public String getProdType() {
        return ProductEnum.PT.name();
    }
}