package com.prudential.d2c.controller;

import static com.prudential.d2c.common.Constants.VALID_BASE64;
import static com.prudential.d2c.utils.StaticFileUtil.convertObjectToJsonFormat;

import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.core.convert.ConversionService;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.prudential.d2c.common.Constants;
import com.prudential.d2c.entity.D2CResponse;
import com.prudential.d2c.entity.Response;
import com.prudential.d2c.entity.dto.CustomerApplication;
import com.prudential.d2c.entity.dto.FailedQuestionnaireDetails;
import com.prudential.d2c.entity.dto.MailList;
import com.prudential.d2c.entity.micro.AssignAgentRequest;
import com.prudential.d2c.entity.micro.payload.AssignAgentResponsePayload;
import com.prudential.d2c.exception.DPValidationException;
import com.prudential.d2c.security.JwtProvider;
import com.prudential.d2c.service.AssignedAgentService;
import com.prudential.d2c.service.CustomerApplicationService;
import com.prudential.d2c.service.MailService;
import com.prudential.d2c.utils.D2CUtils;
import com.prudential.d2c.utils.DateUtil;

import io.jsonwebtoken.Claims;

@RestController
@EnableAutoConfiguration
public class CustomerApplicationController extends BaseController {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    private static final String PRODUCT_TYPE = " ProductType:";

    @Autowired
    private CustomerApplicationService customerApplicationService;
    
    @Autowired
    private AssignedAgentService assignedAgentService;
    
    @Autowired
    private MailService mailService;
    
    @Autowired
    private JwtProvider jwtProvider;
    
    @Autowired
    ConversionService conversionService;


    /**
     * This interface is used for front end to call when start a new policy
     * To record this policy at the beginning including trigger email listener etc
     *
     * @param entity policy start relevant info
     * @return CustomerApplication
     */
    @SuppressWarnings("unchecked")
	@RequestMapping(
            value = "/startPolicy",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public Object startPolicy(@RequestBody CustomerApplication entity, HttpServletRequest request) {

        if (logger.isDebugEnabled()) {
            logger.debug("StartPolicy...{}", convertObjectToJsonFormat(entity));
        }

        String jwt = null;
        if (entity.getChannel() != null) {
            if (Pattern.matches(VALID_BASE64, entity.getChannel())) {
                entity.setChannel(new String(Base64.getDecoder().decode(entity.getChannel())));

            } else {
                throw new IllegalArgumentException("channel code is invalid");
            }

        }
        customerApplicationService.saveStartPolicy(entity);

        // for existing client comes from CRM,EDM,PRUAccess , need to add close browser for listening at first hand and regenerate jwt for these medium with custom ID
        if (entity.isStartListener()) {
            if (!Constants.CHANNEL_PRU_ACCESS.equals(entity.getChannel())) {
                MailList mailList = new MailList(entity.getClientNumber(), entity.getProductType(), entity.getChannel(), Constants.MAIL_CLOSE, entity.getCustomId(), Constants.MAIL_CLOSE_VALUE, entity.getProductName(), entity.getCampaignId());
                mailList.setIPAddress(D2CUtils.retrieveIPAddress(request));
                
                AssignAgentRequest assignAgentRequest = mailService.getAssignAgentRequest(mailList);
                AssignAgentResponsePayload assignAgentResponsePayload = assignedAgentService.callAssignAgent(assignAgentRequest);
                
                mailService.saveMailList(mailList, assignAgentResponsePayload);
            }
            String token = jwtProvider.resolveToken(request);
            if (token != null && Constants.CHANNEL_PRU_ACCESS.equals(entity.getChannel())) {
                Claims claims = jwtProvider.parseJWT(token);
                LinkedHashMap<String, String> payload = (LinkedHashMap<String, String>) claims.get("payload");
                jwt = jwtProvider.createJWT(entity.getCustomId(), claims.getSubject(), payload);
            }
        }

        if (StringUtils.isNotEmpty(entity.getAbandCId())) {
            mailService.invalidCloseBrowser(entity.getAbandCId());
        }

        return new D2CResponse(Constants.SUCCESS_STATUS, HttpStatus.SC_OK,
                Constants.EMPTY_STRING, entity, jwt);
    }

    @RequestMapping(
            value = "/saveAboutYou",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public Object submitAboutYou(@RequestBody CustomerApplication encryptedEntity) {

        CustomerApplication entity = conversionService.convert(encryptedEntity, CustomerApplication.class);

        // Validate Customer Application
        try {
            validateCustomerApplication(entity);
        } catch (DPValidationException e) {
            return ResponseEntity.status(HttpStatus.SC_BAD_REQUEST).body("Invalid input found in request payload");
        }

        logger.info("Invoking submitAboutYou.");
        logger.debug("Start AboutYou info, CustomId: {}{}{} Channel:{}",
                D2CUtils.removeCRLF(entity.getCustomId()), PRODUCT_TYPE,
                D2CUtils.removeCRLF(entity.getProductType()), D2CUtils.removeCRLF(entity.getChannel()));
        logger.debug("CustomId: {} ProductType: {}", D2CUtils.removeCRLF(entity.getCustomId()),
                D2CUtils.removeCRLF(entity.getProductType()));
        if (!StringUtils.isEmpty(entity.getCustomId())) {
            entity.setStepStatus(Constants.SAVE_ABOUTYOU_STATUS);
            if (!StringUtils.isEmpty(entity.getDob())) {
                entity.setDob(DateUtil.checkDateformat(entity.getDob(), Constants.DOBFORMAT));
            }
            customerApplicationService.saveCustomerApplicationInAll(entity);
            logger.info("Complete saving AboutYou info.");
        }
        return new Response(Constants.OK_STRING);
    }

    @RequestMapping(
            value = "/saveMoreAboutYou",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public Object submitMoreAboutYou(@RequestBody CustomerApplication encryptedEntity) {

        CustomerApplication entity = conversionService.convert(encryptedEntity, CustomerApplication.class);

        // Validate Customer Application
        try {
            validateCustomerApplication(entity);
        } catch (DPValidationException e) {
            return ResponseEntity.status(HttpStatus.SC_BAD_REQUEST).body("Invalid input found in request payload");
        }

        logger.info("Invoking submitMoreAboutYou.");
        logger.debug("Start to save MoreAboutYou info, CustomId:{}{}{} Channel:{}",
                D2CUtils.removeCRLF(entity.getCustomId()), PRODUCT_TYPE,
                D2CUtils.removeCRLF(entity.getProductType()), D2CUtils.removeCRLF(entity.getChannel()));
        if (!StringUtils.isEmpty(entity.getCustomId())) {
            entity.setStepStatus(Constants.SAVE_MOREABOUTYOU_STATUS);
            customerApplicationService.saveMoreAboutYouCustomerApplication(entity);
            logger.info("Complete saving AboutYou info.");
        }
        return new Response(Constants.OK_STRING);
    }

    @RequestMapping(
            value = "/saveProductSpecificQuestions",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public Object submitSaveQuestionnaire(@RequestBody CustomerApplication encryptedEntity) {
        logger.info("Invoking saveProductSpecificQuestions.");
        CustomerApplication entity = conversionService.convert(encryptedEntity, CustomerApplication.class);

        logger.debug("Start ProductSpecificQuestions , CustomId:{}{}{}", D2CUtils.removeCRLF(entity.getCustomId()),
                PRODUCT_TYPE, D2CUtils.removeCRLF(entity.getProductType()));
        if (StringUtils.isNotEmpty(entity.getCustomId())) {
            entity.setStepStatus(Constants.SAVE_PRODUCT_SPECIFIED_STATUS);
            customerApplicationService.saveProductSpecificQuestonnaires(entity);
            logger.info("Complete saving ProductSpecificQuestions.");
        }
        return new Response(Constants.OK_STRING);
    }

    @RequestMapping(
            value = "/removeCustomerInputInfo",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object removeCustomerInfo(@RequestBody CustomerApplication encryptedEntity) {

        CustomerApplication entity = conversionService.convert(encryptedEntity, CustomerApplication.class);


        String uuid = entity.getCustomId();
        logger.info("begin RemoveCustomerInfo the CUSTOM_ID is: {}", D2CUtils.removeCRLF(uuid));
        mailService.removeCustomerInfo(uuid);
        logger.info("complete RemoveCustomerInfo");
        return new Response(Constants.OK_STRING);
    }

    /**
     * this method is to call when a client finally submit an application form
     *
     * @param entity
     * @return
     */
    @RequestMapping(
            value = "/saveAllCustomerInputInfo",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public Object submitAll(@RequestBody CustomerApplication encryptedEntity) {

        CustomerApplication entity = conversionService.convert(encryptedEntity, CustomerApplication.class);

        logger.info("Invoking saveAllCustomerInputInfo.");
        logger.debug("Start AllCustomerInputInfo , CustomId:{}{}{}", D2CUtils.removeCRLF(entity.getCustomId()), PRODUCT_TYPE,
                D2CUtils.removeCRLF(entity.getProductType()));
        if (!StringUtils.isEmpty(entity.getCustomId())) {
            entity.setStepStatus(Constants.SAVE_ALL_STATUS);
            if (!StringUtils.isEmpty(entity.getDob())) {
                entity.setDob(DateUtil.checkDateformat(entity.getDob(), Constants.DOBFORMAT));
            }
            customerApplicationService.saveCustomerApplicationInAll(entity);
            // new customer name change, application close

            if (entity.getAgentChange()) {
                MailList mail = new MailList();
                mail.setCustomId(entity.getCustomId());
                mail.setMailType(Constants.MAIL_CLOSE);
                
                AssignAgentRequest assignAgentRequest = mailService.getAssignAgentRequest(mail);
                AssignAgentResponsePayload assignAgentResponsePayload = assignedAgentService.callAssignAgent(assignAgentRequest);
                
                mailService.saveMailList(mail, assignAgentResponsePayload);
            } else {
                mailService.updateCustomerDataforCloseBrowserMail(entity);
            }

        }
        logger.info("Complete saving AllCustomerInputInfo.");
        return new Response(Constants.OK_STRING);
    }

    @RequestMapping(
            value = "/marketConsent",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object updateMarketConsent(@RequestBody CustomerApplication encryptedEntity) {

        CustomerApplication entity = conversionService.convert(encryptedEntity, CustomerApplication.class);

        logger.info("begin updateMarketConsent the CUSTOM_ID is: {}", D2CUtils.removeCRLF(entity.getCustomId()));
        customerApplicationService.updateMarketConsent(entity.getMarketConsent(), entity.getCustomId());
        logger.info("complete updateMarketConsent");
        return new Response(Constants.OK_STRING);
    }

    @RequestMapping(
            value = "/saveFailedQuestionnaire",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public Object saveFailedQuestionnaireDetails(@RequestBody List<FailedQuestionnaireDetails> failedQuestionnaireDetailsList) {

        logger.info("Begin Failed Questionnaire Details : {}", D2CUtils.removeCRLF(failedQuestionnaireDetailsList.toString()));
        for (FailedQuestionnaireDetails encryptedEntity : failedQuestionnaireDetailsList) {
            FailedQuestionnaireDetails entity = conversionService.convert(encryptedEntity, FailedQuestionnaireDetails.class);
            logger.info("FailedQuestionnaireDetails Entity : {}", entity);
            customerApplicationService.saveFailedQuestionnaireDetails(entity);
        }

        return new Response(Constants.OK_STRING);
    }

    private void validateCustomerApplication(CustomerApplication application) throws DPValidationException{
        String htmlPattern = "^\\s+.*|[!$^*=|\\<>?_]|\\s{2,}";
        Pattern pattern = Pattern.compile(htmlPattern);

        // Check Residence
        Boolean residenceMatcherFound = (application.getResidentialBlockNo() != null && pattern.matcher(application.getResidentialBlockNo()).find()) || (application.getResidentialCountry() != null && pattern.matcher(application.getResidentialCountry()).find())
            || (application.getResidentialUnitNo() != null && pattern.matcher(application.getResidentialUnitNo()).find()) || (application.getResidentialPostalCode() != null && pattern.matcher(application.getResidentialPostalCode()).find())
            || (application.getResidentialBuildingName() != null && pattern.matcher(application.getResidentialBuildingName()).find()) || (application.getResidentialStreetName() != null && pattern.matcher(application.getResidentialStreetName()).find());
        // Check Mailing Address
        Boolean mailingAddMatcherFound = (application.getMailingCountry() != null && pattern.matcher(application.getMailingCountry()).find()) || (application.getMailingBlockNo() != null && pattern.matcher(application.getMailingBlockNo()).find())
            || (application.getMailingBuildingName() != null && pattern.matcher(application.getMailingBuildingName()).find()) || (application.getMailingStreetName() != null && pattern.matcher(application.getMailingStreetName()).find())
            || (application.getMailingUnitNo() != null && pattern.matcher(application.getMailingUnitNo()).find()) || (application.getMailingPostalCode() != null && pattern.matcher(application.getMailingPostalCode()).find());
        // Check Given Name & Sur Name
        Boolean nameMatcherFound = (application.getGivenName() != null && pattern.matcher(application.getGivenName()).find())
            || (application.getSurName() != null && pattern.matcher(application.getSurName()).find());
        
        if(residenceMatcherFound || mailingAddMatcherFound || nameMatcherFound){
            throw new DPValidationException("Validation Errors");
        }
    }
    
}
