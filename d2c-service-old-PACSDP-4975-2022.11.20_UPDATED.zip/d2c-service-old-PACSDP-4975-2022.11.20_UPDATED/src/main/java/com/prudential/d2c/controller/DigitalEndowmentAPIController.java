package com.prudential.d2c.controller;

import java.math.BigDecimal;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Calendar;
import java.util.List;
import java.util.Optional;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.prudential.d2c.batch.Jobservice;
import com.prudential.d2c.common.ConfigProperties;
import com.prudential.d2c.common.Constants;
import com.prudential.d2c.entity.DigitalEndowmentAPIDto;
import com.prudential.d2c.entity.config.ChannelProductMapping;
import com.prudential.d2c.entity.config.Channels;
import com.prudential.d2c.entity.config.MyInfoMapping;
import com.prudential.d2c.entity.config.Products;
import com.prudential.d2c.entity.config.ProductsConfig;
import com.prudential.d2c.entity.dto.CustomerApplication;
import com.prudential.d2c.entity.dto.DigitalEndowmentAPIAudit;
import com.prudential.d2c.entity.dto.Occupation;
import com.prudential.d2c.entity.micro.DigitalEndowmentAPIClient;
import com.prudential.d2c.entity.micro.DigitalEndowmentAPIClientAddress;
import com.prudential.d2c.entity.micro.DigitalEndowmentAPIESubPayment;
import com.prudential.d2c.entity.micro.DigitalEndowmentAPIError;
import com.prudential.d2c.entity.micro.DigitalEndowmentAPIPolicy;
import com.prudential.d2c.entity.micro.DigitalEndowmentAPIPruPayResponse;
import com.prudential.d2c.entity.micro.DigitalEndowmentAPIQuestionnaire;
import com.prudential.d2c.entity.micro.DigitalEndowmentAPIRequest;
import com.prudential.d2c.entity.micro.DigitalEndowmentAPIRequestDocument;
import com.prudential.d2c.entity.micro.DigitalEndowmentAPIResponse;
import com.prudential.d2c.entity.micro.DigitalEndowmentAPIResponsePayload;
import com.prudential.d2c.entity.micro.DigitalEndowmentAPIResponseSystem;
import com.prudential.d2c.entity.micro.SQSProductLifeAssured;
import com.prudential.d2c.entity.micro.SQSProductPlan;
import com.prudential.d2c.exception.DPValidationException;
import com.prudential.d2c.exception.DigitalEndowmentAPIException;
import com.prudential.d2c.exception.ProposalFetchException;
import com.prudential.d2c.repository.ChannelProductMappingRepository;
import com.prudential.d2c.repository.MyInfoMappingRepository;
import com.prudential.d2c.service.ChannelService;
import com.prudential.d2c.service.CustomerApplicationService;
import com.prudential.d2c.service.DigitalEndowmentAPIService;
import com.prudential.d2c.service.OccupationService;
import com.prudential.d2c.service.ProductConfigService;
import com.prudential.d2c.service.ProductService;
import com.prudential.d2c.type.DigitalEndowmentAPIExceptionType;
import com.prudential.d2c.utils.ChannelAPIDataUtils;
import com.prudential.d2c.utils.D2CUtils;
import com.prudential.d2c.utils.DateUtil;

import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;


@RestController
@RequestMapping(value = "/digitalEndowmentAPI")
@ApiResponses(value = {
        @ApiResponse(code = 200, message = "OK."),
        @ApiResponse(code = 400, message = "Bad Request."),
        @ApiResponse(code = 500, message = "Internal Server Error.")
})
public class DigitalEndowmentAPIController extends BaseController {
	private static final Logger logger = LoggerFactory.getLogger(DigitalEndowmentAPIController.class);
	
	@Autowired
    private DigitalEndowmentAPIService digitalEndowmentAPIService;
	
    @Autowired
    private ProductConfigService productConfigService;
    
    @Autowired
    private ProductService productService;
    
    @Autowired
    private ChannelService channelService;
	
    @Autowired
    private OccupationService occupationService;
    
    @Autowired
    protected CustomerApplicationService customerApplicationService;
    
    @Autowired
    private ChannelProductMappingRepository channelProductMappingRepository;
    
    @Autowired
    private MyInfoMappingRepository myInfoMappingRepository;
    
    @Autowired
    private ConfigProperties configProperties;
    
    @Autowired
    Jobservice jobservice;

    @SuppressWarnings("unused")
	private final Predicate<Integer> nameValidator = c -> (Character.isLetter(c) || Character.isSpaceChar(c));
	
    @PostMapping(value = "/submitESub", consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<DigitalEndowmentAPIResponse> submitApplication(@RequestHeader(value = "appName", required = false) String appName, @RequestBody DigitalEndowmentAPIRequest request) throws DigitalEndowmentAPIException {
        return doDigitalEndowmentAPIProcess(new DigitalEndowmentAPIDto(request, DigitalEndowmentAPIDto.DigitalEndowmentAPIType.APPLICATION_ESUBMISSION, request.getPayload().getTransactionId(), appName));
    }
    
    private ResponseEntity<DigitalEndowmentAPIResponse> doDigitalEndowmentAPIProcess(DigitalEndowmentAPIDto digitalEndowmentAPIDto) throws DigitalEndowmentAPIException {
    	List<DigitalEndowmentAPIExceptionType> errorList = new ArrayList<>();
    	DigitalEndowmentAPIResponse processResponse;
    	DigitalEndowmentAPIESubPayment payment = null;
    	
    	StopWatch sw = new StopWatch();
        sw.start();
    	
        if (StringUtils.isBlank(digitalEndowmentAPIDto.getChannelName())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }

        if (digitalEndowmentAPIDto.getDigitalEndowmentAPIRequest() == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }

        try {

            logger.info("Digital Endowment API Processing Starts For : {} ", D2CUtils.removeCRLF(digitalEndowmentAPIDto.getDpTransactionId()));

            initiateAudit(digitalEndowmentAPIDto);

            if(StringUtils.isNotBlank(digitalEndowmentAPIDto.getRequestJson())) {
            	validatePayload(digitalEndowmentAPIDto);
            }

            if (CollectionUtils.isNotEmpty(digitalEndowmentAPIDto.getErrors())) {
                logger.info("Digital Endowment API Decode Failed : {}", D2CUtils.removeCRLF(digitalEndowmentAPIDto.getDpTransactionId()));
                return ResponseEntity.ok(getErrorResponse(digitalEndowmentAPIDto));
            }

            logger.info("Digital Endowment API Decode Success : {}", D2CUtils.removeCRLF(digitalEndowmentAPIDto.getDpTransactionId()));

            if (CollectionUtils.isNotEmpty(digitalEndowmentAPIDto.getErrors())) {
                logger.info("Digital Endowment API Object Conversion Failed : {}", D2CUtils.removeCRLF(digitalEndowmentAPIDto.getDpTransactionId()));
                return ResponseEntity.ok(getErrorResponse(digitalEndowmentAPIDto));
            }

            logger.info("Digital Endowment API JSON to Object Conversion Success : {}", D2CUtils.removeCRLF(digitalEndowmentAPIDto.getDpTransactionId()));

            validate(digitalEndowmentAPIDto);

            if (CollectionUtils.isNotEmpty(digitalEndowmentAPIDto.getErrors())) {
                logger.info("Digital Endowment API Validate Failed : {}", D2CUtils.removeCRLF(digitalEndowmentAPIDto.getDpTransactionId()));
                return ResponseEntity.ok(getErrorResponse(digitalEndowmentAPIDto));
            }

            logger.info("Digital Endowment API Validate Success : {}", digitalEndowmentAPIDto);
            
            if(digitalEndowmentAPIDto.getDigitalEndowmentAPIRequest().getPayload().getPayment().getPaymentTransactionId() != null && !digitalEndowmentAPIDto.getDigitalEndowmentAPIRequest().getPayload().getPayment().getPaymentTransactionId().equals(Constants.CASH)) {
                try {
	            	payment = processPaymentResponse(digitalEndowmentAPIDto);
	            } catch (DPValidationException ex) {
	            	errorList.add(DigitalEndowmentAPIExceptionType.PRUPAY_DATE_PARSE_ERROR);
					digitalEndowmentAPIDto.getErrors().addAll(errorList);
					return ResponseEntity.ok(getErrorResponse(digitalEndowmentAPIDto));
	            } catch (DigitalEndowmentAPIException ex) {
	            	errorList.add(DigitalEndowmentAPIExceptionType.PRUPAY_ERROR);
					digitalEndowmentAPIDto.getErrors().addAll(errorList);
					return ResponseEntity.ok(getErrorResponse(digitalEndowmentAPIDto));
	            }
            }

            try {
            	processResponse = process(digitalEndowmentAPIDto, payment);
            } catch (ProposalFetchException ex) {
            	errorList.add(DigitalEndowmentAPIExceptionType.FETCHPROPOSAL_ERROR);
				digitalEndowmentAPIDto.getErrors().addAll(errorList);
				return ResponseEntity.ok(getErrorResponse(digitalEndowmentAPIDto));
            } catch (DigitalEndowmentAPIException ex) {
            	errorList.add(DigitalEndowmentAPIExceptionType.ESUBMISSION_ERROR);
				digitalEndowmentAPIDto.getErrors().addAll(errorList);
				return ResponseEntity.ok(getErrorResponse(digitalEndowmentAPIDto));
            }

           
            if (CollectionUtils.isNotEmpty(digitalEndowmentAPIDto.getErrors())) {
                logger.info("Digital Endowment API Process Failed : {}", digitalEndowmentAPIDto);
                return ResponseEntity.ok(getErrorResponse(digitalEndowmentAPIDto));
            }

            logger.info("Digital Endowment API Process Success : {}", digitalEndowmentAPIDto);

            digitalEndowmentAPIDto.setDigitalEndowmentAPIResponse(processResponse);
            logger.info("Digital Endowment API Processing Ends : {} ", digitalEndowmentAPIDto.toString());

            return ResponseEntity.ok(processResponse);

        } catch (Exception exception) {
            logger.error("Exception Occurred While doDigitalEndowmentAPIProcess : " + exception.getMessage(), exception);
            throw new DigitalEndowmentAPIException("Exception occurred while Digital Endowment API Processing.");
        } finally {
        	sw.stop();
        	digitalEndowmentAPIDto.setExecutionTime(BigDecimal.valueOf(sw.getTime()));
        	digitalEndowmentAPIService.updateDigitalEndowmentAPIAudit(digitalEndowmentAPIDto);
        	logger.info("Digital Endowment API Processing Ends : {} ", digitalEndowmentAPIDto.getTransactionId());
        }

    }
    
    private void initiateAudit(DigitalEndowmentAPIDto digitalEndowmentAPIDto) {
    	DigitalEndowmentAPIAudit digitalEndowmentAPIAudit = new DigitalEndowmentAPIAudit(digitalEndowmentAPIDto.getRequestType().toString());
    	//Original Request to be saved
    	digitalEndowmentAPIAudit.setRequest(D2CUtils.getJsonBlob(digitalEndowmentAPIDto.getDigitalEndowmentAPIRequest()));
    	
    	digitalEndowmentAPIDto.setAudit(digitalEndowmentAPIAudit);
    	digitalEndowmentAPIService.saveDigitalEndowmentAPIAudit(digitalEndowmentAPIAudit);
    }
    
	private DigitalEndowmentAPIResponse process(DigitalEndowmentAPIDto digitalEndowmentAPIDto, DigitalEndowmentAPIESubPayment payment) throws ProposalFetchException, DigitalEndowmentAPIException  {
    	DigitalEndowmentAPIResponse response = null;
    	DigitalEndowmentAPIDto.DigitalEndowmentAPIType apiType = digitalEndowmentAPIDto.getRequestType();
    	
    	String proposalNumber;
    	DigitalEndowmentAPIPolicy policy;
        try {
            if (DigitalEndowmentAPIDto.DigitalEndowmentAPIType.APPLICATION_ESUBMISSION.equals(apiType)) {
                proposalNumber = digitalEndowmentAPIService.fetchProposalNumber(digitalEndowmentAPIDto);
                digitalEndowmentAPIService.submitCustomerApplication(digitalEndowmentAPIDto, payment, proposalNumber);

                List<DigitalEndowmentAPIPolicy> policies = new ArrayList<DigitalEndowmentAPIPolicy>();
                policy = new DigitalEndowmentAPIPolicy();
                policy.setPolicyNo(proposalNumber);
                policies.add(policy);
                
                DigitalEndowmentAPIResponseSystem reponseSystem = new DigitalEndowmentAPIResponseSystem();
                reponseSystem.setStatus("success");
                reponseSystem.setApiVersion("1.0");
                
                DigitalEndowmentAPIResponsePayload payload = new DigitalEndowmentAPIResponsePayload();
                payload.setPolicy(policies);
                payload.setResponseCode("100");
                payload.setResponseDesc("ESubmission successful");
                
                response = DigitalEndowmentAPIResponse.builder().system(reponseSystem).payload(payload).build();
            }
        } catch (ProposalFetchException ex) {
            logger.error("Exception occurred while processing : " + digitalEndowmentAPIDto + " " + ex.getMessage(), ex);
            throw new ProposalFetchException("Exception occurred while Digital Endowment API Processing - Fetch Proposal.");
   
		} catch (DigitalEndowmentAPIException ex) {
            logger.error("Exception occurred while processing : " + digitalEndowmentAPIDto + " " + ex.getMessage(), ex);
            throw new DigitalEndowmentAPIException("Exception occurred while Digital Endowment API Processing - esubmission-service.");
   
		} catch (Exception exception) {
	        logger.error("Exception occurred while processing : " + digitalEndowmentAPIDto + " " + exception.getMessage(), exception);
	        digitalEndowmentAPIDto.getErrors().add(DigitalEndowmentAPIExceptionType.ESUBMISSION_ERROR);
	        throw new DigitalEndowmentAPIException("Exception occurred while Digital Endowment API Processing - esubmission-service.");
	    }
        if (response == null) {
        	digitalEndowmentAPIDto.getErrors().add(DigitalEndowmentAPIExceptionType.ESUBMISSION_ERROR);
            throw new DigitalEndowmentAPIException("Response Not Received");
        }
        return response;
    }

    
    private void validatePayload(DigitalEndowmentAPIDto digitalEndowmentAPIDto){
        String payload = digitalEndowmentAPIDto.getRequestJson();
        String htmlPattern = "<(\"[^\"]*\"|'[^']*'|[^'\">])*>";
        Pattern pattern = Pattern.compile(htmlPattern);
        Matcher matcher = pattern.matcher(payload);

        if(matcher.find()){
        	digitalEndowmentAPIDto.getErrors().add(DigitalEndowmentAPIExceptionType.INVALID_JSON_PAYLOAD_CONTAIN_SCRIPT);
        }
    }
    
    private void validate(DigitalEndowmentAPIDto digitalEndowmentAPIDto) {

        List<DigitalEndowmentAPIExceptionType> errorList = new ArrayList<>();

        try {
            if (DigitalEndowmentAPIDto.DigitalEndowmentAPIType.APPLICATION_ESUBMISSION.equals(digitalEndowmentAPIDto.getRequestType())) {

				DigitalEndowmentAPIRequest request = digitalEndowmentAPIDto.getDigitalEndowmentAPIRequest();
				digitalEndowmentAPIDto.setDpTransactionId(D2CUtils.generateUUID());
                
                validateSystemObjects(request, errorList);
               
                if(errorList.size()>0) {
                	digitalEndowmentAPIDto.getErrors().addAll(errorList);
                	return;
                }
                
                validatePayloadObjects(request, errorList);
                
                if(errorList.size()>0) {
                	digitalEndowmentAPIDto.getErrors().addAll(errorList);
                	return;
                }
                
                validateSubmission(request, digitalEndowmentAPIDto, errorList);
                
                if(errorList.size()>0) {
                	digitalEndowmentAPIDto.getErrors().addAll(errorList);
                	return;
                }
                
                //LOADTEST
                validatePayloadDetails(request, errorList);
                validateClient(request, errorList);
                validateSQS(request, digitalEndowmentAPIDto, errorList);
                validateQuestionnaire(request.getPayload().getQuestionnaire(), errorList);
                validatePayment(request.getPayload().getPayment(), request, errorList);
                validateDocument(request, errorList);
                
				digitalEndowmentAPIDto.getErrors().addAll(errorList);

            }
      
        } catch (Exception exception) {
            logger.error("Exception occurred while converting PayLoad to Object Type : " + D2CUtils.removeCRLF(digitalEndowmentAPIDto.getDpTransactionId()) + " " + exception.getMessage(), exception);
            if(exception instanceof ParseException){
            	digitalEndowmentAPIDto.getErrors().add(DigitalEndowmentAPIExceptionType.INVALID_DOB);
            }else{
            	digitalEndowmentAPIDto.getErrors().add(DigitalEndowmentAPIExceptionType.INTERNAL_ERROR);
            }

        }

    }
    
    private DigitalEndowmentAPIResponse getErrorResponse(DigitalEndowmentAPIDto digitalEndowmentAPIDto) {

        buildErrorResponse(digitalEndowmentAPIDto);

        return digitalEndowmentAPIDto.getDigitalEndowmentAPIResponse();
    }

    
    private void buildErrorResponse(DigitalEndowmentAPIDto digitalEndowmentAPIDto) {
        if (CollectionUtils.isNotEmpty(digitalEndowmentAPIDto.getErrors())) {
            if (DigitalEndowmentAPIDto.DigitalEndowmentAPIType.APPLICATION_ESUBMISSION.equals(digitalEndowmentAPIDto.getRequestType())) {
            	
            	DigitalEndowmentAPIResponseSystem reponseSystem = new DigitalEndowmentAPIResponseSystem();
                reponseSystem.setStatus("failed");
                reponseSystem.setApiVersion("1.0");
                
                DigitalEndowmentAPIResponsePayload payload = new DigitalEndowmentAPIResponsePayload();

                payload.setResponseCode("400");
                payload.setResponseDesc("ESubmission failed");
                payload.setErrors(getDigitalEndowmentAPIErrors(removeDuplicates(digitalEndowmentAPIDto.getErrors())));
                
            	DigitalEndowmentAPIResponse response = DigitalEndowmentAPIResponse.builder().system(reponseSystem).payload(payload).build();
                digitalEndowmentAPIDto.setDigitalEndowmentAPIResponse(response);
                logger.info("Digital Endowment API Build Error Response for {} txnId {}", D2CUtils.removeCRLF(digitalEndowmentAPIDto.getDpTransactionId()));

            } 
        } else {
            logger.info("No errors defined : {}", digitalEndowmentAPIDto);
        }
    }
    
    // Function to remove duplicates from an ArrayList
	public List<DigitalEndowmentAPIExceptionType> removeDuplicates(List<DigitalEndowmentAPIExceptionType> list)
    {
  
        // Create a new ArrayList
        List<DigitalEndowmentAPIExceptionType> newList = new ArrayList<DigitalEndowmentAPIExceptionType>();
  
        // Traverse through the first list
        for (DigitalEndowmentAPIExceptionType element : list) {
  
            // If this element is not present in newList
            // then add it
            if (!newList.contains(element)) {
  
                newList.add(element);
            }
        }
  
        // return the new list
        return newList;
    }

    private List<DigitalEndowmentAPIError> getDigitalEndowmentAPIErrors(List<DigitalEndowmentAPIExceptionType> errorList) {

        List<DigitalEndowmentAPIError> digitalEndowmentAPIErrors = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(errorList)) {
            for (DigitalEndowmentAPIExceptionType error : errorList) {
            	DigitalEndowmentAPIError digitalEndowmentAPIError = new DigitalEndowmentAPIError();
            	digitalEndowmentAPIError.setCode(error.getCode());
            	digitalEndowmentAPIError.setDescription(error.getMessage());
                digitalEndowmentAPIErrors.add(digitalEndowmentAPIError);
            }
        } else {
            logger.info("No errors defined.");
        }
        return digitalEndowmentAPIErrors;
    }
    
    private void validateClient(DigitalEndowmentAPIRequest request, List<DigitalEndowmentAPIExceptionType> errorList) {
    	DigitalEndowmentAPIClient clientProfile;
    	
    	Predicate<String> genderValidator = gender -> Constants.GENDER.contains(gender);
        Predicate<String> residencyStatusValidator = rs -> Constants.RES_STATUS_LIST.contains(rs);
        
        String nationality;
        String countryOfBirth;
    	
    	if (request.getPayload().getClients().size() < 0) {
            errorList.add(DigitalEndowmentAPIExceptionType.INVALID_CLIENTPROFILE);
            return;
        }
    	
    	clientProfile = request.getPayload().getClients().get(0);

		DigitalEndowmentAPIExceptionType validationMessage = D2CUtils.validateGivenNameDE(clientProfile.getGivenName());
		if (validationMessage != null)
			errorList.add(validationMessage);
		
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		boolean nricAllowed;
		List <CustomerApplication> caList = customerApplicationService.findCustomerApplicationByNricFin(clientProfile.getNric());

		for (CustomerApplication ca:caList) {
			try {
				nricAllowed = DateUtil.getMinutesPassed(df.parse(ca.getCreateDate())) <= 5;
				
				if(nricAllowed) {
					errorList.add(DigitalEndowmentAPIExceptionType.NRIC_CHECK_FAIL);
					break;
				}
			} catch (ParseException e) {
				errorList.add(DigitalEndowmentAPIExceptionType.NRIC_DATE_PARSE_ERROR);
			}
		}


		validationMessage = D2CUtils.validateSurNameDE(clientProfile.getSurname());
		if (validationMessage != null)
			errorList.add(validationMessage);

		if (clientProfile.getDateOfBirth() == null) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_DOB);
		}
		else {
			if (StringUtils.isEmpty(clientProfile.getDateOfBirth())) {
	            errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_DOB);
	        } else {
	            clientProfile.setDateOfBirth(clientProfile.getDateOfBirth().trim());
	            if (clientProfile.getDateOfBirth().length() > 10 || StringUtils.isEmpty(DateUtil.checkDateFormatStrict(clientProfile.getDateOfBirth(), Constants.DOBFORMAT))) {
	                errorList.add(DigitalEndowmentAPIExceptionType.INVALID_DOB);
	            } 
	        }
			
		}

		if (clientProfile.getGender() == null) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_GENDER_TYPE);
		} else {
			if (StringUtils.isEmpty(clientProfile.getGender())) {
                errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_GENDER);
            } else {
                clientProfile.setGender(clientProfile.getGender().trim());
                if (!genderValidator.test(clientProfile.getGender())) {
                    errorList.add(DigitalEndowmentAPIExceptionType.INVALID_GENDER_TYPE);
                }
            }
		}
		
		if(clientProfile.getNationality() == null) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_NATIONALITY_CODE);
		} else {
			if (StringUtils.isEmpty(clientProfile.getNationality())) {
	            errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_NATIONALITY_CODE);
	        } else {
	        	MyInfoMapping myInfoMapping = myInfoMappingRepository.findByMyInfoCode(clientProfile.getNationality());
	        	if(myInfoMapping != null) {
	        		nationality = myInfoMapping.getCode();
	        	} else {
	        		nationality = clientProfile.getNationality().trim();
	        	}
	            if (Constants.NOT_APPLICABLE.equals(customerApplicationService.findNationalityName(nationality))) {
	                errorList.add(DigitalEndowmentAPIExceptionType.INVALID_NATIONALITY_CODE);
	            }
	        }
		}
		
		if(clientProfile.getCountryOfBirth() == null) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_COUNTRYOFBIRTH);
		} else {
			if (StringUtils.isEmpty(clientProfile.getCountryOfBirth())) {
	            errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_COUNTRYOFBIRTH);
	        } else {
	        	MyInfoMapping myInfoMapping = myInfoMappingRepository.findByMyInfoCode(clientProfile.getCountryOfBirth());
	        	if(myInfoMapping != null) {
	        		countryOfBirth = myInfoMapping.getCode();
	        	} else {
	        		countryOfBirth = clientProfile.getCountryOfBirth().trim();
	        	}
	            if (Constants.NOT_APPLICABLE.equals(customerApplicationService.findNationalityName(countryOfBirth))) {
	                errorList.add(DigitalEndowmentAPIExceptionType.INVALID_COUNTRYOFBIRTH);
	            }
	        }
		}
		
		if(clientProfile.getNric() == null) {
			if(clientProfile.getFin() != null && !StringUtils.isEmpty(clientProfile.getFin()) ){
        		clientProfile.setNric(clientProfile.getFin().trim());
        	} else {
        		errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_NRIC);

        		if(clientProfile.getNationality() != null && !clientProfile.getNationality().contentEquals(Constants.SINGAPORE)){
        			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_FIN);
        		}
        	}
		}
		else {
			int result = nricValidator.apply(clientProfile.getNric());
	        if (result == 1) {
	        	if(clientProfile.getFin() != null && !StringUtils.isEmpty(clientProfile.getFin()) ){
            		clientProfile.setNric(clientProfile.getFin().trim());
            	} else {
            		errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_NRIC);

            		if(clientProfile.getNationality() != null && !clientProfile.getNationality().contentEquals(Constants.SINGAPORE)){
            			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_FIN);
            		}
            	}
	        } else {
	            clientProfile.setNric(clientProfile.getNric().trim());
	            if (result == 2) {
	                errorList.add(DigitalEndowmentAPIExceptionType.NRIC_TOO_LONG);
	            }
	            if (result == 3) {
	            	//LOADTEST
	                errorList.add(DigitalEndowmentAPIExceptionType.INVALID_NRIC);
	            }
	        }
		}
		
		if (StringUtils.isEmpty(clientProfile.getResidency())) {
            errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_RESIDENCY_STATUS);
        } else {
            clientProfile.setResidency(clientProfile.getResidency().trim());
            if (!residencyStatusValidator.test(clientProfile.getResidency())) {
                errorList.add(DigitalEndowmentAPIExceptionType.INVALID_RESIDENCY_STATUS);
            } 
            
            else if (Constants.RESIDENCY_OTHER_AB.equals(clientProfile.getResidency())) {
                
            	if (StringUtils.isEmpty(clientProfile.getPassType())) {
                    errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_PASSTYPE);
                } 
                
            }
            
        }

        
        
        if (clientProfile.getContact() != null && StringUtils.isEmpty(clientProfile.getContact().getHomePhoneArea())) {
            errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_CONTACT);
        }

        if (clientProfile.getContact() != null && StringUtils.isEmpty(clientProfile.getContact().getHomePhoneArea())) {
            errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_MOBILE_NUMBER);
        } else {
            clientProfile.getContact().setHomePhoneArea(clientProfile.getContact().getHomePhoneArea().trim());
            if (clientProfile.getContact().getHomePhoneArea().length() > 15) {
                errorList.add(DigitalEndowmentAPIExceptionType.MOBILE_NUMBER_TOO_LONG);
            } else {
            	if (clientProfile.getContact().getHomePhoneArea().startsWith("65")) {
                    String number = clientProfile.getContact().getHomePhoneArea().substring(3);
                    if (!(number.length() == 8 && (number.startsWith("8") || number.startsWith("9")))) {
                        errorList.add(DigitalEndowmentAPIExceptionType.INVALID_MOBILE_NUMBER);
                    }
                }
            }
        }

        if (clientProfile.getContact() != null && StringUtils.isEmpty(clientProfile.getContact().getEmail())) {
            errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_EMAIL);
        } else {
        	clientProfile.getContact().setEmail(clientProfile.getContact().getEmail().trim());

            if (clientProfile.getContact().getEmail().length() > 100) {
                errorList.add(DigitalEndowmentAPIExceptionType.EMAIL_TOO_LONG);
            }
            Pattern pattern = Pattern.compile(Constants.EMAIL_PATTERN);
            Matcher matcher = pattern.matcher(clientProfile.getContact().getEmail());
            if (!matcher.matches()) {
                errorList.add(DigitalEndowmentAPIExceptionType.INVALID_EMAIL);
            }
        }
        
        validateResidencyAddress(clientProfile.getAddresses().get(0), errorList);
        validateMailingAddress(clientProfile.getAddresses().get(1), errorList);
    

        //INVALID_CURRENT_EMPLOYMENT
		if (StringUtils.isNotEmpty(clientProfile.getEmployer())
				& (StringUtils.isEmpty(clientProfile.getBusinessIndustry()) || StringUtils.isEmpty(clientProfile.getOtherIndustry()))
				& StringUtils.isEmpty(clientProfile.getOccupation())
				& StringUtils.isEmpty(clientProfile.getOccupationClass())
				& !(clientProfile.getYearsOfWorking() > 0)) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_CURRENT_EMPLOYMENT);
			if(clientProfile.getEmployer().length() > 30) {
				errorList.add(DigitalEndowmentAPIExceptionType.CURRENT_EMPLOYMENT_TOO_LONG);
			}
		}
		else if (StringUtils.isEmpty(clientProfile.getEmployer())
				& (StringUtils.isNotEmpty(clientProfile.getBusinessIndustry()) || StringUtils.isNotEmpty(clientProfile.getOtherIndustry()))
				& StringUtils.isEmpty(clientProfile.getOccupation())
				& StringUtils.isEmpty(clientProfile.getOccupationClass())
				& !(clientProfile.getYearsOfWorking() > 0)) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_CURRENT_EMPLOYMENT);
		}
		else if (StringUtils.isEmpty(clientProfile.getEmployer())
				& (StringUtils.isEmpty(clientProfile.getBusinessIndustry()) || StringUtils.isEmpty(clientProfile.getOtherIndustry()))
				& StringUtils.isNotEmpty(clientProfile.getOccupation())
				& StringUtils.isEmpty(clientProfile.getOccupationClass())
				& !(clientProfile.getYearsOfWorking() > 0)) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_CURRENT_EMPLOYMENT);
		}
		else if (StringUtils.isEmpty(clientProfile.getEmployer())
				& (StringUtils.isEmpty(clientProfile.getBusinessIndustry()) || StringUtils.isEmpty(clientProfile.getOtherIndustry()))
				& StringUtils.isEmpty(clientProfile.getOccupation())
				& StringUtils.isNotEmpty(clientProfile.getOccupationClass())
				& !(clientProfile.getYearsOfWorking() > 0)) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_CURRENT_EMPLOYMENT);
		}
		else if (StringUtils.isEmpty(clientProfile.getEmployer())
				& (StringUtils.isEmpty(clientProfile.getBusinessIndustry()) || StringUtils.isEmpty(clientProfile.getOtherIndustry()))
				& StringUtils.isEmpty(clientProfile.getOccupation())
				& StringUtils.isEmpty(clientProfile.getOccupationClass())
				& !(clientProfile.getYearsOfWorking() == 0)) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_CURRENT_EMPLOYMENT);
		}
		else if (StringUtils.isEmpty(clientProfile.getEmployer())
				& (StringUtils.isEmpty(clientProfile.getBusinessIndustry()) || StringUtils.isEmpty(clientProfile.getOtherIndustry()))
				& StringUtils.isEmpty(clientProfile.getOccupation())
				& StringUtils.isEmpty(clientProfile.getOccupationClass())
				& !(clientProfile.getYearsOfWorking() > 0) 
				& !(clientProfile.getAnnualIncome() == 0)) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_CURRENT_EMPLOYMENT);
		} else {
			if(clientProfile.getEmployer().length() > 30) {
				errorList.add(DigitalEndowmentAPIExceptionType.CURRENT_EMPLOYMENT_TOO_LONG);
			}
			
			if (StringUtils.isEmpty(clientProfile.getOccupationClass())) {
	            errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_OCCUPATION_CLASS);
	        }
			
	        if (StringUtils.isEmpty(clientProfile.getOccupation())) {
	            errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_OCCUPATION_CODE);
	        } else {
	            clientProfile.setOccupation(clientProfile.getOccupation().trim());
	            Occupation occupation = occupationService.getOccupationbyCode(clientProfile.getOccupation());

	            if (occupation == null) {
	                errorList.add(DigitalEndowmentAPIExceptionType.INVALID_OCCUPATION_CODE);
	            }

	            if (occupation != null && !StringUtils.equalsIgnoreCase(clientProfile.getOccupationClass(), occupation.getClassOccupation())) {
	                errorList.add(DigitalEndowmentAPIExceptionType.INVALID_OCCUPATION_CLASS);
	            }
	        }
	       
	        
	        if (StringUtils.isEmpty(clientProfile.getBusinessIndustry())) {
	            errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_INDUSTRY_CODE);
	        } else {
	            clientProfile.setBusinessIndustry(clientProfile.getBusinessIndustry().trim());
	            if (!(ChannelAPIDataUtils.getIndustryByCode(clientProfile.getBusinessIndustry()).isPresent())) {
	                errorList.add(DigitalEndowmentAPIExceptionType.INVALID_INDUSTRY_CODE);
	            } else if (!Constants.INDUSTRY_CATEGORY_OTHER.contains(clientProfile.getBusinessIndustry())) {
	                if (StringUtils.isEmpty(clientProfile.getEmployer())) {
	                    errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_EMPLOYER_NAME);
	                }
	                int val;
	                if ((val = mandatoryAndMaxNValidator.apply(clientProfile.getEmployer(), 30)) > 0) {
	                    errorList.add(val == 1 ? DigitalEndowmentAPIExceptionType.EMPTY_EMPLOYER_NAME : DigitalEndowmentAPIExceptionType.EMPLOYER_NAME_TOO_LONG);
	                } 
	            }
	        }

		}
		
		//INVALID_PREVIOUS_EMPLOYMENT
		if (StringUtils.isNotEmpty(clientProfile.getPreviousEmployer())
				& StringUtils.isEmpty(clientProfile.getPreviousBusinessIndustry())
				& StringUtils.isEmpty(clientProfile.getPreviousOccupation())
				& StringUtils.isEmpty(clientProfile.getPreviousOccupation())
				& !(clientProfile.getPreviousYearsOfWorking() > 0)
				& !(clientProfile.getPreviousAnnualIncome().compareTo(BigDecimal.ZERO) > 0)) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_PREVIOUS_EMPLOYMENT);
		}
		else if (StringUtils.isEmpty(clientProfile.getPreviousEmployer())
				&& StringUtils.isNotEmpty(clientProfile.getPreviousBusinessIndustry())
				& StringUtils.isEmpty(clientProfile.getPreviousOccupation())
				& StringUtils.isEmpty(clientProfile.getPreviousOccupation())
				& !(clientProfile.getPreviousYearsOfWorking() > 0)
				& !(clientProfile.getPreviousAnnualIncome().compareTo(BigDecimal.ZERO) > 0)) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_PREVIOUS_EMPLOYMENT);
		}
		else if (StringUtils.isEmpty(clientProfile.getPreviousEmployer())
				& StringUtils.isEmpty(clientProfile.getPreviousBusinessIndustry())
				& StringUtils.isNotEmpty(clientProfile.getPreviousOccupation())
				& StringUtils.isEmpty(clientProfile.getPreviousOccupation())
				& !(clientProfile.getPreviousYearsOfWorking() > 0)
				& !(clientProfile.getPreviousAnnualIncome().compareTo(BigDecimal.ZERO) > 0)) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_PREVIOUS_EMPLOYMENT);
		}
		else if (StringUtils.isEmpty(clientProfile.getPreviousEmployer())
				& StringUtils.isEmpty(clientProfile.getPreviousBusinessIndustry())
				& StringUtils.isEmpty(clientProfile.getPreviousOccupation())
				& StringUtils.isNotEmpty(clientProfile.getPreviousOccupation())
				& !(clientProfile.getPreviousYearsOfWorking() > 0)
				& !(clientProfile.getPreviousAnnualIncome().compareTo(BigDecimal.ZERO) > 0)) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_PREVIOUS_EMPLOYMENT);
		}
		else if (StringUtils.isEmpty(clientProfile.getPreviousEmployer())
				& StringUtils.isEmpty(clientProfile.getPreviousBusinessIndustry())
				& StringUtils.isEmpty(clientProfile.getPreviousOccupation())
				& StringUtils.isEmpty(clientProfile.getPreviousOccupation())
				& !(clientProfile.getPreviousYearsOfWorking() == 0)
				& !(clientProfile.getPreviousAnnualIncome().compareTo(BigDecimal.ZERO) > 0)) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_PREVIOUS_EMPLOYMENT);
		}
		
		//INVALID_INVESTMENT_INCOME
		if (StringUtils.isNotEmpty(clientProfile.getInvestmentName())
				& StringUtils.isEmpty(clientProfile.getInvestmentType())
				& !(clientProfile.getInvestmentIncomeValue().compareTo(BigDecimal.ZERO) > 0)
				& !(clientProfile.getMonthInvestmentIncomeEarned() > 0)) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_INVESTMENT_INCOME);
		}
		else if (StringUtils.isEmpty(clientProfile.getInvestmentName())
				& StringUtils.isNotEmpty(clientProfile.getInvestmentType())
				& !(clientProfile.getInvestmentIncomeValue().compareTo(BigDecimal.ZERO) > 0)
				& !(clientProfile.getMonthInvestmentIncomeEarned() > 0)) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_INVESTMENT_INCOME);
		}
		else if (StringUtils.isEmpty(clientProfile.getInvestmentName())
				& StringUtils.isEmpty(clientProfile.getInvestmentType())
				& !(clientProfile.getInvestmentIncomeValue().compareTo(BigDecimal.ZERO) == 0)
				& !(clientProfile.getMonthInvestmentIncomeEarned() > 0)) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_INVESTMENT_INCOME);
		}
		else if (StringUtils.isEmpty(clientProfile.getInvestmentName())
				& StringUtils.isEmpty(clientProfile.getInvestmentType())
				& !(clientProfile.getInvestmentIncomeValue().compareTo(BigDecimal.ZERO) > 0)
				& !(clientProfile.getMonthInvestmentIncomeEarned() == 0)) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_INVESTMENT_INCOME);
		}

		//INVALID_SALE_INCOME
		if (StringUtils.isNotEmpty(clientProfile.getSaleIncomeName())
				& !(clientProfile.getValueOfSaleIncome().compareTo(BigDecimal.ZERO) > 0)
				& !(clientProfile.getSaleIncomeYear() > 0)) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_SALE_INCOME);
		}
		else if (StringUtils.isEmpty(clientProfile.getSaleIncomeName())
				& !(clientProfile.getValueOfSaleIncome().compareTo(BigDecimal.ZERO) == 0)
				& !(clientProfile.getSaleIncomeYear() > 0)) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_SALE_INCOME);
		}
		else if (StringUtils.isEmpty(clientProfile.getSaleIncomeName())
				& !(clientProfile.getValueOfSaleIncome().compareTo(BigDecimal.ZERO) > 0)
				& !(clientProfile.getSaleIncomeYear() == 0)) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_SALE_INCOME);
		} else {
			if (StringUtils.isNotEmpty(clientProfile.getSaleIncomeName())
					& !(clientProfile.getValueOfSaleIncome().compareTo(BigDecimal.ZERO) == 0)
					& !(clientProfile.getSaleIncomeYear() == 0)) {
				if (!(clientProfile.getSaleIncomeYear() >=1900 && clientProfile.getSaleIncomeYear() <=  Calendar.getInstance().get(Calendar.YEAR))){
					errorList.add(DigitalEndowmentAPIExceptionType.INVALID_SALE_INCOME_YEAR);
				}
			}
		}

		//INVALID_POLICY_PROCEED
		if (StringUtils.isNotEmpty(clientProfile.getPolicyProceedPayer())
				& !(clientProfile.getValueOfPolicyProceed().compareTo(BigDecimal.ZERO) > 0)
				& !(clientProfile.getPolicyProceedYear() > 0)) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_POLICY_PROCEED);
		}
		else if (StringUtils.isEmpty(clientProfile.getPolicyProceedPayer())
				& !(clientProfile.getValueOfPolicyProceed().compareTo(BigDecimal.ZERO) == 0)
				& !(clientProfile.getPolicyProceedYear() == 0)) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_POLICY_PROCEED);
		}
		else if (StringUtils.isEmpty(clientProfile.getPolicyProceedPayer())
				& !(clientProfile.getValueOfPolicyProceed().compareTo(BigDecimal.ZERO) > 0)
				& !(clientProfile.getPolicyProceedYear() == 0)) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_POLICY_PROCEED);
		} else {
			if (StringUtils.isNotEmpty(clientProfile.getPolicyProceedPayer())
					& !(clientProfile.getValueOfPolicyProceed().compareTo(BigDecimal.ZERO) == 0)
					& !(clientProfile.getPolicyProceedYear() == 0)) {
				if (!(clientProfile.getPolicyProceedYear() >=1900 && clientProfile.getPolicyProceedYear() <=  Calendar.getInstance().get(Calendar.YEAR))){
					errorList.add(DigitalEndowmentAPIExceptionType.INVALID_POLICY_PROCEED_YEAR);
				}
			}

		}
		
		//INVALID_INHERITANCE
		if (!(clientProfile.getValueOfInheritance().compareTo(BigDecimal.ZERO) == 0)
				& StringUtils.isEmpty(clientProfile.getGifterName())
				& StringUtils.isEmpty(clientProfile.getGifterRelationship())
				& StringUtils.isEmpty(clientProfile.getGifterEmployer())
				& StringUtils.isEmpty(clientProfile.getGifterBusinessIndustry())
				& StringUtils.isEmpty(clientProfile.getGifterOccupation())
				& !(clientProfile.getGifterYearsOfWorking() > 0)) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_INHERITANCE);
		}
		else if (!(clientProfile.getValueOfInheritance().compareTo(BigDecimal.ZERO) > 0)
				& StringUtils.isNotEmpty(clientProfile.getGifterName())
				& StringUtils.isEmpty(clientProfile.getGifterRelationship())
				& StringUtils.isEmpty(clientProfile.getGifterEmployer())
				& StringUtils.isEmpty(clientProfile.getGifterBusinessIndustry())
				& StringUtils.isEmpty(clientProfile.getGifterOccupation())
				& !(clientProfile.getGifterYearsOfWorking() > 0)) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_INHERITANCE);
		}
		else if (!(clientProfile.getValueOfInheritance().compareTo(BigDecimal.ZERO) > 0)
				& StringUtils.isEmpty(clientProfile.getGifterName())
				& StringUtils.isNotEmpty(clientProfile.getGifterRelationship())
				& StringUtils.isEmpty(clientProfile.getGifterEmployer())
				& StringUtils.isEmpty(clientProfile.getGifterBusinessIndustry())
				& StringUtils.isEmpty(clientProfile.getGifterOccupation())
				& !(clientProfile.getGifterYearsOfWorking() > 0)) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_INHERITANCE);
		}
		else if (!(clientProfile.getValueOfInheritance().compareTo(BigDecimal.ZERO) > 0)
				& StringUtils.isEmpty(clientProfile.getGifterName())
				& StringUtils.isEmpty(clientProfile.getGifterRelationship())
				& StringUtils.isNotEmpty(clientProfile.getGifterEmployer())
				& StringUtils.isEmpty(clientProfile.getGifterBusinessIndustry())
				& StringUtils.isEmpty(clientProfile.getGifterOccupation())
				& !(clientProfile.getGifterYearsOfWorking() > 0)) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_INHERITANCE);
		}
		else if (!(clientProfile.getValueOfInheritance().compareTo(BigDecimal.ZERO) > 0)
				& StringUtils.isEmpty(clientProfile.getGifterName())
				& StringUtils.isEmpty(clientProfile.getGifterRelationship())
				& StringUtils.isEmpty(clientProfile.getGifterEmployer())
				& StringUtils.isNotEmpty(clientProfile.getGifterBusinessIndustry())
				& StringUtils.isEmpty(clientProfile.getGifterOccupation())
				& !(clientProfile.getGifterYearsOfWorking() > 0)) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_INHERITANCE);
		}
		else if (!(clientProfile.getValueOfInheritance().compareTo(BigDecimal.ZERO) > 0)
				& StringUtils.isEmpty(clientProfile.getGifterName())
				& StringUtils.isEmpty(clientProfile.getGifterRelationship())
				& StringUtils.isEmpty(clientProfile.getGifterEmployer())
				& StringUtils.isEmpty(clientProfile.getGifterBusinessIndustry())
				& StringUtils.isNotEmpty(clientProfile.getGifterOccupation())
				& !(clientProfile.getGifterYearsOfWorking() > 0)) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_INHERITANCE);
		}
		else if (!(clientProfile.getValueOfInheritance().compareTo(BigDecimal.ZERO) > 0)
				& StringUtils.isEmpty(clientProfile.getGifterName())
				& StringUtils.isEmpty(clientProfile.getGifterRelationship())
				& StringUtils.isEmpty(clientProfile.getGifterEmployer())
				& StringUtils.isEmpty(clientProfile.getGifterBusinessIndustry())
				& StringUtils.isEmpty(clientProfile.getGifterOccupation())
				& !(clientProfile.getGifterYearsOfWorking() == 0)) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_INHERITANCE);
		}

		//INVALID_PROVIDER
		if (StringUtils.isNotEmpty(clientProfile.getProviderName())
				& StringUtils.isEmpty(clientProfile.getProviderRelationship())
				& StringUtils.isEmpty(clientProfile.getProviderEmployer())
				& StringUtils.isEmpty(clientProfile.getProviderBusinessIndustry())
				& StringUtils.isEmpty(clientProfile.getProviderOccupation())
				& !(clientProfile.getProviderYearsOfWorking() > 0)) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_PROVIDER);
		}
		else if (StringUtils.isEmpty(clientProfile.getProviderName())
				& StringUtils.isNotEmpty(clientProfile.getProviderRelationship())
				& StringUtils.isEmpty(clientProfile.getProviderEmployer())
				& StringUtils.isEmpty(clientProfile.getProviderBusinessIndustry())
				& StringUtils.isEmpty(clientProfile.getProviderOccupation())
				& !(clientProfile.getProviderYearsOfWorking() > 0)) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_PROVIDER);
		}
		else if (StringUtils.isEmpty(clientProfile.getProviderName())
				& StringUtils.isEmpty(clientProfile.getProviderRelationship())
				& StringUtils.isNotEmpty(clientProfile.getProviderEmployer())
				& StringUtils.isEmpty(clientProfile.getProviderBusinessIndustry())
				& StringUtils.isEmpty(clientProfile.getProviderOccupation())
				& !(clientProfile.getProviderYearsOfWorking() > 0)) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_PROVIDER);
		}
		else if (StringUtils.isEmpty(clientProfile.getProviderName())
				& StringUtils.isEmpty(clientProfile.getProviderRelationship())
				& StringUtils.isEmpty(clientProfile.getProviderEmployer())
				& StringUtils.isNotEmpty(clientProfile.getProviderBusinessIndustry())
				& StringUtils.isEmpty(clientProfile.getProviderOccupation())
				& !(clientProfile.getProviderYearsOfWorking() > 0)) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_PROVIDER);
		}
		else if (StringUtils.isEmpty(clientProfile.getProviderName())
				& StringUtils.isEmpty(clientProfile.getProviderRelationship())
				& StringUtils.isEmpty(clientProfile.getProviderEmployer())
				& StringUtils.isEmpty(clientProfile.getProviderBusinessIndustry())
				& StringUtils.isNotEmpty(clientProfile.getProviderOccupation())
				& !(clientProfile.getProviderYearsOfWorking() > 0)) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_PROVIDER);
		}
		else if (StringUtils.isEmpty(clientProfile.getProviderName())
				& StringUtils.isEmpty(clientProfile.getProviderRelationship())
				& StringUtils.isEmpty(clientProfile.getProviderEmployer())
				& StringUtils.isEmpty(clientProfile.getProviderBusinessIndustry())
				& StringUtils.isEmpty(clientProfile.getProviderOccupation())
				& !(clientProfile.getProviderYearsOfWorking() == 0)) {
			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_PROVIDER);
		}
    }
    
    private void validateSQS(DigitalEndowmentAPIRequest request, DigitalEndowmentAPIDto digitalEndowmentAPIDto, List<DigitalEndowmentAPIExceptionType> errorList) {

    	if (request.getPayload().getSqs().getLifeAssureds() == null) {
    		errorList.add(DigitalEndowmentAPIExceptionType.INVALID_LIFE_ASSURED);
    		return;
    	} else {
    		if (request.getPayload().getSqs().getLifeAssureds() !=null && request.getPayload().getSqs().getLifeAssureds().size() == 0) {
    			errorList.add(DigitalEndowmentAPIExceptionType.INVALID_LIFE_ASSURED);
    		} else {
    			if (!StringUtils.equals("ML", request.getPayload().getSqs().getLifeAssureds().get(0).getClientType())) {
    	            errorList.add(DigitalEndowmentAPIExceptionType.INVALID_LIFE_ASSURED_TYPE);
    	        }
    	        
    	        if (request.getPayload().getSqs().getLifeAssureds().get(0).getPlans() == null) {
    	            errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_PRODUCT);
    	            return;
    	        } else {
    	        	if (request.getPayload().getSqs().getLifeAssureds().get(0).getPlans() != null && request.getPayload().getSqs().getLifeAssureds().get(0).getPlans().size() == 0) {
        	            errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_PRODUCT);
        	        }
    	        }
    		}
    	}
    	
    	if(request.getPayload().getSqs().getProductCode() == null) {
    		 errorList.add(DigitalEndowmentAPIExceptionType.INVALID_PRODUCT_CODE);
    	} else {
	        if (StringUtils.isEmpty(request.getPayload().getSqs().getProductCode())) {
	            errorList.add(DigitalEndowmentAPIExceptionType.INVALID_PRODUCT_CODE);
	        } else {
	        	digitalEndowmentAPIDto.setDpProductCode(request.getPayload().getSqs().getProductCode());
	        	
	        	ProductsConfig productsConfig = productConfigService.findBySqsDocId("id_prod_"+request.getPayload().getSqs().getProductCode().toLowerCase());
	
	            if (productsConfig == null || productsConfig.getD2cProduct() == null) {
	                errorList.add(DigitalEndowmentAPIExceptionType.INVALID_PRODUCT_CODE);
	            } else {
	            	digitalEndowmentAPIDto.setDpProductCode(productsConfig.getD2cProduct().getProductCode());
	                Products products = productService.validateProduct(productsConfig.getD2cProduct().getProductCode());
	                if (products == null) {
	                    errorList.add(DigitalEndowmentAPIExceptionType.INVALID_PRODUCT_CODE);
	                } else if (StringUtils.isNotBlank(digitalEndowmentAPIDto.getChannelName())) {
	                    Channels channels = channelService.validateDEChannelByName(digitalEndowmentAPIDto.getChannelName());
	                    if (channels == null) {
	                        errorList.add(DigitalEndowmentAPIExceptionType.INVALID_APP_NAME);
	                    } else {
	                    	digitalEndowmentAPIDto.setChannelName(channels.getChannelCode());
	                        List<ChannelProductMapping> channelProductMappingList = channelProductMappingRepository.findByChannelCodeAndProductCodeAndAASubChannel(channels, products, request.getPayload().getSrcInd());
	                        if (channelProductMappingList == null) {
	                            errorList.add(DigitalEndowmentAPIExceptionType.INVALID_PRODUCT_TYPE);
	                        }
	                    }
	                }
	            }
	        }
    	}
        
    	if(request.getPayload().getSqs().getCurrencyCode() == null) {
    		errorList.add(DigitalEndowmentAPIExceptionType.INVALID_CURRENCY_CODE);
    	} else {
	        if (StringUtils.isEmpty(request.getPayload().getSqs().getCurrencyCode())) {
	            errorList.add(DigitalEndowmentAPIExceptionType.INVALID_CURRENCY_CODE);
	        }
    	}
    	
    	if(request.getPayload().getSqs().getPaymentTypeIndicator() == null) {
    		errorList.add(DigitalEndowmentAPIExceptionType.INVALID_PAYMENT_TYPE_INDICATOR);
    	} else {
	        if (StringUtils.isEmpty(request.getPayload().getSqs().getPaymentTypeIndicator())) {
	            errorList.add(DigitalEndowmentAPIExceptionType.INVALID_PAYMENT_TYPE_INDICATOR);
	        } else {
	        	if(request.getPayload().getSqs().getProductCode() != null && request.getPayload().getSqs().getProductCode().equals(Constants.CATEGORY_PAR_IPF) && !request.getPayload().getSqs().getPaymentTypeIndicator().equals(Constants.SP_PAYMENT)){
	        		errorList.add(DigitalEndowmentAPIExceptionType.INVALID_PAYMENT_TYPE_INDICATOR);
	        	}
	        }
    	}

		List<SQSProductLifeAssured> lifeAsssuredList = request.getPayload().getSqs().getLifeAssureds();

		for (SQSProductLifeAssured lifeAsssured : lifeAsssuredList) {
			if (lifeAsssured.getPlans() != null) {
				if (lifeAsssured.getPlans() != null && !lifeAsssured.getPlans().isEmpty()) {
					for (SQSProductPlan planInfo : lifeAsssured.getPlans()) {
						if (StringUtils.isBlank(planInfo.getPlanName())) {
							errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_PLANNAME);
						}

						if (StringUtils.isBlank(planInfo.getPlanType())) {
							errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_PLANTYPE);
						}

						if (StringUtils.isBlank(planInfo.getPlanCode())) {
							errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_PLANCODE);
						}

						if (StringUtils.isBlank(planInfo.getProductCategoryCode())) {
							errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_PRODUCTCATEGORYCODE);
						}

						if (!(planInfo.getSumAssured() > 0)) {
							errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_SUMASSURED);
						}

						if (!(planInfo.getPremium() > 0) && !(planInfo.getSinglePremium() > 0)) {
							errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_PREMIUMORSINGLEPREMIUM);
						}

						if (!(planInfo.getPremiumTerm() > 0)) {
							errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_PREMIUMTERM);
						}

						if (!(planInfo.getPolicyTerm() > 0)) {
							errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_POLICYTERM);
						}
					}

				}
			}
			if (lifeAsssured.getExtraPlans() != null && !lifeAsssured.getExtraPlans().isEmpty()) {
				for (SQSProductPlan extraPlan : lifeAsssured.getPlans()) {
					if (StringUtils.isBlank(extraPlan.getPlanName())) {
						errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_PLANNAME);
					}

					if (StringUtils.isBlank(extraPlan.getPlanType())) {
						errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_PLANTYPE);
					}

					if (StringUtils.isBlank(extraPlan.getPlanCode())) {
						errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_PLANCODE);
					}

					if (StringUtils.isBlank(extraPlan.getProductCategoryCode())) {
						errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_PRODUCTCATEGORYCODE);
					}

					if (!(extraPlan.getSumAssured() > 0)) {
						errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_SUMASSURED);
					}

					if (!(extraPlan.getPremium() > 0) || !(extraPlan.getSinglePremium() > 0)) {
						errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_PREMIUMORSINGLEPREMIUM);
					}

					if (!(extraPlan.getPremiumTerm() > 0)) {
						errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_PREMIUMTERM);
					}

					if (!(extraPlan.getPolicyTerm() > 0)) {
						errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_POLICYTERM);
					}
				}
			}
			if (lifeAsssured.getRiders() != null && !lifeAsssured.getExtraPlans().isEmpty()) {
				for (SQSProductPlan riders : lifeAsssured.getPlans()) {
					if (StringUtils.isBlank(riders.getPlanName())) {
						errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_PLANNAME);
					}

					if (StringUtils.isBlank(riders.getPlanType())) {
						errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_PLANTYPE);
					}

					if (StringUtils.isBlank(riders.getPlanCode())) {
						errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_PLANCODE);
					}

					if (StringUtils.isBlank(riders.getProductCategoryCode())) {
						errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_PRODUCTCATEGORYCODE);
					}

					if (!(riders.getSumAssured() > 0)) {
						errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_SUMASSURED);
					}

					if (!(riders.getPremium() > 0) || !(riders.getSinglePremium() > 0)) {
						errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_PREMIUMORSINGLEPREMIUM);
					}

					if (!(riders.getPremiumTerm() > 0)) {
						errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_PREMIUMTERM);
					}

					if (!(riders.getPolicyTerm() > 0)) {
						errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_POLICYTERM);
					}

				}
			}
		}
    }
    
    
    private void validateResidencyAddress(DigitalEndowmentAPIClientAddress residencyAddress, List<DigitalEndowmentAPIExceptionType> errorList) {
        if (residencyAddress == null) {
            errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_RESIDENCE_ADDRESS);
        } else {
            int result = 0;
            result = mandatoryAndMaxNValidator.apply(residencyAddress.getPostalCode(), 30);
            //LOADTEST
            
            if (result > 0) {
                errorList.add(result == 1 ? DigitalEndowmentAPIExceptionType.RES_ADD_EMPTY_POST_CODE : DigitalEndowmentAPIExceptionType.RES_ADD_POST_CODE_TOO_LONG);
            } else if (!D2CUtils.validateSgPostalCode(residencyAddress.getPostalCode())){
                errorList.add(DigitalEndowmentAPIExceptionType.RES_ADD_POST_CODE_INVALID);
            }
            
            
            result = mandatoryAndMaxNValidator.apply(residencyAddress.getBlock(), 30);
            if (result > 0) {
                errorList.add(result == 1 ? DigitalEndowmentAPIExceptionType.RES_ADD_EMPTY_BLOCK_NUMBER : DigitalEndowmentAPIExceptionType.RES_ADD_BLOCK_NUMBER_TOO_LONG);
            } else if (!D2CUtils.hasOnlyLetterOrNumber(residencyAddress.getBlock())) {
                errorList.add(DigitalEndowmentAPIExceptionType.RES_ADD_BLOCK_NUMBER_INVALID_CHARACTER);
            }
            result = mandatoryAndMaxNValidator.apply(residencyAddress.getStreetName(), 30);
            if (result > 0) {
                errorList.add(result == 1 ? DigitalEndowmentAPIExceptionType.RES_ADD_EMPTY_STREET : DigitalEndowmentAPIExceptionType.RES_ADD_STREET_TOO_LONG);
            } else if (!D2CUtils.validateObjectName(residencyAddress.getStreetName())) {
                errorList.add(DigitalEndowmentAPIExceptionType.RES_ADD_STREET_INVALID_CHARACTER);
            }
            if (StringUtils.isNotEmpty(residencyAddress.getBuildingName())) { // Building name isn't mandatory
                if(residencyAddress.getBuildingName().length() > 30)
                    errorList.add(DigitalEndowmentAPIExceptionType.RES_ADD_BUILDING_NAME_TOO_LONG);
                if (!D2CUtils.validateObjectName(residencyAddress.getBuildingName()))
                    errorList.add(DigitalEndowmentAPIExceptionType.RES_ADD_BUILDING_NAME_INVALID_CHARACTER);
            }
            result = mandatoryAndMaxNValidator.apply(residencyAddress.getFloorUnit(), 30);
            if (result == 2) {
                errorList.add(DigitalEndowmentAPIExceptionType.RES_ADD_UNIT_NO_TOO_LONG);
            } else if (!StringUtils.isEmpty(residencyAddress.getFloorUnit()) && !D2CUtils.validateObjectName(residencyAddress.getFloorUnit())) {
                errorList.add(DigitalEndowmentAPIExceptionType.RES_ADD_UNIT_NO_INVALID_CHARACTER);
            }

            if (StringUtils.isEmpty(residencyAddress.getCountry())) {
                errorList.add(DigitalEndowmentAPIExceptionType.RES_ADD_EMPTY_COUNTRY_CODE);
            } else {
                residencyAddress.setCountry(residencyAddress.getCountry().trim());
                if (!Constants.SINGAPOREAN.equalsIgnoreCase(residencyAddress.getCountry())) {
                    errorList.add(DigitalEndowmentAPIExceptionType.RES_ADD_INVALID_COUNTRY_CODE);
                }
            }
        }
    }

    private void validateMailingAddress(DigitalEndowmentAPIClientAddress mailingAddress, List<DigitalEndowmentAPIExceptionType> errorList) {
        Function<String, Boolean> max30Validator = str -> {
            return (StringUtils.isEmpty(str) || str.length() <= 30);
        };
        if (mailingAddress != null) {
            int result = 0;
            result = mandatoryAndMaxNValidator.apply(mailingAddress.getPostalCode(), 30);
            if (result > 0) {
                errorList.add(result == 1 ? DigitalEndowmentAPIExceptionType.MAIL_ADD_EMPTY_LINE_1 : DigitalEndowmentAPIExceptionType.MAIL_ADD_LINE_1_TOO_LONG);
            } else if (!D2CUtils.validateObjectName(mailingAddress.getPostalCode())) {
                errorList.add(DigitalEndowmentAPIExceptionType.MAIL_ADD_LINE_1_INVALID_CHARACTER);
            }

            if (!max30Validator.apply(mailingAddress.getBlock())) {
                errorList.add(DigitalEndowmentAPIExceptionType.MAIL_ADD_LINE_2_TOO_LONG);
            }
            if (StringUtils.isNotEmpty(mailingAddress.getBlock()) && !D2CUtils.validateObjectName(mailingAddress.getBlock())) {
                errorList.add(DigitalEndowmentAPIExceptionType.MAIL_ADD_LINE_2_INVALID_CHARACTER);
            }

            if (!max30Validator.apply(mailingAddress.getStreetName())) {
                errorList.add(DigitalEndowmentAPIExceptionType.MAIL_ADD_LINE_3_TOO_LONG);
            }
            if (StringUtils.isNotEmpty(mailingAddress.getStreetName()) && !D2CUtils.validateObjectName(mailingAddress.getStreetName())) {
                errorList.add(DigitalEndowmentAPIExceptionType.MAIL_ADD_LINE_3_INVALID_CHARACTER);
            }

            if (!max30Validator.apply(mailingAddress.getBuildingName())) {
                errorList.add(DigitalEndowmentAPIExceptionType.MAIL_ADD_LINE_4_TOO_LONG);
            }
            if (StringUtils.isNotEmpty(mailingAddress.getBuildingName()) && !D2CUtils.validateObjectName(mailingAddress.getBuildingName())) {
                errorList.add(DigitalEndowmentAPIExceptionType.MAIL_ADD_LINE_4_INVALID_CHARACTER);
            }

            if (!max30Validator.apply(mailingAddress.getFloorUnit())) {
                errorList.add(DigitalEndowmentAPIExceptionType.MAIL_ADD_LINE_5_TOO_LONG);
            }
            if (StringUtils.isNotEmpty(mailingAddress.getFloorUnit()) && !D2CUtils.validateObjectName(mailingAddress.getFloorUnit())) {
                errorList.add(DigitalEndowmentAPIExceptionType.MAIL_ADD_LINE_5_INVALID_CHARACTER);
            }

            if (StringUtils.isEmpty(mailingAddress.getCountry())) {
                errorList.add(DigitalEndowmentAPIExceptionType.MAIL_ADD_EMPTY_COUNTRY_CODE);
            } else {
                mailingAddress.setCountry(mailingAddress.getCountry().trim());
                if (customerApplicationService.findCountryName(mailingAddress.getCountry()).equalsIgnoreCase(Constants.NOT_APPLICABLE)) {
                    errorList.add(DigitalEndowmentAPIExceptionType.MAIL_ADD_INVALID_COUNTRY_CODE);
                }
            }

        }

    }
    
	private void validateQuestionnaire(DigitalEndowmentAPIQuestionnaire questionnaire, List<DigitalEndowmentAPIExceptionType> errorList) {

        Function<String, Integer> mandatoryAndBooleanValidator = str -> {
            if (StringUtils.isEmpty(str)) {
                return 1;
            }
            if (!str.matches("^([0,1])$")) {
                return 2;
            }
            return 0;
        };

        if (questionnaire == null) {
            errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_QUESTIONNAIRE);
        } else {
            int result = 0;
  
            result = mandatoryAndBooleanValidator.apply(questionnaire.getPayByYou());
            if (result > 0) {
                errorList.add(result == 1 ? DigitalEndowmentAPIExceptionType.EMPTY_PAYBYYOU_DECLARATION : DigitalEndowmentAPIExceptionType.INVALID_PAYBYYOU_DECLARATION);
            } else {
            	if (questionnaire.getPayByYou().equals(Constants.CONFIG_FALSE)){
            		errorList.add(DigitalEndowmentAPIExceptionType.INVALID_PAYBYYOU);
            	}
            }

            result = mandatoryAndBooleanValidator.apply(questionnaire.getSingaporeCitizen());
            if (result > 0) {
                errorList.add(result == 1 ? DigitalEndowmentAPIExceptionType.EMPTY_OFFSHORE_DECLARATION : DigitalEndowmentAPIExceptionType.INVALID_OFFSHORE_DECLARATION);
            }
            
            result = mandatoryAndBooleanValidator.apply(questionnaire.getLocationInSingapore());
            if (result > 0) {
                errorList.add(result == 1 ? DigitalEndowmentAPIExceptionType.EMPTY_LOCATION_IN_SG_DECLARATION : DigitalEndowmentAPIExceptionType.INVALID_LOCATION_IN_SG_DECLARATION);
            } else {
            	if (questionnaire.getLocationInSingapore().equals(Constants.CONFIG_FALSE)){
            		errorList.add(DigitalEndowmentAPIExceptionType.INVALID_LOCATION_IN_SG);
            	}
            }
            
            result = mandatoryAndBooleanValidator.apply(questionnaire.getTaxResidentOfSing());
            if (result > 0) {
                errorList.add(result == 1 ? DigitalEndowmentAPIExceptionType.EMPTY_SG_TAX_DECLARATION : DigitalEndowmentAPIExceptionType.INVALID_SG_TAX_DECLARATION);
            } else {
            	if (questionnaire.getTaxResidentOfSing().equals(Constants.CONFIG_FALSE)){
            		errorList.add(DigitalEndowmentAPIExceptionType.INVALID_SG_TAX);
            	}
            }
            
            result = mandatoryAndBooleanValidator.apply(questionnaire.getSingTINisNRIC());
            if (result > 0) {
                errorList.add(result == 1 ? DigitalEndowmentAPIExceptionType.EMPTY_SING_TIN_ISNRIC_DECLARATION : DigitalEndowmentAPIExceptionType.INVALID_SING_TIN_ISNRIC_DECLARATION);
            } else {
            	if (questionnaire.getSingTINisNRIC().equals(Constants.CONFIG_FALSE)){
            		errorList.add(DigitalEndowmentAPIExceptionType.INVALID_SING_TIN_ISNRIC);
            	}
            }

            result = mandatoryAndBooleanValidator.apply(questionnaire.getBeneficialOwners());
            if (result > 0) {
                errorList.add(result == 1 ? DigitalEndowmentAPIExceptionType.EMPTY_BO_DECLARATION : DigitalEndowmentAPIExceptionType.INVALID_BO_DECLARATION);
            } else {
            	if (questionnaire.getBeneficialOwners().equals(Constants.CONFIG_TRUE)){
            		errorList.add(DigitalEndowmentAPIExceptionType.INVALID_BO);
            	}
            }

            result = mandatoryAndBooleanValidator.apply(questionnaire.getFileTaxInUS());
            if (result > 0) {
                errorList.add(result == 1 ? DigitalEndowmentAPIExceptionType.EMPTY_FATCA_DECLARATION : DigitalEndowmentAPIExceptionType.INVALID_FATCA_DECLARATION);
            } else {
            	if (questionnaire.getFileTaxInUS().equals(Constants.CONFIG_TRUE)){
            		errorList.add(DigitalEndowmentAPIExceptionType.INVALID_FATCA);
            	}
            }
            
            result = mandatoryAndBooleanValidator.apply(questionnaire.getNotReplacePolicy());
            if (result > 0) {
                errorList.add(result == 1 ? DigitalEndowmentAPIExceptionType.EMPTY_REPLACEPOLICY_DECLARATION : DigitalEndowmentAPIExceptionType.INVALID_REPLACEPOLICY_DECLARATION);
            } else {
            	if (questionnaire.getNotReplacePolicy().equals(Constants.CONFIG_FALSE)){
            		errorList.add(DigitalEndowmentAPIExceptionType.INVALID_REPLACEPOLICY);
            	}
            }

            result = mandatoryAndBooleanValidator.apply(questionnaire.getIsPoliticallyExposed());
            if (result > 0) {
                errorList.add(result == 1 ? DigitalEndowmentAPIExceptionType.EMPTY_IS_POLITICALLY_EXPOSED_DECLARATION : DigitalEndowmentAPIExceptionType.INVALID_IS_POLITICALLY_EXPOSED_DECLARATION);
            } else {
            	if (questionnaire.getIsPoliticallyExposed().equals(Constants.CONFIG_TRUE)){
            		errorList.add(DigitalEndowmentAPIExceptionType.INVALID_IS_POLITICALLY_EXPOSED);
            	}
            }
            
            result = mandatoryAndBooleanValidator.apply(questionnaire.getMarketingConsent());
            if (result > 0) {
                errorList.add(result == 1 ? DigitalEndowmentAPIExceptionType.EMPTY_MARKETING_CONSENT_DECLARATION : DigitalEndowmentAPIExceptionType.INVALID_MARKETING_CONSENT_DECLARATION);
            } 
            
            result = mandatoryAndBooleanValidator.apply(questionnaire.getEnglishProficiency());
            if (result > 0) {
                errorList.add(result == 1 ? DigitalEndowmentAPIExceptionType.EMPTY_ENGLISH_PROFICIENCY_DECLARATION : DigitalEndowmentAPIExceptionType.INVALID_ENGLISH_PROFICIENCY_DECLARATION);
            } 
        }
    }
    
    private void validatePayment(DigitalEndowmentAPIESubPayment payment, DigitalEndowmentAPIRequest request, List<DigitalEndowmentAPIExceptionType> errorList) {
        if (payment == null) {
            errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_PAYMENT);
        } else {
        	//POC
        	if (StringUtils.isEmpty(payment.getPaymentTransactionId())) {
                errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_PAYMENT_TRANSACTIONID);
            }
        	if (StringUtils.isEmpty(payment.getPaymentSource())) {
                errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_PAYMENT_SOURCE);
            }
        	
        	if (StringUtils.isEmpty(payment.getMercRefNo())) {
                errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_MERCREFNO);
            }
        	
        	//LOADTEST
        	
            if(payment.getMercRefNo() != null && !request.getPayload().getEreferenceNo().equals(payment.getMercRefNo())) {
           	 	errorList.add(DigitalEndowmentAPIExceptionType.INVALID_MERCREFNO); 
            }
            

        }
    }
    
    private void validateSystemObjects(DigitalEndowmentAPIRequest request, List<DigitalEndowmentAPIExceptionType> errorList) {
    	String IPV4_PATTERN = "^(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(\\.(?!$)|$)){4}$";

        Pattern pattern = Pattern.compile(IPV4_PATTERN);
        
    	if (request.getSystem().getAppName() == null) {
            errorList.add(DigitalEndowmentAPIExceptionType.REQUIRED_APP_NAME);
        }

        if (StringUtils.isBlank(request.getSystem().getAppName())) {
            errorList.add(DigitalEndowmentAPIExceptionType.REQUIRED_APP_NAME);
        }
        
        if (request.getSystem().getAppName() != null && !request.getSystem().getAppName().equals(Constants.APPNAME_PULSE)) {
            errorList.add(DigitalEndowmentAPIExceptionType.INVALID_APP_NAME);
        }
        
        if (request.getSystem().getAppKey() == null) {
            errorList.add(DigitalEndowmentAPIExceptionType.REQUIRED_APP_KEY);
        }
        
        if (StringUtils.isBlank(request.getSystem().getAppKey())) {
            errorList.add(DigitalEndowmentAPIExceptionType.REQUIRED_APP_KEY);
        }
        
        if (request.getSystem().getAppKey() != null && !request.getSystem().getAppKey().equals(configProperties.getAppkey())) {
            errorList.add(DigitalEndowmentAPIExceptionType.INVALID_APP_KEY);
        }
        
        if (request.getSystem().getClientIP() == null) {
            errorList.add(DigitalEndowmentAPIExceptionType.REQUIRED_CLIENT_IP);
        }
        
        if (StringUtils.isBlank(request.getSystem().getClientIP())) {
            errorList.add(DigitalEndowmentAPIExceptionType.REQUIRED_CLIENT_IP);
        }
        
        if (request.getSystem().getClientIP() != null && !(pattern.matcher(request.getSystem().getClientIP()).matches()) ) {
            errorList.add(DigitalEndowmentAPIExceptionType.INVALID_CLIENT_IP);
        }
        
        if (request.getSystem().getEncryptionKey() == null) {
            errorList.add(DigitalEndowmentAPIExceptionType.REQUIRED_ENCRYPTION_KEY);
        }
        
    }
    
    private void validateDocument(DigitalEndowmentAPIRequest request, List<DigitalEndowmentAPIExceptionType> errorList) {
    	
    	if (request.getPayload().getDocument() == null) {
			errorList.add(DigitalEndowmentAPIExceptionType.QUOTATION_DOC_NULL);
		} else if (request.getPayload().getDocument() != null
				&& request.getPayload().getDocument().size() == 0) {
			errorList.add(DigitalEndowmentAPIExceptionType.QUOTATION_DOC_EMPTY);
		} else if (request.getPayload().getDocument() != null
				&& request.getPayload().getDocument().size() > 0) {
			
			try {

				List<DigitalEndowmentAPIRequestDocument> docList = request.getPayload().getDocument();
				boolean fetchQuotationErrorFlag = false;
				boolean noQuotationFlag = true;

				for (DigitalEndowmentAPIRequestDocument doc : docList) {
					if (digitalEndowmentAPIService.getFetchQuotationStatus(doc.getDocumentId()) == 0) {
						noQuotationFlag = false;
						break;
					} else if (digitalEndowmentAPIService.getFetchQuotationStatus(doc.getDocumentId()) == 2
							|| digitalEndowmentAPIService.getFetchQuotationStatus(doc.getDocumentId()) == 3
							|| digitalEndowmentAPIService.getFetchQuotationStatus(doc.getDocumentId()) == 4) {
						fetchQuotationErrorFlag = true;
						break;
					}
				}

				if (fetchQuotationErrorFlag) {
					errorList.add(DigitalEndowmentAPIExceptionType.QUOTATION_FETCH_ERROR);
				} else if (noQuotationFlag) {
					errorList.add(DigitalEndowmentAPIExceptionType.QUOTATION_FETCH_SQS_NOT_FOUND);
				}
				
			 } catch (DigitalEndowmentAPIException exception) {
				 errorList.add(DigitalEndowmentAPIExceptionType.QUOTATION_FETCH_ERROR);
			 }
		}
    	
    }
    private void validateSubmission(DigitalEndowmentAPIRequest request, DigitalEndowmentAPIDto digitalEndowmentAPIDto, List<DigitalEndowmentAPIExceptionType> errorList) {
    	Optional<DigitalEndowmentAPIAudit> submissionAuditObj = null;
    	if (request.getPayload() == null) {
            errorList.add(DigitalEndowmentAPIExceptionType.INVALID_REQUEST_PAYLOAD);
            return;
        }

        if (!D2CUtils.validateObjectName(request.getPayload().getTransactionId())) {
            errorList.add(DigitalEndowmentAPIExceptionType.INVALID_TRANSACTION_ID);
        } else if (!D2CUtils.validateObjectName(request.getPayload().getEreferenceNo())) {
            errorList.add(DigitalEndowmentAPIExceptionType.INVALID_EREF); 
        //POC
        } else if (!D2CUtils.validateObjectName(request.getPayload().getPayment().getPaymentTransactionId())) {
             errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_PAYMENT_TRANSACTIONID);   
        } else {
        	digitalEndowmentAPIDto.setTransactionId(request.getPayload().getTransactionId().trim());
        	digitalEndowmentAPIDto.setEreferenceNo(request.getPayload().getEreferenceNo().trim());
        	digitalEndowmentAPIDto.setPaymentTransactionId(request.getPayload().getPayment().getPaymentTransactionId().trim());

            submissionAuditObj = digitalEndowmentAPIService.findByTransactionIDAndApiTypeAndApiStatusOrderByCreateDateDesc(digitalEndowmentAPIDto.getTransactionId(), DigitalEndowmentAPIDto.DigitalEndowmentAPIType.APPLICATION_ESUBMISSION.toString(), Constants.ResponseStatus.SUCCESS);

            if (submissionAuditObj.isPresent()) {
                errorList.add(DigitalEndowmentAPIExceptionType.ALREADY_SUBMITTED_TXN);
            }
            
            //LOADTEST
            //POC
            
            if(digitalEndowmentAPIDto.getDigitalEndowmentAPIRequest().getPayload().getPayment().getPaymentTransactionId() != null && !digitalEndowmentAPIDto.getDigitalEndowmentAPIRequest().getPayload().getPayment().getPaymentTransactionId().equals(Constants.CASH)) {
	            submissionAuditObj = digitalEndowmentAPIService.findByPaymentTransactionIDAndApiTypeAndApiStatusOrderByCreateDateDesc(request.getPayload().getPayment().getPaymentTransactionId(), DigitalEndowmentAPIDto.DigitalEndowmentAPIType.APPLICATION_ESUBMISSION.toString(), Constants.ResponseStatus.SUCCESS);
	
	            if (submissionAuditObj.isPresent()) {
	                errorList.add(DigitalEndowmentAPIExceptionType.ALREADY_SUBMITTED_PMT);
	            }
            }
            
            //LOADTEST	
	        submissionAuditObj = digitalEndowmentAPIService.findByEreferenceNoAndApiTypeAndApiStatusOrderByCreateDateDesc(request.getPayload().getEreferenceNo(), DigitalEndowmentAPIDto.DigitalEndowmentAPIType.APPLICATION_ESUBMISSION.toString(), Constants.ResponseStatus.SUCCESS);
                
            if (submissionAuditObj.isPresent()) {
                errorList.add(DigitalEndowmentAPIExceptionType.ALREADY_SUBMITTED_EREF);
            }
            
        }
    }
    
    private void validatePayloadObjects(DigitalEndowmentAPIRequest request, List<DigitalEndowmentAPIExceptionType> errorList) {
        if (request.getPayload().getClients() == null) {
            errorList.add(DigitalEndowmentAPIExceptionType.INVALID_CLIENTPROFILE);
        }
        
        if (request.getPayload().getSqs() == null) {
            errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_SQS);
        }
   
        if (request.getPayload().getPayment() == null) {
            errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_PAYMENT);
        }
        
        if (request.getPayload().getQuestionnaire() == null) {
            errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_QUESTIONNAIRE);
        }
        
        if (request.getPayload().getDocument() == null) {
            errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_DOCUMENT);
        }
        
   	
    }
    
    private void validatePayloadDetails(DigitalEndowmentAPIRequest request, List<DigitalEndowmentAPIExceptionType> errorList) {
    	if (request.getPayload().getAgentCode() == null) {
            errorList.add(DigitalEndowmentAPIExceptionType.NULL_AGENT);
        }
    	
    	if (request.getPayload().getAgentCode() != null && StringUtils.isEmpty(request.getPayload().getAgentCode())) {
            errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_AGENT);
        }
    	
    	if (request.getPayload().getAgentBizSource() == null) {
            errorList.add(DigitalEndowmentAPIExceptionType.NULL_AGENT_BIZ_SOURCE);
        }
    	
    	if (request.getPayload().getAgentBizSource() != null && StringUtils.isEmpty(request.getPayload().getAgentBizSource())) {
            errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_AGENT_BIZ_SOURCE);
        }
    	
    	if (request.getPayload().getAgentSubSource() == null) {
            errorList.add(DigitalEndowmentAPIExceptionType.NULL_AGENT_SUB_SOURCE);
        }
    	
    	if (request.getPayload().getAgentSubSource() != null && StringUtils.isEmpty(request.getPayload().getAgentSubSource())) {
            errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_AGENT_SUB_SOURCE);
        }
    	
    	if (request.getPayload().getAgentSubSource() != null && !StringUtils.isEmpty(request.getPayload().getAgentSubSource()) && !request.getPayload().getAgentSubSource().equals(Constants.PULSE_SUBCHANNEL)) {
            errorList.add(DigitalEndowmentAPIExceptionType.WRONG_AGENT_SUB_SOURCE);
        }
    	
    	if (request.getPayload().getAgentName() == null) {
            errorList.add(DigitalEndowmentAPIExceptionType.NULL_AGENT_NAME);
        }
    	
    	if (request.getPayload().getAgentName() != null && StringUtils.isEmpty(request.getPayload().getAgentName())) {
            errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_AGENT_NAME);
        }
    	
    	if (request.getPayload().getAgentType() == null) {
            errorList.add(DigitalEndowmentAPIExceptionType.NULL_AGENT_TYPE);
        }
    	
    	if (request.getPayload().getAgentType() != null && StringUtils.isEmpty(request.getPayload().getAgentType())) {
            errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_AGENT_TYPE);
        }
    	
    	if (request.getPayload().getAgentEmail() == null) {
            errorList.add(DigitalEndowmentAPIExceptionType.NULL_AGENT_EMAIL);
        }
    	
    	if (request.getPayload().getAgentEmail() != null && StringUtils.isEmpty(request.getPayload().getAgentEmail())) {
            errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_AGENT_EMAIL);
        }
    	
    	if (request.getPayload().getAgentMobileNumber() == null) {
            errorList.add(DigitalEndowmentAPIExceptionType.NULL_AGENT_MOBILE_NUMBER);
        }
    	
    	if (request.getPayload().getAgentMobileNumber() != null && StringUtils.isEmpty(request.getPayload().getAgentMobileNumber())) {
            errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_AGENT_MOBILE_NUMBER);
        }
    	
    	if (request.getPayload().getAgentChannelCode() == null) {
            errorList.add(DigitalEndowmentAPIExceptionType.NULL_AGENT_CHANNEL_CODE);
        }
    	
    	if (request.getPayload().getAgentChannelCode() != null && StringUtils.isEmpty(request.getPayload().getAgentChannelCode())) {
            errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_AGENT_CHANNEL_CODE);
        }
    	
    	if (request.getPayload().getSrcInd() == null) {
            errorList.add(DigitalEndowmentAPIExceptionType.NULL_SRC_INDICATOR);
        }
    	
    	if (request.getPayload().getMyInfo() == null) {
            errorList.add(DigitalEndowmentAPIExceptionType.NULL_MYINFO);
        }
    }
    

    private final Function<String, Integer> nricValidator = nric -> {
        if (StringUtils.isEmpty(nric)) {
            return 1;
        }
        if (nric.trim().length() > 9) {
            return 2;
        }
        if (!D2CUtils.validateNRIC(nric.trim())) {
            return 3;
        }

        return 0;
    };
    
    private final BiFunction<String, Integer, Integer> mandatoryAndMaxNValidator = (str, max) -> {
        if (StringUtils.isEmpty(str)) {
            return 1;
        }
        if (str.trim().length() > max) {
            return 2;
        }
        return 0;
    };

    @SuppressWarnings("deprecation")
	public DigitalEndowmentAPIESubPayment processPaymentResponse(DigitalEndowmentAPIDto digitalEndowmentAPIDto) throws DigitalEndowmentAPIException{
    	DigitalEndowmentAPIESubPayment paymentInfo;
    	DigitalEndowmentAPIPruPayResponse prupayResponse = null;
    	DigitalEndowmentAPIRequest esubRequest = digitalEndowmentAPIDto.getDigitalEndowmentAPIRequest();
    	
    	List<DigitalEndowmentAPIExceptionType> errorList = new ArrayList<>();
    	StringBuffer params = new StringBuffer();
    	
    	String paymentTransactionId = esubRequest.getPayload().getPayment().getPaymentTransactionId();
    	String eref = esubRequest.getPayload().getPayment().getMercRefNo();
    	String paymentSource = esubRequest.getPayload().getPayment().getPaymentSource();
    	
    	params.append("&referenceNo=");
    	params.append(paymentTransactionId);
    	params.append("&paymentSource=");
    	params.append(paymentSource);
    	params.append("&signature=");
    	
        String messageBytes=paymentTransactionId+paymentSource;
        Signature sig = null;

        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(configProperties.getBase64PrivateKey().getBytes()));
        
		KeyFactory kf;
		try {
			kf = KeyFactory.getInstance("RSA");
			PrivateKey privateKey = kf.generatePrivate(keySpec);

			sig = Signature.getInstance("SHA256WithRSA");
			sig.initSign(privateKey);
			sig.update(messageBytes.getBytes(StandardCharsets.UTF_8));
			byte[] signature = sig.sign();
			params.append(URLEncoder.encode(Base64.getEncoder().encodeToString(signature)));
		
		} catch (NoSuchAlgorithmException ex) {
			logger.error("Digital Endowment API - Invalid Algorithm in Key Factory {} ", D2CUtils.removeCRLF(eref), ex);
		} catch (InvalidKeySpecException ex) {
			logger.error("Digital Endowment API - InvalidKey Spec in Key Factory {} ", D2CUtils.removeCRLF(eref), ex);
		} catch (InvalidKeyException ex) {
			logger.error("Digital Endowment API - Invalid Key in Key Factory {} ", D2CUtils.removeCRLF(eref), ex);
		} catch (SignatureException ex) {
			logger.error("Digital Endowment API - Signature Exception in Key Factory {} ", eref, ex);
		}
		
		try {	
			prupayResponse = digitalEndowmentAPIService.getPrupayResp(params, digitalEndowmentAPIDto);

			if (prupayResponse != null) {

				paymentInfo = esubRequest.getPayload().getPayment();

				paymentInfo.setPaymentMode(Constants.PAYMENTMETHOD_SINGLEPREMIUM);
				/*
				CASH_CHEQUE(1, "Q", "Cash/Cheque"),
				CPF_OA(2, "O", "CPF Ordinary Account"),
				CPF_SA(3, "S", "CPF Special Account"),
				CPF_SRS(4, "R", "Supplementary Retirement Scheme (SRS) Account"),
				PRUCARD(5, "V", "PruCard"),
				INTERBANK_GIRO(6, "Q", "Interbank GIRO"),
				CREDIT_CARD(7, "V", "Credit Card"),
				MINIMUM_SUM_SCHEME(8, "Q", "Minimum Sum Scheme (MSS)"),
				MINIMUM_SUM_PLUS_SCHEME(9, "Q", "Minimum Sum Plus Scheme (MSPS)"),
				MEDISAVE(10, "V", "Medisave"),
				MATURITY_PROCEEDS_TRANSFER(11, "Q", "Maturity Proceeds Transfer"),
				PRUPAY(12, "EN", "ENETS");
				*/
				paymentInfo.setPaymentTransactionId(prupayResponse.getBody().getReferenceNo());
				if(!StringUtils.isBlank(prupayResponse.getBody().getAttributes().getExternalMerchantId())) {
					paymentInfo.setMercId(prupayResponse.getBody().getAttributes().getExternalMerchantId());
				} else {
					errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_MERCHANTID);
				}
				
				if(!StringUtils.isBlank(prupayResponse.getBody().getAttributes().getPgTransactionId())) {
					paymentInfo.setMercRefNo(prupayResponse.getBody().getAttributes().getPgTransactionId());
				} else {
					errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_PGTRANSACTIONID);
				}
				
				//PRUPAYCHANGE
				//LOADTEST
				
				if(prupayResponse.getBody().getAmount()==null) {
					errorList.add(DigitalEndowmentAPIExceptionType.EMPTY_AMOUNT);
				}
				
				if(prupayResponse.getBody().getAmount()!=null && prupayResponse.getBody().getAmount().doubleValue()!=esubRequest.getPayload().getSqs().getLifeAssureds().get(0).getPlans().get(0).getSinglePremium()) {
					errorList.add(DigitalEndowmentAPIExceptionType.AMOUNT_NOT_MATCHING);
				}
				
				
				paymentInfo.setPaymentMethod(Constants.ESUB_ENETS_PAYMENTMETHOD_IDX);
				paymentInfo.setTotalPrem(prupayResponse.getBody().getAmount().doubleValue());
				paymentInfo.setTransAmt(prupayResponse.getBody().getAmount().doubleValue());
				paymentInfo.setAmtPaid(prupayResponse.getBody().getAmount().doubleValue());
				paymentInfo.setCurrency(prupayResponse.getBody().getCurrency());
				paymentInfo.setValidFlag(1);
				paymentInfo.setTydes(Constants.TYDE_NEW_BUSINESS);
				paymentInfo.setPymtMethod(Constants.ESUB_ENETS_PAYMENTMETHOD);
				paymentInfo.setPaymentType(Constants.ESUB_ENETS);
				paymentInfo.setTxnTimestamp(prupayResponse.getBody().getTransactionDate().toString());
				paymentInfo.setReqTimestamp(prupayResponse.getBody().getTransactionDate().toString());
				paymentInfo.setRespTimestamp(prupayResponse.getBody().getTransactionDate().toString());
				paymentInfo.setLastModifiedTimestamp(prupayResponse.getBody().getAttributes().getLastUpdatedTime().toString());
				paymentInfo.setBankRetCode(Constants.PRUPAY_BANKRETURNCODE);
				paymentInfo.setApprovalCode(Constants.PRUPAY_BANKAPPROVALCODE);
				  //Set timestamps and dates
	            SimpleDateFormat parser = new SimpleDateFormat("EEE MMM d HH:mm:ss zzz yyyy");
	            String.valueOf(parser.parse(paymentInfo.getTxnTimestamp()).getTime()/1000);
		        String.valueOf(parser.parse(paymentInfo.getReqTimestamp()).getTime()/1000);
		        String.valueOf(parser.parse(paymentInfo.getRespTimestamp()).getTime()/1000);
		        String.valueOf(parser.parse(paymentInfo.getLastModifiedTimestamp()).getTime()/1000);

			} else {
				errorList.add(DigitalEndowmentAPIExceptionType.INVALID_PAYMENT_RESPONSE);
				logger.info("Digital Endowment API - Unable to get response from PruPay: "+ D2CUtils.removeCRLF(params!=null?params.toString():""));
				throw new DigitalEndowmentAPIException("Unable to retrieve response while calling Prupay requestPayment.");
			}
			digitalEndowmentAPIDto.getErrors().addAll(errorList);

			
		} catch (ParseException ex) {
			jobservice.triggerDigitalEndowmentMail(digitalEndowmentAPIDto.getDpTransactionId(), Constants.MAIL_ERROR_INTERNAL, ex.getMessage() != null ? ex.getMessage() : "Prupay Parse Exception");
			logger.error("Digital Endowment API - Exception in parsing Date from PruPay {} ", D2CUtils.removeCRLF(prupayResponse!=null?prupayResponse.toString():""), ex);
			throw new DPValidationException("Exception occurred in parsing while calling Prupay requestPayment.");
		} catch (Exception ex) {
			jobservice.triggerDigitalEndowmentMail(digitalEndowmentAPIDto.getDpTransactionId(), Constants.MAIL_ERROR_INTERNAL, ex.getMessage() != null ? ex.getMessage() : "Prupay Error");
			logger.error("Digital Endowment API - Exception in getting response from PruPay {} ", prupayResponse, ex);
			throw new DigitalEndowmentAPIException("Unexpected exception occurred while calling Prupay requestPayment.");
		}
		
		return paymentInfo;
	}

}
