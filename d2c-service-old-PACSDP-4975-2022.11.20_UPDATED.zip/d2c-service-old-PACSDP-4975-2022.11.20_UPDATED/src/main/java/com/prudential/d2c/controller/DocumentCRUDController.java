package com.prudential.d2c.controller;

import static com.prudential.d2c.utils.StaticFileUtil.convertObjectToJsonFormat;

import java.sql.Blob;
import java.sql.SQLException;
import java.util.Base64;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.prudential.d2c.common.Constants;
import com.prudential.d2c.entity.Response;
import com.prudential.d2c.entity.dto.Documents;
import com.prudential.d2c.repository.DocumentsRepository;
import com.prudential.d2c.repository.MailListRepository;
import com.prudential.d2c.utils.D2CUtils;
import com.prudential.d2c.utils.DateUtil;
import com.prudential.d2c.utils.DocumentUtil;

@RestController
@EnableAutoConfiguration
public class DocumentCRUDController {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private DocumentsRepository repository;

    @Autowired
    private MailListRepository mailListRepository;

    @RequestMapping(
            value = "/saveDocuments",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public Object submit(@RequestBody Documents entity)  {
        logger.info("Invoking saveDocuments.");
        logger.info("saveDocuments : {} ", convertObjectToJsonFormat(entity));


        if (!isPdf(entity.getFile1())
                || !isPdf(entity.getFile2())
                || !isPdf(entity.getFile3())
                || !isPdf(entity.getFile4())
                || !isPdf(entity.getFile5())
                || !isPdf(entity.getFile6())
                || !isPdf(entity.getFile7())
                || !isPdf(entity.getFile8())
                || !isPdf(entity.getFile9())
                || !isPdf(entity.getFile10())) {
            return new Response(Constants.ERROR_STATUS);
        }

        String customId = entity.getCustomId();
        if(CollectionUtils.isEmpty(mailListRepository.findByCustomId(customId)))
            return new Response(Constants.ERROR_STATUS);

        if (repository.existsById(customId)) {
            logger.info("Delete previous document.");
            logger.info("Delete documents customid: {}", D2CUtils.removeCRLF(customId));
            repository.deleteById(customId);
        }
        entity.setCreateDate(DateUtil.getNowDateTimeWithFormat());
        logger.info("saving documents to db for custom id={}", D2CUtils.removeCRLF(customId));
        repository.save(entity);
        return new Response(Constants.OK_STRING);
    }


    boolean isPdf(Blob file)  {
        if(file == null){
            return true;
        }

        long length=0;
        byte[] base64EncodedBytes=null;
        try {
            length=file.length();
            if(length==0){
                // empty file
                return false;
            }

            base64EncodedBytes = file.getBytes((long) 1, (int) length);

        } catch (SQLException e) {
            logger.error("SQLException occurs, errorMessage={}",e.getMessage());
            return false;
        }


        String fileContent = new String(Base64.getDecoder().decode(base64EncodedBytes));
        if(StringUtils.isBlank(fileContent)){
            logger.error("fileContent is null or blank");
            return false;
        }

        byte[] bytes = fileContent.getBytes();

        //logger.info("base64EncodedString={}",new String(base64EncodedBytes));
        //logger.info(" decrypted fileContent={}",fileContent);

        //PACSDP-4610
        //Validate file MimeType
        //Validate Image content
        //Validate image file size

        //check validMimeType from content
        if(!DocumentUtil.isValidMimeType(bytes,DocumentUtil.MIME_TYPE_PDF)){
            logger.error("Invalid image mime type");
            return false;
        }

        //Validate image file size
        //Max file size for PDF is 7 MB
        float maxFileSize=7*1024*1024;
        if(DocumentUtil.validateImageFileSize(bytes,maxFileSize)){
            logger.error("PDF file size exceeds max limit (7MB)");
            return false;
        }


        try {
            //parse image to validate image content
            int numOfPages=DocumentUtil.parsePdf(bytes);
            logger.info("numOfPages={}",numOfPages);
            if(numOfPages < 1){
                throw new Exception("numOfPages is less than 1");
            }
        }catch(Exception e)  {
            logger.error("Invalid image file, error message={}", e.getMessage());
            return false;
        }

        return true;
    }

    @RequestMapping(
            value = "/fetchDocumentsByCustId",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public Object submitFetch(@RequestBody Documents entity) {
        logger.info("Start fetch documents.......");
        String customId = entity.getCustomId();
        logger.debug("The CUSTOM_ID is: {}", D2CUtils.removeCRLF(customId));
        Documents document = repository.findById(customId).orElse(null);
        logger.info("Complete fetch documents.......");
        return document;
    }

    @RequestMapping(
            value = "/deleteDocumentsByCustId",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public Object submitDelete(@RequestBody Documents entity) {
        logger.info("Start delete documents.......");
        String customId = entity.getCustomId();
        if (repository.existsById(customId)) {
            logger.debug("The CUSTOM_ID is: {}", D2CUtils.removeCRLF(customId));
            repository.deleteById(customId);
        }
        logger.info("Complete delete documents.......");
        return new Response(Constants.OK_STRING);
    }

}
