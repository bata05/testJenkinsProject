package com.prudential.d2c.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.prudential.d2c.common.Constants;
import com.prudential.d2c.entity.DropdownRequest;
import com.prudential.d2c.entity.dto.Dropdown;
import com.prudential.d2c.repository.DropdownRepository;

@RestController
public class DropdownController extends BaseController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private DropdownRepository dropdownRepository;

    /**
     * This method is used to fetch the drop down vales based on the code input
     *
     * @param request
     * @return
     */
    @RequestMapping(
            value = "/dropdowns",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object getDropDownList(@RequestBody DropdownRequest request) {
        // PFCOPT066 nationality
        // PFCOPT070 residential country (same as PFCOPT066)
        // MPFCOPT070 maximum country for one question
        // PFCOPT067 nation people
        logger.info("Invoking dropdowns.");
        String ddc = request.getDropDownCode();
        String[] ddcList = request.getDropDownCodeList();
        List<Dropdown> dropdowns;

        if (Constants.DROPDOWN_CODE_OF_MAXIMUM_COUNTRY.equals(ddc)) {
            dropdowns = getDropdowns(ddc);
        } else if (ddcList != null && ddcList.length > 0) {
            return getDropdownsList(ddcList);
        } else {
            dropdowns = getDropdownsByOptions(ddc);
        }
        logger.debug("Respose from dropdowns : " + dropdowns.toString());
        return dropdowns;

    }

    @Cacheable(cacheNames = "getDropdownsByOptions", sync = true, key = "#ddc", unless = "#result.isEmpty()==true")
    private List<Dropdown> getDropdownsByOptions(String ddc) {

        return dropdownRepository.findByCodeOrderByOptionAsc(ddc);

    }

    @Cacheable(cacheNames = "getDropdowns", sync = true, key = "#ddc", unless = "#result.isEmpty()==true")
    private List<Dropdown> getDropdowns(String ddc) {

        List<Dropdown> dropdowns;
        dropdowns = dropdownRepository.findByCodeOrderByOptionAsc(ddc);
        Dropdown dp = new Dropdown();
        dp.setCode(Constants.DROPDOWN_CODE_OF_MAXIMUM_COUNTRY);
        dp.setOption(Constants.OPTION_OTHERS);
        dropdowns.add(dp);
        return dropdowns;
    }

    @Cacheable(cacheNames = "getDropdownsList", sync = true, key = "#ddcList.toString()", unless = "#result.isEmpty()==true")
    private Map<String, List<Dropdown>> getDropdownsList(String[] ddcList) {

        Map<String, List<Dropdown>> dropdownMapList = new HashMap<>();
        for (String dc : ddcList) {
            dropdownMapList.put(dc, new ArrayList<Dropdown>());
        }
        for (Dropdown dd : dropdownRepository.findByCodeInOrderByOptionAsc(ddcList)) {
            if (!dd.getValue().equals(Constants.DROPDOWN_SPR))
                dropdownMapList.get(dd.getCode()).add(dd);
        }
        return dropdownMapList;

    }

}
