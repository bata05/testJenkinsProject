package com.prudential.d2c.controller;

import com.prudential.d2c.entity.ErrorLogRequest;
import com.prudential.d2c.utils.D2CUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

@RestController
@EnableAutoConfiguration
@RequestMapping(value = "/error")
public class ErrorLogsController extends BaseController {

    public static final Logger logger = LoggerFactory.getLogger(ErrorLogsController.class);

    @RequestMapping(
            value = "/browserErrorLogs",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public void errorLogs(@RequestBody ErrorLogRequest errorLogRequest) {
        if (!"prod".equalsIgnoreCase(configProperties.getServerEnvironment()))
            logger.warn("ErrorLogRequest received: errorMsg {} , errorURL {}, sessionID {}",
                    D2CUtils.removeCRLF(errorLogRequest.getErrorMessage()),
                    D2CUtils.removeCRLF(errorLogRequest.getErrorUrl()),
                    D2CUtils.removeCRLF(errorLogRequest.getErrorSessionId()));
    }
}
