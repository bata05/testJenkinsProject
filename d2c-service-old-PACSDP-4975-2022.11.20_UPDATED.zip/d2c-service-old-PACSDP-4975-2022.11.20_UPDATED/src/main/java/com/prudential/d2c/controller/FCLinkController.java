package com.prudential.d2c.controller;

import com.prudential.d2c.common.Constants;
import com.prudential.d2c.entity.*;
import com.prudential.d2c.entity.config.Products;
import com.prudential.d2c.service.ProductService;
import com.prudential.d2c.service.micro.FCLinkService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;


import java.util.ArrayList;
import java.util.List;

@RestController
@EnableAutoConfiguration
public class FCLinkController {

    @Autowired
    private FCLinkService fcLinkService;

    @Autowired
    private ProductService productService;

    @RequestMapping(value = "/validateFCLink", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public GenericResponse validateFCLink(@RequestBody AdminRequest request){
        GenericResponse response = new GenericResponse();
        String prodCode=request.getProdCode();

        ProductEnum productEnum = ProductEnum.getProductByProductCode(prodCode);

        //Product Code Validation
        if(productEnum == null){
            response.setStatus(Constants.ERROR_STATUS);
            response.setMessage("Product Code is not valid");

            return  response;
        }


        FCLinkRequest fcLinkRequest = new FCLinkRequest();
        List<String> componentList = new ArrayList<String>();
        componentList.add(productEnum.getCompCode());
        fcLinkRequest.setAgentCode(request.getAgentCode());
        fcLinkRequest.setProdCode(request.getProdCode());

        fcLinkRequest.setComponentList(componentList);

        Products product = productService.validateProduct(prodCode);

        boolean sendEmail = request.isSendEmail();

        //Agent Validation (Calling Agent-Service (PruService) )
        response = fcLinkService.checkAgentValid(fcLinkRequest,product.getProductName(),sendEmail);

        return  response;

    }
}
