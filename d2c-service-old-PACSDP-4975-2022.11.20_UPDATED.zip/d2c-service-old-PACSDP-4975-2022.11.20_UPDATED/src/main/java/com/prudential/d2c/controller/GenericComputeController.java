	package com.prudential.d2c.controller;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.prudential.d2c.common.Constants;
import com.prudential.d2c.entity.Component;
import com.prudential.d2c.entity.ComputeBean;
import com.prudential.d2c.entity.D2CResponse;
import com.prudential.d2c.entity.Product;
import com.prudential.d2c.entity.QuestionnaireDetails;
import com.prudential.d2c.entity.dto.CustomerApplication;
import com.prudential.d2c.entity.dto.ProductData;
import com.prudential.d2c.entity.micro.LifeProfile;
import com.prudential.d2c.entity.micro.LifeProfileProposal;
import com.prudential.d2c.entity.micro.LifeProfileProposalAddress;
import com.prudential.d2c.entity.micro.LifeProfileProposalContact;
import com.prudential.d2c.entity.micro.payload.ComputeResponsePayload;
import com.prudential.d2c.exception.D2CException;
import com.prudential.d2c.service.CustomerApplicationService;
import com.prudential.d2c.service.DpApiService;
import com.prudential.d2c.service.PdfService;
import com.prudential.d2c.service.ProductPromoService;
import com.prudential.d2c.service.TranCustomerAppService;
import com.prudential.d2c.service.micro.SQSEngineService;
import com.prudential.d2c.service.validator.ValidationFailure;
import com.prudential.d2c.utils.D2CUtils;
import com.prudential.d2c.utils.DecryptionUtil;

@RestController
@EnableAutoConfiguration
@RequestMapping(value = "/api")
public class GenericComputeController extends BaseController {
    @Autowired
    private DpApiService dpApiService;
    
    @Autowired
    private SQSEngineService sqsEngineService;
    
    @Autowired
    private TranCustomerAppService tranCustomerAppService;
   
    @Autowired
    private CustomerApplicationService customerApplicationService;


    @Autowired
    private PdfService pdfService;

    @Autowired
    private ProductPromoService productPromoService;

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @RequestMapping(value = "/compute", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object compute(@RequestBody ComputeBean computeRequest) {

        computeRequest.setLifeProfiles(this.regenerateLifeProfiles(computeRequest.getLifeProfiles()));

        if(!D2CUtils.isValidComputeRequestAgeAndDob(computeRequest)){
            return D2CResponse.badRequestExceptionMessage();
        }

        // Fetch product details
        String docId = dpApiService.getDocId(computeRequest);
        preprocessProductRequest(computeRequest);
        CustomerApplication customerApplication = customerApplicationService.findCustomerApplicationByCustomId(computeRequest.getLifeProfiles().get(0).getCustomID());
        
        Product prodResFromServ = sqsEngineService.getProducts(docId, computeRequest.getLifeProfiles(), customerApplication);

        // Override product details from service
        computeRequest = dpApiService.overrideProductDetail(computeRequest, prodResFromServ);

        // Validate product specific fields if required
        Set<ValidationFailure> productValidationFailures = dpApiService.validateProduct(computeRequest, prodResFromServ);
        if (CollectionUtils.isNotEmpty(productValidationFailures))
            return D2CResponse.with500ValidationErrors(productValidationFailures);

        // Call compute (and for some computeAll) PRUService.
        ComputeResponsePayload serviceResponse = sqsEngineService.compute(computeRequest, customerApplication);
        if (dpApiService.getValidatorClass(computeRequest).isComputeAllRequiredForComputeCall())
            serviceResponse = dpApiService.getComputeAllForProduct(computeRequest, serviceResponse);
        if(dpApiService.getValidatorClass(computeRequest).isUpdateComputeALLResponseFromComputeRequired())
            dpApiService.overrideComputeAllResponse(serviceResponse, computeRequest);
        // Validate service response from PRUService.
        Set<ValidationFailure> computeValidationFailures = dpApiService.validateCompute(serviceResponse, computeRequest);
        if (CollectionUtils.isNotEmpty(computeValidationFailures))
            return D2CResponse.with500ValidationErrors(productValidationFailures);

        productPromoService.calculateDiscountPromo(serviceResponse);

        return new D2CResponse(Constants.SUCCESS_STATUS, HttpStatus.SC_OK, null, serviceResponse);

    }

    /**
     * This method will be used to call compute all
     *
     * @param computeRequest
     * @return
     * @throws IOException
     */
    @RequestMapping(value = "/computeAll", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object computeAll(@RequestBody ComputeBean computeRequest) {

        computeRequest.setLifeProfiles(regenerateLifeProfiles(computeRequest.getLifeProfiles()));

        if(!D2CUtils.isValidComputeRequestAgeAndDob(computeRequest)){
            return D2CResponse.badRequestExceptionMessage();
        }

        preprocessProductRequest(computeRequest);
        
        CustomerApplication customerApplication = customerApplicationService.findCustomerApplicationByCustomId(computeRequest.getLifeProfiles().get(0).getCustomID());
        // Get product from service and override
        Product prodResFromServ = sqsEngineService.getProducts(computeRequest.getSelectedSQSProducts().get(0).getDocId(), computeRequest.getLifeProfiles(), customerApplication);
        computeRequest = dpApiService.overrideProductDetail(computeRequest, prodResFromServ);

        if (computeRequest != null && CollectionUtils.isNotEmpty(computeRequest.getSelectedSQSProducts()) && CollectionUtils.isNotEmpty(computeRequest.getSelectedSQSProducts().get(0).getComponents()) &&
                Constants.PAS_SP_PROD_CODES.contains(computeRequest.getSelectedSQSProducts().get(0).getProdCode().toUpperCase())) {
            String paymentMode = getPaymentModeForPruActiveSaver(computeRequest.getCustomId());
            if(StringUtils.equalsIgnoreCase(paymentMode, Constants.SRS_PAYMENT)){
                computeRequest.getSelectedSQSProducts().get(0).setProdCode(Constants.CATEGORY_PAS_XR8);
                computeRequest.getSelectedSQSProducts().get(0).setDocId(Constants.DOCID_PREFIX+Constants.CATEGORY_PAS_XR8.toLowerCase());
                computeRequest.getSelectedSQSProducts().get(0).getComponents().get(0).setCompoCode(Constants.CATEGORY_PAS_ES28_COMPO);
            }else if(StringUtils.equalsIgnoreCase(paymentMode, Constants.CASH_PAYMENT)){
                computeRequest.getSelectedSQSProducts().get(0).setProdCode(Constants.CATEGORY_PAS_XB8);
                computeRequest.getSelectedSQSProducts().get(0).setDocId(Constants.DOCID_PREFIX+Constants.CATEGORY_PAS_XB8.toLowerCase());
                computeRequest.getSelectedSQSProducts().get(0).getComponents().get(0).setCompoCode(Constants.CATEGORY_PAS_EC28_COMPO);
            }
        }

        // Override request with compute
        computeRequest = dpApiService.overrideComputeAllRequestWithService(computeRequest, customerApplication);

        ComputeResponsePayload computeResponsePayload = sqsEngineService.computeAll(computeRequest);
        // Generate eref/set eref if already generated
        computeResponsePayload.setErefCode(dpApiService.generateErefNo(computeRequest.getCustomId(), computeResponsePayload));

        // Update Compute response from request - For product specific objects required
        // for further processing.
        dpApiService.updateComputeResponseFromRequest(computeRequest, computeResponsePayload);

        computeRequest.setPdfData(computeResponsePayload.getPdfData());
        computeRequest.setLifeProfiles(computeResponsePayload.getLifeProfiles());
        computeRequest.setSelectedSQSProducts(computeResponsePayload.getSelectedSQSProducts());
        computeRequest.setErefCode(computeResponsePayload.getErefCode());


        // Verify compute all object during summary page load
        Set<ValidationFailure> computeAllValidationFailures = dpApiService.validateComputeAll(computeResponsePayload, computeRequest);

        if (CollectionUtils.isNotEmpty(computeAllValidationFailures))
            return D2CResponse.with500ValidationErrors(computeAllValidationFailures);

        productPromoService.calculateDiscountPromo(computeResponsePayload);

        // Save response for future use
        tranCustomerAppService.saveComputeAllObj(computeResponsePayload, computeRequest.getCustomId(),sqsEngineService.getProductInformation(computeResponsePayload));

        return new D2CResponse(Constants.SUCCESS_STATUS, HttpStatus.SC_OK, null, computeRequest);
    }

    private List<LifeProfile> regenerateLifeProfiles(List<LifeProfile> profiles) {
        List<LifeProfile> regeneratedLifeProfiles = new ArrayList<>(profiles.size());

        for (LifeProfile lifeProfile : profiles) {
            regeneratedLifeProfiles.add(regenerateLifeProfile(lifeProfile));
        }

        return regeneratedLifeProfiles;
    }

    protected LifeProfile regenerateLifeProfile(LifeProfile lifeProfile) {
        LifeProfile newLifeProfile = new LifeProfile();

        try {
            BeanUtils.copyProperties(newLifeProfile, lifeProfile);
        } catch (IllegalAccessException | InvocationTargetException e) {
            throw new D2CException("Regeneration of profile failed.", e);
        }

        if (StringUtils.isNotEmpty(lifeProfile.getName())) newLifeProfile.setName(decrypt(lifeProfile.getName()));
        if (StringUtils.isNotEmpty(lifeProfile.getNric())) newLifeProfile.setNric(decrypt(lifeProfile.getNric()));

        LifeProfileProposal proposal = lifeProfile.getProposal();
        if (proposal != null) {
            if (proposal.getHomeAddress() != null) newLifeProfile.getProposal().setHomeAddress(reGenerateAddress(proposal.getHomeAddress()));
            if (proposal.getMailingAddress() != null) newLifeProfile.getProposal().setMailingAddress(reGenerateAddress(proposal.getMailingAddress()));
            if (proposal.getContact() != null) newLifeProfile.getProposal().setContact(reGenerateContact(proposal.getContact()));
        }

        return newLifeProfile;
    }

    private String decrypt(String req) {
        return DecryptionUtil.decryption(req, configProperties);
    }

    private LifeProfileProposalAddress reGenerateAddress(LifeProfileProposalAddress address) {
        LifeProfileProposalAddress newAddress = new LifeProfileProposalAddress();

        if (StringUtils.isNotEmpty(address.getBuilding())) newAddress.setBuilding(decrypt(address.getBuilding()));
        if (StringUtils.isNotEmpty(address.getCity())) newAddress.setCity(decrypt(address.getCity()));
        if (StringUtils.isNotEmpty(address.getCountryCode())) newAddress.setCountryCode(decrypt(address.getCountryCode()));
        if (StringUtils.isNotEmpty(address.getHouseNo())) newAddress.setHouseNo(decrypt(address.getHouseNo()));
        if (StringUtils.isNotEmpty(address.getPostcode())) newAddress.setPostcode(decrypt(address.getPostcode()));
        if (StringUtils.isNotEmpty(address.getStreet())) newAddress.setStreet(decrypt(address.getStreet()));
        if (StringUtils.isNotEmpty(address.getUnitNo())) newAddress.setUnitNo(decrypt(address.getUnitNo()));

        return newAddress;

    }

    private LifeProfileProposalContact reGenerateContact(LifeProfileProposalContact contact) {
        LifeProfileProposalContact newContact = new LifeProfileProposalContact();

        if (StringUtils.isNotEmpty(contact.getHomePhoneNo())) newContact.setHomePhoneNo(decrypt(contact.getHomePhoneNo()));
        if (StringUtils.isNotEmpty(contact.getMobilePhoneNo())) newContact.setMobilePhoneNo(decrypt(contact.getMobilePhoneNo()));
        if (StringUtils.isNotEmpty(contact.getOfficePhoneNo())) newContact.setOfficePhoneNo(decrypt(contact.getOfficePhoneNo()));

        return newContact;
    }

    @SuppressWarnings({ "unused", "unchecked", "rawtypes" })
	private ProductData getProductInformation(ComputeResponsePayload computeResponsePayLoad) {
        ProductData productData = null;
        if (computeResponsePayLoad != null && CollectionUtils.isNotEmpty(computeResponsePayLoad.getSelectedSQSProducts())) {
            List<String> productCodes = new ArrayList<>();
            List<String> productNames = new ArrayList<>();
            List<String> componentCode = new ArrayList<>();
            List<String> componentNames = new ArrayList<>();
            List<String> pruShieldProductCodes = new ArrayList();
            double totalPremium = 0;
            pruShieldProductCodes.add("PM1");
            pruShieldProductCodes.add("PM2");
            pruShieldProductCodes.add("PMB");
            for (Product product : computeResponsePayLoad.getSelectedSQSProducts()) {
                totalPremium = product.getTotalPremium();
                if (StringUtils.isNotBlank(product.getProdCode()) &&
                        StringUtils.isNotBlank(product.getProdDesc()) && !pruShieldProductCodes.contains(product.getProdCode())) {
                    productCodes.add(product.getProdCode());
                    productNames.add(product.getProdDesc());
                }
                if (CollectionUtils.isNotEmpty(product.getComponents())) {
                    for (Component component : product.getComponents()) {
                        if (StringUtils.isNotBlank(component.getCompoCode()) && StringUtils.isNotBlank(component.getCompoDesc()) && Boolean.TRUE.equals(component.getIsBasic()) && pruShieldProductCodes.contains(product.getProdCode())) {
                            productCodes.add(component.getCompoCode());
                            productNames.add(component.getCompoDesc());
                        } else if (StringUtils.isNotBlank(component.getCompoCode()) && StringUtils.isNotBlank(component.getCompoDesc())) {
                            componentCode.add(component.getCompoCode());
                            componentNames.add(component.getCompoDesc());
                        }
                    }
                }
            }
            if (CollectionUtils.isNotEmpty(productCodes) || CollectionUtils.isNotEmpty(productNames) || CollectionUtils.isNotEmpty(componentCode) || CollectionUtils.isNotEmpty(componentNames)) {
                productData = new ProductData();
                productData.setTotalPremium(totalPremium);
                if (CollectionUtils.isNotEmpty(productCodes)) {
                    productData.setProductCodes(productCodes.stream().map(Object::toString).collect(Collectors.joining(" , ")));
                }
                if (CollectionUtils.isNotEmpty(productNames)) {
                    productData.setProductNames(productNames.stream().map(Object::toString).collect(Collectors.joining(" , ")));
                }
                if (CollectionUtils.isNotEmpty(componentCode)) {
                    productData.setComponentCodes(componentCode.stream().map(Object::toString).collect(Collectors.joining(" , ")));
                }
                if (CollectionUtils.isNotEmpty(componentNames)) {
                    productData.setComponentNames(componentNames.stream().map(Object::toString).collect(Collectors.joining(" , ")));
                }
            }
        }
        return productData;
    }

    //Setting premiumTerm into lifeProfile for PAS Products to load correct minPremium values from sqs @ProductCall
    private void preprocessProductRequest(ComputeBean computeRequest) {
        Product product = computeRequest.getSelectedSQSProducts().get(0);
        if (product != null && Constants.PAS_PRODUCT_CODE_LIST.contains(product.getProdCode())) {
            Optional<Component> basicComponent = product.getComponents().stream().filter(pr -> pr.getIsBasic()).findFirst();
            if (basicComponent.isPresent() && !CollectionUtils.isEmpty(computeRequest.getLifeProfiles())) {
                computeRequest.getLifeProfiles().get(0).setPremiumTerm(basicComponent.get().getPremiumTerm());
            }
        }
    }

    private String getPaymentModeForPruActiveSaver(String customId) {
        try {
            logger.info("Finding the Payment Method For the Custom Id : {}", D2CUtils.removeCRLF(customId));
            CustomerApplication customerAppData = customerApplicationService.findCustomerApplicationByCustomId(customId);
            if (customerAppData != null) {
                logger.info("Customer App Data Found For the Custom Id : {}", D2CUtils.removeCRLF(customId));
                List<QuestionnaireDetails> questionnaireDetails = Arrays.asList(pdfService.extractQuestionnaire(customerAppData.getQmayQuestionnaires()));
                if (CollectionUtils.isNotEmpty(questionnaireDetails)) {
                    logger.info("Questionnarie Details Found For the Custom Id : {}", D2CUtils.removeCRLF(customId));
                    if (CollectionUtils.isNotEmpty(questionnaireDetails.stream().filter(questionDetails -> questionDetails.getQuestion() != null && questionDetails.getAnswer() != null && (StringUtils.equalsIgnoreCase(questionDetails.getQuestion().getCode(), "QMAY03601") || StringUtils.equalsIgnoreCase(questionDetails.getQuestion().getCode(), "QMAY03602")) && StringUtils.equalsIgnoreCase(questionDetails.getAnswer().getValue(), "true")).collect(Collectors.toList()))) {
                        logger.info("SRS Payment Method Found for the Custom Id : {}", D2CUtils.removeCRLF(customId));
                        return Constants.SRS_PAYMENT;
                    } else if (CollectionUtils.isNotEmpty(questionnaireDetails.stream().filter(questionDetails -> questionDetails.getQuestion() != null && questionDetails.getAnswer() != null && StringUtils.equalsIgnoreCase(questionDetails.getQuestion().getCode(), "QMAY03603") && StringUtils.equalsIgnoreCase(questionDetails.getAnswer().getValue(), "true")).collect(Collectors.toList()))) {
                        logger.info("CASH Payment Method Found for the Custom Id : {}", D2CUtils.removeCRLF(customId));
                        return Constants.CASH_PAYMENT;
                    }
                } else {
                    logger.info("No questionnarie Details Found For the Custom Id : {}", D2CUtils.removeCRLF(customId));
                }
            } else {
                logger.info("No Customer App Data Found For the Custom Id : {}", D2CUtils.removeCRLF(customId));
            }
        } catch (Exception exception) {
            logger.error("Exception occured while finding Payment Mode for PruActive Saver: " + exception.getMessage(), exception);
        }
        logger.info("No Payment Mode Questionnarie Identified For Custom id : {} ", D2CUtils.removeCRLF(customId));
        return null;
    }
}
