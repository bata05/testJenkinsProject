 package com.prudential.d2c.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.prudential.d2c.entity.dto.HSMRandomStorage;
import com.prudential.d2c.repository.HSMRandomStorageRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.MediaType;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.client.ClientAPI;
import com.client.Converter;
import com.prudential.d2c.common.Constants;
import com.prudential.d2c.entity.HSMResponse;

@RestController
@EnableAutoConfiguration
public class HSMController extends BaseController {
	// Define the logger object for this class
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	HSMRandomStorageRepository randomStorageRepository;


	@SuppressWarnings("deprecation")
	@RequestMapping(value = "/getRandomAndRSAPublicKey", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public HSMResponse getRandomAndRSAPublicKey(Integer count) throws Exception {
		logger.info("calling getRandomAndRSAPublicKey()");
		ClientAPI clientApi = ClientAPI.getInstance(configProperties.getKeystoreLocation(), configProperties.getKeystorePassword(), configProperties.getHsmIP(), true);
		
		List<String> ram = new ArrayList<>();
		
		if(StringUtils.isEmpty(count)){
			count = 1;
		}
		for(int i = 0; i < count; i++){
			ram.add(i, clientApi.getRandom(Constants.EMPTY_STRING.getBytes(), Constants.RANDOMLENGTH).getRandom());
		}

		//Saving random to db
		saveRandomToDB(ram);
		
		String rsaKey = Converter.bytesToHexString(clientApi.keyGetValue(Constants.EMPTY_STRING.getBytes(), Constants.DOMAIN, Constants.KEYINDEX, Constants.KEYTYPEENC).getKey());
		logger.info("QueryRandom: {}", ram);
		logger.info("QueryRSAPublicKey: {}", rsaKey);

		HSMResponse res = new HSMResponse();
		res.setRandom(ram);
		res.setRsaPublicKey(rsaKey);
		logger.info("end getRandomAndRSAPublicKey()");
		return res;
	}

	private void saveRandomToDB(List<String> randomList){
		for(String random:randomList){
			HSMRandomStorage storage = new HSMRandomStorage();
			storage.setRandomKey(random);
			storage.setCreateDate(new Date());
			storage.setExpired('N');

			randomStorageRepository.save(storage);
		}
	}

}
