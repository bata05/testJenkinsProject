package com.prudential.d2c.controller;

import static com.prudential.d2c.common.Constants.EMPTY_STRING;
import static com.prudential.d2c.common.Constants.SAVE_ABOUTYOU_STATUS;
import static com.prudential.d2c.common.Constants.SHARP;
import static com.prudential.d2c.common.Constants.SNG_IDD;
import static com.prudential.d2c.common.Constants.SPACE_STRING;
import static com.prudential.d2c.exception.AppWideExceptionHandle.MSG_ERROR;
import static com.prudential.d2c.utils.StaticFileUtil.convertObjectToJsonFormat;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.ParseException;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Objects;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.prudential.d2c.common.Constants;
import com.prudential.d2c.entity.D2CResponse;
import com.prudential.d2c.entity.DecryptFormEdm;
import com.prudential.d2c.entity.EncryptedParameters;
import com.prudential.d2c.entity.PruAccessClient;
import com.prudential.d2c.entity.TransactionLogin;
import com.prudential.d2c.entity.ValidatedClient;
import com.prudential.d2c.entity.config.Channels;
import com.prudential.d2c.entity.config.Products;
import com.prudential.d2c.entity.dto.ConfigureProperties;
import com.prudential.d2c.entity.dto.CustomerApplication;
import com.prudential.d2c.entity.dto.HSMRandomStorage;
import com.prudential.d2c.entity.dto.PruAccessParams;
import com.prudential.d2c.entity.dto.QuotationBenefit;
import com.prudential.d2c.entity.dto.UserActionLog;
import com.prudential.d2c.entity.micro.ClientInfo;
import com.prudential.d2c.entity.micro.ClientPolicyResponse;
import com.prudential.d2c.entity.micro.ClientResponse;
import com.prudential.d2c.entity.micro.ErrorMessagesResponse;
import com.prudential.d2c.entity.micro.EsubClientContact;
import com.prudential.d2c.entity.micro.LifeProfile;
import com.prudential.d2c.entity.micro.OtpResponse;
import com.prudential.d2c.entity.micro.OtpVerifyResponse;
import com.prudential.d2c.entity.micro.PruAccessParameters;
import com.prudential.d2c.entity.micro.PruAccessParamsResponse;
import com.prudential.d2c.entity.micro.payload.AuthPayload;
import com.prudential.d2c.entity.micro.payload.BasePayload;
import com.prudential.d2c.entity.micro.payload.ClientResponsePayload;
import com.prudential.d2c.entity.micro.payload.ClientSearchResponsePayload;
import com.prudential.d2c.exception.D2CException;
import com.prudential.d2c.repository.ChannelProductMappingRepository;
import com.prudential.d2c.repository.ConfigurePropertiesRepository;
import com.prudential.d2c.repository.HSMRandomStorageRepository;
import com.prudential.d2c.repository.PruAccessParamsRepository;
import com.prudential.d2c.repository.QuotationBenefitRepository;
import com.prudential.d2c.security.JwtProvider;
import com.prudential.d2c.service.ChannelService;
import com.prudential.d2c.service.ClientService;
import com.prudential.d2c.service.CustomerApplicationService;
import com.prudential.d2c.service.HSMRandomStorageService;
import com.prudential.d2c.service.ProductService;
import com.prudential.d2c.service.PruAccessParamsService;
import com.prudential.d2c.service.TranCustomerAppService;
import com.prudential.d2c.service.UserActionLogService;
import com.prudential.d2c.service.micro.AuthenticationService;
import com.prudential.d2c.utils.D2CUtils;
import com.prudential.d2c.utils.DataUtils;
import com.prudential.d2c.utils.DateUtil;
import com.prudential.d2c.utils.DecryptionUtil;
import com.prudential.d2c.utils.EncryptDecryptUtil;
import com.prudential.d2c.utils.EncryptedIdsUtil;

import lombok.var;

/**
 * Login Controller, provide methods to check client existing, request OTP, verify OTP.
 * Decrypt parameters for CRM, EDM, PRUACCESS flows.
 */
@RestController
@EnableAutoConfiguration
@RequestMapping(value = "/login")
public class LoginController extends BaseController {

    public static final String NML = "NML";
    private static final String DECRYPT_URL_FROM_AUTOMATED_CAMPAIGN_FAILED_DUE_TO_EXCEPTION = "Decrypt URL from Automated Campaign failed due to exception.";
    private static final String DECRYPT_URL_FROM_EDM_FAILED_DUE_TO_EXCEPTION = "Decrypt URL from EDM failed due to exception ";
    private static final String UNKNOWN_EXCEPTION_CATCHED = "Unknown Exception catched.";
    private static final String THIS_IS_AN_INVALID_OTP_PLEASE_TRY_AGAIN = "This is an invalid OTP. Please try again.";
    private static final String ERROR_HAPPENED_WHILE_VERIFY_OTP = "Error happened while verify OTP.";
    private static final String EXCEPTION_WHEN_CALLING_OTP_REQUEST = "Exception when calling OTPRequest";
    private static final String STRING_A = "A";
    private static final String PLAN = "Plan ";
    private static final String MSG_NOT_FOUND = "Not Found.";
    private static final String MSG_UNAUTHORIZED_TIMEOUT = "Unauthorized Timeout";
    private static final String MSG_REQUEST_TIMEOUT = "Request Timeout. Please get a verification code again";
    private static final String MSG_EXCEEDED_LIMIT = "Exceeded limit!";
    private static final String MSG_INVALID_REQUEST = "Invalid request.";
    private static final String MSG_INVALID_RANDOM = "Invalid request. Please try again.";

    private static final String ALLOW_NEW_CUSTOMER = "ALLOW_NEW_CUSTOMER_";

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private static final String BAD_REQUEST = "Bad Request.";
    private static final String ERROR = "Error:";
    private static final String HTTP_STATUS_CODE = "HTTP status code:";
    private static final String EXPIRY_DATE_FORMAT="dd/MM/yyyy";

    @Autowired
    private ClientService clientService;
    @Autowired
    private JwtProvider jwtProvider;
    @Autowired
    private AuthenticationService authenticationService;
    @Autowired
    private QuotationBenefitRepository quotationBenefitRepository;
    @Autowired
    private ConfigurePropertiesRepository configureRepository;
    @Autowired
    private UserActionLogService userActionLogService;
    @Autowired
    private CustomerApplicationService customerApplicationService;
    @Autowired
    private ChannelService channelService;
    @Autowired
    private ProductService productService;
    @Autowired
    private ChannelProductMappingRepository channelProductMappingRepository;
    @Autowired
    private PruAccessParamsService pruAccessParamsService;
    @Autowired
    private PruAccessParamsRepository paramsRepository;
    @Autowired
    private HSMRandomStorageService randomStorageService;
    @Autowired
    private HSMRandomStorageRepository randomStorageRepository;


    /**
     * Interface to request OTP, only allow request once in certain time (config in properties)
     * Input: Username transactionId
     * Output:Status transactionId otprequesttime
     */
    @RequestMapping(
            value = "/otpRequest",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object otpRequest(@RequestBody TransactionLogin login) {
        logger.info("Invoking otpRequest.");

        logger.debug("OtpRequest : {} ", convertObjectToJsonFormat(login));

        try {
            //fetch customer OTP request log in last one minute.
            UserActionLog actionLog = userActionLogService.getOTPRequestHistory(login);

            //Customer requested OTP in last one minute.
            if (actionLog != null) {
                Date now = new Date();

                int sec = (configProperties.getOtpRequestLimitMins() * Constants.SECONDS_OF_MUNITE)
                        - (int) (now.getTime() - actionLog.getActionTime().getTime()) / Constants.MILLISECONDS_OF_SECOND;

                return new D2CResponse(Constants.ERROR_STATUS, HttpStatus.SC_FORBIDDEN,
                        "OTP already requested!", sec);
            }
            //Customer didn't request OTP in last one minute.
            else {
                //make sure every OTP request will have new transaction id generated in prepareAuthPayload.
                AuthPayload payload = new AuthPayload();
                payload.setTransactionId(EncryptedIdsUtil.generateDefaultTransactionId());
                payload.setAuthType(Constants.AUTHTYPE_CUSTOMER);

                if (StringUtils.isNotEmpty(login.getUsername())) {
                    String userName = DecryptionUtil.decryptWithoutLengthLimit(login.getUsername(), configProperties);
                    payload.setUsername(userName);
                } else if (StringUtils.isNotEmpty(login.getClientNumber())) {
                    String clientNumber = DecryptionUtil.decryptWithoutLengthLimit(login.getClientNumber(),
                            configProperties);
                    ClientResponse clientRes = clientService.getClientInfo(clientNumber);

                    if (!clientRes.getPayload().getClientList().isEmpty()) {
                        payload.setUsername(clientRes.getPayload().getClientList().get(0).getIdNumber());
                    }
                }

                //set new trasaction ID back to login entity to save in DB
                login.setTransactionId(payload.getTransactionId());

                userActionLogService.saveActionLog(login, Constants.ACTION_OTP_REQUEST);
                OtpResponse otpRes = authenticationService.otpRequest(payload);

                //if didn't get success response from API.
                if (!Constants.SUCCESS_STATUS.equalsIgnoreCase(otpRes.getSystem().getStatus())) {
                    return new D2CResponse(Constants.ERROR_STATUS, HttpStatus.SC_BAD_REQUEST,
                            getFirstErrorMessage(otpRes.getPayload().getErrorMessages()), null);
                }

                BasePayload fp = otpRes.getPayload();
                TransactionLogin lreturn = new TransactionLogin();
                lreturn.setTransactionId(fp.getTransactionId());
                lreturn.setTimeForCheckOTP(DateUtil.getNowDateTime(Constants.DATEFORMAT));

                return new D2CResponse(Constants.SUCCESS_STATUS, HttpStatus.SC_OK,
                        Constants.EMPTY_STRING, lreturn);
            }
        } catch (Exception e) {
            logger.error(EXCEPTION_WHEN_CALLING_OTP_REQUEST, e);

            return new D2CResponse(Constants.ERROR_STATUS, HttpStatus.SC_INTERNAL_SERVER_ERROR,
                    MSG_INVALID_REQUEST, null);
        }
    }

    @SuppressWarnings("unused")
	@Autowired
    private TranCustomerAppService tranCustomerAppService;

    /**
     * Verify the code
     */
    @RequestMapping(
            value = "/otpVerify",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object otpVerify(@RequestBody TransactionLogin login) {

        logger.info("Invoking otpVerify.");
        logger.debug("otpVerify : {}", convertObjectToJsonFormat(login));

        // find the transaction in DB, if not throw error
        List<UserActionLog> userActions = userActionLogService.getOTPRequestByTransactionId(login.getTransactionId());
        if (userActions.size() == 0 || StringUtils.isEmpty(userActions.get(0).getClientNumber())) {
            return new D2CResponse(Constants.ERROR_STATUS, HttpStatus.SC_FORBIDDEN,
                    MSG_INVALID_REQUEST, null);
        }

        //OTP submitted times over limitation.
        //int attemptedTimes = userActionLogService.countOfLimitTime(userActions.get(0).getClientNumber());
        int attemptedTimes = userActionLogService.getOTPSubmitCountByTransactionId(login.getTransactionId());
        if (attemptedTimes > configProperties.getOtpVerifyAttempTimes()) {
            return new D2CResponse(Constants.ERROR_STATUS, HttpStatus.SC_FORBIDDEN,
                    MSG_EXCEEDED_LIMIT, null);
        }

        //Calculate the time gap between now and timestamp in the request parameters
        long inter = DateUtil.getIntervalTime(
                DateUtil.getStringToDate(login.getTimeForCheckOTP(), Constants.DATEFORMAT), new Date());

        //OTP submit expired
        if (inter > configProperties.getOtpExpiry()) {
            return new D2CResponse(Constants.ERROR_STATUS, HttpStatus.SC_REQUEST_TIMEOUT,
                    MSG_REQUEST_TIMEOUT, null);
        }

        try {
            AuthPayload payload = new AuthPayload();
            payload.setTransactionId(login.getTransactionId());
            payload.setAuthType(Constants.AUTHTYPE_CUSTOMER);

            ClientResponse clientRes = clientService.getClientInfo(userActions.get(0).getClientNumber());
            if (!clientRes.getPayload().getClientList().isEmpty()) {
                payload.setUsername(clientRes.getPayload().getClientList().get(0).getIdNumber());
            }

            payload.setOtp(login.getOtp());
            OtpVerifyResponse otpVerify = authenticationService.otpVerify(payload);

            //didn't get success response from API.
            if (!Constants.SUCCESS_STATUS.equalsIgnoreCase(otpVerify.getSystem().getStatus())) {
                return new D2CResponse(Constants.ERROR_STATUS, HttpStatus.SC_BAD_REQUEST,
                        getFirstErrorMessage(otpVerify.getPayload().getErrorMessages()), null);
            }

            LifeProfile lifeProfile = new LifeProfile();
            lifeProfile.setNric(payload.getUsername());
            List<ClientInfo> clientList = clientService.searchClient(true, lifeProfile).getClientList();

            // As of now, this is the status quo. It returns empty JWT and SC_OK even if conditions not met.
            // We should revisit this in the future. - boon, akilan @ 20180829
            String jwt = null;
            if (CollectionUtils.isNotEmpty(clientList)) {
                String customID = login.getCustId();
                if (customID != null) {
                    CustomerApplication ca = customerApplicationService.findCustomerApplicationByCustomId(customID);
                    if (ca != null) {
                        ClientInfo clientInfo = clientList.get(0);
                        jwt = prepareJwt(customID, clientInfo, ca);
                        setCustomerApplicationUsingClientInfo(ca, clientInfo);
                        customerApplicationService.saveCustomerApplicationInAll(ca);
                    }
                }
            }

            return new D2CResponse(Constants.SUCCESS_STATUS, HttpStatus.SC_OK, Constants.EMPTY_STRING, clientList, jwt);
        } catch (HttpClientErrorException he) {
            logger.error(HTTP_STATUS_CODE + he.getRawStatusCode()+" " +ERROR + he.getResponseBodyAsString());
            return handleHttpClientErrorMessage(he);
        } catch (Exception e) {
            logger.error(ERROR_HAPPENED_WHILE_VERIFY_OTP, e);

            return new D2CResponse(Constants.ERROR_STATUS, HttpStatus.SC_INTERNAL_SERVER_ERROR,
                    THIS_IS_AN_INVALID_OTP_PLEASE_TRY_AGAIN, null);
        }
    }

    protected String prepareJwt(String customID, ClientInfo clientInfo, CustomerApplication ca) {
        String jwt;
        String nric = clientInfo.getIdNumber();
        var jwtPayload = new LinkedHashMap<String, String>();
        jwtPayload.put("nric", nric);
        jwt = jwtProvider.createJWT(customID, ca.getProductType(), jwtPayload);
        return jwt;
    }

    protected void setCustomerApplicationUsingClientInfo(CustomerApplication ca, ClientInfo clientInfo) {
        ca.setSurName(clientInfo.getLastName());
        ca.setGivenName(clientInfo.getFirstName());
        EsubClientContact contact = clientInfo.getContact();
        // BA will get back to us on country code standards currently dp only support SGP, even in esub - akilan 20180829
        String iDD = getIDD(contact);
        ca.setMobilePhone(iDD + contact.getMobilePhone());
        ca.setNricFin(clientInfo.getIdNumber());
        ca.setCustomerEmail(clientInfo.getEmailAddress());
        ca.setDob(clientInfo.getDateOfBirth());
        ca.setNationality(clientInfo.getNationality());
        ca.setClientNumber(clientInfo.getClientNumber());
        ca.setStepStatus(SAVE_ABOUTYOU_STATUS);
    }

    protected String getIDD(EsubClientContact contact){
        return (contact != null && contact.getMobilePhoneArea()!=null && contact.getMobilePhoneArea().equalsIgnoreCase("SGP")) ? SNG_IDD : "";
    }

    /**
     * Check client is existing in LA by NRIC and clientnumber,
     * If existed, return masked name and phonenumber; If not, return null values;
     *
     * @param lifeProfile client information object, NRIC or client number is mandatory.
     *                    client number only works for existing client;
     * @return ValidatedClient
     * if validated client, return masked information;
     * if unvalidated, return null values;
     */
    @RequestMapping(
            value = "/validateClient",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object validateClient(@RequestBody LifeProfile lifeProfile) {
        logger.info("Invoking validateClient.");

        // Validate if random is valid
        if (!validateRandom(lifeProfile.getRandom())) {
           return new D2CResponse(Constants.ERROR_STATUS, HttpStatus.SC_REQUEST_TIMEOUT,
                   MSG_INVALID_RANDOM, null);
        }

        logger.debug("Begin to validate client for nric ,lifeProfile : {}", convertObjectToJsonFormat(lifeProfile));
        LifeProfile profile = new LifeProfile();
        List<ClientInfo> clientList = new ArrayList<>();
        ValidatedClient vClient = new ValidatedClient();

        try {
            // validate customer by nric.
            if (StringUtils.isNotEmpty(lifeProfile.getNric())) {
                String nric = DecryptionUtil.decryptWithoutLengthLimit(lifeProfile.getNric(), configProperties);
                profile.setNric(nric);
                ClientSearchResponsePayload payload = clientService.searchClient(true, profile);
                clientList = payload.getClientList();

                if (StringUtils.isNotEmpty(payload.getTransactionId())) {
                    vClient.setTransactionId(payload.getTransactionId());
                }
            }
            //validate customer by client number.
            else if (StringUtils.isNotEmpty(lifeProfile.getClientNumber())) {
                String clientNumber = DecryptionUtil.decryptWithoutLengthLimit(lifeProfile.getClientNumber(),
                        configProperties);

                ClientResponse response = clientService.getClientInfo(clientNumber);
                clientList = response.getPayload().getClientList();
                vClient.setTransactionId(response.getPayload().getTransactionId());
            }
            String jwt = null;
            String customID = lifeProfile.getCustomID();
            if (StringUtils.isNotEmpty(customID)) {
                CustomerApplication ca = customerApplicationService.findCustomerApplicationByCustomId(customID);
                if (CollectionUtils.isNotEmpty(clientList)) {
                    maskClientInfo(clientList, vClient);
                } else {
                    String nric = DecryptionUtil.decryptWithoutLengthLimit(lifeProfile.getNric(), configProperties);
                    var payload = new LinkedHashMap<String, String>();
                    if (StringUtils.isNotEmpty(nric))
                        payload.put("nric", nric);
                    jwt = jwtProvider.createJWT(customID, ca.getProductType(), payload);
                    vClient.setAllowNewCustomer(getNewCustomerAllowConfig(ca.getProductType(), ca.getChannel()));
                }
            }


            return new D2CResponse(Constants.SUCCESS_STATUS, HttpStatus.SC_OK,
                    Constants.EMPTY_STRING, vClient, jwt);
        } catch (HttpClientErrorException he) {
            logger.error(ERROR + he.getResponseBodyAsString());
            logger.error(HTTP_STATUS_CODE + he.getRawStatusCode());

            return handleHttpClientErrorMessage(he);
        } catch (Exception e) {
            logger.error(UNKNOWN_EXCEPTION_CATCHED, e);
            return new D2CResponse(Constants.ERROR_STATUS, HttpStatus.SC_INTERNAL_SERVER_ERROR,
                    MSG_ERROR, null);
        } /*finally {
            // Remove the random from cache
            invalidateRandom(lifeProfile.getRandom());
        }*/
    }

    @RequestMapping(
            value = "/getPruaccessParams",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object getPruAccessParams(@RequestBody PruAccessParameters parameters) {
        logger.info("getPruAccessParams");

       String uniqueID=parameters.getUniqueID();

        logger.debug("uniqueID={}", D2CUtils.removeCRLF(uniqueID));

        if(uniqueID==null || uniqueID.isEmpty()){
            logger.error("Missing some parameter");
            return new D2CResponse(Constants.ERROR_STATUS, HttpStatus.SC_BAD_REQUEST,
                    BAD_REQUEST, null);
        }

        //get the params from db
        PruAccessParams params = pruAccessParamsService.getPruAccessParams(uniqueID);

        if(Objects.isNull(params)){
            logger.error("uniqueID: {} is not found in db.", D2CUtils.removeCRLF(uniqueID));

            return new D2CResponse(Constants.ERROR_STATUS, HttpStatus.SC_UNAUTHORIZED,
                    MSG_UNAUTHORIZED_TIMEOUT, null);
        }

        Instant createDateInstant = params.getCreateDate().toInstant();
        Instant nowInstant = new Date().toInstant();

        Duration duration = Duration.between(createDateInstant, nowInstant);
        int timeOutInSeconds = configProperties.getTimeOutPruaccessParams();
        logger.debug("timeOutInSeconds={}", timeOutInSeconds);

        if(params.getExpired()!='N'){
            logger.error("PruaccessParams Request is expired.");

            return new D2CResponse(Constants.ERROR_STATUS, HttpStatus.SC_UNAUTHORIZED,
                    MSG_UNAUTHORIZED_TIMEOUT, null);
        }

        if(duration.getSeconds() > timeOutInSeconds){
            logger.error("PruaccessParams Request is expired.");
           //Update expired status to 'Y'
            params.setExpired('Y');
            //save to db
            paramsRepository.save(params);

            return new D2CResponse(Constants.ERROR_STATUS, HttpStatus.SC_UNAUTHORIZED,
                    MSG_UNAUTHORIZED_TIMEOUT, null);
        }

        PruAccessParamsResponse response = new PruAccessParamsResponse();
        response.setParam1(params.getParam1());
        response.setParam2(params.getParam2());


        //Update expired status to 'Y'
        params.setExpired('Y');
        //save to db
        paramsRepository.save(params);

        return new D2CResponse(Constants.SUCCESS_STATUS, HttpStatus.SC_OK,
                null, response);

    }

    /**
     * Decrypt parameters for pruaccess flow by HSM.
     *
     * @param parameters param1: encrypted parameters of pruaccess flow.
     *                   param2: Hash value of original parameters;
     * @return decrypted result;
     */
    @RequestMapping(
            value = "/decryptForPruaccess",
            method = RequestMethod.POST,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object decryptForPru(@RequestBody EncryptedParameters parameters) {
        logger.info("Invoking decryptForPruaccess.");

        logger.debug("Start to decrypt pruaccess parameters.{}", convertObjectToJsonFormat(parameters));


        String orginalStr = decryptParameters(parameters, true);

        String[] originalStrArray = orginalStr.split(SHARP);

        //parameters passed from is not correct. 
        //Correct one should be sourceSystemCode#clientNumber#productType#reservedField#pruTranTime
        if (originalStrArray.length < 5) {
            logger.error("Missing some parameters passed from pruaccess.");
            return new D2CResponse(Constants.ERROR_STATUS, HttpStatus.SC_BAD_REQUEST,
                    BAD_REQUEST, null);
        }

        String sourceSystemCode = originalStrArray[0];
        String clientNumber = originalStrArray[1];
        String productType = originalStrArray[2];
        String reservedField = originalStrArray[3];
        String pruTranTime = originalStrArray[4];

        pruTranTime = pruTranTime.substring(0, pruTranTime.indexOf(Constants.DOT));
        long timePast = DateUtil.getIntervalTime(DateUtil.getStringToDate(pruTranTime, Constants.DATETIME_FORMAT),
                new Date());

        //PRUAccess request is expired.
        if (timePast > configProperties.getTimeoutMillis()) {
            logger.error("PRUAccess request is expired.");

            return new D2CResponse(Constants.ERROR_STATUS, HttpStatus.SC_UNAUTHORIZED,
                    MSG_UNAUTHORIZED_TIMEOUT, null);
        }

        ClientResponse client = new ClientResponse();

        try {
            client = clientService.getClientInfo(clientNumber);
        } catch (HttpClientErrorException he) {
            logger.error(ERROR + he.getResponseBodyAsString());
            logger.error(HTTP_STATUS_CODE + he.getRawStatusCode());

            return handleHttpClientErrorMessage(he);

        } catch (Exception e) {
            logger.error("Exception happened when calling client API.", e);
            return new D2CResponse(Constants.ERROR_STATUS, HttpStatus.SC_INTERNAL_SERVER_ERROR,
                    MSG_ERROR, null);
        }

        //didn't get success response from API. 
        if (!Constants.SUCCESS_STATUS.equals(client.getSystem().getStatus())) {
            return new D2CResponse(Constants.ERROR_STATUS, HttpStatus.SC_BAD_REQUEST,
                    client.getPayload().getFirstErrorMessage(), null);
        }

        ClientResponsePayload clientInfo = client.getPayload();

        PruAccessClient pruClient = new PruAccessClient();
        pruClient.setSourceSystemCode(sourceSystemCode);
        pruClient.setClientNumber(clientNumber);
        pruClient.setProductType(productType);
        pruClient.setReservedField(reservedField);
        pruClient.setClientList(clientInfo.getClientList());
        LinkedHashMap<String, String> jwtPayload = new LinkedHashMap<String, String>();
        if (CollectionUtils.isNotEmpty(clientInfo.getClientList())) {
            jwtPayload.put("nric", clientInfo.getClientList().get(0).getIdNumber());
        }
        String jwt = jwtProvider.createJWT("", productType, jwtPayload);
        return new D2CResponse(Constants.SUCCESS_STATUS, HttpStatus.SC_OK,
                Constants.EMPTY_STRING, pruClient, jwt);
    }

    /**
     * Decrypt parameters for edm flow by DP's decryption logic.
     *
     * @param parameters param1: encrypted parameters of generic edm links.
     *                   param2: Hash value of original parameters;
     * @return decrypted result;
     */
    @RequestMapping(value = "/decryptFromEdm", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object decryptForEdm(@RequestBody EncryptedParameters parameters) {
        logger.info("Invoking decryptFromEdm.");
        logger.debug("Start to decrypt URL from EDM.{}", convertObjectToJsonFormat(parameters));

        try {
            String originalStr = decryptParameters(parameters, false);
            String hashValue = EncryptDecryptUtil.sha512EncryptWithSalt(originalStr, configProperties.getPacsSalt());

            DecryptFormEdm edm = new DecryptFormEdm();
            String[] array = originalStr.split(SHARP);

            if (Constants.CATEGORY_PA.equalsIgnoreCase(array[0])) {
                addPaAndRalist(array, edm);
            }

            edm.setOrginalStr(originalStr);

            if (hashValue.equals(parameters.getParam2())) {

                return new D2CResponse(Constants.SUCCESS_STATUS, HttpStatus.SC_OK,
                        null, edm);
            } else {
                return new D2CResponse(Constants.ERROR_STATUS, HttpStatus.SC_OK,
                        null, edm);
            }
        } catch (Exception e) {
            throw new D2CException(DECRYPT_URL_FROM_EDM_FAILED_DUE_TO_EXCEPTION, e);
        }
    }

    /**
     * Decrypt parameters for crm flow and generic edm links by DP's decryption logic.
     *
     * @param parameters param1: encrypted parameters of CRM flow and generic EDM links.
     *                   param2: Hash value of original parameters;
     * @return decrypted result;
     */
    @RequestMapping(
            value = "/decryptForCRMOrGenericEDM",
            method = RequestMethod.POST,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object decryptForCRMOrGenericEDM(@RequestBody EncryptedParameters parameters) {
        logger.info("Invoking decryptForCRMOrGenericEDM.");

        logger.debug("Start to decrypt URL from Automated Campain: {}", convertObjectToJsonFormat(parameters));


        try {
            String orginalStr = decryptParameters(parameters, false);
            String hashValue = EncryptDecryptUtil.sha512EncryptWithSalt(orginalStr, configProperties.getPacsSalt());
            String sioLinkValid = null ;
            String[] array = orginalStr.split(SHARP);

          /* while array lenth less than 4, means it is for EDM GENERIC. */
            if (array.length <= 4) {

                String campaignID = array[0];
                String trackingID = EMPTY_STRING;// placeholder
                String clientId = array[1];
                String prodCode = array[2];
                boolean isSIOLink = StringUtils.equals(parameters.getParam3(), "SIO");
                String expiryDate = isSIOLink ? (array.length > 3 ? array[3] : configProperties.getSIOLinkExpiryFirstCamp()) : null;
                String offer = array.length > 3 && !isSIOLink ? array[3] : EMPTY_STRING;
                String gender = EMPTY_STRING;
                String residencyStatus = EMPTY_STRING;
                String dob = EMPTY_STRING;
                String occupation = EMPTY_STRING;
                String smokingStatus = EMPTY_STRING;
                String countryOfResidence = EMPTY_STRING;

                ClientResponse response = clientService.getClientInfo(clientId);
                List<ClientInfo> clients = response.getPayload().getClientList();

                if (CollectionUtils.isNotEmpty(clients)) {

                    ClientInfo clientInfo = clients.get(0);
                    gender = clientInfo.getGender();
                    dob = clientInfo.getDateOfBirth();
                    occupation = clientInfo.getOccupationClass();
                }
                StringBuilder edmGeneric = new StringBuilder();
                edmGeneric.append(campaignID).append(SHARP).append(trackingID).append(SHARP).append(clientId)
                        .append(SHARP).append(prodCode).append(SHARP).append(gender).append(SHARP)
                        .append(residencyStatus).append(SHARP).append(dob).append(SHARP).append(occupation)
                        .append(SHARP).append(smokingStatus).append(SHARP).append(countryOfResidence)
                        .append(SHARP).append(offer);
                orginalStr = edmGeneric.toString();
                // Expiry Date Check for SIO Link
                sioLinkValid = getLinkStatus(expiryDate);

            }

            if (hashValue.equals(parameters.getParam2())) {
                DecryptFormEdm edm = new DecryptFormEdm();
                edm.setOrginalStr(orginalStr);
                edm.setSioLinkValid(sioLinkValid);
                return new D2CResponse(Constants.SUCCESS_STATUS, HttpStatus.SC_OK,
                        null, edm);
            } else {
                return new D2CResponse(Constants.ERROR_STATUS, HttpStatus.SC_OK,
                        BAD_REQUEST, null);
            }
        } catch (Exception e) {
            throw new D2CException(DECRYPT_URL_FROM_AUTOMATED_CAMPAIGN_FAILED_DUE_TO_EXCEPTION, e);
        }
    }

    String getLinkStatus(String expiryDateStr) throws ParseException {
        String sioLinkValid = null ;
        if(null != expiryDateStr){
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern(EXPIRY_DATE_FORMAT);
            LocalDate today = LocalDate.now();
            LocalDate expiryDate = LocalDate.parse(expiryDateStr,formatter);
            sioLinkValid = today.isAfter(expiryDate) ? "N" :"Y" ;
        }
        return sioLinkValid;
    }


    /**
     * TO check if allow new customer entry for specified product.
     *
     * @param productType PA,PS,PT....
     * @return true: new customer entry is enabled.
     * false: new customer entry is disable.
     */
    @RequestMapping(
            value = "/allowNewCustomer",
            method = RequestMethod.POST,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public boolean getNewCustomerAllowConfig(String productType, String channel) {

        logger.info("Invoking allowNewCustomer.");
        String configName = ALLOW_NEW_CUSTOMER + productType;
        // Handling direct Entry channel code like PULSE
        if (channel != null && Constants.DIRECT_ENTRY_CHANNEL_CODES.contains(channel)) {
            return true;
        }
        if (channel != null && !channel.equalsIgnoreCase(NML)) {
            Products products = productService.validateProduct(productType);
            Channels channels = channelService.validateChannel(channel);
            int allowNewCustomer = channelProductMappingRepository.findByChannelsAndProducts(channels, products).getAllowNewCustomer();
            return Constants.CONFIG_TRUE.equalsIgnoreCase(String.valueOf(allowNewCustomer));
        } else {
            ConfigureProperties properites = configureRepository.findById(configName).orElse(null);
            return properites != null && Constants.CONFIG_TRUE.equalsIgnoreCase(properites.getConValue());
        }

    }
    @RequestMapping(
            value = "/checkForPruShieldPolicy",
            method = RequestMethod.POST,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public D2CResponse checkForPruShieldPolicy(@RequestBody LifeProfile lifeProfile){
        logger.info("Invoking checkForPruShieldPolicy.");
        if (StringUtils.isNotEmpty(lifeProfile.getNric())) {
            String nric = DecryptionUtil.decryptWithoutLengthLimit(lifeProfile.getNric(), configProperties);
            ClientPolicyResponse response =  clientService.checkPolicyByNric(nric);
            return new D2CResponse(Constants.SUCCESS_STATUS, HttpStatus.SC_OK,
                    null, response.getPayload());
        }else {
            return new D2CResponse(Constants.ERROR_STATUS, HttpStatus.SC_UNAUTHORIZED,
                    MSG_NOT_FOUND, null);
        }
    }

    /**
     * TO check if allow new customer entry for specified product.
     *
     * @param lifeProfile PA,PS,PT....
     * @return true: new customer entry is enabled.
     * false: new customer entry is disable.
     */
    @RequestMapping(value = "/getClientInfo", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object getClientInfo(@RequestBody LifeProfile lifeProfile) {
        logger.info("INvoking getClientInfo");

        logger.debug("Begin to get customer info , LifeProfile : {} ", convertObjectToJsonFormat(lifeProfile));


        List<ClientInfo> clients = new ArrayList<>();

        if (StringUtils.isNotEmpty(lifeProfile.getNric())) {
            String nric = DecryptionUtil.decryptWithoutLengthLimit(lifeProfile.getNric(), configProperties);
            LifeProfile profile = new LifeProfile();
            profile.setNric(nric);

            ClientSearchResponsePayload response = clientService.searchClient(true, lifeProfile);
            clients = response.getClientList();
        } else if (StringUtils.isNotEmpty(lifeProfile.getClientNumber())) {
            String clientNumber = DecryptionUtil.decryptWithoutLengthLimit(lifeProfile.getClientNumber(),
                    configProperties);
            ClientResponse response = clientService.getClientInfo(clientNumber);
            clients = response.getPayload().getClientList();
        }

        ClientInfo newClient = new ClientInfo();
        if (!clients.isEmpty()) {
            newClient.setClientNumber(clients.get(0).getClientNumber());
            newClient.setDateOfBirth(clients.get(0).getDateOfBirth());
            newClient.setGender(clients.get(0).getGender());
            newClient.setNationality(clients.get(0).getNationality());
            newClient.setNationalityName(clients.get(0).getNationalityName());
            newClient.setOccupation(clients.get(0).getOccupation());
            newClient.setOccupationClass(clients.get(0).getOccupationClass());
            newClient.setFirstName(clients.get(0).getFirstName());
            newClient.setLastName(clients.get(0).getLastName());

            if (clients.get(0).getContact() != null) {
                EsubClientContact newContact = new EsubClientContact();
                newContact.setMobilePhoneArea(clients.get(0).getContact().getMobilePhoneArea());
                newContact.setMobilePhone(clients.get(0).getContact().getMobilePhone());
                newContact.setEmail(clients.get(0).getContact().getEmail());
                newClient.setContact(newContact);
            }
            return new D2CResponse(Constants.SUCCESS_STATUS, HttpStatus.SC_OK,
                    null, newClient);
        } else {
            return new D2CResponse(Constants.ERROR_STATUS, HttpStatus.SC_UNAUTHORIZED,
                    MSG_NOT_FOUND, null);
        }
    }

    private String getFirstErrorMessage(List<String> errors) {
        String error = null;

        if (CollectionUtils.isNotEmpty(errors) && errors.get(0) != null) {
            error = errors.get(0);
        }
        return error;

    }

    private void addPaAndRalist(String[] parameterArray, DecryptFormEdm edm) {
        List<QuotationBenefit> paList;
        List<QuotationBenefit> raList = new ArrayList<>();

        if (parameterArray.length >= 6 && StringUtils.isNotEmpty(parameterArray[5])) {
            //Sample of PA parameters
            //                productCode#campaignId#basicCompoCode#basicSumAssured#basicPremium#planCode
            //index 5
            //                main component plan code
            paList = quotationBenefitRepository.findByPlanAndType(PLAN + parameterArray[5], Constants.PRUPERSONAL_ACCIDENT);

            if (parameterArray.length >= 10 && STRING_A.equalsIgnoreCase(parameterArray[9])) {
                //Sample of PA parameters
                //			productCode#campaignId#basicCompoCode#basicSumAssured#basicPremium#planCode#rec_riderCompoCode#rec_riderSumAssured#rec_riderPremium#planCode
                //index 9
                //			rider component plan code
                raList = quotationBenefitRepository.findByPlanAndType(PLAN + parameterArray[5], Constants.RECOVERY_AID);
            }

            edm.setPaList(paList);
            edm.setRaList(raList);
        }

    }

    private Object handleHttpClientErrorMessage(HttpClientErrorException he) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            ErrorMessagesResponse error = mapper.readValue(he.getResponseBodyAsString(),
                    ErrorMessagesResponse.class);
            logger.warn("Error while calling API: {}", getFirstErrorMessage(error.getPayload().getErrorMessages()));

            return new D2CResponse(Constants.ERROR_STATUS, he.getRawStatusCode(),
                    getFirstErrorMessage(error.getPayload().getErrorMessages()), null);
        } catch (Exception e) {
            logger.error("Error while get error message from API error response.", e);
            throw new D2CException("Verify OTP failed due to exception.", e);
        }
    }

    private String decryptParameters(EncryptedParameters parameters, boolean byHSM) {
        String orginalStr;
        String encryptedData = parameters.getParam1();
        String hashValue = parameters.getParam2();

        if (byHSM) {
            String decryptedParam1 = DecryptionUtil.decryptionWith21Domain(encryptedData, hashValue, configProperties);

            try {
                orginalStr = EncryptDecryptUtil.decodeBase64(decryptedParam1);
            } catch (UnsupportedEncodingException e) {
                logger.error("Error while decoding by Base64.", e);
                throw new D2CException("DecryptForPru error");
            }
            return orginalStr;
        } else {
            try {
                String decodeURLParam1 = URLDecoder.decode(encryptedData, Constants.ENCODING_UTF8);
                String decryptedParam1 = EncryptDecryptUtil.decodeBase64(decodeURLParam1);
                orginalStr = EncryptDecryptUtil.xorEncryptDecrypt(decryptedParam1, configProperties.getPacsKey());
            } catch (UnsupportedEncodingException e) {
                logger.error("Error while decoding by Base64.", e);
                throw new D2CException("DecryptForPru error");
            }
            return orginalStr;
        }
    }

    private void maskClientInfo(List<ClientInfo> clientList, ValidatedClient vClient) {
        String clientName = EMPTY_STRING;
        StringBuilder maskedMobile = new StringBuilder(SPACE_STRING);
        boolean mobileValid = false;
        if (StringUtils.isNotEmpty(clientList.get(0).getFirstName())) {
            clientName = clientList.get(0).getFirstName();
        }

        if (clientList.get(0).getContact() != null && StringUtils.isNotEmpty(clientList.get(0).getContact().getMobilePhone())) {
            String mobileNo = clientList.get(0).getContact().getMobilePhone();

            int length = mobileNo.length();
            maskedMobile.append(Constants.FOUR_DIGIT_STAR).append(SPACE_STRING).append(mobileNo.substring(length - 4, length));
            mobileValid = DataUtils.isDataNumber(mobileNo);

        }
        vClient.setMobileValid(mobileValid);
        vClient.setClientName(clientName);
        vClient.setMobile(maskedMobile.toString());
    }


    private boolean validateRandom(String random) {
        logger.info("invoking validateRandom()");
        HSMRandomStorage randomStorage= randomStorageService.getHSMRandomStorage(random);

        if(Objects.isNull(randomStorage)){
            logger.error("random: {} is not found in db.", D2CUtils.removeCRLF(random));
            return false;
        }

        Instant createDateInstant = randomStorage.getCreateDate().toInstant();
        Instant nowInstant = new Date().toInstant();

        Duration duration = Duration.between(createDateInstant, nowInstant);
        //need change timeout
        int timeOutInSeconds = configProperties.getTimeOutHSMStorage();
        logger.debug("timeOutInSeconds={}", timeOutInSeconds);

        if(randomStorage.getExpired()!='N'){
            logger.error("HSMRandomStorage Request is expired.");
            return false;
        }

        if(duration.getSeconds() > timeOutInSeconds){
            logger.error("HSMRandomStorage Request is expired.");
            //Update expired status to 'Y'
            randomStorage.setExpired('Y');
            //save to db
            randomStorageRepository.save(randomStorage);

            return false;
        }


        //Update expired status to 'Y'
        randomStorage.setExpired('Y');
        //save to db
        randomStorageRepository.save(randomStorage);

        return true;
    }

}
