package com.prudential.d2c.controller;

import com.prudential.d2c.common.Constants;
import com.prudential.d2c.entity.D2CResponse;
import com.prudential.d2c.entity.Response;
import com.prudential.d2c.entity.dto.MailList;
import com.prudential.d2c.entity.micro.AgentData;
import com.prudential.d2c.entity.micro.AssignAgentRequest;
import com.prudential.d2c.entity.micro.payload.AssignAgentResponsePayload;
import com.prudential.d2c.service.MailService;
import com.prudential.d2c.utils.D2CUtils;
import com.prudential.d2c.utils.DecryptionUtil;

import org.apache.commons.collections.CollectionUtils;
import org.apache.http.HttpStatus;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.core.convert.ConversionService;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

import static com.prudential.d2c.exception.AppWideExceptionHandle.MSG_ERROR;
import static com.prudential.d2c.utils.DateUtil.getAgeByDob;

@RestController
@EnableAutoConfiguration
public class MailController extends BaseController {

    // Define the logger object for this class
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private MailService mailService;

    @Autowired
    ConversionService conversionService;

    @RequestMapping(
            value = "/addMail",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object addMail(@RequestBody MailList encryptedMailRequest, HttpServletRequest request) {

        MailList mailRequest = conversionService.convert(encryptedMailRequest, MailList.class);
        try {
            logger.info("Invoking addMail for custom ID {}", D2CUtils.removeCRLF(mailRequest.getCustomId()));
            List<MailList> mailList = mailService.findMailListByCustomIdAndMailType(mailRequest);
            AgentData agent = null;
            Boolean isCloseBrowser = Constants.MAIL_CLOSE.equals(mailRequest.getMailType());
            if (isCloseBrowser || CollectionUtils.isEmpty(mailList)) {
                mailRequest.setIPAddress(D2CUtils.retrieveIPAddress(request));
                
                AssignAgentRequest assignAgentRequest = getAssignAgentRequest(mailRequest);
                AssignAgentResponsePayload assignAgentResponsePayload = assignedAgentService.callAssignAgent(assignAgentRequest);
                
                agent = mailService.saveMailList(mailRequest, assignAgentResponsePayload);
            }
            return new D2CResponse(Constants.SUCCESS_STATUS, HttpStatus.SC_OK, null, agent);

        } catch (Exception e) {
            logger.error("Exception happens when save mails", e);
            return new D2CResponse(Constants.ERROR_STATUS, HttpStatus.SC_INTERNAL_SERVER_ERROR, MSG_ERROR, null);
        }
    }

    /**
     * Used as a listener with front-end , front-end will send message every 50 seconds to keep contact,once the contact
     * lose, it will trigger close browser email
     *
     * @param mailRequest only need customId
     * @return
     */
    @RequestMapping(
            value = "/refreshCloseMailStatus",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public Object refreshCloseMailStatus(@RequestBody MailList mailRequest) {

        logger.info("Invoking refreshCloseMailStatus");
        Object response = new Response(Constants.OK_STRING);

        if (StringUtils.isEmpty(mailRequest.getCustomId())) {
            return response;
        }

        mailRequest.setMailType(Constants.MAIL_CLOSE);
        List<MailList> mailList = mailService.findMailListByCustomIdAndMailType(mailRequest);

        if (CollectionUtils.isEmpty(mailList)) {
            return response;
        }

        //only one close browser in DB according to one customId
        MailList mail = mailList.get(0);

        if (mail.getStatusCode() == Constants.MAIL_ENABLE) {
            mail.setStatusCode(Constants.MAIL_CLOSE_VALUE);
        }

        if (StringUtils.isNotEmpty(mailRequest.getStage())) {
            mail.setStage(mailRequest.getStage());
        }

        mailService.updateMailStatusAndStageByCustomIdAndMailType(mail);

        return response;
    }
    
    public AssignAgentRequest getAssignAgentRequest(MailList mailRequest) {

        AssignAgentRequest assignAgentRequest = new AssignAgentRequest();
        assignAgentRequest.setNric(decryptWithReturn(mailRequest.getNricFin(), null));
        assignAgentRequest.setClientNumber(decryptWithReturn(mailRequest.getClientNumber(), null));
        assignAgentRequest.setPolicyNumber(mailRequest.getPolicyNumber());

        if (StringUtils.isEmpty(mailRequest.getAge()) && StringUtils.isNotEmpty(mailRequest.getDob())) {
            mailRequest.setAge(getAgeByDob(mailRequest.getDob()));
        }

        // for PA product, needs this value
        assignAgentRequest.setAge(mailRequest.getAge());
        assignAgentRequest.setGender(mailRequest.getGender());
        assignAgentRequest.setNationality(mailRequest.getNationality());
        assignAgentRequest.setDob(mailRequest.getDob());
        assignAgentRequest.setProType(mailRequest.getProductType());
        assignAgentRequest.setChannelType(mailRequest.getChannel());
        assignAgentRequest.setCustomId(mailRequest.getCustomId());

        assignAgentRequest.setNricSuffix(decryptWithReturn(mailRequest.getNricSuffix(), null));
        assignAgentRequest.setMobileNo(decryptWithReturn(mailRequest.getMobilePhone(), null));
        assignAgentRequest.setEmailId(decryptWithReturn(mailRequest.getCustomerEmail(), null));

        assignAgentRequest.setIsSaleCompleted(mailRequest.isSaleCompleted() ? "Y" : "N");

        assignAgentRequest.setSelectedProducts(mailRequest.getSelectedProducts());

        assignAgentRequest.setReferralAgentCode(mailRequest.getReferralAgentCode());
        assignAgentRequest.setPreferredAgentMobile(mailRequest.getPreferredAgentMobile());
        return assignAgentRequest;
    }
    

    private String decryptWithReturn(String req,String ret) {

        if (StringUtils.isEmpty(req) || Constants.NULL_STRING.equalsIgnoreCase(req)) {
            return ret;
        } else {
            return DecryptionUtil.decryption(req, configProperties).trim();
        }
    }

}
