package com.prudential.d2c.controller;


import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.prudential.d2c.common.ConfigProperties;
import com.prudential.d2c.config.MyInfoConfig;
import com.prudential.d2c.entity.*;
import com.prudential.d2c.entity.MyInfoResponse.DropdownResponse;
import com.prudential.d2c.entity.MyInfoResponse.MyInfoConfigResponse;
import com.prudential.d2c.entity.MyInfoResponse.MyInfoDetails;
import com.prudential.d2c.entity.config.MyInfoMapping;
import com.prudential.d2c.entity.config.PassTypeMapping;
import com.prudential.d2c.entity.micro.payload.LogRequest;
import com.prudential.d2c.exception.MyInfoException;
import com.prudential.d2c.repository.MyInfoMappingRepository;
import com.prudential.d2c.repository.PassTypeMappingRepository;
import com.prudential.d2c.service.MyInfoService;
import com.prudential.d2c.utils.MyInfoConstants;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import net.minidev.json.parser.JSONParser;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Pattern;

import static com.prudential.d2c.utils.StaticFileUtil.convertObjectToJsonFormat;
import static org.apache.commons.lang.StringEscapeUtils.escapeHtml; 

@RestController
@EnableAutoConfiguration
public class MyInfoController {

    @Autowired
    protected MyInfoConfig myInfoConfig;

    @Autowired
    protected ConfigProperties configProperties;

    @Autowired
    private MyInfoService myInfoService;

    @Autowired
    private MyInfoMappingRepository myInfoMappingRepository;

    @Autowired
    private PassTypeMappingRepository passTypeMappingRepository;

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @RequestMapping(
            value = "/myinfo/api/retrieve/{authCodeAndState}",
            method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ResponseEntity<?> getMyInfoDetails(@PathVariable String authCodeAndState) {
    	logger.info("authCodeAndState value : {}", authCodeAndState);
        if(null == authCodeAndState || StringUtils.isAllBlank(authCodeAndState)){
            logger.error("MyInfoController getMyInfoDetails PathVariable is null or empty");
            return ResponseEntity.badRequest().body(new MessageResponse(MyInfoConstants.INVALID_INPUT));
        }
        MyInfoDetailsResponse myInfoDetailsResponse = null;
        MyInfoDetails myInfoDetails = null;

        String[] splitter = authCodeAndState.split(Pattern.quote("_"));
        if(null == splitter || splitter.length <= 1){
            logger.error("MyInfoController getMyInfoDetails authCodeAndState does not contain required values");
            return ResponseEntity.badRequest().body(new MessageResponse(MyInfoConstants.INVALID_INPUT));
        }
        String authCode= splitter[0];
        String state=splitter[1];
        
        try {
            myInfoDetails = myInfoService.getMyInfoPersonData(authCode, state);
            if (myInfoDetails != null) {
                myInfoDetailsResponse = myInfoObjectMapper(myInfoDetails);

                if ("sit".equalsIgnoreCase(configProperties.getServerEnvironment())
                        || "uat".equalsIgnoreCase(configProperties.getServerEnvironment())
                        || "preprod".equalsIgnoreCase(configProperties.getServerEnvironment())) {
                    MyInfoDetailsResponse testResponse = getTestDataFromFile(myInfoDetails.getUinfin().getValue());
                    if (testResponse != null) {
                        testResponse.setNamePermutations(namePermuation(testResponse.getName()));
                        myInfoDetailsResponse = testResponse;
                        MyInfoMapping myInfoMapping = myInfoMappingRepository.findByMyInfoCode(testResponse.getNationality().getCode());
                        if(myInfoMapping != null) {
                            myInfoDetailsResponse.getNationality().setCode(escapeHtml(myInfoMapping.getCode()));
                        }
                        List<PassTypeMapping> passTypeMappingList = passTypeMappingRepository.findByCodeIgnoreCase(testResponse.getPassType().getCode());
                        if (passTypeMappingList != null && passTypeMappingList.size() > 0) {
                            myInfoDetailsResponse.getPassType().setCode(escapeHtml(String.valueOf(passTypeMappingList.get(0).getDpCode())));
                            myInfoDetailsResponse.getPassType().setDesc(escapeHtml(passTypeMappingList.get(0).getDescription()));
                        }
                    }
                }

                myInfoService.saveforMyInfo(myInfoDetailsResponse);
            }
        } catch (MyInfoException | IllegalArgumentException e) {
            logger.error("MyInfoController getMyInfoDetails MyInfoException calling MyInfo: {}", e.getMessage());
            return ResponseEntity.ok().body(
                    new MessageResponse(e.getMessage()));
        }  catch (Exception e) {
            logger.error("MyInfoController getMyInfoDetails Error calling MyInfo: {}", e.getMessage());
            return ResponseEntity.ok().body(
                    new MessageResponse(e.getMessage()));
          }
        logger.info("MyInfoController getMyInfoDetails Invoking: getMyInfoPersonData.");
        return ResponseEntity.ok().body(myInfoDetailsResponse);
    }

    @RequestMapping(
            value = "/getMyInfoConfig",
            method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public MyInfoConfigResponse getMyInfoConfig() {
        logger.info("Retrieving MyInfo configuration details");
        MyInfoConfigResponse myInfoConfigResponse = new MyInfoConfigResponse();
        myInfoConfigResponse.setAuthApiUrl(myInfoConfig.getAuthApiUrl());
        myInfoConfigResponse.setClientId(myInfoConfig.getClientId());
        myInfoConfigResponse.setRedirectUrl(myInfoConfig.getRedirectUrl());
        myInfoConfigResponse.setAttributes(myInfoConfig.getAttributes());
        myInfoConfigResponse.setCode(myInfoConfig.getCode());
        myInfoConfigResponse.setState(myInfoConfig.getState());
        return myInfoConfigResponse;
    }

    private MyInfoDetailsResponse myInfoObjectMapper(MyInfoDetails myInfoDetails) {
    	logger.debug("In MyInfoObjectMapper");
        List<DropdownResponse> listData = null;

        MyInfoDetailsResponse myInfoDetailsResponse = new MyInfoDetailsResponse();
        myInfoDetailsResponse.setUinfin(escapeHtml(myInfoDetails.getUinfin().getValue()));
        myInfoDetailsResponse.setName(escapeHtml(myInfoDetails.getName().getValue()));
        myInfoDetailsResponse.setSex(escapeHtml(myInfoDetails.getSex().getDesc()));
        myInfoDetailsResponse.setGenderCode(escapeHtml(myInfoDetails.getSex().getCode()));
        myInfoDetailsResponse.setDob(escapeHtml(myInfoDetails.getDob().getValue()));
        myInfoDetailsResponse.setEmail(escapeHtml(myInfoDetails.getEmail().getValue()));
        myInfoDetailsResponse.setPassStatus(escapeHtml(myInfoDetails.getPassstatus().getValue()));
        myInfoDetailsResponse.setPassExpiryDate(escapeHtml(myInfoDetails.getPassexpirydate().getValue()));
        listData = namePermuation(escapeHtml(myInfoDetails.getName().getValue()));
        myInfoDetailsResponse.setNamePermutations(listData);

        Nationality nationality = new Nationality();
        MyInfoMapping myInfoMapping = myInfoMappingRepository.findByMyInfoCode(myInfoDetails.getNationality().getCode());
        if(myInfoMapping != null) {
            nationality.setCode(escapeHtml(myInfoMapping.getCode()));
            nationality.setDesc(escapeHtml(myInfoDetails.getNationality().getDesc()));
        }

        PassType passType = null;
        if (myInfoDetails.getPasstype() != null && myInfoDetails.getPasstype().getCode() != null
                && !myInfoDetails.getPasstype().getCode().trim().equals("")) {
            List<PassTypeMapping> passTypeMappingList = passTypeMappingRepository.findByCodeIgnoreCase(myInfoDetails.getPasstype().getCode());
            if (passTypeMappingList != null && passTypeMappingList.size() > 0) {
                passType = new PassType();
                passType.setCode(escapeHtml(String.valueOf(passTypeMappingList.get(0).getDpCode())));
                passType.setDesc(escapeHtml(passTypeMappingList.get(0).getDescription()));
            }
        }

        Country country = new Country();
        if(myInfoDetails.getRegadd() != null && myInfoDetails.getRegadd().getCountry() != null){
            country.setCode(escapeHtml(myInfoDetails.getRegadd().getCountry().getCode()));
        	country.setDesc(escapeHtml(myInfoDetails.getRegadd().getCountry().getDesc()));
        }

        RegAdd regAdd = new RegAdd();
        regAdd.setCountry(country);
        if(myInfoDetails.getRegadd() != null){
            if (myInfoDetails.getRegadd().getType() != null) {
                regAdd.setType(escapeHtml(myInfoDetails.getRegadd().getType()));
            }
            if (myInfoDetails.getRegadd().getUnit() != null) {
                regAdd.setUnit(escapeHtml(myInfoDetails.getRegadd().getUnit().getValue()));
            }
            if (myInfoDetails.getRegadd().getStreet() != null) {
                regAdd.setStreet(escapeHtml(myInfoDetails.getRegadd().getStreet().getValue()));
            }
            if (myInfoDetails.getRegadd().getBlock() != null) {
                regAdd.setBlock(escapeHtml(myInfoDetails.getRegadd().getBlock().getValue()));
            }
            if (myInfoDetails.getRegadd().getPostal() != null) {
                regAdd.setPostal(escapeHtml(myInfoDetails.getRegadd().getPostal().getValue()));
            }
            if (myInfoDetails.getRegadd().getFloor() != null) {
                regAdd.setFloor(escapeHtml(myInfoDetails.getRegadd().getFloor().getValue()));
            }
            if (myInfoDetails.getRegadd().getBuilding() != null) {
                regAdd.setBuilding(escapeHtml(myInfoDetails.getRegadd().getBuilding().getValue()));
            }
        }

        ResidentialStatus residentialStatus = null;
        if (myInfoDetails.getResidentialstatus() != null) {
            residentialStatus = new ResidentialStatus();
            if (myInfoDetails.getResidentialstatus().getCode() != null && !myInfoDetails.getResidentialstatus().getCode().trim().equals("")) {
                residentialStatus.setCode(escapeHtml(myInfoDetails.getResidentialstatus().getCode()));
                residentialStatus.setDesc(escapeHtml(myInfoDetails.getResidentialstatus().getDesc()));
            } else {
                residentialStatus.setCode("");
                residentialStatus.setDesc("");
            }
        }

        MobileNo mobileNo = new MobileNo();
        mobileNo.setPrefix(escapeHtml(myInfoDetails.getMobileno().getPrefix().getValue()));
        mobileNo.setAreaCode(escapeHtml(myInfoDetails.getMobileno().getAreacode().getValue()));
        mobileNo.setNbr(escapeHtml(myInfoDetails.getMobileno().getNbr().getValue()));

        myInfoDetailsResponse.setMobileNo(mobileNo);
        myInfoDetailsResponse.setResidentialStatus(residentialStatus);
        myInfoDetailsResponse.setNationality(nationality);
        myInfoDetailsResponse.setPassType(passType);
        myInfoDetailsResponse.setRegAdd(regAdd);
        logger.debug("Exiting MyInfoObjectMapper");
        return myInfoDetailsResponse;
    }

    private List<DropdownResponse> namePermuation(String name) {
        List<DropdownResponse> listData = new ArrayList<DropdownResponse>();
        String[] splitName = name.split(" ");
        List<String> list = new ArrayList<String>();
        StringBuilder result = new StringBuilder();
        StringBuilder result1 = new StringBuilder();
        for (int i = 0; i < splitName.length - 1; i++) {
            result.append(splitName[i] + " ");
            String temp = result.toString();
            list.add(temp.trim());
        }

        int length = splitName.length;
        for (int j = length - 1; j >= 0; j--) {

            result1.insert(0, " " + splitName[j]);
            String temp = result1.toString();
            list.add(temp.trim());
        }
        Collections.sort(list, Comparator.comparing(String::length));

        for (int i = 0; i < list.size(); i++){
            DropdownResponse response = new DropdownResponse();
            response.setId(i);
            response.setName(escapeHtml(list.get(i)));
            listData.add(response);
        }
        return listData;
    }

    private MyInfoDetailsResponse getTestDataFromFile(String nric) throws MyInfoException {
        logger.info("Retrieving MyInfo test data from test file... ");
        MyInfoDetailsResponse myInfoDetailsResponse = null;
        String jsonResponse = null;
        JSONParser parser1 = new JSONParser();
        Object obj = null;
        try {
            obj = parser1.parse(new FileReader(myInfoConfig.getStub()));
        } catch (Exception e) {
            logger.error("MyInfo Error: {}", e.getMessage());
            throw new MyInfoException(e.getMessage(),e);
        }
        jsonResponse = obj.toString();
        Gson gson = new Gson();
        JsonParser parser = new JsonParser();
        JsonArray objectArray = (JsonArray) parser.parse(jsonResponse);// response will be the json String

        for (int i = 0; objectArray.size() > 0; i++) {
            JsonObject jsonObj = (JsonObject) objectArray.get(i);
            if (jsonObj.get(nric) != null) {
                myInfoDetailsResponse = gson.fromJson(jsonObj.get(nric).toString(), MyInfoDetailsResponse.class);
                break;
            }
        }

        return myInfoDetailsResponse;
    }
}
@Setter
@Getter
@AllArgsConstructor
class MessageResponse {
    private String message;
}