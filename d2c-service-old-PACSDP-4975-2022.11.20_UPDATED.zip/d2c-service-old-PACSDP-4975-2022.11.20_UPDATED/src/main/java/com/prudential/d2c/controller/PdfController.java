package com.prudential.d2c.controller;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.DatatypeConverter;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.prudential.d2c.common.Constants;
import com.prudential.d2c.entity.EncryptPdfBean;
import com.prudential.d2c.entity.SuccessStatus;
import com.prudential.d2c.entity.dto.CustomerApplication;
import com.prudential.d2c.entity.micro.PdfData;
import com.prudential.d2c.service.CustomerApplicationService;
import com.prudential.d2c.service.PdfService;
import com.prudential.d2c.utils.D2CUtils;
import com.prudential.d2c.utils.DocumentUtil;
import com.prudential.d2c.utils.StaticFileUtil;

@RestController
@EnableAutoConfiguration
public class PdfController extends BaseController {

    private static final String MSG_STATUS_FAILED = "Failed";
    private static final String MSG_ERROR_INVALID_IMAGE = "Invalid Image uploaded.";
    private static final String MSG_ERROR_INVALID_FILENAME_LENGTH = "File Name should be less than 255 chars.";
    private static final String MSG_ERROR_INVALID_CONVERSION = "Conversion to PDF failed";
    private static final String MSG_ERROR_INVALID_IMAGE_SIZE = "Image File exceeds max limit allowed (4 MB)";
    private static final String MSG_ERROR_INVALID_FILENAME_PATTERN = "File Name can only contain alpha numeric, underscore '_', dash '-', comma ',' chars.";
    private static final String MSG_ERROR = "Error happened. Please contact the admin.";
    public static final String IMAGE_TYPE_PNG = "png";
    public static final String IMAGE_TYPE_JPG = "jpg";
    public static final String IMAGE_TYPE_JPEG = "jpeg";
    public static final String IMAGE_TYPE_GIF = "gif";



    
    private static final Logger LOGGER = LoggerFactory.getLogger(PdfController.class);
    
    @Autowired
    private PdfService pdfService;

    @Autowired
    CustomerApplicationService customerApplicationService;
    
    @RequestMapping(value = "/uploadImage", headers = "content-type=multipart/*", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object uploadImage(@RequestParam("file") MultipartFile file) {
        String fileName= file.getOriginalFilename();
        LOGGER.info("Received request to upload image with file name: {}", fileName);
        ByteArrayOutputStream baos;

        if(file==null|| file.isEmpty()){
            LOGGER.error("File {} is null or empty",fileName);
            SuccessStatus status = new SuccessStatus();
            status.setSuccess(false);
            status.setMessage(MSG_ERROR_INVALID_IMAGE);
            status.setExcuteStatus(MSG_STATUS_FAILED);
            return status;
        }

        String fileType = file.getContentType().substring(6);

        //PACSDP-4610
        //Validate file MimeType
        //Validate Image content
        //Validate file Name length
        //Validate file Name Pattern
        //Validate Image File Size
        //Validate file type
        //Remove all control chars from filename

        //Remove all control chars from filename
        fileName=D2CUtils.removeControlCharFull(fileName);

        //Validate file Name Length
        if(!D2CUtils.validateFileNameLength(fileName)){
            LOGGER.error("Invalid file name length: {}, length=", fileName, fileName.length());
            SuccessStatus status = new SuccessStatus();
            status.setSuccess(false);
            status.setMessage(MSG_ERROR_INVALID_FILENAME_LENGTH);
            status.setExcuteStatus(MSG_STATUS_FAILED);
            return status;
        }


        //Validate file Name Pattern
        if(!D2CUtils.validateAndRenameFileNamePattern(fileName)){
            LOGGER.error("Invalid file name pattern: {}", fileName);
            SuccessStatus status = new SuccessStatus();
            status.setSuccess(false);
            status.setMessage(MSG_ERROR_INVALID_FILENAME_PATTERN);
            status.setExcuteStatus(MSG_STATUS_FAILED);
            return status;
        }

        byte[] bytes=null;
        try {
            bytes=file.getBytes();
        } catch (IOException e) {
            LOGGER.error("IOException occurs for file: {}, errorMessage={}",fileName,e.getMessage());
            SuccessStatus status = new SuccessStatus();
            status.setSuccess(false);
            status.setMessage(MSG_ERROR_INVALID_IMAGE);
            status.setExcuteStatus(MSG_STATUS_FAILED);
            return status;
        }

        //original image
        String imgString = new String(bytes);
        LOGGER.debug("Original Img String={}",imgString);

        //Validate file MimeType
        if(DocumentUtil.isValidMimeType(bytes)) {
            if (IMAGE_TYPE_GIF.equalsIgnoreCase(fileType)) {
                fileType = IMAGE_TYPE_PNG;
            }

            //Validate image file size
            //Max file size for image is 4MB
            float maxFileSize=4*1024*1024;
            if(DocumentUtil.validateImageFileSize(bytes,maxFileSize)){
                LOGGER.error("Image file size exceeds max limit (4MB): {}", fileName);
                SuccessStatus status = new SuccessStatus();
                status.setSuccess(false);
                status.setMessage(MSG_ERROR_INVALID_IMAGE_SIZE);
                status.setExcuteStatus(MSG_STATUS_FAILED);

                return status;
            } else {
            	LOGGER.info("File Size: "+(bytes.length!=0?String.valueOf(bytes.length/(1024)):"0")+"kB");
            }

            InputStream inputstream = new ByteArrayInputStream(bytes);
            boolean isValidImage=DocumentUtil.isValidImage(inputstream);

            if(!isValidImage){
                LOGGER.error("Invalid image file: {}", fileName);
                SuccessStatus status = new SuccessStatus();
                status.setSuccess(false);
                status.setMessage(MSG_ERROR_INVALID_IMAGE);
                status.setExcuteStatus(MSG_STATUS_FAILED);
                return status;
            }

            try {
                //parse image to validate image content
                //DocumentUtil.parseImageContent(file.getBytes());

               LOGGER.info("Converting Image to PDF..");
                //convert image to pdf
                baos = StaticFileUtil.generatePDFFromImageByte(bytes, fileType);
                if(baos==null||baos.size()==0){
                    LOGGER.error("Failed at converting image to pdf ",fileName);
                    SuccessStatus status = new SuccessStatus();
                    status.setSuccess(false);
                    status.setMessage(MSG_ERROR_INVALID_IMAGE);
                    status.setExcuteStatus(MSG_STATUS_FAILED);
                    return status;
                }

            }catch(Exception e)  {
                LOGGER.error("Invalid image file: {}, error message={}", fileName, e.getMessage());
                SuccessStatus status = new SuccessStatus();
                status.setSuccess(false);
                status.setMessage(MSG_ERROR_INVALID_CONVERSION);
                status.setExcuteStatus(MSG_STATUS_FAILED);
                return status;
            }

            byte[] resOrigin = baos.toByteArray();

            // build base64
            String pdfStr = new String(Base64.getEncoder().encode(resOrigin));
            LOGGER.info("pdfStr={}",pdfStr);

            if(StringUtils.isBlank(pdfStr)){
                LOGGER.error("pdfStr is null or empty");
                SuccessStatus status = new SuccessStatus();
                status.setSuccess(false);
                status.setMessage(MSG_ERROR_INVALID_IMAGE);
                status.setExcuteStatus(MSG_STATUS_FAILED);
                return status;
            }

            // build MD5
            byte[] hash = null;
            try {
                hash = MessageDigest.getInstance(Constants.SHA256_ALGORITHM).digest(resOrigin);
            } catch (NoSuchAlgorithmException e) {
                LOGGER.error("NoSuchAlgorithmException occurs for file: {}, errorMessage={}",fileName,e.getMessage());
                SuccessStatus status = new SuccessStatus();
                status.setSuccess(false);
                status.setMessage(MSG_ERROR_INVALID_IMAGE);
                status.setExcuteStatus(MSG_STATUS_FAILED);
                return status;
            }

            LOGGER.info("hash={}", hash);

            String actual = DatatypeConverter.printHexBinary(hash);
            if(StringUtils.isBlank(actual)){
                LOGGER.error("actual is null or empty");
                SuccessStatus status = new SuccessStatus();
                status.setSuccess(false);
                status.setMessage(MSG_ERROR_INVALID_IMAGE);
                status.setExcuteStatus(MSG_STATUS_FAILED);
                return status;
            }


            PdfData res = new PdfData();
            res.setFile(pdfStr);
            res.setChecksum(actual);
            
            LOGGER.info("Upload successful");
            return res;
        }
        else {
            LOGGER.error("Invalid file type for image upload: {}", D2CUtils.removeCRLF(fileType));
            SuccessStatus status = new SuccessStatus();
            status.setSuccess(false);
            status.setMessage(MSG_ERROR);
            status.setExcuteStatus(MSG_ERROR_INVALID_IMAGE);
            return status;
        }

    }
    
    @RequestMapping(value = "/encryptPdf", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public EncryptPdfBean encryptPdf(@RequestBody EncryptPdfBean encryptPdfBean, HttpServletRequest httpServletRequest) {
        LOGGER.info("Received request for pdf encryption with customId: {} and docType: {}",
                D2CUtils.removeCRLF(encryptPdfBean.getCustomId()),
                D2CUtils.removeCRLF(encryptPdfBean.getDocCategory()));
        CustomerApplication customerApplication = customerApplicationService.findCustomerApplicationByCustomId(encryptPdfBean.getCustomId());
        
        return pdfService.encryptPdf(encryptPdfBean, httpServletRequest, customerApplication);
    }
    
}
