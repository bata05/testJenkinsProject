package com.prudential.d2c.controller;

import org.apache.http.HttpStatus;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.prudential.d2c.common.Constants;
import com.prudential.d2c.entity.D2CResponse;
import com.prudential.d2c.entity.dto.PgpOrders;
import com.prudential.d2c.exception.D2CException;
import com.prudential.d2c.service.PgpCurrencyService;

import static com.prudential.d2c.exception.AppWideExceptionHandle.MSG_ERROR;

@RestController
@EnableAutoConfiguration
public class PgpCurrencyController extends BaseController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
    private static final String MSG_SAVE_SUCCESSFULLY = "Save Successfully";
    
    @Autowired
    private PgpCurrencyService pgpCurrencyService;

    @RequestMapping(
            value = "/getAndsetPgpRemaingBalance",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public Object checkPgpRemaingBalance(@RequestBody PgpOrders pgpRecord) {
    	
    	logger.info("Invoking getAndsetPgpRemaingBalance.");
        D2CResponse res = new D2CResponse();
        /*two scenarios:
         * when estimate apply
         * when submit to payment
         * if remain>=0 continue, else can't proceed
         */
        try {
            double remain = pgpCurrencyService.getRemainingBalance(pgpRecord);
            if (StringUtils.isNotEmpty(pgpRecord.getAmount())) {
                remain = remain - Float.parseFloat(pgpRecord.getAmount());
            }
            if (remain >= 0 && StringUtils.isNotEmpty(pgpRecord.getErefNo())) {
                pgpCurrencyService.savePgpRecord(pgpRecord);
                res.setMessage(MSG_SAVE_SUCCESSFULLY);
            }
            res.setStatus(Constants.SUCCESS_STATUS);
            res.setStatusCode(HttpStatus.SC_OK);
            res.setPayload(remain);

        }
        catch (Exception e) {
        	logger.error("CheckPgpRemaingBalance error", e);
            res.setStatusCode(HttpStatus.SC_INTERNAL_SERVER_ERROR);
            res.setMessage(MSG_ERROR);
            res.setStatus(Constants.ERROR_STATUS);
            throw new D2CException("CheckPgpRemaingBalance error");
        }
        return res;
    }
}
