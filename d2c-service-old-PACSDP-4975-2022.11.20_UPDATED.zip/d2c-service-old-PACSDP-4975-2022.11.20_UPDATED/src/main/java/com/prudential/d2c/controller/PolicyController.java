package com.prudential.d2c.controller;

import java.io.IOException;
import java.util.List;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.prudential.d2c.common.Constants;
import com.prudential.d2c.entity.D2CResponse;
import com.prudential.d2c.entity.Policy;
import com.prudential.d2c.entity.micro.ErrorMessagesResponse;
import com.prudential.d2c.entity.micro.PolicyRequestPayload;
import com.prudential.d2c.service.micro.PolicyService;

import static com.prudential.d2c.exception.AppWideExceptionHandle.MSG_ERROR;

@RestController
@EnableAutoConfiguration
public class PolicyController {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private PolicyService policyService;

    @RequestMapping(
            value = "/getLastIssuedPolicy",
            method = RequestMethod.POST,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object getLastIssuedPolicy(@RequestBody PolicyRequestPayload policyRequest) throws IOException {
        
    	logger.info("Invoking getLastIssuedPolicy.");

        logger.debug("Start to call getLastIssuedPolicy ,policyRequest : {} ", policyRequest);
        

        D2CResponse d2cResponse = new D2CResponse();

        try {
            List<Policy> policies = policyService.getLastIssuedPolicy(policyRequest);

            d2cResponse.setStatus(Constants.SUCCESS_STATUS);
            d2cResponse.setStatusCode(HttpStatus.SC_OK);
            d2cResponse.setPayload(policies);

        }
        catch (HttpClientErrorException he) {
            logger.error("Error:" + he.getResponseBodyAsString());
            logger.error("HTTP status code:" + he.getRawStatusCode());
            ObjectMapper mapper = new ObjectMapper();
            ErrorMessagesResponse error = mapper.readValue(he.getResponseBodyAsString(), ErrorMessagesResponse.class);
            logger.error("Error Message:" + error.getPayload().getErrorMessages().get(0));

            d2cResponse.setStatus(Constants.ERROR_STATUS);
            d2cResponse.setMessage(error.getPayload().getErrorMessages().get(0));
            d2cResponse.setStatusCode(he.getRawStatusCode());
        }
        catch (Exception e) {
            logger.error("Other exception happen when calling getLastIssuedPolicy:", e);

            d2cResponse.setStatus(Constants.ERROR_STATUS);
            d2cResponse.setStatusCode(HttpStatus.SC_INTERNAL_SERVER_ERROR);
            d2cResponse.setMessage(MSG_ERROR);
        }
        return d2cResponse;
    }
}
