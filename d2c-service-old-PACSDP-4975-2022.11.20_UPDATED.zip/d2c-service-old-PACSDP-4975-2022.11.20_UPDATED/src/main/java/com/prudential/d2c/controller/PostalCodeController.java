package com.prudential.d2c.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.prudential.d2c.entity.dto.PostalCodeInfo;
import com.prudential.d2c.repository.PostalCodeRepository;

@RestController
public class PostalCodeController extends BaseController {

    // Define the logger object for this class
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private PostalCodeRepository postalcodeRepository;

    /**
     * This method is used to fetch address details based on postal code input
     * 
     * @param postalcode
     * @return
     */
    @RequestMapping(
            value = "/postalCode",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object postalcodeRA(@RequestBody PostalCodeInfo postalcode) {

    	logger.info("Invoking postalCode.");
        String pc = postalcode.getPostalCode();
        return postalcodeRepository.findById(pc).orElse(null);
    }
}
