package com.prudential.d2c.controller;

import com.prudential.d2c.common.Constants;
import com.prudential.d2c.common.ProductComputeValidatorEnum;
import com.prudential.d2c.entity.*;
import com.prudential.d2c.entity.dto.ConfigureProperties;
import com.prudential.d2c.entity.dto.CustomerApplication;
import com.prudential.d2c.entity.micro.*;
import com.prudential.d2c.entity.micro.payload.ComputeResponsePayload;
import com.prudential.d2c.exception.D2CException;
import com.prudential.d2c.repository.ConfigurePropertiesRepository;
import com.prudential.d2c.service.*;
import com.prudential.d2c.service.impl.UserTransactionVerifyService;
import com.prudential.d2c.service.micro.SQSEngineService;
import com.prudential.d2c.utils.D2CUtils;
import com.prudential.d2c.utils.DataUtils;
import com.prudential.d2c.utils.DataValidator;
import com.prudential.d2c.utils.DecryptionUtil;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@RestController
@EnableAutoConfiguration
public class ProductsController extends BaseController {

    private static final String AGENT_CODE_MUSTN_T_BE_NULL = "AgentCode Mustn't be null!";
    public static final String VALIDATE_CUSTOMER_TRANSACTION_IN_COMPUTE_ALL_FOR_SUMMARY_ = "ValidateCustomerTransaction in computeAllForSummary ";
    public static final String ERROR_DURING_COMPUTE_ALL_FOR_SUMMARY_ = "Error during computeAllForSummary ";

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private static final String PGP_BUYING_YEARS = "PGP_BUYING_YEARS";
    private static final String DOC_ID_PROD_TB1 = "id_prod_tb1";
    private static final String DOC_ID_PROD_RB1 = "id_prod_rb1";
    private static final String DOC_ID_PROD_TC1 = "id_prod_tc1";

    @Autowired
    private SQSEngineService sqsEngineService;
    @Autowired
    private ErefDataService erefDataService;
    @Autowired
    private ConfigurePropertiesRepository configRepository;

    @Autowired
    private ClientService clientService;

    @Autowired
    private UserTransactionVerifyService userTransactionVerifyService;

    @Autowired
    private TranCustomerAppService tranCustomerAppService;

    @Autowired
    private CustomerApplicationService customerApplicationService;

    @Autowired
    private DPLoggerService dpLoggerService;

    @Autowired
    ProductService productService;

    @Autowired
    private ProductConfigService productConfigService;

    @Autowired
    private ProductPromoService productPromoService;

    @RequestMapping(value = "/products", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object getProducts() {
        this.logInfo("Start to call getProducts.");
        List<ProductList> productList = sqsEngineService.getProducts();
        return new D2CResponse(Constants.SUCCESS_STATUS, HttpStatus.SC_OK, null, productList);
    }

    @RequestMapping(
            value = "/products/{docId}",
            method = RequestMethod.POST,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object getProducts(@PathVariable String docId, @RequestBody List<LifeProfile> lifeProfiles) {
        this.logInfo("Invoking products/{docId");
        Product product;
    	CustomerApplication customerApplication = customerApplicationService.findCustomerApplicationByCustomId(lifeProfiles.get(0).getCustomID());
        
        if (DOC_ID_PROD_TB1.equalsIgnoreCase(docId) || DOC_ID_PROD_RB1.equalsIgnoreCase(docId)
                || DOC_ID_PROD_TC1.equalsIgnoreCase(docId)) {
        	
            product = sqsEngineService.getPruProtect(docId, lifeProfiles, customerApplication);
        } else {
            product = sqsEngineService.getProducts(docId, lifeProfiles, customerApplication);
        }
        return new D2CResponse(Constants.SUCCESS_STATUS, HttpStatus.SC_OK, null, product);
    }

    /**
     * This method will be used to call compute call for loading application page
     *
     * @param compute
     * @return
     * @throws IOException
     */
    @RequestMapping(value = "/loading/compute", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object computeForLoadingInfo(@RequestBody ComputeBean compute) throws IOException {
        D2CResponse result = (D2CResponse) this.compute(compute);
        return result;
    }

    private void validateProduct(@RequestBody ComputeBean compute) {
        if (compute.getReqType().equals(ProductComputeValidatorEnum.ET.name())) {
            compute.getLifeProfiles().get(0).setClientIndicator("ALL");
            D2CResponse products = (D2CResponse) this.getProducts(ProductComputeValidatorEnum.ET.getDocId(), compute.getLifeProfiles());
            Product productFromService = (Product) products.getPayload();
            for (Product reqProd : compute.getSelectedSQSProducts()) {
                if (!reqProd.getComponents().equals(productFromService.getComponents())) {
                    throw new D2CException("Product comp validation error during loading compute");
                }

                //Selected comp plan option
                List<Component> reqComps = reqProd.getComponents();
                List<Component> componentFromServices = productFromService.getComponents();

                for (Component reqComp : reqComps) {
                    for (Component compFromService : componentFromServices) {
                        PlanOption selectedCompoPlanOption = reqComp.getSelectedCompoPlanOption();
                        List<PlanOption> compoPlanOptions = compFromService.getCompoPlanOptions();
                        for (PlanOption planOption : compoPlanOptions) {
                            if (selectedCompoPlanOption.getOptCode().equals(planOption.getOptCode())) {
                                if (!selectedCompoPlanOption.equals(planOption)) {
                                    throw new D2CException("Product comp validation error during loading compute");
                                }
                                break;
                            }
                        }
                    }

                }
            }
        }
    }


    /**
     * Validate ptv product
     * @param bean
     * @return
     */
    private boolean isValidatePTVProduct(ComputeBean bean) {
    	CustomerApplication customerApplication = customerApplicationService.findCustomerApplicationByCustomId(bean.getLifeProfiles().get(0).getCustomID());
        
        if (bean.getReqType() != null && Constants.PRU_TERM_VANTAGE.equalsIgnoreCase(bean.getReqType()) && bean.getSelectedSQSProducts().size() > 0) {
            Product selectedProduct = bean.getSelectedSQSProducts().get(0);
            Product productLA = sqsEngineService.getProducts(Constants.DOCID_PREFIX + Constants.CATEGORY_PTV.toLowerCase(), bean.getLifeProfiles(), customerApplication);
            return DataValidator.validatePTVProductInfo(selectedProduct, productLA);
        }
        return true;
    }

    /**
     * This method will be used to call compute call for summary page
     *
     * @param compute
     * @return
     * @throws IOException
     */
    @RequestMapping(value = "/summary/compute", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object computeForSummary(@RequestBody ComputeBean compute) throws IOException {
        D2CResponse result = (D2CResponse) this.compute(compute);
        return result;
    }

    /**
     * Validate customer transaction information
     *
     * @param compute
     * @param result
     * @param s
     * @param s2
     */
    @SuppressWarnings("unused")
	private void validateCustomerTransaction(ComputeBean compute, D2CResponse result, String s, String s2) {
    	CustomerApplication customerApplication = customerApplicationService.findCustomerApplicationByCustomId(compute.getLifeProfiles().get(0).getCustomID());
        
        boolean validateCustomerTransaction = tranCustomerAppService.validateCustomerTransaction(
                (ComputeResponsePayload) result.getPayload(), compute, Constants.EMPTY_STRING, customerApplication);
        logger.info(s + validateCustomerTransaction);
        if (!validateCustomerTransaction) {
            throw new D2CException(s2);
        }
    }

    /**
     * @param compute
     * @param payload
     * @param s
     * @param s2
     */
    private void validateCustomerTransactionComputeAll(ComputeBean compute, ComputeResponsePayload payload,
                                                       String s, String s2, String requestType) {
    	CustomerApplication customerApplication = customerApplicationService.findCustomerApplicationByCustomId(compute.getLifeProfiles().get(0).getCustomID());
        
        boolean validateCustomerTransaction = tranCustomerAppService.validateCustomerTransaction(payload, compute, requestType, customerApplication);
        logger.info(s + validateCustomerTransaction);
        if (!validateCustomerTransaction) {
            throw new D2CException(s2);
        }
    }

    @Autowired
    private DpApiService apiService;

    /**
     * This method will be used to call compute all call for summary page
     *
     * @param compute
     * @return
     * @throws IOException
     */
    @RequestMapping(value = "/summary/computeAll", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object computeAllForSummary(@RequestBody ComputeBean compute) throws IOException {
        this.logInfo("Invoking /summary/computeAll");
        ComputeBean bean = reGenerateProfile(compute);
        if (!validateComputeAllRequest(bean)) {
            return D2CResponse.with500Message("Error validating compute all request ");
        }

        if(!D2CUtils.isValidComputeRequestAgeAndDob(bean)){
            return D2CResponse.badRequestExceptionMessage();
        }

        ComputeResponsePayload payload = sqsEngineService.computeAll(bean);
        payload.setErefCode(apiService.generateErefNo(compute.getCustomId(), payload));
        productPromoService.calculateDiscountPromo(payload);
        validateComputeAllRequestForET(compute, payload);
        savePayload(compute, bean, payload);
        return new D2CResponse(Constants.SUCCESS_STATUS, HttpStatus.SC_OK, null, bean);
    }

    /**
     * Save payload blob content to db for e submission / proposal
     * @param compute
     * @param bean
     * @param payload
     */
    public void savePayload(ComputeBean compute, ComputeBean bean, ComputeResponsePayload payload) {
        bean.setErefCode(payload.getErefCode());
        bean.setPdfData(payload.getPdfData());
        bean.setLifeProfiles(payload.getLifeProfiles());
        bean.setSelectedSQSProducts(payload.getSelectedSQSProducts());
        tranCustomerAppService.saveComputeAllObj(payload, compute.getCustomId(), null);
    }

    /**
     * For ET validate compute all request
     * @param compute
     * @param payload
     */
    public void validateComputeAllRequestForET(ComputeBean compute, ComputeResponsePayload payload) {
        if (CollectionUtils.isNotEmpty(compute.getSelectedSQSProducts())
                && userTransactionVerifyService.verifyProductForComputeValidation(compute.getSelectedSQSProducts().get(0).getProdCode(), null)) {
            validateCustomerTransactionComputeAll(compute, payload, VALIDATE_CUSTOMER_TRANSACTION_IN_COMPUTE_ALL_FOR_SUMMARY_,
                    ERROR_DURING_COMPUTE_ALL_FOR_SUMMARY_, Constants.COMPUTE_ALL);
        }
    }

    @RequestMapping(value = "/compute", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object compute(@RequestBody ComputeBean compute) throws IOException {

        this.logInfo("Invoking /compute.");
        ComputeBean bean = reGenerateProfile(compute);

        if(!D2CUtils.isValidComputeRequestAgeAndDob(bean)){
            return D2CResponse.badRequestExceptionMessage();
        }
        
        CustomerApplication customerApplication = customerApplicationService.findCustomerApplicationByCustomId(bean.getLifeProfiles().get(0).getCustomID());

        ComputeResponsePayload payload = sqsEngineService.compute(bean, customerApplication);
        validateProduct(compute);
        if (!isValidatePTVProduct(bean)) {
            return D2CResponse.with500Message("error in compute request");
        }

        productPromoService.calculateDiscountPromo(payload);

        return new D2CResponse(Constants.SUCCESS_STATUS, HttpStatus.SC_OK, null, payload);
    }

    //    @RequestMapping(value = "/computeAll", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
//    @ResponseBody
//    disable this method for pen-test issue
    @SuppressWarnings("unused")
	public Object computeAll(@RequestBody ComputeBean compute) {
        D2CResponse d2cResponse = new D2CResponse();

        ComputeBean bean = reGenerateProfile(compute);
        ComputeResponsePayload payload;

        payload = sqsEngineService.computeAll(bean);

        if (Constants.PRU_FLEXI_CASH.equalsIgnoreCase(bean.getReqType())) {
            caculateDeathBenefitForPFC(payload);
        }

        payload = sqsEngineService.computeAll(bean);

        if (StringUtils.isEmpty(compute.getErefCode())) {
            String agentCode = assignedAgentService.getAgentCodeByCustomId(compute.getCustomId());

            if (StringUtils.isEmpty(agentCode)) {
                logger.warn(AGENT_CODE_MUSTN_T_BE_NULL);
                return new D2CResponse(Constants.ERROR_STATUS, HttpStatus.SC_INTERNAL_SERVER_ERROR, AGENT_CODE_MUSTN_T_BE_NULL, null);
            }

            if (!agentCode.equals(Constants.NOT_APPLICABLE)) {
                String erefCode = erefDataService.generateEREFCode(agentCode);
                bean.setErefCode(erefCode);
            }
        } else {
            bean.setErefCode(compute.getErefCode());
        }

        bean.setPdfData(payload.getPdfData());
        bean.setLifeProfiles(payload.getLifeProfiles());
        bean.setSelectedSQSProducts(payload.getSelectedSQSProducts());

        return new D2CResponse(Constants.SUCCESS_STATUS, HttpStatus.SC_OK, null, bean);
    }

    @RequestMapping(value = "/getPGPSaveYears", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public String getPGPSaveYears() {
        logger.info("Start to get configged PGP save year");
        ConfigureProperties properties = configRepository.findById(PGP_BUYING_YEARS).orElse(null);
        return properties.getConValue();
    }

    private ComputeBean reGenerateProfile(ComputeBean bean) {
        List<LifeProfile> profiles = new ArrayList<>();

        for (LifeProfile profile : bean.getLifeProfiles()) {
            LifeProfile newProfile = new LifeProfile();
            try {
                BeanUtils.copyProperties(newProfile, profile);
            } catch (IllegalAccessException | InvocationTargetException e) {
                throw new D2CException("ReGenerateProfile Error", e);
            }
            if (StringUtils.isNotEmpty(profile.getName())) {
                newProfile.setName(decrypt(profile.getName()));
            }

            if (StringUtils.isNotEmpty(profile.getNric())) {
                newProfile.setNric(decrypt(profile.getNric()));
            }

            if (profile.getProposal() != null && profile.getProposal().getHomeAddress() != null) {
                LifeProfileProposalAddress homeAddress = reGenerateAddress(profile.getProposal().getHomeAddress());

                newProfile.getProposal().setHomeAddress(homeAddress);
            }
            if (profile.getProposal() != null && profile.getProposal().getMailingAddress() != null) {
                LifeProfileProposalAddress mailingAddress = reGenerateAddress(
                        profile.getProposal().getMailingAddress());
                newProfile.getProposal().setMailingAddress(mailingAddress);
            }
            if (profile.getProposal() != null && profile.getProposal().getContact() != null) {
                LifeProfileProposalContact contact = reGenerateContact(profile.getProposal().getContact());
                newProfile.getProposal().setContact(contact);
            }

            profiles.add(newProfile);
        }

        bean.setLifeProfiles(profiles);

        return bean;

    }

    private LifeProfileProposalAddress reGenerateAddress(LifeProfileProposalAddress address) {
        LifeProfileProposalAddress newAddress = new LifeProfileProposalAddress();

        if (StringUtils.isNotEmpty(address.getBuilding())) {
            newAddress.setBuilding(decrypt(address.getBuilding()));
        }
        if (StringUtils.isNotEmpty(address.getCity())) {
            newAddress.setCity(decrypt(address.getCity()));
        }
        if (StringUtils.isNotEmpty(address.getCountryCode())) {
            newAddress.setCountryCode(decrypt(address.getCountryCode()));
        }
        if (StringUtils.isNotEmpty(address.getHouseNo())) {
            newAddress.setHouseNo(decrypt(address.getHouseNo()));
        }
        if (StringUtils.isNotEmpty(address.getPostcode())) {
            newAddress.setPostcode(decrypt(address.getPostcode()));
        }
        if (StringUtils.isNotEmpty(address.getStreet())) {
            newAddress.setStreet(decrypt(address.getStreet()));
        }
        if (StringUtils.isNotEmpty(address.getUnitNo())) {
            newAddress.setUnitNo(decrypt(address.getUnitNo()));
        }

        return newAddress;

    }

    private LifeProfileProposalContact reGenerateContact(LifeProfileProposalContact contact) {
        LifeProfileProposalContact newContact = new LifeProfileProposalContact();

        if (StringUtils.isNotEmpty(contact.getHomePhoneNo())) {
            newContact.setHomePhoneNo(decrypt(contact.getHomePhoneNo()));
        }
        if (StringUtils.isNotEmpty(contact.getMobilePhoneNo())) {
            newContact.setMobilePhoneNo(decrypt(contact.getMobilePhoneNo()));
        }
        if (StringUtils.isNotEmpty(contact.getOfficePhoneNo())) {
            newContact.setOfficePhoneNo(decrypt(contact.getOfficePhoneNo()));
        }

        return newContact;
    }

    private boolean validateComputeAllRequest(ComputeBean bean) {
        // validate payload before calling compute all and generate PDF. for PT specifically.
        if (bean.getGeneratePDF() && Constants.PRU_PROTECT_TERM.equalsIgnoreCase(bean.getReqType())) {
            // 1st. check profile if it's existing customer.
            CustomerApplication application = customerApplicationService.findCustomerApplicationByCustomId(bean.getCustomId());
            if (StringUtils.isNotEmpty(application.getClientNumber())) {
                ClientResponse clientResponse = clientService.getClientInfo(application.getClientNumber());
                if (clientResponse.getPayload().getClientList().size() > 0) {
                    ClientInfo ci = clientResponse.getPayload().getClientList().get(0);
                    LifeProfile lp = bean.getLifeProfiles().get(0);
                    lp = DataUtils.setValfromBackend(lp, ci);
                    if (!DataValidator.validateClientProfile(lp, ci)) {
                        return false;
                    }
                }
            }
            // 2nd check product and compute request
            if (bean.getSelectedSQSProducts().size() > 0) {
                Product selectedProduct = bean.getSelectedSQSProducts().get(0);
                // check product code
                CustomerApplication customerApplication = customerApplicationService.findCustomerApplicationByCustomId(bean.getLifeProfiles().get(0).getCustomID());

                Product productLA = sqsEngineService.getPruProtect(selectedProduct.getDocId(), bean.getLifeProfiles(), customerApplication);
                if (!DataValidator.validateProductInfo(selectedProduct, productLA)) {
                    return false;
                }
                // 3rd check compute result
                ComputeBean newCompute = new ComputeBean();
                newCompute.setLifeProfiles(bean.getLifeProfiles());
                newCompute.setGeneratePDF(false);
                newCompute.setSelectedSQSProducts(bean.getSelectedSQSProducts());
                ComputeResponsePayload newResult = sqsEngineService.compute(newCompute, customerApplication);
                if (!(newResult.getSelectedSQSProducts().size() > 0
                        && DataValidator.validateComputeResult(bean.getSelectedSQSProducts().get(0), newResult.getSelectedSQSProducts().get(0)))) {
                    return false;
                }
            }
        }

        return true;
    }

    // Validate AllowedOccupations and AllowedOccupations Code
    public boolean occupationIsValid(LifeProfile lp) {
        String occupationId = lp.getOccupation();
        String occupationCode = lp.getOccupationCode();

        AllowedOccupations[] values = AllowedOccupations.values();

        return Arrays.stream(values)
                .anyMatch(o -> o.getId().equals(occupationId) && o.getCode().equals(occupationCode));
    }

    private String decrypt(String req) {
        return DecryptionUtil.decryption(req, configProperties);
    }

    /**
     * TODO This method should be removed when we implement plmf product
     *
     * @param compute
     * @return
     */
    @RequestMapping(value = "/computeAllForPlmf", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Object computeAllForPlmf(@RequestBody ComputeBean compute) {
        logger.info("Invoking /computeAllForPlmf ");
        ComputeBean bean = reGenerateProfile(compute);

        if(!D2CUtils.isValidComputeRequestAgeAndDob(bean)){
            return D2CResponse.badRequestExceptionMessage();
        }

        ComputeResponsePayload payload;
        payload = sqsEngineService.computeAll(bean);
        bean.setErefCode(compute.getErefCode());
        bean.setPdfData(payload.getPdfData());
        bean.setLifeProfiles(payload.getLifeProfiles());
        bean.setSelectedSQSProducts(payload.getSelectedSQSProducts());
        return new D2CResponse(Constants.SUCCESS_STATUS, HttpStatus.SC_OK, null, bean);
    }

    private void caculateDeathBenefitForPFC(ComputeResponsePayload payload) {
        int term = payload.getSelectedSQSProducts().get(0).getComponents().get(0).getTerm();

        String totalDeathBenefit = payload.getSelectedSQSProducts().get(0).getTables()
                .getMainBenefitTable().getData().get(term - 1).get(26);
        String totalSV = payload.getSelectedSQSProducts().get(0).getTables()
                .getMainBenefitTable().getData().get(term - 1).get(32);

        payload.getSelectedSQSProducts().get(0).setTotalDeathBenefit(new BigDecimal(totalDeathBenefit));
        payload.getSelectedSQSProducts().get(0).setTotalSV(new BigDecimal(totalSV));
    }

    @RequestMapping(
            value = "/getChannels/{product}",
            method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public D2CResponse getChannels(@PathVariable String product) {
        try {
            return new D2CResponse(Constants.SUCCESS_STATUS, HttpStatus.SC_OK, null, productService.getChannels(product));
        } catch (Exception e) {
            return new D2CResponse(Constants.ERROR_STATUS, HttpStatus.SC_INTERNAL_SERVER_ERROR,
                    "Error While Getting Channels Based on Product", null);
        }
    }

    @RequestMapping(
            value = "/products/discardOldProductConfig",
            method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public D2CResponse discardOldProductConfig() {
        try {
            return new D2CResponse(Constants.SUCCESS_STATUS, HttpStatus.SC_OK, null, productConfigService.invalidateProductConfigCache());
        } catch (Exception e) {
            return new D2CResponse(Constants.ERROR_STATUS, HttpStatus.SC_INTERNAL_SERVER_ERROR,
                    "Error While Evicting Cache Table for # PRODUCT_CONFIG_INFO", null);
        }
    }

    /**
     *
     * @param needsAnalysisRequest
     * @return
     */
    @RequestMapping(
        value = "/saveNeedsAnalysis",
        method = RequestMethod.POST,
        consumes = MediaType.APPLICATION_JSON_VALUE,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public D2CResponse saveNeedsAnalysis(@RequestBody NeedsAnalysisRequest needsAnalysisRequest) {
        logger.info("Invoking /saveNeedsAnalysis");
        logger.info(needsAnalysisRequest.toString());
        try {
            NeedsAnalysisRequest needsAnalysisResponse = productService.saveNeedsAnalysis(needsAnalysisRequest);
            return new D2CResponse(Constants.SUCCESS_STATUS, HttpStatus.SC_OK, null, needsAnalysisResponse);
        } catch (Exception e) {
            logger.error(e.toString());
            return new D2CResponse(Constants.ERROR_STATUS, HttpStatus.SC_INTERNAL_SERVER_ERROR,
                "Error While Saving Needs Analysis", needsAnalysisRequest);
        }
    }

    /**
     * Logger
     * @param exception
     */
    protected void logError(Exception exception){
        dpLoggerService.error(exception, logger);
    }

    /**
     * Logger
     * @param message
     */
    protected void logInfo(String message){
        dpLoggerService.info(message, logger);
    }
}