package com.prudential.d2c.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.prudential.d2c.entity.micro.Compute;
import com.prudential.d2c.service.impl.EsubServiceImpl;

@RestController
@EnableAutoConfiguration
public class TestController {

	@Autowired
	private EsubServiceImpl esubService;

	@GetMapping(value = "/testESUB")
	private @ResponseBody
	Compute testESUB(@RequestParam(required = false, name = "transactionId") String transactionId) {
		return esubService.submitEsub(transactionId);
	}
}
