package com.prudential.d2c.controller;

import com.prudential.d2c.common.dto.URLDto;
import com.prudential.d2c.service.URLService;
import com.prudential.d2c.utils.D2CUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/url")
public class URLController {

    @Autowired
    private URLService urlService;

    private final static Logger logger = LoggerFactory.getLogger(URLController.class);

    @RequestMapping("/validate")
    public Object validateChannel(@RequestBody URLDto urlDto){
        logger.info("URLController validateChannel urlDto="+ D2CUtils.removeCRLF(urlDto.toString()));
        return urlService.validateURL(urlDto);
    }

}
