package com.prudential.d2c.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;
import java.util.Objects;

@Entity
@Table(name = "AGENT_DETAILS")
@EntityListeners(AuditingEntityListener.class)
@JsonIgnoreProperties(ignoreUnknown = true)
public class AgentDetails {

    @Id
    @SequenceGenerator(name = "agentDetailsSeqGen", sequenceName = "AGENTDETAILSEQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "agentDetailsSeqGen")
    @Column(name = "ID_NO", nullable = false)
    private Integer idNo;

    @Column(name = "CUSTOM_ID", nullable = false)
    private String custId;

    @Column(name = "AGENT_CODE", nullable = false)
    private String agentCode;

    @Column(name = "AGENT_NAME")
    private String agentName;

    @Column(name = "BUSINESS_SRC")
    private String businessSource;

    @Column(name = "BUSINESS_SUB_SRC")
    private String businessSubSource;

    @Column(name = "AGENT_TYPE")
    private String agentType;

    @Column(name = "EMAIL_ADDRESS")
    private String emailAddress;

    @Column(name = "MOB_NUMBER", nullable = false)
    private String mobileNumber;

    @Column(name = "CREATED_DATE")
    @CreatedDate
    private Date createDate;
    
    @Column(name = "AGENT_CHANNEL_CODE")
    private String agentChannelCode;

    public String getCustId() {
        return custId;
    }

    public void setCustId(String custId) {
        this.custId = custId;
    }

    public String getAgentCode() {
        return agentCode;
    }

    public void setAgentCode(String agentCode) {
        this.agentCode = agentCode;
    }

    public String getAgentName() {
        return agentName;
    }

    public void setAgentName(String agentName) {
        this.agentName = agentName;
    }

    public String getBusinessSource() {
        return businessSource;
    }

    public void setBusinessSource(String businessSource) {
        this.businessSource = businessSource;
    }

    public String getBusinessSubSource() {
        return businessSubSource;
    }

    public void setBusinessSubSource(String businessSubSource) {
        this.businessSubSource = businessSubSource;
    }

    public String getAgentType() {
        return agentType;
    }

    public void setAgentType(String agentType) {
        this.agentType = agentType;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }
    
    public String getAgentChannelCode() {
        return agentChannelCode;
    }
    
    public void setAgentChannelCode(String agentChannelCode) {
        this.agentChannelCode = agentChannelCode;
    }
    
    @Override
    public String toString() {
        return "AgentDetails{" +
                       "idNo=" + idNo +
                       ", custId='" + custId + '\'' +
                       ", agentCode='" + agentCode + '\'' +
                       ", agentName='" + agentName + '\'' +
                       ", businessSource='" + businessSource + '\'' +
                       ", businessSubSource='" + businessSubSource + '\'' +
                       ", agentType='" + agentType + '\'' +
                       ", emailAddress='" + emailAddress + '\'' +
                       ", mobileNumber='" + mobileNumber + '\'' +
                       ", createDate=" + createDate +
                       ", agentChannelCode='" + agentChannelCode + '\'' +
                       '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (!(o instanceof AgentDetails))
            return false;
        AgentDetails that = (AgentDetails) o;
        return Objects.equals(idNo, that.idNo) &&
                       Objects.equals(getCustId(), that.getCustId()) &&
                       Objects.equals(getAgentCode(), that.getAgentCode()) &&
                       Objects.equals(getAgentName(), that.getAgentName()) &&
                       Objects.equals(getBusinessSource(), that.getBusinessSource()) &&
                       Objects.equals(getBusinessSubSource(), that.getBusinessSubSource()) &&
                       Objects.equals(getAgentType(), that.getAgentType()) &&
                       Objects.equals(getEmailAddress(), that.getEmailAddress()) &&
                       Objects.equals(getMobileNumber(), that.getMobileNumber()) &&
                       Objects.equals(createDate, that.createDate) &&
                       Objects.equals(getAgentChannelCode(), that.getAgentChannelCode());
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(idNo, getCustId(), getAgentCode(), getAgentName(), getBusinessSource(), getBusinessSubSource(),
                getAgentType(), getEmailAddress(), getMobileNumber(), createDate, getAgentChannelCode());
    }
}
