package com.prudential.d2c.entity;

public enum AllowedOccupations {
    PROFESSIONAL("1", "OTH1", "Professional / White collar / Office worker"),
    LIGHT_WORKER("2", "OTH2", "Sales / Light manual worker"),
    SKILLED_WORKER("3", "OTH3", "Skilled / Semi-skilled worker");

    private final String id;
    private final String code;
    private final String description;
    AllowedOccupations(String id, String code, String description) {
        this.id = id;
        this.code = code;
        this.description = description;
    }

    public String getId() { return id; }
    public String getCode() { return code; }
    public String getDescription() { return description; }
}
