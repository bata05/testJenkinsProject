package com.prudential.d2c.entity;



import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AppDataResponse extends SuccessStatus {
	
	private String erefNo;
	private String proposal;
	private String payRequest;
	private String payResponse;
	private String md5Checksum;
	
	
	
	/**
	 * @return the erefNo
	 */
	public String getErefNo() {
		return erefNo;
	}



	/**
	 * @param erefNo the erefNo to set
	 */
	public void setErefNo(String erefNo) {
		this.erefNo = erefNo;
	}



	/**
	 * @return the proposal
	 */
	public String getProposal() {
		return proposal;
	}



	/**
	 * @param proposal the proposal to set
	 */
	public void setProposal(String proposal) {
		this.proposal = proposal;
	}



	/**
	 * @return the payRequest
	 */
	public String getPayRequest() {
		return payRequest;
	}



	/**
	 * @param payRequest the payRequest to set
	 */
	public void setPayRequest(String payRequest) {
		this.payRequest = payRequest;
	}



	/**
	 * @return the payResponse
	 */
	public String getPayResponse() {
		return payResponse;
	}



	/**
	 * @param payResponse the payResponse to set
	 */
	public void setPayResponse(String payResponse) {
		this.payResponse = payResponse;
	}



	/**
	 * @return the md5Checksum
	 */
	public String getMd5Checksum() {
		return md5Checksum;
	}



	/**
	 * @param md5Checksum the md5Checksum to set
	 */
	public void setMd5Checksum(String md5Checksum) {
		this.md5Checksum = md5Checksum;
	}



	@Override
	public String toString() {
		return "AppDataResponse [erefNo=" + erefNo + ", payRequest=" + payRequest + ", payResponse=" + payResponse
				+ ", md5Checksum=" + md5Checksum + "]";
	}

}
