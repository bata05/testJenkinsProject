package com.prudential.d2c.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Benefit {

	private String medicalLabel;
	private String medicalValue;
	private String traditionalLabel;
	private String traditionalValue;
	private String privateTransportLabel;
	private String privateTransportValue;
	private String publicTransportLabel;
	private String publicTransportValue;
	private String allAccidentsLabel;
	private String allAccidentsValue;

	public String getMedicalLabel() {
		return medicalLabel;
	}

	public void setMedicalLabel(String medicalLabel) {
		this.medicalLabel = medicalLabel;
	}

	public String getMedicalValue() {
		return medicalValue;
	}

	public void setMedicalValue(String medicalValue) {
		this.medicalValue = medicalValue;
	}

	public String getTraditionalLabel() {
		return traditionalLabel;
	}

	public void setTraditionalLabel(String traditionalLabel) {
		this.traditionalLabel = traditionalLabel;
	}

	public String getTraditionalValue() {
		return traditionalValue;
	}

	public void setTraditionalValue(String traditionalValue) {
		this.traditionalValue = traditionalValue;
	}

	public String getPrivateTransportLabel() {
		return privateTransportLabel;
	}

	public void setPrivateTransportLabel(String privateTransportLabel) {
		this.privateTransportLabel = privateTransportLabel;
	}

	public String getPrivateTransportValue() {
		return privateTransportValue;
	}

	public void setPrivateTransportValue(String privateTransportValue) {
		this.privateTransportValue = privateTransportValue;
	}

	public String getPublicTransportLabel() {
		return publicTransportLabel;
	}

	public void setPublicTransportLabel(String publicTransportLabel) {
		this.publicTransportLabel = publicTransportLabel;
	}

	public String getPublicTransportValue() {
		return publicTransportValue;
	}

	public void setPublicTransportValue(String publicTransportValue) {
		this.publicTransportValue = publicTransportValue;
	}

	public String getAllAccidentsLabel() {
		return allAccidentsLabel;
	}

	public void setAllAccidentsLabel(String allAccidentsLabel) {
		this.allAccidentsLabel = allAccidentsLabel;
	}

	public String getAllAccidentsValue() {
		return allAccidentsValue;
	}

	public void setAllAccidentsValue(String allAccidentsValue) {
		this.allAccidentsValue = allAccidentsValue;
	}

}
