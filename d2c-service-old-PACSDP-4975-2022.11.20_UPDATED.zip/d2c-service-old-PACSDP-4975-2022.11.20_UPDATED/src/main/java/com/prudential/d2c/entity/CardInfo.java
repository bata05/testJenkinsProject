package com.prudential.d2c.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class CardInfo {
	private boolean onUs;

	/**
	 * @return the onUs
	 */
	public boolean isOnUs() {
		return onUs;
	}

	/**
	 * @param onUs the onUs to set
	 */
	public void setOnUs(boolean onUs) {
		this.onUs = onUs;
	}
}
