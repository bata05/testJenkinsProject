package com.prudential.d2c.entity;

import com.prudential.d2c.entity.dto.ChannelAPIAudit;
import com.prudential.d2c.entity.micro.ChannelAPIRequest;
import com.prudential.d2c.entity.micro.ChannelAPIResponse;
import com.prudential.d2c.type.ChannelAPIExceptionType;
import org.apache.commons.lang.StringUtils;

import java.util.ArrayList;
import java.util.List;

public class ChannelAPIDto {

    public enum ChannelAPIType {
        QUOTATION,
        QUOTATION_DOCUMENT,
        APPLICATION_SUBMISSION
    }

    private String channelName;

    private ChannelAPIType requestType;

    private String encryptedRequestPayload;

    private String requestJson;

    private List<ChannelAPIExceptionType> errors;

    @SuppressWarnings("rawtypes")
	private ChannelAPIRequest channelAPIRequest;

    @SuppressWarnings("rawtypes")
	private ChannelAPIResponse channelAPIResponse;

    private String channelTransactionID;

    private String DPTransactionID;

    private String responseJson;

    private String encryptedResponsePayload;

    private String dpProductCode;

    private String partnerEref;

    private ChannelAPIAudit audit;

    public ChannelAPIDto(String encryptedRequestPayload, ChannelAPIType requestType, String DPTransactionID, String channelName) {
        this.encryptedRequestPayload = encryptedRequestPayload;
        this.requestType = requestType;
        this.DPTransactionID = DPTransactionID;
        this.errors = new ArrayList<>();
        this.channelName = channelName;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public ChannelAPIType getRequestType() {
        return requestType;
    }

    public void setRequestType(ChannelAPIType requestType) {
        this.requestType = requestType;
    }

    public String getEncryptedRequestPayload() {
        return encryptedRequestPayload;
    }

    public void setEncryptedRequestPayload(String encryptedRequestPayload) {
        this.encryptedRequestPayload = encryptedRequestPayload;
    }

    public String getRequestJson() {
        return requestJson;
    }

    public void setRequestJson(String requestJson) {
        this.requestJson = requestJson;
    }

    public List<ChannelAPIExceptionType> getErrors() {
        return errors;
    }

    public void setErrors(List<ChannelAPIExceptionType> errors) {
        this.errors = errors;
    }

    @SuppressWarnings("rawtypes")
	public ChannelAPIRequest getChannelAPIRequest() {
        return channelAPIRequest;
    }

    @SuppressWarnings("rawtypes")
	public void setChannelAPIRequest(ChannelAPIRequest channelAPIRequest) {
        this.channelAPIRequest = channelAPIRequest;
    }

    @SuppressWarnings("rawtypes")
	public ChannelAPIResponse getChannelAPIResponse() {
        return channelAPIResponse;
    }

    @SuppressWarnings("rawtypes")
	public void setChannelAPIResponse(ChannelAPIResponse channelAPIResponse) {
        this.channelAPIResponse = channelAPIResponse;
    }

    public String getTransactionId() {
        return channelAPIRequest != null && channelAPIRequest.getPayload() != null ? channelAPIRequest.getPayload().getTransactionId() : StringUtils.EMPTY;
    }

    public String getChannelTransactionID() {
        return channelTransactionID;
    }

    public void setChannelTransactionID(String channelTransactionID) {
        this.channelTransactionID = channelTransactionID;
    }

    public String getDPTransactionID() {
        return DPTransactionID;
    }

    public void setDPTransactionID(String DPTransactionID) {
        this.DPTransactionID = DPTransactionID;
    }

    public String getResponseJson() {
        return responseJson;
    }

    public void setResponseJson(String responseJson) {
        this.responseJson = responseJson;
    }

    public String getEncryptedResponsePayload() {
        return encryptedResponsePayload;
    }

    public void setEncryptedResponsePayload(String encryptedResponsePayload) {
        this.encryptedResponsePayload = encryptedResponsePayload;
    }

    public String getDpProductCode() {
        return dpProductCode;
    }

    public void setDpProductCode(String dpProductCode) {
        this.dpProductCode = dpProductCode;
    }

    public String getPartnerEref() {
        return partnerEref;
    }

    public void setPartnerEref(String partnerEref) {
        this.partnerEref = partnerEref;
    }

    public ChannelAPIAudit getAudit() {
        return audit;
    }

    public void setAudit(ChannelAPIAudit audit) {
        this.audit = audit;
    }

    @Override
    public String toString() {
        return "ChannelAPIDto{" +
                "requestType=" + requestType +
                ", channelTransactionID='" + channelTransactionID + '\'' +
                ", DPTransactionID='" + DPTransactionID + '\'' +
                '}';
    }
}
