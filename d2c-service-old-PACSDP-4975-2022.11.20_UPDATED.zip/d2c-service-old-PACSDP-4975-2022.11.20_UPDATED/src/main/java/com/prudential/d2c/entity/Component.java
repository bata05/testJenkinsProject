package com.prudential.d2c.entity;

import java.util.List;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Component {
	private String docId;
	private String compoCode;
	private String compoDesc;
	private String genderType;
	private Boolean isBasic;
	private Boolean isRequired;
	private Boolean isDefault;
	private Boolean isPSWaived;
    private Boolean isPSPWaived;
    private Boolean isCWAppl;
    private Boolean isESCWAppl;
    private Boolean isSASameAsBasic;
    private Boolean isPremTermSameAsBasic;
    private Boolean isPolTermSameAsBasic;
    private Boolean isBTTermSameAsBasic;
    private Boolean isDefaultPolTermSameAsBasic;
    private Boolean isPremTermSameAsPolTerm;
    private Boolean isBTTermSameAsPolTerm;
    private Boolean isPremTermInputReq;
    private Boolean isPolTermInputReq;
    private Boolean isSumAssuredInputReq;
    private Boolean isPremInputReq;
    private Boolean isMinPolTermSameAsBasic;
    private Boolean isMaxPolTermSameAsBasic;
    private Boolean isMaxSASameAsBasic;
    private Boolean isMinPremiumCalcReq;
    private Boolean isMinSACalcReq;
    private String parentComponent;
    private String dependentComponent;
    private String lifeInsuredType;
    private Integer minPolicyTerm;
    private Integer maxPolicyTerm;
    private String benefitsDesc;
    private String riskDesc;
    private String benefitInfo;
    private Integer term;
    private Integer benefitTerm;
    private Integer premiumTerm;
    private double premium;
    private double yearlyPremium;
    private double halfYearlyPremium;
    private double quarterlyPremium;
    private double monthlyPremium;
    private double singlePremium;
    private double sumAssured;
    private double minSumAssured;
    private double maxSumAssured;
    private double medisaveYearlyPremium;
    private double medisaveMonthlyPremium;
	private double cashOutlayYearly;
	private double payableByMedisaveYearly;
	private double discountedPremium;
	private double payableByDiscountMedisave;

	private double discountedCashOutlayYearly;

    
    private List<PlanOption> compoPlanOptions;
    private PlanOption selectedCompoPlanOption;
    private TermOption selectedTermOption;
    private List<Component> subComponents;
    private Integer sequence;
    private String benefitCode;
    private String[] premiumTerms;
    private String[] policyTerms;
    private double minPremium;
    private Double minPremiumValue;
    private Double multiple;
    
    private Boolean componentDiscount;
    private double discountPercentage;

	public double getMinPremium() {
		return minPremium;
	}

	public void setMinPremium(double minPremium) {
		this.minPremium = minPremium;
	}

	public Double getMultiple() {
		return multiple;
	}

	public void setMultiple(Double multiple) {
		this.multiple = multiple;
	}

	public String[] getPremiumTerms() {
		return premiumTerms;
	}

	public void setPremiumTerms(String[] premiumTerms) {
		this.premiumTerms = premiumTerms;
	}

	public String[] getPolicyTerms() {
		return policyTerms;
	}

	public void setPolicyTerms(String[] policyTerms) {
		this.policyTerms = policyTerms;
	}

	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	public String getCompoCode() {
		return compoCode;
	}
	public void setCompoCode(String compoCode) {
		this.compoCode = compoCode;
	}
	public String getCompoDesc() {
		return compoDesc;
	}
	public void setCompoDesc(String compoDesc) {
		this.compoDesc = compoDesc;
	}
	public String getGenderType() {
		return genderType;
	}
	public void setGenderType(String genderType) {
		this.genderType = genderType;
	}
	public Boolean getIsBasic() {
		return isBasic;
	}
	public void setIsBasic(Boolean isBasic) {
		this.isBasic = isBasic;
	}
	public Boolean getIsRequired() {
		return isRequired;
	}
	public void setIsRequired(Boolean isRequired) {
		this.isRequired = isRequired;
	}
	public Boolean getIsDefault() {
		return isDefault;
	}
	public void setIsDefault(Boolean isDefault) {
		this.isDefault = isDefault;
	}
	public Boolean getIsPSWaived() {
		return isPSWaived;
	}
	public void setIsPSWaived(Boolean isPSWaived) {
		this.isPSWaived = isPSWaived;
	}
	public Boolean getIsPSPWaived() {
		return isPSPWaived;
	}
	public void setIsPSPWaived(Boolean isPSPWaived) {
		this.isPSPWaived = isPSPWaived;
	}
	public Boolean getIsCWAppl() {
		return isCWAppl;
	}
	public void setIsCWAppl(Boolean isCWAppl) {
		this.isCWAppl = isCWAppl;
	}
	public Boolean getIsESCWAppl() {
		return isESCWAppl;
	}
	public void setIsESCWAppl(Boolean isESCWAppl) {
		this.isESCWAppl = isESCWAppl;
	}
	public Boolean getIsSASameAsBasic() {
		return isSASameAsBasic;
	}
	public void setIsSASameAsBasic(Boolean isSASameAsBasic) {
		this.isSASameAsBasic = isSASameAsBasic;
	}
	public Boolean getIsPremTermSameAsBasic() {
		return isPremTermSameAsBasic;
	}
	public void setIsPremTermSameAsBasic(Boolean isPremTermSameAsBasic) {
		this.isPremTermSameAsBasic = isPremTermSameAsBasic;
	}
	public Boolean getIsPolTermSameAsBasic() {
		return isPolTermSameAsBasic;
	}
	public void setIsPolTermSameAsBasic(Boolean isPolTermSameAsBasic) {
		this.isPolTermSameAsBasic = isPolTermSameAsBasic;
	}
	public Boolean getIsBTTermSameAsBasic() {
		return isBTTermSameAsBasic;
	}
	public void setIsBTTermSameAsBasic(Boolean isBTTermSameAsBasic) {
		this.isBTTermSameAsBasic = isBTTermSameAsBasic;
	}
	public Boolean getIsDefaultPolTermSameAsBasic() {
		return isDefaultPolTermSameAsBasic;
	}
	public void setIsDefaultPolTermSameAsBasic(Boolean isDefaultPolTermSameAsBasic) {
		this.isDefaultPolTermSameAsBasic = isDefaultPolTermSameAsBasic;
	}
	public Boolean getIsPremTermSameAsPolTerm() {
		return isPremTermSameAsPolTerm;
	}
	public void setIsPremTermSameAsPolTerm(Boolean isPremTermSameAsPolTerm) {
		this.isPremTermSameAsPolTerm = isPremTermSameAsPolTerm;
	}
	public Boolean getIsBTTermSameAsPolTerm() {
		return isBTTermSameAsPolTerm;
	}
	public void setIsBTTermSameAsPolTerm(Boolean isBTTermSameAsPolTerm) {
		this.isBTTermSameAsPolTerm = isBTTermSameAsPolTerm;
	}
	public Boolean getIsPremTermInputReq() {
		return isPremTermInputReq;
	}
	public void setIsPremTermInputReq(Boolean isPremTermInputReq) {
		this.isPremTermInputReq = isPremTermInputReq;
	}
	public Boolean getIsPolTermInputReq() {
		return isPolTermInputReq;
	}
	public void setIsPolTermInputReq(Boolean isPolTermInputReq) {
		this.isPolTermInputReq = isPolTermInputReq;
	}
	public Boolean getIsSumAssuredInputReq() {
		return isSumAssuredInputReq;
	}
	public void setIsSumAssuredInputReq(Boolean isSumAssuredInputReq) {
		this.isSumAssuredInputReq = isSumAssuredInputReq;
	}
	public Boolean getIsPremInputReq() {
		return isPremInputReq;
	}
	public void setIsPremInputReq(Boolean isPremInputReq) {
		this.isPremInputReq = isPremInputReq;
	}
	public Boolean getIsMinPolTermSameAsBasic() {
		return isMinPolTermSameAsBasic;
	}
	public void setIsMinPolTermSameAsBasic(Boolean isMinPolTermSameAsBasic) {
		this.isMinPolTermSameAsBasic = isMinPolTermSameAsBasic;
	}
	public Boolean getIsMaxPolTermSameAsBasic() {
		return isMaxPolTermSameAsBasic;
	}
	public void setIsMaxPolTermSameAsBasic(Boolean isMaxPolTermSameAsBasic) {
		this.isMaxPolTermSameAsBasic = isMaxPolTermSameAsBasic;
	}
	public Boolean getIsMaxSASameAsBasic() {
		return isMaxSASameAsBasic;
	}
	public void setIsMaxSASameAsBasic(Boolean isMaxSASameAsBasic) {
		this.isMaxSASameAsBasic = isMaxSASameAsBasic;
	}
	public Boolean getIsMinPremiumCalcReq() {
		return isMinPremiumCalcReq;
	}
	public void setIsMinPremiumCalcReq(Boolean isMinPremiumCalcReq) {
		this.isMinPremiumCalcReq = isMinPremiumCalcReq;
	}
	public Boolean getIsMinSACalcReq() {
		return isMinSACalcReq;
	}
	public void setIsMinSACalcReq(Boolean isMinSACalcReq) {
		this.isMinSACalcReq = isMinSACalcReq;
	}
	public String getParentComponent() {
		return parentComponent;
	}
	public void setParentComponent(String parentComponent) {
		this.parentComponent = parentComponent;
	}
	public String getDependentComponent() {
		return dependentComponent;
	}
	public void setDependentComponent(String dependentComponent) {
		this.dependentComponent = dependentComponent;
	}
	public String getLifeInsuredType() {
		return lifeInsuredType;
	}
	public void setLifeInsuredType(String lifeInsuredType) {
		this.lifeInsuredType = lifeInsuredType;
	}
	public List<Component> getSubComponents() {
		return subComponents;
	}
	public void setSubComponents(List<Component> subComponents) {
		this.subComponents = subComponents;
	}
	public Integer getSequence() {
		return sequence;
	}
	public void setSequence(Integer sequence) {
		this.sequence = sequence;
	}
	public Integer getMinPolicyTerm() {
		return minPolicyTerm;
	}
	public void setMinPolicyTerm(Integer minPolicyTerm) {
		this.minPolicyTerm = minPolicyTerm;
	}
	public Integer getMaxPolicyTerm() {
		return maxPolicyTerm;
	}
	public void setMaxPolicyTerm(Integer maxPolicyTerm) {
		this.maxPolicyTerm = maxPolicyTerm;
	}
	public String getBenefitsDesc() {
		return benefitsDesc;
	}
	public void setBenefitsDesc(String benefitsDesc) {
		this.benefitsDesc = benefitsDesc;
	}
	public String getRiskDesc() {
		return riskDesc;
	}
	public void setRiskDesc(String riskDesc) {
		this.riskDesc = riskDesc;
	}
	public Integer getTerm() {
		return term;
	}
	public void setTerm(Integer term) {
		this.term = term;
	}
	public Integer getBenefitTerm() {
		return benefitTerm;
	}
	public void setBenefitTerm(Integer benefitTerm) {
		this.benefitTerm = benefitTerm;
	}
	public Integer getPremiumTerm() {
		return premiumTerm;
	}
	public void setPremiumTerm(Integer premiumTerm) {
		this.premiumTerm = premiumTerm;
	}
	public double getPremium() {
		return premium;
	}
	public void setPremium(double premium) {
		this.premium = premium;
	}
	public double getYearlyPremium() {
		return yearlyPremium;
	}
	public void setYearlyPremium(double yearlyPremium) {
		this.yearlyPremium = yearlyPremium;
	}
	public double getHalfYearlyPremium() {
		return halfYearlyPremium;
	}
	public void setHalfYearlyPremium(double halfYearlyPremium) {
		this.halfYearlyPremium = halfYearlyPremium;
	}
	public double getQuarterlyPremium() {
		return quarterlyPremium;
	}
	public void setQuarterlyPremium(double quarterlyPremium) {
		this.quarterlyPremium = quarterlyPremium;
	}
	public double getMonthlyPremium() {
		return monthlyPremium;
	}
	public void setMonthlyPremium(double monthlyPremium) {
		this.monthlyPremium = monthlyPremium;
	}
	public double getSinglePremium() {
		return singlePremium;
	}
	public void setSinglePremium(double singlePremium) {
		this.singlePremium = singlePremium;
	}
	public double getSumAssured() {
		return sumAssured;
	}
	public void setSumAssured(double sumAssured) {
		this.sumAssured = sumAssured;
	}
	public List<PlanOption> getCompoPlanOptions() {
		return compoPlanOptions;
	}
	public void setCompoPlanOptions(List<PlanOption> compoPlanOptions) {
		this.compoPlanOptions = compoPlanOptions;
	}
	public PlanOption getSelectedCompoPlanOption() {
		return selectedCompoPlanOption;
	}
	public void setSelectedCompoPlanOption(PlanOption selectedCompoPlanOption) {
		this.selectedCompoPlanOption = selectedCompoPlanOption;
	}
	public String getBenefitCode() {
		return benefitCode;
	}
	public void setBenefitCode(String benefitCode) {
		this.benefitCode = benefitCode;
	}
	public double getMinSumAssured() {
		return minSumAssured;
	}
	public void setMinSumAssured(double minSumAssured) {
		this.minSumAssured = minSumAssured;
	}
	public double getMaxSumAssured() {
		return maxSumAssured;
	}
	public void setMaxSumAssured(double maxSumAssured) {
		this.maxSumAssured = maxSumAssured;
	}
	public String getBenefitInfo() {
		return benefitInfo;
	}
	public void setBenefitInfo(String benefitInfo) {
		this.benefitInfo = benefitInfo;
	}
	public TermOption getSelectedTermOption() {
		return selectedTermOption;
	}
	public void setSelectedTermOption(TermOption selectedTermOption) {
		this.selectedTermOption = selectedTermOption;
	}
	public double getMedisaveYearlyPremium() {
		return medisaveYearlyPremium;
	}
	public void setMedisaveYearlyPremium(double medisaveYearlyPremium) {
		this.medisaveYearlyPremium = medisaveYearlyPremium;
	}
	public double getMedisaveMonthlyPremium() {
		return medisaveMonthlyPremium;
	}
	public void setMedisaveMonthlyPremium(double medisaveMonthlyPremium) {
		this.medisaveMonthlyPremium = medisaveMonthlyPremium;
	}

	public double getCashOutlayYearly() {
		return cashOutlayYearly;
	}

	public void setCashOutlayYearly(double cashOutlayYearly) {
		this.cashOutlayYearly = cashOutlayYearly;
	}

	public double getPayableByMedisaveYearly() {
		return payableByMedisaveYearly;
	}

	public void setPayableByMedisaveYearly(double payableByMedisaveYearly) {
		this.payableByMedisaveYearly = payableByMedisaveYearly;
	}

	public double getDiscountedPremium() {
		return discountedPremium;
	}

	public void setDiscountedPremium(double discountedPremium) {
		this.discountedPremium = discountedPremium;
	}

	public double getPayableByDiscountMedisave() {
		return payableByDiscountMedisave;
	}

	public void setPayableByDiscountMedisave(double payableByDiscountMedisave) {
		this.payableByDiscountMedisave = payableByDiscountMedisave;
	}

	public double getDiscountedCashOutlayYearly() {
		return discountedCashOutlayYearly;
	}

	public void setDiscountedCashOutlayYearly(double discountedCashOutlayYearly) {
		this.discountedCashOutlayYearly = discountedCashOutlayYearly;
	}

	public Double getMinPremiumValue() {
		return minPremiumValue;
	}

	public void setMinPremiumValue(Double minPremiumValue) {
		this.minPremiumValue = minPremiumValue;
	}
	
	public Boolean getComponentDiscount() {
		return componentDiscount;
	}

	public void setComponentDiscount(Boolean componentDiscount) {
		this.componentDiscount = componentDiscount;
	}

	public double getDiscountPercentage() {
		return discountPercentage;
	}

	public void setDiscountPercentage(double discountPercentage) {
		this.discountPercentage = discountPercentage;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		Component component = (Component) o;
		return Math.round(component.premium) == Math.round(premium) &&
				Math.round(component.yearlyPremium) == Math.round(yearlyPremium) &&
				Math.round(component.halfYearlyPremium) == Math.round(halfYearlyPremium) &&
				Math.round(component.quarterlyPremium) == Math.round(quarterlyPremium) &&
				Math.round(component.monthlyPremium) == Math.round(monthlyPremium) &&
				Math.round(component.singlePremium) == Math.round(singlePremium) &&
				Math.round(component.discountedPremium) == Math.round(discountedPremium) &&
				Math.round(component.sumAssured) == Math.round(sumAssured) &&
				Math.round(component.minSumAssured) == Math.round(minSumAssured) &&
				Math.round(component.maxSumAssured) == Math.round(maxSumAssured) &&
				Objects.equals(compoCode, component.compoCode) &&
				//Objects.equals(compoDesc, component.compoDesc) &&
				//Objects.equals(genderType, component.genderType) &&
				Objects.equals(isBasic, component.isBasic) &&
				//Objects.equals(isRequired, component.isRequired) &&
				//Objects.equals(isDefault, component.isDefault) &&
				Objects.equals(term, component.term) &&
				Objects.equals(benefitTerm, component.benefitTerm) &&
				Objects.equals(premiumTerm, component.premiumTerm) &&
				Objects.equals(selectedTermOption, component.selectedTermOption) &&
				Objects.equals(benefitCode, component.benefitCode) &&
				Objects.equals(componentDiscount, component.componentDiscount) &&
				Objects.equals(discountPercentage, component.discountPercentage);
	}

	@Override
	public int hashCode() {

		return Objects.hash(compoCode, compoDesc, genderType, isBasic, isRequired, isDefault, term, benefitTerm, premiumTerm, premium, yearlyPremium, halfYearlyPremium, quarterlyPremium, monthlyPremium, singlePremium, discountedPremium, sumAssured, minSumAssured, maxSumAssured, selectedTermOption, benefitCode);
	}
}
