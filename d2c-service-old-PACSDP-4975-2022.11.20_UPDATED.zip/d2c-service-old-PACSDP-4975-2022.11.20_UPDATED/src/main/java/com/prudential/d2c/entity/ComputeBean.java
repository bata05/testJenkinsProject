package com.prudential.d2c.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.prudential.d2c.entity.micro.LifeProfile;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ComputeBean {
	private String customId;
	private String reqType;
	private Boolean generatePDF;
	private Boolean generatePIPDF;
	private String erefCode;
	private PDFData pdfData;
	private List<LifeProfile> lifeProfiles;
	private List<Product> selectedSQSProducts;
	private Boolean isExistingClient;
	private String agentChannelCode = "";
	private String entryChannelCode;
	
	public String getReqType() {
		return reqType;
	}
	public void setReqType(String reqType) {
		this.reqType = reqType;
	}
	public Boolean getGeneratePDF() {
		return generatePDF;
	}
	public void setGeneratePDF(Boolean generatePDF) {
		this.generatePDF = generatePDF;
	}

	public Boolean getGeneratePIPDF() {
		return generatePIPDF;
	}

	public void setGeneratePIPDF(Boolean generatePIPDF) {
		this.generatePIPDF = generatePIPDF;
	}

	public Boolean getExistingClient() {
		return isExistingClient;
	}

	public String getErefCode() {
		return erefCode;
	}
	public void setErefCode(String erefCode) {
		this.erefCode = erefCode;
	}
	public PDFData getPdfData() {
		return pdfData;
	}
	public void setPdfData(PDFData pdfData) {
		this.pdfData = pdfData;
	}
	public List<LifeProfile> getLifeProfiles() {
		return lifeProfiles;
	}
	public void setLifeProfiles(List<LifeProfile> lifeProfiles) {
		this.lifeProfiles = lifeProfiles;
	}
	public List<Product> getSelectedSQSProducts() {
		return selectedSQSProducts;
	}
	public void setSelectedSQSProducts(List<Product> selectedSQSProducts) {
		this.selectedSQSProducts = selectedSQSProducts;
	}
	public Boolean isExistingClient() {
		return isExistingClient;
	}
	public void setExistingClient(Boolean isExistingClient) {
		this.isExistingClient = isExistingClient;
	}
	public String getCustomId() {
		return customId;
	}
	public void setCustomId(String customId) {
		this.customId = customId;
	}
	public String getAgentChannelCode() {
		return agentChannelCode;
	}
	public void setAgentChannelCode(String agentChannelCode) {
		this.agentChannelCode = agentChannelCode;
	}
	public String getEntryChannelCode() {
		return entryChannelCode;
	}
	public void setEntryChannelCode(String entryChannelCode) {
		this.entryChannelCode = entryChannelCode;
	}
	
}
