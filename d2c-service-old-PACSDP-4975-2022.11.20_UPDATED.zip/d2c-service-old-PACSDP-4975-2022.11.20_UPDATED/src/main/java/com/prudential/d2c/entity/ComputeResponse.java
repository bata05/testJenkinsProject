package com.prudential.d2c.entity;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.springframework.web.multipart.MultipartFile;

public class ComputeResponse {
	
	  private Double premium;
	  private Double discountedPremium;
	  private Double monthlyPremium;
	  private Double yearlyPremium;
	  private Double enp7Premium;
	  private Double enp7MonthlyPremium;
	  private Double enp7YearlyPremium;
	  private Double dan7Premium;
	  private Double dan7MonthlyPremium;
	  private Double dan7YearlyPremium;
	  private Double mainPayout;
	  private Double accumulatedPayout;
	  private Double totalPayout;
	  private Double sumAssured;
	  private Double minSumAssured;
	  private String pdfFile;
	  private String pdfMD5;
	  private String sumAssuredPA;
	  private String sumAssuredRA;
	  private String sumAssuredPAFE;
	  private String premiumPA;
	  private String discountedPremiumPA;
	  private String premiumRA;
	  private String discountedPremiumRA;
	  private String premiumPAFE;
	  private String discountedPremiumPAFE;
	  private String erefCode;
	  private MultipartFile file;
	  private Double totalDeathBenefit;
	  private Double totalSV;
	  private String status;
      private int statusCode;
	  private String message;
	  
	/**
	 * @return the file
	 */
	public MultipartFile getFile() {
		return file;
	}
	/**
	 * @param file the file to set
	 */
	public void setFile(MultipartFile file) {
		this.file = file;
	}

	/**
	 * @return the premium
	 */
	public Double getPremium() {
		return premium;
	}
	/**
	 * @param premium the premium to set
	 */
	public void setPremium(Double premium) {
		this.premium = premium;
	}
	
	/**
	 * @return the monthlyPremium
	 */
	public Double getMonthlyPremium() {
		return monthlyPremium;
	}
	/**
	 * @param monthlyPremium the monthlyPremium to set
	 */
	public void setMonthlyPremium(Double monthlyPremium) {
		this.monthlyPremium = monthlyPremium;
	}
	/**
	 * @return the yearlyPremium
	 */
	public Double getYearlyPremium() {
		return yearlyPremium;
	}
	/**
	 * @param yearlyPremium the yearlyPremium to set
	 */
	public void setYearlyPremium(Double yearlyPremium) {
		this.yearlyPremium = yearlyPremium;
	}
	/**
	 * @return the totalPayout
	 */
	public Double getTotalPayout() {
		return totalPayout;
	}
	/**
	 * @param totalPayout the totalPayout to set
	 */
	public void setTotalPayout(Double totalPayout) {
		this.totalPayout = totalPayout;
	}
	/**
	 * @return the sumAssured
	 */
	public Double getSumAssured() {
		return sumAssured;
	}
	/**
	 * @param sumAssured the sumAssured to set
	 */
	public void setSumAssured(Double sumAssured) {
		this.sumAssured = sumAssured;
	}
	/**
	 * @return the pdfFile
	 */
	public String getPdfFile() {
		return pdfFile;
	}
	/**
	 * @param pdfFile the pdfFile to set
	 */
	public void setPdfFile(String pdfFile) {
		this.pdfFile = pdfFile;
	}
	/**
	 * @return the sumAssuredPA
	 */
	public String getSumAssuredPA() {
		return sumAssuredPA;
	}
	/**
	 * @param sumAssuredPA the sumAssuredPA to set
	 */
	public void setSumAssuredPA(String sumAssuredPA) {
		this.sumAssuredPA = sumAssuredPA;
	}
	/**
	 * @return the sumAssuredRA
	 */
	public String getSumAssuredRA() {
		return sumAssuredRA;
	}
	/**
	 * @param sumAssuredRA the sumAssuredRA to set
	 */
	public void setSumAssuredRA(String sumAssuredRA) {
		this.sumAssuredRA = sumAssuredRA;
	}
	/**
	 * @return the sumAssuredPAFE
	 */
	public String getSumAssuredPAFE() {
		return sumAssuredPAFE;
	}
	/**
	 * @param sumAssuredPAFE the sumAssuredPAFE to set
	 */
	public void setSumAssuredPAFE(String sumAssuredPAFE) {
		this.sumAssuredPAFE = sumAssuredPAFE;
	}
	/**
	 * @return the erefCode
	 */
	public String getErefCode() {
		return erefCode;
	}
	/**
	 * @param erefCode the erefCode to set
	 */
	public void setErefCode(String erefCode) {
		this.erefCode = erefCode;
	}
	/**
	 * @return the premiumPA
	 */
	public String getPremiumPA() {
		return premiumPA;
	}
	/**
	 * @param premiumPA the premiumPA to set
	 */
	public void setPremiumPA(String premiumPA) {
		this.premiumPA = premiumPA;
	}
	/**
	 * @return the premiumRA
	 */
	public String getPremiumRA() {
		return premiumRA;
	}
	/**
	 * @param premiumRA the premiumRA to set
	 */
	public void setPremiumRA(String premiumRA) {
		this.premiumRA = premiumRA;
	}
	/**
	 * @return the premiumPAFE
	 */
	public String getPremiumPAFE() {
		return premiumPAFE;
	}
	/**
	 * @param premiumPAFE the premiumPAFE to set
	 */
	public void setPremiumPAFE(String premiumPAFE) {
		this.premiumPAFE = premiumPAFE;
	}
	
	/**
	 * @return the pdfMD5
	 */
	public String getPdfMD5() {
		return pdfMD5;
	}
	/**
	 * @param pdfMD5 the pdfMD5 to set
	 */
	public void setPdfMD5(String pdfMD5) {
		this.pdfMD5 = pdfMD5;
	}
	
	
	
	/**
	 * @return the mainPayout
	 */
	public Double getMainPayout() {
		return mainPayout;
	}
	/**
	 * @param mainPayout the mainPayout to set
	 */
	public void setMainPayout(Double mainPayout) {
		this.mainPayout = mainPayout;
	}
	/**
	 * @return the accumulatedPayout
	 */
	public Double getAccumulatedPayout() {
		return accumulatedPayout;
	}
	/**
	 * @param accumulatedPayout the accumulatedPayout to set
	 */
	public void setAccumulatedPayout(Double accumulatedPayout) {
		this.accumulatedPayout = accumulatedPayout;
	}
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
	public Double getEnp7Premium() {
		return enp7Premium;
	}
	public void setEnp7Premium(Double enp7Premium) {
		this.enp7Premium = enp7Premium;
	}
	
	/**
	 * @return the enp7MonthlyPremium
	 */
	public Double getEnp7MonthlyPremium() {
		return enp7MonthlyPremium;
	}
	/**
	 * @param enp7MonthlyPremium the enp7MonthlyPremium to set
	 */
	public void setEnp7MonthlyPremium(Double enp7MonthlyPremium) {
		this.enp7MonthlyPremium = enp7MonthlyPremium;
	}
	/**
	 * @return the enp7YearlyPremium
	 */
	public Double getEnp7YearlyPremium() {
		return enp7YearlyPremium;
	}
	/**
	 * @param enp7YearlyPremium the enp7YearlyPremium to set
	 */
	public void setEnp7YearlyPremium(Double enp7YearlyPremium) {
		this.enp7YearlyPremium = enp7YearlyPremium;
	}
	public Double getDan7Premium() {
		return dan7Premium;
	}
	public void setDan7Premium(Double dan7Premium) {
		this.dan7Premium = dan7Premium;
	}
	
	/**
	 * @return the dan7MonthlyPremium
	 */
	public Double getDan7MonthlyPremium() {
		return dan7MonthlyPremium;
	}
	/**
	 * @param dan7MonthlyPremium the dan7MonthlyPremium to set
	 */
	public void setDan7MonthlyPremium(Double dan7MonthlyPremium) {
		this.dan7MonthlyPremium = dan7MonthlyPremium;
	}
	/**
	 * @return the dan7YearlyPremium
	 */
	public Double getDan7YearlyPremium() {
		return dan7YearlyPremium;
	}
	/**
	 * @param dan7YearlyPremium the dan7YearlyPremium to set
	 */
	public void setDan7YearlyPremium(Double dan7YearlyPremium) {
		this.dan7YearlyPremium = dan7YearlyPremium;
	}
	/**
	 * @return the minSumAssured
	 */
	public Double getMinSumAssured() {
		return minSumAssured;
	}
	/**
	 * @param minSumAssured the minSumAssured to set
	 */
	public void setMinSumAssured(Double minSumAssured) {
		this.minSumAssured = minSumAssured;
	}
	/**
	 * @return the totalDeathBenefit
	 */
	public Double getTotalDeathBenefit() {
		return totalDeathBenefit;
	}
	/**
	 * @param totalDeathBenefit the totalDeathBenefit to set
	 */
	public void setTotalDeathBenefit(Double totalDeathBenefit) {
		this.totalDeathBenefit = totalDeathBenefit;
	}
	/**
	 * @return the totalSV
	 */
	public Double getTotalSV() {
		return totalSV;
	}
	/**
	 * @param totalSV the totalSV to set
	 */
	public void setTotalSV(Double totalSV) {
		this.totalSV = totalSV;
	}
	public int getStatusCode() {
		return statusCode;
	}
	
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	public Double getDiscountedPremium() {
		return discountedPremium;
	}

	public void setDiscountedPremium(Double discountedPremium) {
		this.discountedPremium = discountedPremium;
	}

	public String getDiscountedPremiumPA() {
		return discountedPremiumPA;
	}

	public void setDiscountedPremiumPA(String discountedPremiumPA) {
		this.discountedPremiumPA = discountedPremiumPA;
	}

	public String getDiscountedPremiumRA() {
		return discountedPremiumRA;
	}

	public void setDiscountedPremiumRA(String discountedPremiumRA) {
		this.discountedPremiumRA = discountedPremiumRA;
	}

	public String getDiscountedPremiumPAFE() {
		return discountedPremiumPAFE;
	}

	public void setDiscountedPremiumPAFE(String discountedPremiumPAFE) {
		this.discountedPremiumPAFE = discountedPremiumPAFE;
	}
}
