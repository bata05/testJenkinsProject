package com.prudential.d2c.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Object return to DP front-end, including data for form posting to issuing bank authentication
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class CybAcsInfo {
    // ACS URL is the issuing bank's authentication URL.
    private String acsUrl;

    // mapping to transaction_xid in the response of enrollment check.
    private String md;

    // Payment authentication request.
    private String paReq;

    // re-call URL once authentication finished at issuing bank side.
    private String termUrl;


}
