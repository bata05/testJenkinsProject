package com.prudential.d2c.entity;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * 
 * Object to parser response of cybersource payment token generation
 *
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CybCheckoutResultData {
    // Decision from cybersource response, sample data: ACCEPT/REJECT/ERROR
    private String decision; // Required

    // Reason code from cybersource reponse, sample data: 100/101/102/475
    private String reasonCode; // Required

    // Signature responsed from cybersource, which was generated at DP side
    private String signature; // Required

    // transaction amount
    private BigDecimal amount;

    // request credit card expiry date, sample data: 02-2022
    private String cardExpiryDate;

    // credit card type, sample data: VISA:001/MASTER CARD:002
    private String cardType;

    // credit card BIN, sample data: 400000xxxxxx0002
    private String cardNumber;

    // transaction currency, sample data: SGD/USD
    private String currency;

    // transaction locale, sample data: en-US
    private String locale;

    // sample data: card
    private String paymentMethod;

    // sample data:
    private String paymentToken; // Required

    private String referenceNumber; // Required

    private String transactionType;

    private String transactionUuid;

    private String signedFieldNames; // Required
    
    private String billToForename;
    
    private String billToSurname;
    
    private String billToEmail;
    
    private String billToAddressLine1;
    
    private String billToAddressCity;
    
    private String billToAddressCountry;

}
