package com.prudential.d2c.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CybDDCInfo {

	private String ddcUrl;
	private String accessToken;
	private String referenceID;

}
