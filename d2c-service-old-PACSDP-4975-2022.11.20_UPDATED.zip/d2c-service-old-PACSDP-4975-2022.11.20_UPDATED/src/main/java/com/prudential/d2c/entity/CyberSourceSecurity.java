package com.prudential.d2c.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * Object to parse data which used for signature generation.
 * 
 * Coding style is not followed for some properties in this POJO since below reason: 1. The third party service CyberSource Signature only accepts the name with
 * style they used. 2. The form field name will be validated in CyberSource checkout page. Reference:
 * http://apps.cybersource.com/library/documentation/dev_guides/Secure_Acceptance_WM/html/wwhelp/wwhimpl/js/html/wwhelp.htm#href=app_fields_WM.10.2.html
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class CyberSourceSecurity {
    // names of fields which the value need to be decrypted
    private String field_to_decypt;

    // Generated in Cybersource business center, configured in application.properties
    private String access_key;

    // Generated in Cybersource business center, configured in application.properties
    private String profile_id;

    // transaction uuid which is unique for every transaction
    private String transaction_uuid;

    // signature time
    private String signed_date_time;

    // names of fields which need to be signed
    private String signed_field_names; // Required

    // names of fields which don't need to be signed
    private String unsigned_field_names;

    // eg en-EN
    private String locale;

    // transaction type, card or e-pay, always card for DP.
    private String transaction_type;

    // reference number which is unique for every transaction and same as the policy number
    private String reference_number; // Required

    private String amount;

    // Sample: SGD
    private String currency;

    // bill address
    private String bill_to_address_line1;

    // bill addrees city
    private String bill_to_address_city;

    // bill address country
    private String bill_to_address_country;

    // bill email address
    private String bill_to_email;

    // bill last name
    private String bill_to_surname;

    // bill given name
    private String bill_to_forename;

    private String customId; // Required

    /**
     * @return the field_to_decypt
     */
    public String getField_to_decypt() {
        return field_to_decypt;
    }

    /**
     * @param field_to_decypt
     *            the field_to_decypt to set
     */
    public void setField_to_decypt(String field_to_decypt) {
        this.field_to_decypt = field_to_decypt;
    }

    /**
     * @return the access_key
     */
    public String getAccess_key() {
        return access_key;
    }

    /**
     * @param access_key
     *            the access_key to set
     */
    public void setAccess_key(String access_key) {
        this.access_key = access_key;
    }

    /**
     * @return the profile_id
     */
    public String getProfile_id() {
        return profile_id;
    }

    /**
     * @param profile_id
     *            the profile_id to set
     */
    public void setProfile_id(String profile_id) {
        this.profile_id = profile_id;
    }

    /**
     * @return the transaction_uuid
     */
    public String getTransaction_uuid() {
        return transaction_uuid;
    }

    /**
     * @param transaction_uuid
     *            the transaction_uuid to set
     */
    public void setTransaction_uuid(String transaction_uuid) {
        this.transaction_uuid = transaction_uuid;
    }

    /**
     * @return the signed_date_time
     */
    public String getSigned_date_time() {
        return signed_date_time;
    }

    /**
     * @param signed_date_time
     *            the signed_date_time to set
     */
    public void setSigned_date_time(String signed_date_time) {
        this.signed_date_time = signed_date_time;
    }

    /**
     * @return the signed_field_names
     */
    public String getSigned_field_names() {
        return signed_field_names;
    }

    /**
     * @param signed_field_names
     *            the signed_field_names to set
     */
    public void setSigned_field_names(String signed_field_names) {
        this.signed_field_names = signed_field_names;
    }

    /**
     * @return the unsigned_field_names
     */
    public String getUnsigned_field_names() {
        return unsigned_field_names;
    }

    /**
     * @param unsigned_field_names
     *            the unsigned_field_names to set
     */
    public void setUnsigned_field_names(String unsigned_field_names) {
        this.unsigned_field_names = unsigned_field_names;
    }

    /**
     * @return the locale
     */
    public String getLocale() {
        return locale;
    }

    /**
     * @param locale
     *            the locale to set
     */
    public void setLocale(String locale) {
        this.locale = locale;
    }

    /**
     * @return the transaction_type
     */
    public String getTransaction_type() {
        return transaction_type;
    }

    /**
     * @param transaction_type
     *            the transaction_type to set
     */
    public void setTransaction_type(String transaction_type) {
        this.transaction_type = transaction_type;
    }

    /**
     * @return the reference_number
     */
    public String getReference_number() {
        return reference_number;
    }

    /**
     * @param reference_number
     *            the reference_number to set
     */
    public void setReference_number(String reference_number) {
        this.reference_number = reference_number;
    }

    /**
     * @return the amount
     */
    public String getAmount() {
        return amount;
    }

    /**
     * @param amount
     *            the amount to set
     */
    public void setAmount(String amount) {
        this.amount = amount;
    }

    /**
     * @return the currency
     */
    public String getCurrency() {
        return currency;
    }

    /**
     * @param currency
     *            the currency to set
     */
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    /**
     * @return the bill_to_address_line1
     */
    public String getBill_to_address_line1() {
        return bill_to_address_line1;
    }

    /**
     * @param bill_to_address_line1
     *            the bill_to_address_line1 to set
     */
    public void setBill_to_address_line1(String bill_to_address_line1) {
        this.bill_to_address_line1 = bill_to_address_line1;
    }

    /**
     * @return the bill_to_address_city
     */
    public String getBill_to_address_city() {
        return bill_to_address_city;
    }

    /**
     * @param bill_to_address_city
     *            the bill_to_address_city to set
     */
    public void setBill_to_address_city(String bill_to_address_city) {
        this.bill_to_address_city = bill_to_address_city;
    }

    /**
     * @return the bill_to_address_country
     */
    public String getBill_to_address_country() {
        return bill_to_address_country;
    }

    /**
     * @param bill_to_address_country
     *            the bill_to_address_country to set
     */
    public void setBill_to_address_country(String bill_to_address_country) {
        this.bill_to_address_country = bill_to_address_country;
    }

    /**
     * @return the bill_to_email
     */
    public String getBill_to_email() {
        return bill_to_email;
    }

    /**
     * @param bill_to_email
     *            the bill_to_email to set
     */
    public void setBill_to_email(String bill_to_email) {
        this.bill_to_email = bill_to_email;
    }

    /**
     * @return the bill_to_surname
     */
    public String getBill_to_surname() {
        return bill_to_surname;
    }

    /**
     * @param bill_to_surname
     *            the bill_to_surname to set
     */
    public void setBill_to_surname(String bill_to_surname) {
        this.bill_to_surname = bill_to_surname;
    }

    /**
     * @return the bill_to_forename
     */
    public String getBill_to_forename() {
        return bill_to_forename;
    }

    /**
     * @param bill_to_forename
     *            the bill_to_forename to set
     */
    public void setBill_to_forename(String bill_to_forename) {
        this.bill_to_forename = bill_to_forename;
    }

    /**
     * @return the customId
     */
    public String getCustomId() {
        return customId;
    }

    /**
     * @param customId
     *            the customId to set
     */
    public void setCustomId(String customId) {
        this.customId = customId;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "CyberSourceSecurity [field_to_decypt=" + field_to_decypt + ", access_key=" + access_key
                + ", profile_id=" + profile_id + ", transaction_uuid=" + transaction_uuid + ", signed_date_time="
                + signed_date_time + ", signed_field_names=" + signed_field_names + ", unsigned_field_names="
                + unsigned_field_names + ", locale=" + locale + ", transaction_type=" + transaction_type
                + ", reference_number=" + reference_number + ", amount=" + amount + ", currency=" + currency
                + ", bill_to_address_line1=" + bill_to_address_line1 + ", bill_to_address_city=" + bill_to_address_city
                + ", bill_to_address_country=" + bill_to_address_country + ", bill_to_email=" + bill_to_email
                + ", bill_to_surname=" + bill_to_surname + ", bill_to_forename=" + bill_to_forename + ", customId="
                + customId + "]";
    }

}
