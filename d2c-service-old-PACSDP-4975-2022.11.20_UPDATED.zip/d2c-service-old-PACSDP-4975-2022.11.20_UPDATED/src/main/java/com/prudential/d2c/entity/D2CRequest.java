package com.prudential.d2c.entity;

import java.util.Date;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.prudential.d2c.common.Constants;
import com.prudential.d2c.entity.micro.LifeProfileProposalAddress;
import com.prudential.d2c.entity.micro.SelectedPolicyOption;
import com.prudential.d2c.utils.JsonDateSerializer;
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class D2CRequest {
	  private String customId;
	  // add for Products
	  private String reqType;
	  private String type;
	  private String planCode;
	  private String planRA;
	  private String planFCPA;
	  private String occupationCode;
	  private String residencyCode;
	  //common
	  private Integer age;
	  private String gender;
	  private boolean smoker;
	  //PFC
	  private String selectedTerm;
	  private String selectedOptionCode;
	  private String selectedOptionVal;
	  //special occupation
	  private String occupationId;
	  //drop down
	  private String dropDownCode;
	  //finalComputeAll
	  private String name;
	  private String nric;
	  private String phoneNo;
	  private String nationality;
	  @JsonSerialize(using=JsonDateSerializer.class)
	  @JsonFormat(shape=JsonFormat.Shape.STRING, pattern=Constants.DOBFORMAT)
	  private Date dob;
	  private String occupation;
	  private String occupationDesc;
	  private String totalYearlyPremium;
	  private String monthlyPremium;
	  private String premiumPA;
	  private String premiumRA;
	  private String premiumPAFE;
	  private String sumAssuredPA;
	  private String sumAssuredRA;
	  private String sumAssuredPAFE;
	  private double sumAssured;
	  private LifeProfileProposalAddress homeAddress;
	  private LifeProfileProposalAddress mailingAddress;
	  boolean isMailingAddressSameAsHomeAddress;
	  private SelectedPolicyOption selectedCompoPlanOption;
	  private SelectedPolicyOption selectedCompoOption;
	  
	  private MultipartFile file;  
	  
	  private String erefCode;
	/**
	 * @return the reqType
	 */
	public String getReqType() {
		return reqType;
	}
	/**
	 * @param reqType the reqType to set
	 */
	public void setReqType(String reqType) {
		this.reqType = reqType;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the planCode
	 */
	public String getPlanCode() {
		return planCode;
	}
	/**
	 * @param planCode the planCode to set
	 */
	public void setPlanCode(String planCode) {
		this.planCode = planCode;
	}
	/**
	 * @return the occupationCode
	 */
	public String getOccupationCode() {
		return occupationCode;
	}
	/**
	 * @param occupationCode the occupationCode to set
	 */
	public void setOccupationCode(String occupationCode) {
		this.occupationCode = occupationCode;
	}
	/**
	 * @return the residencyCode
	 */
	public String getResidencyCode() {
		return residencyCode;
	}
	/**
	 * @param residencyCode the residencyCode to set
	 */
	public void setResidencyCode(String residencyCode) {
		this.residencyCode = residencyCode;
	}
	/**
	 * @return the age
	 */
	public Integer getAge() {
		return age;
	}
	/**
	 * @param age the age to set
	 */
	public void setAge(Integer age) {
		this.age = age;
	}
	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}
	/**
	 * @param gender the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}
	/**
	 * @return the smoker
	 */
	public boolean isSmoker() {
		return smoker;
	}
	/**
	 * @param smoker the smoker to set
	 */
	public void setSmoker(boolean smoker) {
		this.smoker = smoker;
	}
	/**
	 * @return the selectedTerm
	 */
	public String getSelectedTerm() {
		return selectedTerm == null || ("null").equals(selectedTerm) ? "10" : selectedTerm;
	}
	/**
	 * @param selectedTerm the selectedTerm to set
	 */
	public void setSelectedTerm(String selectedTerm) {
		this.selectedTerm = selectedTerm;
	}
	/**
	 * @return the selectedOptionCode
	 */
	public String getSelectedOptionCode() {
		return selectedOptionCode;
	}
	/**
	 * @param selectedOptionCode the selectedOptionCode to set
	 */
	public void setSelectedOptionCode(String selectedOptionCode) {
		this.selectedOptionCode = selectedOptionCode;
	}
	/**
	 * @return the selectedOptionVal
	 */
	public String getSelectedOptionVal() {
		return selectedOptionVal;
	}
	/**
	 * @param selectedOptionVal the selectedOptionVal to set
	 */
	public void setSelectedOptionVal(String selectedOptionVal) {
		this.selectedOptionVal = selectedOptionVal;
	}
	/**
	 * @return the occupationId
	 */
	public String getOccupationId() {
		return occupationId;
	}
	/**
	 * @param occupationId the occupationId to set
	 */
	public void setOccupationId(String occupationId) {
		this.occupationId = occupationId;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * @return the nric
	 */
	public String getNric() {
		return nric;
	}
	/**
	 * @param nric the nric to set
	 */
	public void setNric(String nric) {
		this.nric = nric;
	}
	
	/**
	 * @return the nationality
	 */
	public String getNationality() {
		return nationality;
	}
	/**
	 * @param nationality the nationality to set
	 */
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	/**
	 * @return the phoneNo
	 */
	public String getPhoneNo() {
		return phoneNo;
	}
	/**
	 * @param phoneNo the phoneNo to set
	 */
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	/**
	 * @return the dob
	 */
	public Date getDob() {
		return dob;
	}
	/**
	 * @param dob the dob to set
	 */
	public void setDob(Date dob) {
		this.dob = dob;
	}
	/**
	 * @return the occupation
	 */
	public String getOccupation() {
		return occupation;
	}
	/**
	 * @param occupation the occupation to set
	 */
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	/**
	 * @return the totalYearlyPremium
	 */
	public String getTotalYearlyPremium() {
		return totalYearlyPremium;
	}
	/**
	 * @param totalYearlyPremium the totalYearlyPremium to set
	 */
	public void setTotalYearlyPremium(String totalYearlyPremium) {
		this.totalYearlyPremium = totalYearlyPremium;
	}
	/**
	 * @return the premiumPA
	 */
	public String getPremiumPA() {
		return premiumPA;
	}
	/**
	 * @param premiumPA the premiumPA to set
	 */
	public void setPremiumPA(String premiumPA) {
		this.premiumPA = premiumPA;
	}
	/**
	 * @return the premiumRA
	 */
	public String getPremiumRA() {
		return premiumRA;
	}
	/**
	 * @param premiumRA the premiumRA to set
	 */
	public void setPremiumRA(String premiumRA) {
		this.premiumRA = premiumRA;
	}
	/**
	 * @return the premiumPAFE
	 */
	public String getPremiumPAFE() {
		return premiumPAFE;
	}
	/**
	 * @param premiumPAFE the premiumPAFE to set
	 */
	public void setPremiumPAFE(String premiumPAFE) {
		this.premiumPAFE = premiumPAFE;
	}
	/**
	 * @return the sumAssuredPA
	 */
	public String getSumAssuredPA() {
		return sumAssuredPA;
	}
	/**
	 * @param sumAssuredPA the sumAssuredPA to set
	 */
	public void setSumAssuredPA(String sumAssuredPA) {
		this.sumAssuredPA = sumAssuredPA;
	}
	/**
	 * @return the sumAssuredRA
	 */
	public String getSumAssuredRA() {
		return sumAssuredRA;
	}
	/**
	 * @param sumAssuredRA the sumAssuredRA to set
	 */
	public void setSumAssuredRA(String sumAssuredRA) {
		this.sumAssuredRA = sumAssuredRA;
	}
	/**
	 * @return the sumAssuredPAFE
	 */
	public String getSumAssuredPAFE() {
		return sumAssuredPAFE;
	}
	/**
	 * @param sumAssuredPAFE the sumAssuredPAFE to set
	 */
	public void setSumAssuredPAFE(String sumAssuredPAFE) {
		this.sumAssuredPAFE = sumAssuredPAFE;
	}
	
	
	/**
	 * @return the planRA
	 */
	public String getPlanRA() {
		return planRA;
	}
	/**
	 * @param planRA the planRA to set
	 */
	public void setPlanRA(String planRA) {
		this.planRA = planRA;
	}
	/**
	 * @return the planFCPA
	 */
	public String getPlanFCPA() {
		return planFCPA;
	}
	/**
	 * @param planFCPA the planFCPA to set
	 */
	public void setPlanFCPA(String planFCPA) {
		this.planFCPA = planFCPA;
	}

	/**
	 * @return the file
	 */
	public MultipartFile getFile() {
		return file;
	}
	/**
	 * @param file the file to set
	 */
	public void setFile(MultipartFile file) {
		this.file = file;
	}
	/**
	 * @return the dropDownCode
	 */
	public String getDropDownCode() {
		return dropDownCode;
	}
	/**
	 * @param dropDownCode the dropDownCode to set
	 */
	public void setDropDownCode(String dropDownCode) {
		this.dropDownCode = dropDownCode;
	}
	
	/**
	 * @return the homeAddress
	 */
	public LifeProfileProposalAddress getHomeAddress() {
		return homeAddress;
	}
	/**
	 * @param homeAddress the homeAddress to set
	 */
	public void setHomeAddress(LifeProfileProposalAddress homeAddress) {
		this.homeAddress = homeAddress;
	}
	/**
	 * @return the mailingAddress
	 */
	public LifeProfileProposalAddress getMailingAddress() {
		return mailingAddress;
	}
	/**
	 * @param mailingAddress the mailingAddress to set
	 */
	public void setMailingAddress(LifeProfileProposalAddress mailingAddress) {
		this.mailingAddress = mailingAddress;
	}
	
	/**
	 * @return the isMailingAddressSameAsHomeAddress
	 */
	public boolean getIsMailingAddressSameAsHomeAddress() {
		return isMailingAddressSameAsHomeAddress;
	}
	/**
	 * @param isMailingAddressSameAsHomeAddress the isMailingAddressSameAsHomeAddress to set
	 */
	public void setIsMailingAddressSameAsHomeAddress(boolean isMailingAddressSameAsHomeAddress) {
		this.isMailingAddressSameAsHomeAddress = isMailingAddressSameAsHomeAddress;
	}

	/**
	 * @return the sumAssured
	 */
	public double getSumAssured() {
		return sumAssured;
	}
	/**
	 * @param sumAssured the sumAssured to set
	 */
	public void setSumAssured(double sumAssured) {
		this.sumAssured = sumAssured;
	}
	
	/**
	 * @return the occupationDesc
	 */
	public String getOccupationDesc() {
		return occupationDesc;
	}
	/**
	 * @param occupationDesc the occupationDesc to set
	 */
	public void setOccupationDesc(String occupationDesc) {
		this.occupationDesc = occupationDesc;
	}
	
	@Override
	public String toString()
	{

		Object fieldExcludedObject = ReflectionToStringBuilder.toStringExclude(this, "nric");
		return ToStringBuilder.reflectionToString(fieldExcludedObject);
	}
	/**
	 * @return the selectedCompoPlanOption
	 */
	public SelectedPolicyOption getSelectedCompoPlanOption() {
		return selectedCompoPlanOption;
	}
	/**
	 * @param selectedCompoPlanOption the selectedCompoPlanOption to set
	 */
	public void setSelectedCompoPlanOption(SelectedPolicyOption selectedCompoPlanOption) {
		this.selectedCompoPlanOption = selectedCompoPlanOption;
	}
	/**
	 * @return the selectedCompoOption
	 */
	public SelectedPolicyOption getSelectedCompoOption() {
		return selectedCompoOption;
	}
	/**
	 * @param selectedCompoOption the selectedCompoOption to set
	 */
	public void setSelectedCompoOption(SelectedPolicyOption selectedCompoOption) {
		this.selectedCompoOption = selectedCompoOption;
	}
	/**
	 * @return the monthlyPremium
	 */
	public String getMonthlyPremium() {
		return monthlyPremium;
	}
	/**
	 * @param monthlyPremium the monthlyPremium to set
	 */
	public void setMonthlyPremium(String monthlyPremium) {
		this.monthlyPremium = monthlyPremium;
	}
	/**
	 * @return the erefCode
	 */
	public String getErefCode() {
		return erefCode;
	}
	/**
	 * @param erefCode the erefCode to set
	 */
	public void setErefCode(String erefCode) {
		this.erefCode = erefCode;
	}
	public String getCustomId() {
		return customId;
	}
	public void setCustomId(String customId) {
		this.customId = customId;
	}
	
}
