package com.prudential.d2c.entity;

import com.prudential.d2c.common.Constants;
import com.prudential.d2c.service.validator.ValidationFailure;
import org.apache.http.HttpStatus;

import java.util.Set;

import static com.prudential.d2c.exception.AppWideExceptionHandle.MSG_ERROR;

public class D2CResponse {
    private String status;
    private int statusCode;
    private String message;
    private String token;
    private Object payload;
    private Set<ValidationFailure> validationFailure;

    public D2CResponse() {
    }

    public static D2CResponse badRequestExceptionMessage() {
        return new D2CResponse(Constants.ERROR_STATUS, HttpStatus.SC_BAD_REQUEST, MSG_ERROR, null);
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
	public static D2CResponse with500ValidationErrors(Set validationFailure) {
        return new D2CResponse(Constants.ERROR_STATUS, HttpStatus.SC_INTERNAL_SERVER_ERROR, validationFailure);
    }

    public static D2CResponse with500ExceptionMessage(Exception exception) {
        return new D2CResponse(Constants.ERROR_STATUS, HttpStatus.SC_INTERNAL_SERVER_ERROR, MSG_ERROR, null);
    }

    public static D2CResponse with500Message(String message) {
        return new D2CResponse(Constants.ERROR_STATUS, HttpStatus.SC_INTERNAL_SERVER_ERROR, message, null);
    }

    public D2CResponse(String status, int statusCode, Set<ValidationFailure> validationFailure) {
        this.status = status;
        this.statusCode = statusCode;
        this.validationFailure = validationFailure;
    }

    public D2CResponse(String status, int statusCode, String message, Object payload) {
        super();
        this.status = status;
        this.statusCode = statusCode;
        this.message = message;
        this.payload = payload;
        this.token = null;
    }

    public D2CResponse(String status, int statusCode, String message, Object payload, String token) {
        super();
        this.status = status;
        this.statusCode = statusCode;
        this.message = message;
        this.payload = payload;
        this.token = token;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getPayload() {
        return payload;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public void setPayload(Object payload) {
        this.payload = payload;
    }

    public Set<ValidationFailure> getValidationFailure() {
        return validationFailure;
    }
}
