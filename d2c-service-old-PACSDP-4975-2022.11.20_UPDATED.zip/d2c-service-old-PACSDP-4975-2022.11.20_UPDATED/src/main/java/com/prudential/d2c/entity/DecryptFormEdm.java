package com.prudential.d2c.entity;

import java.util.List;

import com.prudential.d2c.entity.dto.QuotationBenefit;


public class DecryptFormEdm {
    
	private String orginalStr;
    private List<QuotationBenefit> paList;
	private List<QuotationBenefit> raList;
	private String sioLinkValid ;

	public String getSioLinkValid() { return sioLinkValid; }
	public void setSioLinkValid(String sioLinkValid) { this.sioLinkValid = sioLinkValid; }
	public String getOrginalStr() {
		return orginalStr;
	}
	public List<QuotationBenefit> getPaList() {
		return paList;
	}
	public List<QuotationBenefit> getRaList() {
		return raList;
	}
	public void setOrginalStr(String orginalStr) {
		this.orginalStr = orginalStr;
	}
	public void setPaList(List<QuotationBenefit> paList) {
		this.paList = paList;
	}
	public void setRaList(List<QuotationBenefit> raList) {
		this.raList = raList;
	}
	
}