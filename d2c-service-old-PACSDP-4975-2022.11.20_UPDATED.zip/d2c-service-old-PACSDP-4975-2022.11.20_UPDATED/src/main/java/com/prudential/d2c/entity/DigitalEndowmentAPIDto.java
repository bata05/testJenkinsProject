package com.prudential.d2c.entity;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.prudential.d2c.entity.dto.DigitalEndowmentAPIAudit;
import com.prudential.d2c.entity.micro.DigitalEndowmentAPIRequest;
import com.prudential.d2c.entity.micro.DigitalEndowmentAPIResponse;
import com.prudential.d2c.type.DigitalEndowmentAPIExceptionType;

public class DigitalEndowmentAPIDto {

    public enum DigitalEndowmentAPIType {
        APPLICATION_ESUBMISSION
    }
    
    private DigitalEndowmentAPIAudit audit;

    private String channelName;

    private DigitalEndowmentAPIType requestType;

    private String requestJson;

    private List<DigitalEndowmentAPIExceptionType> errors;

	private DigitalEndowmentAPIRequest digitalEndowmentAPIRequest;

	private DigitalEndowmentAPIResponse digitalEndowmentAPIResponse;

    private String transactionId;

    private String dpTransactionId;
    
    private String paymentTransactionId;

    private String responseJson;

    private String responsePayload;

    private String dpProductCode;

    private String ereferenceNo;
    
    private int prupayRetryCount;
    
    private int proposalRetryCount;
    
    private BigDecimal executionTime;

    public DigitalEndowmentAPIDto(DigitalEndowmentAPIRequest digitalEndowmentAPIRequest, DigitalEndowmentAPIType requestType, String dpTransactionId, String channelName) {
        this.digitalEndowmentAPIRequest = digitalEndowmentAPIRequest;
        this.requestType = requestType;
        this.dpTransactionId = dpTransactionId;
        this.errors = new ArrayList<>();
        this.channelName = channelName;
    }

    

	public DigitalEndowmentAPIAudit getAudit() {
		return audit;
	}

	public void setAudit(DigitalEndowmentAPIAudit audit) {
		this.audit = audit;
	}

	public String getChannelName() {
		return channelName;
	}

	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}

	public DigitalEndowmentAPIType getRequestType() {
		return requestType;
	}

	public void setRequestType(DigitalEndowmentAPIType requestType) {
		this.requestType = requestType;
	}

	public String getRequestJson() {
		return requestJson;
	}

	public void setRequestJson(String requestJson) {
		this.requestJson = requestJson;
	}

	public List<DigitalEndowmentAPIExceptionType> getErrors() {
		return errors;
	}

	public void setErrors(List<DigitalEndowmentAPIExceptionType> errors) {
		this.errors = errors;
	}

	public DigitalEndowmentAPIRequest getDigitalEndowmentAPIRequest() {
		return digitalEndowmentAPIRequest;
	}

	public void setDigitalEndowmentAPIRequest(DigitalEndowmentAPIRequest digitalEndowmentAPIRequest) {
		this.digitalEndowmentAPIRequest = digitalEndowmentAPIRequest;
	}

	public DigitalEndowmentAPIResponse getDigitalEndowmentAPIResponse() {
		return digitalEndowmentAPIResponse;
	}

	public void setDigitalEndowmentAPIResponse(DigitalEndowmentAPIResponse digitalEndowmentAPIResponse) {
		this.digitalEndowmentAPIResponse = digitalEndowmentAPIResponse;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getDpTransactionId() {
		return dpTransactionId;
	}

	public void setDpTransactionId(String dpTransactionId) {
		this.dpTransactionId = dpTransactionId;
	}

	public String getPaymentTransactionId() {
		return paymentTransactionId;
	}

	public void setPaymentTransactionId(String paymentTransactionId) {
		this.paymentTransactionId = paymentTransactionId;
	}

	public String getResponseJson() {
		return responseJson;
	}

	public void setResponseJson(String responseJson) {
		this.responseJson = responseJson;
	}

	public String getResponsePayload() {
		return responsePayload;
	}

	public void setResponsePayload(String responsePayload) {
		this.responsePayload = responsePayload;
	}

	public String getDpProductCode() {
		return dpProductCode;
	}

	public void setDpProductCode(String dpProductCode) {
		this.dpProductCode = dpProductCode;
	}

	public String getEreferenceNo() {
		return ereferenceNo;
	}

	public void setEreferenceNo(String ereferenceNo) {
		this.ereferenceNo = ereferenceNo;
	}
	
	public int getPrupayRetryCount() {
		return prupayRetryCount;
	}

	public void setPrupayRetryCount(int prupayRetryCount) {
		this.prupayRetryCount = prupayRetryCount;
	}

	
	public int getProposalRetryCount() {
		return proposalRetryCount;
	}


	public void setProposalRetryCount(int proposalRetryCount) {
		this.proposalRetryCount = proposalRetryCount;
	}

	
	public BigDecimal getExecutionTime() {
		return executionTime;
	}


	public void setExecutionTime(BigDecimal executionTime) {
		this.executionTime = executionTime;
	}


	@Override
    public String toString() {
        return "DigitalEndowmentAPIDto{" +
                "requestType=" + requestType +
                ", digitalEndowmentTransactionID='" + transactionId + '\'' +
                ", dpTransactionID='" + dpTransactionId + '\'' +
                ", paymentTransactionId='" + paymentTransactionId + '\'' +
                '}';
    }
}
