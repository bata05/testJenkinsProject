package com.prudential.d2c.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class DropdownRequest {

		private String dropDownCode;
		private String[] dropDownCodeList;
		
		public String getDropDownCode() {
			return dropDownCode;
		}

		public void setDropDownCode(String dropDownCode) {
			this.dropDownCode = dropDownCode;
		}

		public String[] getDropDownCodeList() {
			return dropDownCodeList;
		}

		public void setDropDownCodeList(String[] dropDownCodeList) {
			this.dropDownCodeList = dropDownCodeList;
		}





	}
