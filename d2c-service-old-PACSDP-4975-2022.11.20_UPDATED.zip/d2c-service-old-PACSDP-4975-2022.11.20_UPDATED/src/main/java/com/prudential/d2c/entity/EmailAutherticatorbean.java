package com.prudential.d2c.entity;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;

public class EmailAutherticatorbean extends Authenticator {
    private String username = null;
    private String userpass = null;

    public void setUsername(String username) {
        this.username = username;
    }

    public void setUserpass(String userpass) {
        this.userpass = userpass;
    }

    public EmailAutherticatorbean(String username, String userpass) {
        super();
        setUsername(username);
        setUserpass(userpass);

    }

    @Override
    public PasswordAuthentication getPasswordAuthentication() {

        return new PasswordAuthentication(username, userpass);
    }
}
