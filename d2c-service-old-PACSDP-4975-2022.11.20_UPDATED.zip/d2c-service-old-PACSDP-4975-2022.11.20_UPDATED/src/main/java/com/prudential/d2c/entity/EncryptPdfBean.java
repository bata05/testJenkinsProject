package com.prudential.d2c.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.Objects;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class EncryptPdfBean {
	
	private String requestType;
	private String customId;
	private String erefNo;
	private String docName;
	private String docCategory;
	private String encryptedPdfFile;
	
	public String getRequestType() { return requestType; }
	
	public void setRequestType(String requestType) { this.requestType = requestType; }
	
	public String getCustomId() { return customId; }
	
	public void setCustomId(String customId) {
		this.customId = customId;
	}
	
	public String getErefNo() {	return erefNo; }
	
	public void setErefNo(String erefNo) { this.erefNo = erefNo; }
	
	public String getDocName() { return docName; }
	
	public void setDocName(String docName) { this.docName = docName; }
	
	public String getDocCategory() { return docCategory; }
	
	public void setDocCategory(String docCategory) { this.docCategory = docCategory; }
	
	public String getEncryptedPdfFile() { return encryptedPdfFile; }
	
	public void setEncryptedPdfFile(String encryptedPdfFile) { this.encryptedPdfFile = encryptedPdfFile; }
	
	@Override
	public String toString() {
		return "EncryptPdfBean{" +
					   "requestType='" + requestType + '\'' +
					   ", customId='" + customId + '\'' +
					   ", erefNo='" + erefNo + '\'' +
					   ", docName='" + docName + '\'' +
					   ", docCategory='" + docCategory + '\'' +
					   ", encryptedPdfFile='" + encryptedPdfFile + '\'' +
					   '}';
	}
	
	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof EncryptPdfBean))
			return false;
		EncryptPdfBean that = (EncryptPdfBean) o;
		return Objects.equals(getRequestType(), that.getRequestType()) &&
					   Objects.equals(getCustomId(), that.getCustomId()) &&
					   Objects.equals(getErefNo(), that.getErefNo()) &&
					   Objects.equals(getDocName(), that.getDocName()) &&
					   Objects.equals(getDocCategory(), that.getDocCategory()) &&
					   Objects.equals(getEncryptedPdfFile(), that.getEncryptedPdfFile());
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(getRequestType(), getCustomId(), getErefNo(), getDocName(), getDocCategory(), getEncryptedPdfFile());
	}
	
	public static EncryptPdfBean initializeBean(String requestType, String customId, String erefNo, String docName, String docCategory) {
		EncryptPdfBean bean = new EncryptPdfBean();
		bean.setRequestType(requestType);
		bean.setCustomId(customId);
		bean.setErefNo(erefNo);
		bean.setDocName(docName);
		bean.setDocCategory(docCategory);
		
		return bean;
	}
}
