package com.prudential.d2c.entity;

/**
 * Mapping to JSON string which including encrypted data of transaction.
 */
public class ErefAuth {
    // e-reference number
    private String erefNo;

    // accessToken at Front-end
    private String accessToken;

    /**
     * @return the erefNo
     */
    public String getErefNo() {
        return erefNo;
    }

    /**
     * @param erefNo
     *            the erefNo to set
     */
    public void setErefNo(String erefNo) {
        this.erefNo = erefNo;
    }

    /**
     * @return the accessToken
     */
    public String getAccessToken() {
        return accessToken;
    }

    /**
     * @param accessToken
     *            the accessToken to set
     */
    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "ErefAuth [erefNo=" + erefNo + ", accessToken=" + accessToken + "]";
    }

}
