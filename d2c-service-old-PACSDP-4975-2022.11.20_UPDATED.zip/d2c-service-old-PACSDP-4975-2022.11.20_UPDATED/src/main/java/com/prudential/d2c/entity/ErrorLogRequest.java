package com.prudential.d2c.entity;

public class ErrorLogRequest {
    private String errorMessage;
    private String errorUrl;
    private String errorSessionId;

    public String getErrorSessionId() {
        return errorSessionId;
    }

    public void setErrorSessionId(String errorSessionId) {
        this.errorSessionId = errorSessionId;
    }

    public String getErrorUrl() {
        return errorUrl;
    }

    public void setErrorUrl(String errorUrl) {
        this.errorUrl = errorUrl;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
}
