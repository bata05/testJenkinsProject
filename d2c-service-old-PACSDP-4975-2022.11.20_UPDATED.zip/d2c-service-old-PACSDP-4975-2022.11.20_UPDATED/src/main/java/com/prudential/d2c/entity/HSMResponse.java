package com.prudential.d2c.entity;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class HSMResponse extends SuccessStatus{
	
	private List<String> random;
	
	private String rsaPublicKey;

	/**
	 * @return the random
	 */
	public List<String> getRandom() {
		return random;
	}

	/**
	 * @param random the random to set
	 */
	public void setRandom(List<String> random) {
		this.random = random;
	}

	/**
	 * @return the rsaPublicKey
	 */
	public String getRsaPublicKey() {
		return rsaPublicKey;
	}

	/**
	 * @param rsaPublicKey the rsaPublicKey to set
	 */
	public void setRsaPublicKey(String rsaPublicKey) {
		this.rsaPublicKey = rsaPublicKey;
	}
	
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
}
