package com.prudential.d2c.entity;

import com.fasterxml.jackson.annotation.JsonProperty;


public class LinkGen {
    @JsonProperty("aCode")
    private String agentCode;

    public String getAgentCode() {
        return agentCode;
    }

    public void setAgentCode(String agentCode) {
        this.agentCode = agentCode;
    }


}
