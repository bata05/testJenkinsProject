package com.prudential.d2c.entity;

import org.apache.commons.lang.builder.ToStringBuilder;

public class MailServer {
	
	private String mailHost;
	
	private Integer mailPort;
	
	private String mailUser;
	
	private String mailPwd;
	
	private boolean debug;

	/**
	 * @return the mailHost
	 */
	public String getMailHost() {
		return mailHost;
	}

	/**
	 * @param mailHost the mailHost to set
	 */
	public void setMailHost(String mailHost) {
		this.mailHost = mailHost;
	}



	/**
	 * @return the mailPort
	 */
	public Integer getMailPort() {
		return mailPort;
	}

	/**
	 * @param mailPort the mailPort to set
	 */
	public void setMailPort(Integer mailPort) {
		this.mailPort = mailPort;
	}

	/**
	 * @return the mailUser
	 */
	public String getMailUser() {
		return mailUser;
	}

	/**
	 * @param mailUser the mailUser to set
	 */
	public void setMailUser(String mailUser) {
		this.mailUser = mailUser;
	}

	/**
	 * @return the mailPwd
	 */
	public String getMailPwd() {
		return mailPwd;
	}

	/**
	 * @param mailPwd the mailPwd to set
	 */
	public void setMailPwd(String mailPwd) {
		this.mailPwd = mailPwd;
	}

	/**
	 * @return the debug
	 */
	public boolean isDebug() {
		return debug;
	}

	/**
	 * @param debug the debug to set
	 */
	public void setDebug(boolean debug) {
		this.debug = debug;
	}
	
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}

}
