package com.prudential.d2c.entity;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.prudential.d2c.entity.micro.PdfFile;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MailTemplate {
	
	private String subject;
	private String subjectCode;
	private String mailFrom;
	private String templateName;
	private String mimeType;
	private String sendTo;
	private String copyTo;
	private String content;
	private Map<String,String> mailImages;
	private List<PdfFile> fileList;
	private List<PdfFile> excelAttachment;
	
	
	/**
	 * @return the subject
	 */
	public String getSubject() {
		return subject;
	}


	/**
	 * @param subject the subject to set
	 */
	public void setSubject(String subject) {
		this.subject = subject;
	}


	/**
	 * @return the subjectCode
	 */
	public String getSubjectCode() {
		return subjectCode;
	}


	/**
	 * @param subjectCode the subjectCode to set
	 */
	public void setSubjectCode(String subjectCode) {
		this.subjectCode = subjectCode;
	}


	/**
	 * @return the mailFrom
	 */
	public String getMailFrom() {
		return mailFrom;
	}


	/**
	 * @param mailFrom the mailFrom to set
	 */
	public void setMailFrom(String mailFrom) {
		this.mailFrom = mailFrom;
	}


	/**
	 * @return the templateName
	 */
	public String getTemplateName() {
		return templateName;
	}


	/**
	 * @param templateName the templateName to set
	 */
	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}


	/**
	 * @return the mimeType
	 */
	public String getMimeType() {
		return mimeType;
	}


	/**
	 * @param mimeType the mimeType to set
	 */
	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}


	/**
	 * @return the sendTo
	 */
	public String getSendTo() {
		return sendTo;
	}


	/**
	 * @param sendTo the sendTo to set
	 */
	public void setSendTo(String sendTo) {
		this.sendTo = sendTo;
	}


	/**
	 * @return the content
	 */
	public String getContent() {
		return content;
	}


	/**
	 * @param content the content to set
	 */
	public void setContent(String content) {
		this.content = content;
	}






	public List<PdfFile> getFileList() {
		return fileList;
	}


	public void setFileList(List<PdfFile> fileList) {
		this.fileList = fileList;
	}


	public Map<String, String> getMailImages() {
		return mailImages;
	}


	public void setMailImages(Map<String, String> mailImages) {
		this.mailImages = mailImages;
	}


	public String getCopyTo() {
		return copyTo;
	}


	public void setCopyTo(String copyTo) {
		this.copyTo = copyTo;
	}


	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}


	public List<PdfFile> getExcelAttachment() {
		return excelAttachment;
	}


	public void setExcelAttachment(List<PdfFile> excelAttachment) {
		this.excelAttachment = excelAttachment;
	}


}
