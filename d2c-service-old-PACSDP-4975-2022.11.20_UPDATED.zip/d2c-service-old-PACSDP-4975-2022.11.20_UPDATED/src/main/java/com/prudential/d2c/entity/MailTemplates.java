package com.prudential.d2c.entity;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MailTemplates {

	private MailTemplate customer;
	private MailTemplate agent;
	private MailTemplate gethelp;
	private MailTemplate backup;
	private MailTemplate timeout;
	private MailTemplate leadgen;
	private MailTemplate internal;
	private MailTemplate dpiFailedQuestionnaire;
	private MailTemplate customerDE;
	private MailTemplate deInternalError;

	/**
	 * @return the customer
	 */
	public MailTemplate getCustomer() {
		return customer;
	}

	/**
	 * @param customer the customer to set
	 */
	public void setCustomer(MailTemplate customer) {
		this.customer = customer;
	}

	/**
	 * @return the agent
	 */
	public MailTemplate getAgent() {
		return agent;
	}

	/**
	 * @param agent the agent to set
	 */
	public void setAgent(MailTemplate agent) {
		this.agent = agent;
	}

	public MailTemplate getBackup() {
		return backup;
	}

	public void setBackup(MailTemplate backup) {
		this.backup = backup;
	}

	public MailTemplate getTimeout() {
		return timeout;
	}

	public void setTimeout(MailTemplate timeout) {
		this.timeout = timeout;
	}

	public MailTemplate getGethelp() {
		return gethelp;
	}

	public void setGethelp(MailTemplate gethelp) {
		this.gethelp = gethelp;
	}

	public MailTemplate getLeadgen() {
		return leadgen;
	}

	public void setLeadgen(MailTemplate leadgen) {
		this.leadgen = leadgen;
	}

	public MailTemplate getInternal() {
		return internal;
	}

	public void setInternal(MailTemplate internal) {
		this.internal = internal;
	}

	public MailTemplate getDpiFailedQuestionnaire() {
		return dpiFailedQuestionnaire;
	}

	public void setDpiFailedQuestionnaire(MailTemplate dpiFailedQuestionnaire) {
		this.dpiFailedQuestionnaire = dpiFailedQuestionnaire;
	}

	public MailTemplate getCustomerDE() {
		return customerDE;
	}

	public void setCustomerDE(MailTemplate customerDE) {
		this.customerDE = customerDE;
	}

	public MailTemplate getDeInternalError() {
		return deInternalError;
	}

	public void setDeInternalError(MailTemplate deInternalError) {
		this.deInternalError = deInternalError;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
