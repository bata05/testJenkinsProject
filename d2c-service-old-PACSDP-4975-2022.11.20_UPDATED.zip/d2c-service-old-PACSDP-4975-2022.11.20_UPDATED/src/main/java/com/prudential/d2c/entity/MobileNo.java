package com.prudential.d2c.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.prudential.d2c.entity.MyInfoResponse.Areacode;
import com.prudential.d2c.entity.MyInfoResponse.Nbr;
import com.prudential.d2c.entity.MyInfoResponse.Prefix;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MobileNo {
    private String areaCode;
    private String prefix;
    private String nbr;

    public String getAreaCode() {
        return areaCode;
    }

    public void setAreaCode(String areaCode) {
        this.areaCode = areaCode;
    }

    public String getPrefix() {
        return prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public String getNbr() {
        return nbr;
    }

    public void setNbr(String nbr) {
        this.nbr = nbr;
    }
}
