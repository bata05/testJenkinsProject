package com.prudential.d2c.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.prudential.d2c.entity.MyInfoResponse.DropdownResponse;

import java.util.List;
import java.util.Objects;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class MyInfoDetailsResponse {
    private String uinfin;
    private String name;
    private String sex;
    private String genderCode;
    private Nationality nationality;
    private String dob;
    private String email;
    private MobileNo mobileNo;
    private RegAdd regAdd;
    private PassType passType;
    private String passStatus;
    private String passExpiryDate;
    private ResidentialStatus residentialStatus;
    private String data;
    private List<DropdownResponse> namePermutations;
    private String nationalityCode;

    public String getUinfin() {
        return uinfin;
    }

    public void setUinfin(String uinfin) {
        this.uinfin = uinfin;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public Nationality getNationality() {
        return nationality;
    }

    public void setNationality(Nationality nationality) {
        this.nationality = nationality;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public MobileNo getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(MobileNo mobileNo) {
        this.mobileNo = mobileNo;
    }

    public RegAdd getRegAdd() {
        return regAdd;
    }

    public void setRegAdd(RegAdd regAdd) {
        this.regAdd = regAdd;
    }

    public PassType getPassType() {
        return passType;
    }

    public void setPassType(PassType passType) {
        this.passType = passType;
    }

    public String getPassStatus() {
        return passStatus;
    }

    public void setPassStatus(String passStatus) {
        this.passStatus = passStatus;
    }

    public String getPassExpiryDate() {
        return passExpiryDate;
    }

    public void setPassExpiryDate(String passExpiryDate) {
        this.passExpiryDate = passExpiryDate;
    }

    public ResidentialStatus getResidentialStatus() {
        return residentialStatus;
    }

    public void setResidentialStatus(ResidentialStatus residentialStatus) {
        this.residentialStatus = residentialStatus;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public List<DropdownResponse> getNamePermutations() {
        return namePermutations;
    }

    public void setNamePermutations(List<DropdownResponse> namePermutations) {
        this.namePermutations = namePermutations;
    }

    public String getNationalityCode() {
        return nationalityCode;
    }

    public void setNationalityCode(String nationalityCode) {
        this.nationalityCode = nationalityCode;
    }

    public String getGenderCode() {
        return genderCode;
    }

    public void setGenderCode(String genderCode) {
        this.genderCode = genderCode;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MyInfoDetailsResponse that = (MyInfoDetailsResponse) o;
        return Objects.equals(uinfin, that.uinfin) && Objects.equals(name, that.name)
                && Objects.equals(sex, that.sex) && Objects.equals(nationality, that.nationality)
                && Objects.equals(dob, that.dob) && Objects.equals(email, that.email)
                && Objects.equals(mobileNo, that.mobileNo) && Objects.equals(regAdd, that.regAdd)
                && Objects.equals(passType, that.passType) && Objects.equals(passStatus, that.passStatus)
                && Objects.equals(passExpiryDate, that.passExpiryDate) && Objects.equals(residentialStatus, that.residentialStatus)
                && Objects.equals(data, that.data) && Objects.equals(namePermutations, that.namePermutations)
                && Objects.equals(nationalityCode, that.nationalityCode) && Objects.equals(nationalityCode, that.nationalityCode)
                && Objects.equals(genderCode, that.genderCode) && Objects.equals(genderCode, that.genderCode);
    }

    @Override
    public int hashCode() {
        return Objects.hash(uinfin, name, sex, nationality, dob, email, mobileNo, regAdd, passType, passStatus, passExpiryDate, residentialStatus, data, namePermutations, nationalityCode, genderCode);
    }

    @Override
    public String toString() {
        return "MyInfoDetailsResponse{" +
                "uinfin='" + uinfin + '\'' +
                ", name='" + name + '\'' +
                ", sex='" + sex + '\'' +
                ", nationality='" + nationality + '\'' +
                ", dob='" + dob + '\'' +
                ", email='" + email + '\'' +
                ", mobileno='" + mobileNo + '\'' +
                ", regadd='" + regAdd + '\'' +
                ", passtype='" + passType + '\'' +
                ", passStatus='" + passStatus + '\'' +
                ", passexpirydate='" + passExpiryDate + '\'' +
                ", residentialStatus='" + residentialStatus + '\'' +
                ", namePermutations='" + namePermutations + '\'' +
                ", nationalityCode='" + nationalityCode + '\'' +
                ", genderCode='" + genderCode + '\'' +
                ", data='" + data + '\'' +
                '}';
    }
}