package com.prudential.d2c.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class MyInfoPDFData {
	private String proposalNo;
	private String eref;
	private String fullName;
	private String nric;
	private String nricSuffix;
	private String gender;
	private String dob;
	private String nationality;
	private String residentialStatus;
	private String mobileNumber;
	private String email;
	private String resAddr;
	private String passType;
	private String passExpiryDate;
	private String passStatus;
	private String transDate;
}
