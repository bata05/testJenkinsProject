package com.prudential.d2c.entity.MyInfoResponse;

public class MyInfoConfigResponse {

    private String authApiUrl;
    private String clientId;
    private String redirectUrl;
    private String attributes;
    private String code;
    private String state;

    public String getAuthApiUrl() {
        return authApiUrl;
    }

    public void setAuthApiUrl(String authApiUrl) {
        this.authApiUrl = authApiUrl;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getRedirectUrl() {
        return redirectUrl;
    }

    public void setRedirectUrl(String redirectUrl) {
        this.redirectUrl = redirectUrl;
    }

    public String getAttributes() {
        return attributes;
    }

    public void setAttributes(String attributes) {
        this.attributes = attributes;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
}
