
package com.prudential.d2c.entity.MyInfoResponse;

import com.fasterxml.jackson.annotation.*;

import javax.annotation.Generated;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "uinfin",
    "name",
    "sex",
    "nationality",
    "dob",
    "email",
    "mobileno",
    "regadd",
    "passtype",
    "passstatus",
    "passexpirydate",
    "residentialstatus"
})
@Generated("jsonschema2pojo")
public class MyInfoDetails {

    @JsonProperty("uinfin")
    private Uinfin uinfin;
    @JsonProperty("name")
    private Name name;
    @JsonProperty("sex")
    private Sex sex;
    @JsonProperty("nationality")
    private Nationality nationality;
    @JsonProperty("dob")
    private Dob dob;
    @JsonProperty("email")
    private Email email;
    @JsonProperty("mobileno")
    private Mobileno mobileno;
    @JsonProperty("regadd")
    private Regadd regadd;
    @JsonProperty("passtype")
    private Passtype passtype;
    @JsonProperty("passstatus")
    private Passstatus passstatus;
    @JsonProperty("passexpirydate")
    private Passexpirydate passexpirydate;
    @JsonProperty("residentialstatus")
    private Residentialstatus residentialstatus;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("uinfin")
    public Uinfin getUinfin() {
        return uinfin;
    }

    @JsonProperty("uinfin")
    public void setUinfin(Uinfin uinfin) {
        this.uinfin = uinfin;
    }

    @JsonProperty("name")
    public Name getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(Name name) {
        this.name = name;
    }

    @JsonProperty("sex")
    public Sex getSex() {
        return sex;
    }

    @JsonProperty("sex")
    public void setSex(Sex sex) {
        this.sex = sex;
    }

    @JsonProperty("nationality")
    public Nationality getNationality() {
        return nationality;
    }

    @JsonProperty("nationality")
    public void setNationality(Nationality nationality) {
        this.nationality = nationality;
    }

    @JsonProperty("dob")
    public Dob getDob() {
        return dob;
    }

    @JsonProperty("dob")
    public void setDob(Dob dob) {
        this.dob = dob;
    }

    @JsonProperty("email")
    public Email getEmail() {
        return email;
    }

    @JsonProperty("email")
    public void setEmail(Email email) {
        this.email = email;
    }

    @JsonProperty("mobileno")
    public Mobileno getMobileno() {
        return mobileno;
    }

    @JsonProperty("mobileno")
    public void setMobileno(Mobileno mobileno) {
        this.mobileno = mobileno;
    }

    @JsonProperty("regadd")
    public Regadd getRegadd() {
        return regadd;
    }

    @JsonProperty("regadd")
    public void setRegadd(Regadd regadd) {
        this.regadd = regadd;
    }

    @JsonProperty("passtype")
    public Passtype getPasstype() {
        return passtype;
    }

    @JsonProperty("passtype")
    public void setPasstype(Passtype passtype) {
        this.passtype = passtype;
    }

    @JsonProperty("passstatus")
    public Passstatus getPassstatus() {
        return passstatus;
    }

    @JsonProperty("passstatus")
    public void setPassstatus(Passstatus passstatus) {
        this.passstatus = passstatus;
    }

    @JsonProperty("passexpirydate")
    public Passexpirydate getPassexpirydate() {
        return passexpirydate;
    }

    @JsonProperty("passexpirydate")
    public void setPassexpirydate(Passexpirydate passexpirydate) {
        this.passexpirydate = passexpirydate;
    }

    @JsonProperty("residentialstatus")
    public Residentialstatus getResidentialstatus() {
        return residentialstatus;
    }

    @JsonProperty("residentialstatus")
    public void setResidentialstatus(Residentialstatus residentialstatus) {
        this.residentialstatus = residentialstatus;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(MyInfoDetails.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("uinfin");
        sb.append('=');
        sb.append(((this.uinfin == null)?"<null>":this.uinfin));
        sb.append(',');
        sb.append("name");
        sb.append('=');
        sb.append(((this.name == null)?"<null>":this.name));
        sb.append(',');
        sb.append("sex");
        sb.append('=');
        sb.append(((this.sex == null)?"<null>":this.sex));
        sb.append(',');
        sb.append("nationality");
        sb.append('=');
        sb.append(((this.nationality == null)?"<null>":this.nationality));
        sb.append(',');
        sb.append("dob");
        sb.append('=');
        sb.append(((this.dob == null)?"<null>":this.dob));
        sb.append(',');
        sb.append("email");
        sb.append('=');
        sb.append(((this.email == null)?"<null>":this.email));
        sb.append(',');
        sb.append("mobileno");
        sb.append('=');
        sb.append(((this.mobileno == null)?"<null>":this.mobileno));
        sb.append(',');
        sb.append("regadd");
        sb.append('=');
        sb.append(((this.regadd == null)?"<null>":this.regadd));
        sb.append(',');
        sb.append("passtype");
        sb.append('=');
        sb.append(((this.passtype == null)?"<null>":this.passtype));
        sb.append(',');
        sb.append("passstatus");
        sb.append('=');
        sb.append(((this.passstatus == null)?"<null>":this.passstatus));
        sb.append(',');
        sb.append("passexpirydate");
        sb.append('=');
        sb.append(((this.passexpirydate == null)?"<null>":this.passexpirydate));
        sb.append(',');
        sb.append("residentialstatus");
        sb.append('=');
        sb.append(((this.residentialstatus == null)?"<null>":this.residentialstatus));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

}
