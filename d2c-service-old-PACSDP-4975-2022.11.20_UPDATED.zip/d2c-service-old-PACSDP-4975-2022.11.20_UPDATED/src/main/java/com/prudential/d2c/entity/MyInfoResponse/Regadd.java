
package com.prudential.d2c.entity.MyInfoResponse;

import com.fasterxml.jackson.annotation.*;

import javax.annotation.Generated;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "lastupdated",
        "source",
        "classification",
        "type",
        "country",
        "unit",
        "street",
        "block",
        "postal",
        "floor",
        "building"

})
@Generated("jsonschema2pojo")
public class Regadd {

    @JsonProperty("lastupdated")
    private String lastupdated;
    @JsonProperty("source")
    private String source;
    @JsonProperty("classification")
    private String classification;
    @JsonProperty("type")
    private String type;
    @JsonProperty("country")
    private Country country;
    @JsonProperty("unit")
    private Unit unit;
    @JsonProperty("street")
    private Street street;
    @JsonProperty("block")
    private Block block;
    @JsonProperty("postal")
    private Postal postal;
    @JsonProperty("floor")
    private Floor floor;
    @JsonProperty("building")
    private Building building;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("lastupdated")
    public String getLastupdated() {
        return lastupdated;
    }

    @JsonProperty("lastupdated")
    public void setLastupdated(String lastupdated) {
        this.lastupdated = lastupdated;
    }

    @JsonProperty("source")
    public String getSource() {
        return source;
    }

    @JsonProperty("source")
    public void setSource(String source) {
        this.source = source;
    }

    @JsonProperty("classification")
    public String getClassification() {
        return classification;
    }

    @JsonProperty("classification")
    public void setClassification(String classification) {
        this.classification = classification;
    }

    @JsonProperty("type")
    public String getType() {
        return type;
    }

    @JsonProperty("type")
    public void setType(String type) {
        this.type = type;
    }

    @JsonProperty("country")
    public Country getCountry() {
        return country;
    }

    @JsonProperty("country")
    public void setCountry(Country country) {
        this.country = country;
    }

    @JsonProperty("unit")
    public Unit getUnit() {
        return unit;
    }

    @JsonProperty("unit")
    public void setUnit(Unit unit) {
        this.unit = unit;
    }

    @JsonProperty("street")
    public Street getStreet() {
        return street;
    }

    @JsonProperty("street")
    public void setStreet(Street street) {
        this.street = street;
    }

    @JsonProperty("block")
    public Block getBlock() {
        return block;
    }

    @JsonProperty("block")
    public void setBlock(Block block) {
        this.block = block;
    }

    @JsonProperty("postal")
    public Postal getPostal() {
        return postal;
    }

    @JsonProperty("postal")
    public void setPostal(Postal postal) {
        this.postal = postal;
    }

    @JsonProperty("floor")
    public Floor getFloor() {
        return floor;
    }

    @JsonProperty("floor")
    public void setFloor(Floor floor) {
        this.floor = floor;
    }

    @JsonProperty("building")
    public Building getBuilding() {
        return building;
    }

    @JsonProperty("building")
    public void setBuilding(Building building) {
        this.building = building;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Email.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("lastupdated");
        sb.append('=');
        sb.append(((this.lastupdated == null)?"<null>":this.lastupdated));
        sb.append(',');
        sb.append("source");
        sb.append('=');
        sb.append(((this.source == null)?"<null>":this.source));
        sb.append(',');
        sb.append("classification");
        sb.append('=');
        sb.append(((this.classification == null)?"<null>":this.classification));
        sb.append(',');
        sb.append("type");
        sb.append('=');
        sb.append(((this.type == null)?"<null>":this.type));
        sb.append(',');
        sb.append("country");
        sb.append('=');
        sb.append(((this.country == null)?"<null>":this.country));
        sb.append(',');
        sb.append("unit");
        sb.append('=');
        sb.append(((this.unit == null)?"<null>":this.unit));
        sb.append(',');
        sb.append("street");
        sb.append('=');
        sb.append(((this.street == null)?"<null>":this.street));
        sb.append(',');
        sb.append("block");
        sb.append('=');
        sb.append(((this.block == null)?"<null>":this.block));
        sb.append(',');
        sb.append("postal");
        sb.append('=');
        sb.append(((this.postal == null)?"<null>":this.postal));
        sb.append(',');
        sb.append("floor");
        sb.append('=');
        sb.append(((this.floor == null)?"<null>":this.floor));
        sb.append(',');
        sb.append("building");
        sb.append('=');
        sb.append(((this.building == null)?"<null>":this.building));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)?"<null>":this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

}
