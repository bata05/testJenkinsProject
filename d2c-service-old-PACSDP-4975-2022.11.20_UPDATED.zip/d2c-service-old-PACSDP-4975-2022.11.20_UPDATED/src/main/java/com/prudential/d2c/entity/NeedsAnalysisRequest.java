package com.prudential.d2c.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.prudential.d2c.entity.micro.NeedsAnalysisRecommendedProductPayload;
import com.prudential.d2c.entity.micro.payload.NeedsAnalysisPayload;

@JsonIgnoreProperties(ignoreUnknown = true)
public class NeedsAnalysisRequest {

  private String customId;
  private int monthlyBudget;
  private NeedsAnalysisPayload needsAnalysisPayload;
  private NeedsAnalysisRecommendedProductPayload recommendedProductPayload;

  public NeedsAnalysisRequest() {
  }

  public String getCustomId() {
    return customId;
  }

  public void setCustomId(String customId) {
    this.customId = customId;
  }

  public int getMonthlyBudget() {
    return monthlyBudget;
  }

  public void setMonthlyBudget(int monthlyBudget) {
    this.monthlyBudget = monthlyBudget;
  }

  public NeedsAnalysisRecommendedProductPayload getRecommendedProductPayload() {
    return recommendedProductPayload;
  }

  public void setRecommendedProductPayload(NeedsAnalysisRecommendedProductPayload recommendedProduct) {
    this.recommendedProductPayload = recommendedProduct;
  }

  public NeedsAnalysisPayload getNeedsAnalysisPayload() {
    return needsAnalysisPayload;
  }

  public void setNeedsAnalysisPayload(NeedsAnalysisPayload needsAnalysisPayload) {
    this.needsAnalysisPayload = needsAnalysisPayload;
  }

  @Override
  public String toString() {
    return "NeedsAnalysisRequest{" +
        "erefNoMain='" + customId + '\'' +
        ", monthlyBudget=" + monthlyBudget +
        ", needsAnalysisPayload=" + needsAnalysisPayload +
        ", recommendedProduct=" + recommendedProductPayload +
        '}';
  }
}
