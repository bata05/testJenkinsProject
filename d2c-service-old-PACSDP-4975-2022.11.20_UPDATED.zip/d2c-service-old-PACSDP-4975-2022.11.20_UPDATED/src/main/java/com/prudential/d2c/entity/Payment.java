package com.prudential.d2c.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Payment implements Cloneable{

	public Object clone()throws CloneNotSupportedException{
		return super.clone();
	}

	private double totalPrem;
	private String paymentMode;
	private String paymentModeX;
	private String paymentMethod;
	private String paymentMethodX;
	private String payFor;
	private String cardType;
	private String nameOfCardholder;
	private String cardholderRelToProposer;
	private String cardTypeX;
	private String nameOfCardholderX;
	private String cardholderRelToProposerX;
	private double firstPremAmt;
	private double installPremAmtX;
	private String maturityPolNo;
	private String cpfAccountNoOA;
	private String cpfAccountNoSA;
	private String cpfAccountNoSRS;
	private String cpfAgentBank;
	private String invAccountNo;
	
	//begin not in PS---------------
	private String mercId;
	private String mercRefNo;
	private String currency;
	private double transAmt;
	private String paymentType;
	private String gatewayErrorCode;
	private String gatewayErrorMsg;
	private String approvalCode;
	private String bankRetCode;
	private String creditCardNum;
	private String creditCardExpiration;
	private String respSignature;
	private String eci;
	private String cavv;
	private String xid;
	private String origRefNo;
	private String origPayType;
	private int validFlag;
	private String respTimestamp;
	private String reqTimestamp;
	private String lastModifiedTimestamp;
	private double installPremAmt;
	private double amtPaid;
	private String txnTimestamp;
	private String tydes;
	private String pymtMethod;
	private String instFromDate;
	private String instToDate;
	private String remark;
	private double itemPymtAmt;
	private double premDue;
	private double origPrem;
	//end not in PS------------------
	
	private String maskedCreditCardNum;
	private String creditCardNumX;
	private String maskedCreditCardNumX;
	private String creditCardExpirationX;
    private String recupDate;

	
	/**
	 * @return the totalPrem
	 */
	public double getTotalPrem() {
		return totalPrem;
	}
	/**
	 * @param totalPrem the totalPrem to set
	 */
	public void setTotalPrem(double totalPrem) {
		this.totalPrem = totalPrem;
	}
	/**
	 * @return the paymentMode
	 */
	public String getPaymentMode() {
		return paymentMode;
	}
	/**
	 * @param paymentMode the paymentMode to set
	 */
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	/**
	 * @return the paymentModeX
	 */
	public String getPaymentModeX() {
		return paymentModeX;
	}
	/**
	 * @param paymentModeX the paymentModeX to set
	 */
	public void setPaymentModeX(String paymentModeX) {
		this.paymentModeX = paymentModeX;
	}
	/**
	 * @return the paymentMethod
	 */
	public String getPaymentMethod() {
		return paymentMethod;
	}
	/**
	 * @param paymentMethod the paymentMethod to set
	 */
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	/**
	 * @return the paymentMethodX
	 */
	public String getPaymentMethodX() {
		return paymentMethodX;
	}
	/**
	 * @param paymentMethodX the paymentMethodX to set
	 */
	public void setPaymentMethodX(String paymentMethodX) {
		this.paymentMethodX = paymentMethodX;
	}
	/**
	 * @return the payFor
	 */
	public String getPayFor() {
		return payFor;
	}
	/**
	 * @param payFor the payFor to set
	 */
	public void setPayFor(String payFor) {
		this.payFor = payFor;
	}
	/**
	 * @return the cardType
	 */
	public String getCardType() {
		return cardType;
	}
	/**
	 * @param cardType the cardType to set
	 */
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	/**
	 * @return the nameOfCardholder
	 */
	public String getNameOfCardholder() {
		return nameOfCardholder;
	}
	/**
	 * @param nameOfCardholder the nameOfCardholder to set
	 */
	public void setNameOfCardholder(String nameOfCardholder) {
		this.nameOfCardholder = nameOfCardholder;
	}
	/**
	 * @return the cardholderRelToProposer
	 */
	public String getCardholderRelToProposer() {
		return cardholderRelToProposer;
	}
	/**
	 * @param cardholderRelToProposer the cardholderRelToProposer to set
	 */
	public void setCardholderRelToProposer(String cardholderRelToProposer) {
		this.cardholderRelToProposer = cardholderRelToProposer;
	}
	/**
	 * @return the cardTypeX
	 */
	public String getCardTypeX() {
		return cardTypeX;
	}
	/**
	 * @param cardTypeX the cardTypeX to set
	 */
	public void setCardTypeX(String cardTypeX) {
		this.cardTypeX = cardTypeX;
	}
	/**
	 * @return the nameOfCardholderX
	 */
	public String getNameOfCardholderX() {
		return nameOfCardholderX;
	}
	/**
	 * @param nameOfCardholderX the nameOfCardholderX to set
	 */
	public void setNameOfCardholderX(String nameOfCardholderX) {
		this.nameOfCardholderX = nameOfCardholderX;
	}
	/**
	 * @return the cardholderRelToProposerX
	 */
	public String getCardholderRelToProposerX() {
		return cardholderRelToProposerX;
	}
	/**
	 * @param cardholderRelToProposerX the cardholderRelToProposerX to set
	 */
	public void setCardholderRelToProposerX(String cardholderRelToProposerX) {
		this.cardholderRelToProposerX = cardholderRelToProposerX;
	}
	/**
	 * @return the firstPremAmt
	 */
	public double getFirstPremAmt() {
		return firstPremAmt;
	}
	/**
	 * @param firstPremAmt the firstPremAmt to set
	 */
	public void setFirstPremAmt(double firstPremAmt) {
		this.firstPremAmt = firstPremAmt;
	}
	/**
	 * @return the installPremAmt
	 */
	public double getInstallPremAmt() {
		return installPremAmt;
	}
	/**
	 * @param installPremAmt the installPremAmt to set
	 */
	public void setInstallPremAmt(double installPremAmt) {
		this.installPremAmt = installPremAmt;
	}
	/**
	 * @return the installPremAmtX
	 */
	public double getInstallPremAmtX() {
		return installPremAmtX;
	}
	/**
	 * @param installPremAmtX the installPremAmtX to set
	 */
	public void setInstallPremAmtX(double installPremAmtX) {
		this.installPremAmtX = installPremAmtX;
	}
	/**
	 * @return the maturityPolNo
	 */
	public String getMaturityPolNo() {
		return maturityPolNo;
	}
	/**
	 * @param maturityPolNo the maturityPolNo to set
	 */
	public void setMaturityPolNo(String maturityPolNo) {
		this.maturityPolNo = maturityPolNo;
	}
	/**
	 * @return the cpfAccountNoOA
	 */
	public String getCpfAccountNoOA() {
		return cpfAccountNoOA;
	}
	/**
	 * @param cpfAccountNoOA the cpfAccountNoOA to set
	 */
	public void setCpfAccountNoOA(String cpfAccountNoOA) {
		this.cpfAccountNoOA = cpfAccountNoOA;
	}
	/**
	 * @return the cpfAccountNoSA
	 */
	public String getCpfAccountNoSA() {
		return cpfAccountNoSA;
	}
	/**
	 * @param cpfAccountNoSA the cpfAccountNoSA to set
	 */
	public void setCpfAccountNoSA(String cpfAccountNoSA) {
		this.cpfAccountNoSA = cpfAccountNoSA;
	}
	/**
	 * @return the cpfAccountNoSRS
	 */
	public String getCpfAccountNoSRS() {
		return cpfAccountNoSRS;
	}
	/**
	 * @param cpfAccountNoSRS the cpfAccountNoSRS to set
	 */
	public void setCpfAccountNoSRS(String cpfAccountNoSRS) {
		this.cpfAccountNoSRS = cpfAccountNoSRS;
	}
	/**
	 * @return the cpfAgentBank
	 */
	public String getCpfAgentBank() {
		return cpfAgentBank;
	}
	/**
	 * @param cpfAgentBank the cpfAgentBank to set
	 */
	public void setCpfAgentBank(String cpfAgentBank) {
		this.cpfAgentBank = cpfAgentBank;
	}
	/**
	 * @return the invAccountNo
	 */
	public String getInvAccountNo() {
		return invAccountNo;
	}
	/**
	 * @param invAccountNo the invAccountNo to set
	 */
	public void setInvAccountNo(String invAccountNo) {
		this.invAccountNo = invAccountNo;
	}
	/**
	 * @return the mercId
	 */
	public String getMercId() {
		return mercId;
	}
	/**
	 * @param mercId the mercId to set
	 */
	public void setMercId(String mercId) {
		this.mercId = mercId;
	}
	/**
	 * @return the mercRefNo
	 */
	public String getMercRefNo() {
		return mercRefNo;
	}
	/**
	 * @param mercRefNo the mercRefNo to set
	 */
	public void setMercRefNo(String mercRefNo) {
		this.mercRefNo = mercRefNo;
	}
	/**
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}
	/**
	 * @param currency the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	/**
	 * @return the transAmt
	 */
	public double getTransAmt() {
		return transAmt;
	}
	/**
	 * @param transAmt the transAmt to set
	 */
	public void setTransAmt(double transAmt) {
		this.transAmt = transAmt;
	}
	/**
	 * @return the paymentType
	 */
	public String getPaymentType() {
		return paymentType;
	}
	/**
	 * @param paymentType the paymentType to set
	 */
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	/**
	 * @return the gatewayErrorCode
	 */
	public String getGatewayErrorCode() {
		return gatewayErrorCode;
	}
	/**
	 * @param gatewayErrorCode the gatewayErrorCode to set
	 */
	public void setGatewayErrorCode(String gatewayErrorCode) {
		this.gatewayErrorCode = gatewayErrorCode;
	}
	/**
	 * @return the gatewayErrorMsg
	 */
	public String getGatewayErrorMsg() {
		return gatewayErrorMsg;
	}
	/**
	 * @param gatewayErrorMsg the gatewayErrorMsg to set
	 */
	public void setGatewayErrorMsg(String gatewayErrorMsg) {
		this.gatewayErrorMsg = gatewayErrorMsg;
	}
	/**
	 * @return the approvalCode
	 */
	public String getApprovalCode() {
		return approvalCode;
	}
	/**
	 * @param approvalCode the approvalCode to set
	 */
	public void setApprovalCode(String approvalCode) {
		this.approvalCode = approvalCode;
	}
	/**
	 * @return the bankRetCode
	 */
	public String getBankRetCode() {
		return bankRetCode;
	}
	/**
	 * @param bankRetCode the bankRetCode to set
	 */
	public void setBankRetCode(String bankRetCode) {
		this.bankRetCode = bankRetCode;
	}
	/**
	 * @return the creditCardNum
	 */
	public String getCreditCardNum() {
		return creditCardNum;
	}
	/**
	 * @param creditCardNum the creditCardNum to set
	 */
	public void setCreditCardNum(String creditCardNum) {
		this.creditCardNum = creditCardNum;
	}
	/**
	 * @return the maskedCreditCardNum
	 */
	public String getMaskedCreditCardNum() {
		return maskedCreditCardNum;
	}
	/**
	 * @param maskedCreditCardNum the maskedCreditCardNum to set
	 */
	public void setMaskedCreditCardNum(String maskedCreditCardNum) {
		this.maskedCreditCardNum = maskedCreditCardNum;
	}
	/**
	 * @return the creditCardExpiration
	 */
	public String getCreditCardExpiration() {
		return creditCardExpiration;
	}
	/**
	 * @param creditCardExpiration the creditCardExpiration to set
	 */
	public void setCreditCardExpiration(String creditCardExpiration) {
		this.creditCardExpiration = creditCardExpiration;
	}
	/**
	 * @return the creditCardNumX
	 */
	public String getCreditCardNumX() {
		return creditCardNumX;
	}
	/**
	 * @param creditCardNumX the creditCardNumX to set
	 */
	public void setCreditCardNumX(String creditCardNumX) {
		this.creditCardNumX = creditCardNumX;
	}
	/**
	 * @return the maskedCreditCardNumX
	 */
	public String getMaskedCreditCardNumX() {
		return maskedCreditCardNumX;
	}
	/**
	 * @param maskedCreditCardNumX the maskedCreditCardNumX to set
	 */
	public void setMaskedCreditCardNumX(String maskedCreditCardNumX) {
		this.maskedCreditCardNumX = maskedCreditCardNumX;
	}
	/**
	 * @return the creditCardExpirationX
	 */
	public String getCreditCardExpirationX() {
		return creditCardExpirationX;
	}
	/**
	 * @param creditCardExpirationX the creditCardExpirationX to set
	 */
	public void setCreditCardExpirationX(String creditCardExpirationX) {
		this.creditCardExpirationX = creditCardExpirationX;
	}
	/**
	 * @return the respSignature
	 */
	public String getRespSignature() {
		return respSignature;
	}
	/**
	 * @param respSignature the respSignature to set
	 */
	public void setRespSignature(String respSignature) {
		this.respSignature = respSignature;
	}
	/**
	 * @return the eci
	 */
	public String getEci() {
		return eci;
	}
	/**
	 * @param eci the eci to set
	 */
	public void setEci(String eci) {
		this.eci = eci;
	}
	/**
	 * @return the cavv
	 */
	public String getCavv() {
		return cavv;
	}
	/**
	 * @param cavv the cavv to set
	 */
	public void setCavv(String cavv) {
		this.cavv = cavv;
	}
	/**
	 * @return the xid
	 */
	public String getXid() {
		return xid;
	}
	/**
	 * @param xid the xid to set
	 */
	public void setXid(String xid) {
		this.xid = xid;
	}
	/**
	 * @return the origRefNo
	 */
	public String getOrigRefNo() {
		return origRefNo;
	}
	/**
	 * @param origRefNo the origRefNo to set
	 */
	public void setOrigRefNo(String origRefNo) {
		this.origRefNo = origRefNo;
	}
	/**
	 * @return the origPayType
	 */
	public String getOrigPayType() {
		return origPayType;
	}
	/**
	 * @param origPayType the origPayType to set
	 */
	public void setOrigPayType(String origPayType) {
		this.origPayType = origPayType;
	}
	/**
	 * @return the validFlag
	 */
	public int getValidFlag() {
		return validFlag;
	}
	/**
	 * @param validFlag the validFlag to set
	 */
	public void setValidFlag(int validFlag) {
		this.validFlag = validFlag;
	}
	/**
	 * @return the amtPaid
	 */
	public double getAmtPaid() {
		return amtPaid;
	}
	/**
	 * @param amtPaid the amtPaid to set
	 */
	public void setAmtPaid(double amtPaid) {
		this.amtPaid = amtPaid;
	}
	/**
	 * @return the txnTimestamp
	 */
	public String getTxnTimestamp() {
		return txnTimestamp;
	}
	/**
	 * @param txnTimestamp the txnTimestamp to set
	 */
	public void setTxnTimestamp(String txnTimestamp) {
		this.txnTimestamp = txnTimestamp;
	}
	/**
	 * @return the reqTimestamp
	 */
	public String getReqTimestamp() {
		return reqTimestamp;
	}
	/**
	 * @param reqTimestamp the reqTimestamp to set
	 */
	public void setReqTimestamp(String reqTimestamp) {
		this.reqTimestamp = reqTimestamp;
	}
	/**
	 * @return the respTimestamp
	 */
	public String getRespTimestamp() {
		return respTimestamp;
	}
	/**
	 * @param respTimestamp the respTimestamp to set
	 */
	public void setRespTimestamp(String respTimestamp) {
		this.respTimestamp = respTimestamp;
	}
	/**
	 * @return the lastModifiedTimestamp
	 */
	public String getLastModifiedTimestamp() {
		return lastModifiedTimestamp;
	}
	/**
	 * @param lastModifiedTimestamp the lastModifiedTimestamp to set
	 */
	public void setLastModifiedTimestamp(String lastModifiedTimestamp) {
		this.lastModifiedTimestamp = lastModifiedTimestamp;
	}
	/**
	 * @return the tydes
	 */
	public String getTydes() {
		return tydes;
	}
	/**
	 * @param tydes the tydes to set
	 */
	public void setTydes(String tydes) {
		this.tydes = tydes;
	}
	/**
	 * @return the pymtMethod
	 */
	public String getPymtMethod() {
		return pymtMethod;
	}
	/**
	 * @param pymtMethod the pymtMethod to set
	 */
	public void setPymtMethod(String pymtMethod) {
		this.pymtMethod = pymtMethod;
	}
	/**
	 * @return the recupDate
	 */
	public String getRecupDate() {
		return recupDate;
	}
	/**
	 * @param recupDate the recupDate to set
	 */
	public void setRecupDate(String recupDate) {
		this.recupDate = recupDate;
	}
	/**
	 * @return the instFromDate
	 */
	public String getInstFromDate() {
		return instFromDate;
	}
	/**
	 * @param instFromDate the instFromDate to set
	 */
	public void setInstFromDate(String instFromDate) {
		this.instFromDate = instFromDate;
	}
	/**
	 * @return the instToDate
	 */
	public String getInstToDate() {
		return instToDate;
	}
	/**
	 * @param instToDate the instToDate to set
	 */
	public void setInstToDate(String instToDate) {
		this.instToDate = instToDate;
	}
	/**
	 * @return the remark
	 */
	public String getRemark() {
		return remark;
	}
	/**
	 * @param remark the remark to set
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}
	/**
	 * @return the itemPymtAmt
	 */
	public double getItemPymtAmt() {
		return itemPymtAmt;
	}
	/**
	 * @param itemPymtAmt the itemPymtAmt to set
	 */
	public void setItemPymtAmt(double itemPymtAmt) {
		this.itemPymtAmt = itemPymtAmt;
	}
	/**
	 * @return the premDue
	 */
	public double getPremDue() {
		return premDue;
	}
	/**
	 * @param premDue the premDue to set
	 */
	public void setPremDue(double premDue) {
		this.premDue = premDue;
	}
	/**
	 * @return the origPrem
	 */
	public double getOrigPrem() {
		return origPrem;
	}
	/**
	 * @param origPrem the origPrem to set
	 */
	public void setOrigPrem(double origPrem) {
		this.origPrem = origPrem;
	}
	
}
