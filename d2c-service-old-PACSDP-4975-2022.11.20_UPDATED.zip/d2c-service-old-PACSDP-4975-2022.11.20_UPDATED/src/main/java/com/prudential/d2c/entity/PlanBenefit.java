package com.prudential.d2c.entity;

import java.util.List;

public class PlanBenefit {
	private String benefitCode;
	private String benefitDesc;
	private String benefitValue;
	private List<PlanBenefit> subBenefits;
	
	public String getBenefitCode() {
		return benefitCode;
	}
	public void setBenefitCode(String benefitCode) {
		this.benefitCode = benefitCode;
	}
	public String getBenefitDesc() {
		return benefitDesc;
	}
	public void setBenefitDesc(String benefitDesc) {
		this.benefitDesc = benefitDesc;
	}
	public String getBenefitValue() {
		return benefitValue;
	}
	public void setBenefitValue(String benefitValue) {
		this.benefitValue = benefitValue;
	}
	public List<PlanBenefit> getSubBenefits() {
		return subBenefits;
	}
	public void setSubBenefits(List<PlanBenefit> subBenefits) {
		this.subBenefits = subBenefits;
	}
	
	
}
