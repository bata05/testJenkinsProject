/**
 * 
 */
package com.prudential.d2c.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author rprasad017
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class PlanDetails {
	private String planName;
	private String planType;
	private String term;
	private String premiumTerm;
	private String sumAssured;
	private String premium;
	private String optDescp;
	private String ageProtectedUntil;
	private String differedYear;
	private String benefit;
	private String retirementAge;
	private String monthlyIncome;
	private String monthlyIncomePeriod;
	private String monthlyIncomeOption;
	private String mediSavePremium;
	private String cashOutlayPremium;
	/**
	 * @return the planName
	 */
	public String getPlanName() {
		return planName;
	}
	/**
	 * @return the ageProtectedUntil
	 */
	public String getAgeProtectedUntil() {
		return ageProtectedUntil;
	}
	/**
	 * @param ageProtectedUntil the ageProtectedUntil to set
	 */
	public void setAgeProtectedUntil(String ageProtectedUntil) {
		this.ageProtectedUntil = ageProtectedUntil;
	}
	/**
	 * @param planName the planName to set
	 */
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	/**
	 * @return the planType
	 */
	public String getPlanType() {
		return planType;
	}
	/**
	 * @param planType the planType to set
	 */
	public void setPlanType(String planType) {
		this.planType = planType;
	}
	/**
	 * @return the term
	 */
	public String getTerm() {
		return term;
	}
	/**
	 * @param term the term to set
	 */
	public void setTerm(String term) {
		this.term = term;
	}
	/**
	 * @return the premium
	 */
	public String getPremium() {
		return premium;
	}
	/**
	 * @param premium the premium to set
	 */
	public void setPremium(String premium) {
		this.premium = premium;
	}
	public String getSumAssured() {
		return sumAssured;
	}
	public void setSumAssured(String sumAssured) {
		this.sumAssured = sumAssured;
	}
	public String getOptDescp() {
		return optDescp;
	}
	public void setOptDescp(String optDescp) {
		this.optDescp = optDescp;
	}
	public String getDifferedYear() {
		return differedYear;
	}
	public void setDifferedYear(String differedYear) {
		this.differedYear = differedYear;
	}
	public String getBenefit() {
		return benefit;
	}
	public void setBenefit(String benefit) {
		this.benefit = benefit;
	}

	public String getRetirementAge() {
		return retirementAge;
	}
	public void setRetirementAge(String retirementAge) {
		this.retirementAge = retirementAge;
	}
	public String getMonthlyIncome() {
		return monthlyIncome;
	}
	public void setMonthlyIncome(String monthlyIncome) {
		this.monthlyIncome = monthlyIncome;
	}
	public String getMonthlyIncomePeriod() {
		return monthlyIncomePeriod;
	}
	public void setMonthlyIncomePeriod(String monthlyIncomePeriod) {
		this.monthlyIncomePeriod = monthlyIncomePeriod;
	}
	public String getMonthlyIncomeOption() {
		return monthlyIncomeOption;
	}
	public void setMonthlyIncomeOption(String monthlyIncomeOption) {
		this.monthlyIncomeOption = monthlyIncomeOption;
	}

	public String getPremiumTerm() {
		return premiumTerm;
	}

	public void setPremiumTerm(String premiumTerm) {
		this.premiumTerm = premiumTerm;
	}

	public String getMediSavePremium() { return mediSavePremium; }

	public void setMediSavePremium(String mediSaveYearlyPremium) { this.mediSavePremium = mediSaveYearlyPremium; }

    public String getCashOutlayPremium() {
        return cashOutlayPremium;
    }

    public void setCashOutlayPremium(String cashOutlayPremium) {
        this.cashOutlayPremium = cashOutlayPremium;
    }
}
