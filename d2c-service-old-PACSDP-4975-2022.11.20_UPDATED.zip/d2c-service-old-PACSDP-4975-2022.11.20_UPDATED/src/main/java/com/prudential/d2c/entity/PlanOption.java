package com.prudential.d2c.entity;

import java.util.List;
import java.util.Objects;

public class PlanOption {
	private Boolean optValueEditable;
	private String optCode;
	private String optDescp;
	private String optDataType;
	private String optValue;
	private Boolean isOptValueEditable;
	private String optDetails;
	private List<PlanBenefit> benefits;
	
	public Boolean getOptValueEditable() {
		return optValueEditable;
	}
	public void setOptValueEditable(Boolean optValueEditable) {
		this.optValueEditable = optValueEditable;
	}
	public String getOptCode() {
		return optCode;
	}
	public void setOptCode(String optCode) {
		this.optCode = optCode;
	}
	public String getOptDescp() {
		return optDescp;
	}
	public void setOptDescp(String optDescp) {
		this.optDescp = optDescp;
	}
	public String getOptDataType() {
		return optDataType;
	}
	public void setOptDataType(String optDataType) {
		this.optDataType = optDataType;
	}
	public String getOptValue() {
		return optValue;
	}
	public void setOptValue(String optValue) {
		this.optValue = optValue;
	}
	public Boolean getIsOptValueEditable() {
		return isOptValueEditable;
	}
	public void setIsOptValueEditable(Boolean isOptValueEditable) {
		this.isOptValueEditable = isOptValueEditable;
	}
	public String getOptDetails() {
		return optDetails;
	}
	public void setOptDetails(String optDetails) {
		this.optDetails = optDetails;
	}
	public List<PlanBenefit> getBenefits() {
		return benefits;
	}
	public void setBenefits(List<PlanBenefit> benefits) {
		this.benefits = benefits;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		PlanOption that = (PlanOption) o;
		return Objects.equals(optCode, that.optCode) &&
				//Objects.equals(optDataType, that.optDataType) &&
				Objects.equals(optValue, that.optValue);
	}

}
