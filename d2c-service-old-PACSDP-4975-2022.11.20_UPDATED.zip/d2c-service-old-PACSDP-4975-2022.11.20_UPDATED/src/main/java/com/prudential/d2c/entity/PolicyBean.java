package com.prudential.d2c.entity;

import java.util.List;

public class PolicyBean {
	private List<String> policyStatus;
	private String afterIssueDate;
	
	public List<String> getPolicyStatus() {
		return policyStatus;
	}
	public void setPolicyStatus(List<String> policyStatus) {
		this.policyStatus = policyStatus;
	}
	public String getAfterIssueDate() {
		return afterIssueDate;
	}
	public void setAfterIssueDate(String afterIssueDate) {
		this.afterIssueDate = afterIssueDate;
	}
	
	
}
