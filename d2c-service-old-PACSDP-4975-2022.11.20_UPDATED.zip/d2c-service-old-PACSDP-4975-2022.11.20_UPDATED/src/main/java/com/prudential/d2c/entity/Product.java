package com.prudential.d2c.entity;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.prudential.d2c.entity.micro.Discount;
import com.prudential.d2c.entity.micro.PolicyOption;
import com.prudential.d2c.entity.micro.SelectedSQSProductTables;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Product {
	private String docId;
	private String prodCode;
	private String prodDesc;
	private String minAge;
	private String maxAge;
	private String toDisplay;
	private String currency;
	private String paymentTypeIndicator;
	private double totalPremium;
	private double totalYearlyPremium;
	private double totalHalfYearlyPremium;
	private double totalQuarterlyPremium;
	private double totalMonthlyPremium;
	private Boolean isAgeReq;
	private Boolean isSmokerReq;
	private Boolean isResidentialStatusReq;
	private Boolean isOccupReq;
	private Boolean isGenderReq;
	private Boolean isPaymentModeReq;
	private Boolean isActive;
	private Boolean isCWOpt;
	private Boolean isESCWOpt;
	private String paymentMode;
	private double totalCashPayment;
	private List<PolicyOption> policyOptions;
	private PolicyOption selectedPolicyOption;
	private List<Component> components;
	private SelectedSQSProductTables tables;
	private String createdDate;
	private String version;
	private BigDecimal totalDeathBenefit;
	private BigDecimal totalSV;
	private Discount discount;

	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	public String getProdCode() {
		return prodCode;
	}
	public void setProdCode(String prodCode) {
		this.prodCode = prodCode;
	}
	public String getProdDesc() {
		return prodDesc;
	}
	public void setProdDesc(String prodDesc) {
		this.prodDesc = prodDesc;
	}
	public String getMinAge() {
		return minAge;
	}
	public void setMinAge(String minAge) {
		this.minAge = minAge;
	}
	public String getMaxAge() {
		return maxAge;
	}
	public void setMaxAge(String maxAge) {
		this.maxAge = maxAge;
	}
	public String getToDisplay() {
		return toDisplay;
	}
	public void setToDisplay(String toDisplay) {
		this.toDisplay = toDisplay;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getPaymentTypeIndicator() {
		return paymentTypeIndicator;
	}
	public void setPaymentTypeIndicator(String paymentTypeIndicator) {
		this.paymentTypeIndicator = paymentTypeIndicator;
	}
	public Boolean getIsAgeReq() {
		return isAgeReq;
	}
	public void setIsAgeReq(Boolean isAgeReq) {
		this.isAgeReq = isAgeReq;
	}
	public Boolean getIsSmokerReq() {
		return isSmokerReq;
	}
	public void setIsSmokerReq(Boolean isSmokerReq) {
		this.isSmokerReq = isSmokerReq;
	}
	public Boolean getIsResidentialStatusReq() {
		return isResidentialStatusReq;
	}
	public void setIsResidentialStatusReq(Boolean isResidentialStatusReq) {
		this.isResidentialStatusReq = isResidentialStatusReq;
	}
	public Boolean getIsOccupReq() {
		return isOccupReq;
	}
	public void setIsOccupReq(Boolean isOccupReq) {
		this.isOccupReq = isOccupReq;
	}
	public Boolean getIsGenderReq() {
		return isGenderReq;
	}
	public void setIsGenderReq(Boolean isGenderReq) {
		this.isGenderReq = isGenderReq;
	}
	public Boolean getIsPaymentModeReq() {
		return isPaymentModeReq;
	}
	public void setIsPaymentModeReq(Boolean isPaymentModeReq) {
		this.isPaymentModeReq = isPaymentModeReq;
	}
	public Boolean getIsActive() {
		return isActive;
	}
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	public Boolean getIsCWOpt() {
		return isCWOpt;
	}
	public void setIsCWOpt(Boolean isCWOpt) {
		this.isCWOpt = isCWOpt;
	}
	public Boolean getIsESCWOpt() {
		return isESCWOpt;
	}
	public void setIsESCWOpt(Boolean isESCWOpt) {
		this.isESCWOpt = isESCWOpt;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public List<PolicyOption> getPolicyOptions() {
		return policyOptions;
	}
	public void setPolicyOptions(List<PolicyOption> policyOptions) {
		this.policyOptions = policyOptions;
	}
	public List<Component> getComponents() {
		return components;
	}
	public void setComponents(List<Component> components) {
		this.components = components;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public double getTotalPremium() {
		return totalPremium;
	}
	public void setTotalPremium(double totalPremium) {
		this.totalPremium = totalPremium;
	}
	public double getTotalYearlyPremium() {
		return totalYearlyPremium;
	}
	public void setTotalYearlyPremium(double totalYearlyPremium) {
		this.totalYearlyPremium = totalYearlyPremium;
	}
	public double getTotalHalfYearlyPremium() {
		return totalHalfYearlyPremium;
	}
	public void setTotalHalfYearlyPremium(double totalHalfYearlyPremium) {
		this.totalHalfYearlyPremium = totalHalfYearlyPremium;
	}
	public double getTotalQuarterlyPremium() {
		return totalQuarterlyPremium;
	}
	public void setTotalQuarterlyPremium(double totalQuarterlyPremium) {
		this.totalQuarterlyPremium = totalQuarterlyPremium;
	}
	public double getTotalMonthlyPremium() {
		return totalMonthlyPremium;
	}
	public void setTotalMonthlyPremium(double totalMonthlyPremium) {
		this.totalMonthlyPremium = totalMonthlyPremium;
	}
	/**
	 * @return the tables
	 */
	public SelectedSQSProductTables getTables() {
		return tables;
	}
	/**
	 * @param tables the tables to set
	 */
	public void setTables(SelectedSQSProductTables tables) {
		this.tables = tables;
	}
	public PolicyOption getSelectedPolicyOption() {
		return selectedPolicyOption;
	}
	public void setSelectedPolicyOption(PolicyOption selectedPolicyOption) {
		this.selectedPolicyOption = selectedPolicyOption;
	}

	public BigDecimal getTotalDeathBenefit() {
		return totalDeathBenefit;
	}
	public void setTotalDeathBenefit(BigDecimal totalDeathBenefit) {
		this.totalDeathBenefit = totalDeathBenefit;
	}
	public BigDecimal getTotalSV() {
		return totalSV;
	}
	public void setTotalSV(BigDecimal totalSV) {
		this.totalSV = totalSV;
	}
	public double getTotalCashPayment() {
		return totalCashPayment;
	}

	public void setTotalCashPayment(double totalCashPayment) {
		this.totalCashPayment = totalCashPayment;
	}
	public Discount getDiscount() {
		return discount;
	}

	public void setDiscount(Discount discount) {
		this.discount = discount;
	}

	/*@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		Product product = (Product) o;
		return Objects.equals(prodCode, product.prodCode) &&
				Objects.equals(components, product.components);
	}

	@Override
	public int hashCode() {

		return Objects.hash(prodCode, components);
	}*/

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		Product product = (Product) o;
		return Math.round(product.totalPremium) == Math.round(totalPremium) &&
				Math.round(product.totalYearlyPremium) == Math.round(totalYearlyPremium) &&
				Math.round(product.totalHalfYearlyPremium) == Math.round(totalHalfYearlyPremium) &&
				Math.round(product.totalQuarterlyPremium) == Math.round(totalQuarterlyPremium) &&
				Math.round(product.totalMonthlyPremium) == Math.round(totalMonthlyPremium) &&
				Objects.equals(docId, product.docId) &&
				Objects.equals(prodCode, product.prodCode) &&
				Objects.equals(prodDesc, product.prodDesc) &&
				Objects.equals(currency, product.currency) &&
				Objects.equals(components, product.components);
	}

	@Override
	public int hashCode() {

		return Objects.hash(docId, prodCode, prodDesc, currency, totalPremium, totalYearlyPremium, totalHalfYearlyPremium, totalQuarterlyPremium, totalMonthlyPremium, components);
	}
}
