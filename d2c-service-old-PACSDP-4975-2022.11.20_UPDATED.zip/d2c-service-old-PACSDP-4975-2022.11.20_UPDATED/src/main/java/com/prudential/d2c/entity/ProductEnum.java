package com.prudential.d2c.entity;

import java.util.Arrays;

public enum ProductEnum {
    //PA, PL, PM, PT, ET, PS, PGP, PGRP, PAS

    ET("id_prod_ct7","CT7","TGT2"),
    PT("id_prod_tb1","TB1","BBT1"),
    PL("id_prod_sl2","SL2","XSL4"),
    PM("id_prod_sm1","SM1","XML1"),
    PS("id_prod_pm1","PM1","PMSD"),
    PFC("id_prod_ec7","EC7","DAN7"),
    PTV("id_prod_lt4","LT4","TLT8"),
    PGP("id_prod_in7","IN7","INN7"),
    PLMF("id_prod_wr7","WR7","WRA7"),
    PGRP("id_prod_al7_60","AL7","ALA7"),
    PAS("id_prod_xw8","XW8","EX48"),
    PTP("id_prod_cta","CTA","CSDA"),
    PA("id_prod_pau", "PAU", ""),
    PAT("id_prod_lt5","LT5","TLTL"),
    PAR("id_prod_at7","AT7","AQB7"),
    PLVA("id_prod_pg7","PG7","WSG7"),
    PAL("id_prod_wo7","WO7","WOA7"),
    PATC("id_prod_lt5_1","LT5_1","HCRE"),
    PRU("id_prod_pru","PRU",""),
    PER("id_prod_xz7","XZ7","EXP7"),
    PCS("id_prod_ac7","AC7","ACM7"),
    PLSC("id_prod_pr3","PR3","PR03"),
    PGR("id_prod_ah7","AH7","AHA7"),
    PGRR("id_prod_aq7","AQ7","APC7"),
    PLI4P("id_prod_wk7","WK7","WTK7"),
    PLIP("id_prod_wx7","WX7","WTX7"),
    PLEP("id_prod_px1","PX1","PX01"),
    PSSA("id_prod_r2m","R2M","PMA7"),
    PSV("id_prod_sfa","SFA","SVDA"),
    PE("id_prod_pmb","PMB","PMSD"),
    PWP("id_prod_ve7","VE7","WVE7"),
    PC("id_prod_can","CAN","CAN3"),
    PASO("id_prod_xy7","XY7","EX17"),
    PAP("id_prod_nci", "NCI", "NCI2"),
    PVTA("id_prod_py1", "PY1", "PY01"),
    PVTAR("id_prod_py2", "PY2", "PY02"),
    PAC("id_prod_ac8", "AC8", "ACM8"),
	PVTRE("id_prod_pz1", "PZ1", "PZ01"),
	DEPAR("id_prod_ipf","IPF","IPF1");

    private String prodCode;
    private String docId;
    private String compCode;

    ProductEnum(String docId, String prodCode, String compCode){
        this.docId = docId;
        this.prodCode = prodCode;
        this.compCode = compCode;
    }

    public String getProdCode() {
        return prodCode;
    }

    public String getDocId() {
        return docId;
    }

    public String getCompCode() {
        return compCode;
    }

    /**
     * Get the product based on product code
     * @param prodCode
     * @return
     */
    public static ProductEnum getProductByProductCode(String prodCode){
        return Arrays.stream(ProductEnum.values()).filter(product -> product.name().equals(prodCode)).findFirst().orElse(null);
    }
}
