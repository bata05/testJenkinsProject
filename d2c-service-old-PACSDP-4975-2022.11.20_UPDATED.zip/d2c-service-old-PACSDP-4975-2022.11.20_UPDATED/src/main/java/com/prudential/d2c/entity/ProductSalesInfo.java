package com.prudential.d2c.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "PRODUCT_SALES_INFO")
@SequenceGenerator(name = "PRODUCT_SALES_INFO_SEQ", sequenceName = "PRODUCT_SALES_INFO_SEQ", allocationSize = 1)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductSalesInfo {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PRODUCT_SALES_INFO_SEQ")
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "custom_id", nullable = false)
    private String customId;

    @Column(name = "comp_code", nullable = false)
    private String componentCode;

    @Column(name = "comp_desc", nullable = false)
    private String componentDesc;

    @Column(name = "TOT_PREMIUM")
    private Double totalPremium;

    @Column(name = "eref_no", nullable = false)
    private String erefNo;

    @Column(name = "proposal_no", nullable = false)
    private String proposalNo;

    @Column(name = "CREATED_DATE")
    private Date createdDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCustomId() {
        return customId;
    }

    public void setCustomId(String customId) {
        this.customId = customId;
    }

    public String getComponentCode() {
        return componentCode;
    }

    public void setComponentCode(String componentCode) {
        this.componentCode = componentCode;
    }

    public String getComponentDesc() {
        return componentDesc;
    }

    public void setComponentDesc(String componentDesc) {
        this.componentDesc = componentDesc;
    }

    public Double getTotalPremium() {
        return totalPremium;
    }

    public void setTotalPremium(Double totalPremium) {
        this.totalPremium = totalPremium;
    }

    public String getErefNo() {
        return erefNo;
    }

    public void setErefNo(String erefNo) {
        this.erefNo = erefNo;
    }

    public String getProposalNo() {
        return proposalNo;
    }

    public void setProposalNo(String proposalNo) {
        this.proposalNo = proposalNo;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }
}
