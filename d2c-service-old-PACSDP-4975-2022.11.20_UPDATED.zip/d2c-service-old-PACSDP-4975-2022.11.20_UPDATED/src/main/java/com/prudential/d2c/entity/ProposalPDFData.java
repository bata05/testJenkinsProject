package com.prudential.d2c.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ProposalPDFData {
	private String customId;
	private String erefCode;
	private String agentCode;
	private String agentName;
	private String bankCode;
	private String receiveMarketing;
	private String consultationReq;
	private String totalPremium;
	private String occupationClass;
	private String occupationDescription;
	private PlanDetails basicPlanDetails;
	private PlanDetails raPlanDetails;
	private PlanDetails fcaPlanDetails;
	private PlanDetails defaultPlanDetails;
	private PlanDetails riderPlanDetails;
	private String currency;
	private int noOfSelectedPlans;

	public String getCustomId() {
		return customId;
	}
	public void setCustomId(String customId) {
		this.customId = customId;
	}
	
	public String getErefCode() {
		return erefCode;
	}
	public void setErefCode(String erefCode) {
		this.erefCode = erefCode;
	}
	public String getAgentCode() {
		return agentCode;
	}
	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}
	
	public String getAgentName() {
		return agentName;
	}
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	public String getBankCode() {
		return bankCode;
	}
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}
	public String getReceiveMarketing() {
		return receiveMarketing;
	}
	public void setReceiveMarketing(String receiveMarketing) {
		this.receiveMarketing = receiveMarketing;
	}
	
	public String getConsultationReq() {
		return consultationReq;
	}
	public void setConsultationReq(String consultationReq) {
		this.consultationReq = consultationReq;
	}
	public PlanDetails getBasicPlanDetails() {
		return basicPlanDetails;
	}
	public void setBasicPlanDetails(PlanDetails basicPlanDetails) {
		this.basicPlanDetails = basicPlanDetails;
	}
	public PlanDetails getRaPlanDetails() {
		return raPlanDetails;
	}
	public void setRaPlanDetails(PlanDetails raPlanDetails) {
		this.raPlanDetails = raPlanDetails;
	}
	public PlanDetails getFcaPlanDetails() {
		return fcaPlanDetails;
	}
	public void setFcaPlanDetails(PlanDetails fcaPlanDetails) {
		this.fcaPlanDetails = fcaPlanDetails;
	}
	public PlanDetails getDefaultPlanDetails() {
		return defaultPlanDetails;
	}
	public void setDefaultPlanDetails(PlanDetails defaultPlanDetails) {
		this.defaultPlanDetails = defaultPlanDetails;
	}
	public PlanDetails getRiderPlanDetails() {
		return riderPlanDetails;
	}
	public void setRiderPlanDetails(PlanDetails riderPlanDetails) {
		this.riderPlanDetails = riderPlanDetails;
	}
	public String getTotalPremium() {
		return totalPremium;
	}
	public void setTotalPremium(String totalPremium) {
		this.totalPremium = totalPremium;
	}
	public String getOccupationClass() {
		return occupationClass;
	}
	public void setOccupationClass(String occupationClass) {
		this.occupationClass = occupationClass;
	}
	public String getOccupationDescription() {
		return occupationDescription;
	}
	public void setOccupationDescription(String occupationDescription) {
		this.occupationDescription = occupationDescription;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
    public int getNoOfSelectedPlans() {
        return noOfSelectedPlans;
    }
    public void setNoOfSelectedPlans(int noOfSelectedPlans) {
        this.noOfSelectedPlans = noOfSelectedPlans;
    }

}
