package com.prudential.d2c.entity;

public final class ProposalPDFDataBuilder {
    private String customId;
    private String erefCode;
    private String agentCode;
    private String agentName;
    private String bankCode;
    private String receiveMarketing;
    private String consultationReq;
    private String totalPremium;
    private String occupationClass;
    private String occupationDescription;
    private PlanDetails basicPlanDetails;
    private PlanDetails raPlanDetails;
    private PlanDetails fcaPlanDetails;
    private PlanDetails defaultPlanDetails;
    private PlanDetails riderPlanDetails;
    private String currency;
    private int noOfSelectedPlans;

    private ProposalPDFDataBuilder() {
    }

    public static ProposalPDFDataBuilder builder() {
        return new ProposalPDFDataBuilder();
    }

    public ProposalPDFDataBuilder customId(String customId) {
        this.customId = customId;
        return this;
    }

    public ProposalPDFDataBuilder erefCode(String erefCode) {
        this.erefCode = erefCode;
        return this;
    }

    public ProposalPDFDataBuilder agentCode(String agentCode) {
        this.agentCode = agentCode;
        return this;
    }

    public ProposalPDFDataBuilder agentName(String agentName) {
        this.agentName = agentName;
        return this;
    }

    public ProposalPDFDataBuilder bankCode(String bankCode) {
        this.bankCode = bankCode;
        return this;
    }

    public ProposalPDFDataBuilder receiveMarketing(String receiveMarketing) {
        this.receiveMarketing = receiveMarketing;
        return this;
    }

    public ProposalPDFDataBuilder consultationReq(String consultationReq) {
        this.consultationReq = consultationReq;
        return this;
    }

    public ProposalPDFDataBuilder totalPremium(String totalPremium) {
        this.totalPremium = totalPremium;
        return this;
    }

    public ProposalPDFDataBuilder occupationClass(String occupationClass) {
        this.occupationClass = occupationClass;
        return this;
    }

    public ProposalPDFDataBuilder occupationDescription(String occupationDescription) {
        this.occupationDescription = occupationDescription;
        return this;
    }

    public ProposalPDFDataBuilder basicPlanDetails(PlanDetails basicPlanDetails) {
        this.basicPlanDetails = basicPlanDetails;
        return this;
    }

    public ProposalPDFDataBuilder raPlanDetails(PlanDetails raPlanDetails) {
        this.raPlanDetails = raPlanDetails;
        return this;
    }

    public ProposalPDFDataBuilder fcaPlanDetails(PlanDetails fcaPlanDetails) {
        this.fcaPlanDetails = fcaPlanDetails;
        return this;
    }

    public ProposalPDFDataBuilder defaultPlanDetails(PlanDetails defaultPlanDetails) {
        this.defaultPlanDetails = defaultPlanDetails;
        return this;
    }

    public ProposalPDFDataBuilder riderPlanDetails(PlanDetails riderPlanDetails) {
        this.riderPlanDetails = riderPlanDetails;
        return this;
    }

    public ProposalPDFDataBuilder currency(String currency) {
        this.currency = currency;
        return this;
    }

    public ProposalPDFDataBuilder noOfSelectedPlans(int noOfSelectedPlans) {
        this.noOfSelectedPlans = noOfSelectedPlans;
        return this;
    }

    public ProposalPDFData build() {
        ProposalPDFData proposalPDFData = new ProposalPDFData();
        proposalPDFData.setCustomId(customId);
        proposalPDFData.setErefCode(erefCode);
        proposalPDFData.setAgentCode(agentCode);
        proposalPDFData.setAgentName(agentName);
        proposalPDFData.setBankCode(bankCode);
        proposalPDFData.setReceiveMarketing(receiveMarketing);
        proposalPDFData.setConsultationReq(consultationReq);
        proposalPDFData.setTotalPremium(totalPremium);
        proposalPDFData.setOccupationClass(occupationClass);
        proposalPDFData.setOccupationDescription(occupationDescription);
        proposalPDFData.setBasicPlanDetails(basicPlanDetails);
        proposalPDFData.setRaPlanDetails(raPlanDetails);
        proposalPDFData.setFcaPlanDetails(fcaPlanDetails);
        proposalPDFData.setDefaultPlanDetails(defaultPlanDetails);
        proposalPDFData.setRiderPlanDetails(riderPlanDetails);
        proposalPDFData.setCurrency(currency);
        proposalPDFData.setNoOfSelectedPlans(noOfSelectedPlans);
        return proposalPDFData;
    }
}
