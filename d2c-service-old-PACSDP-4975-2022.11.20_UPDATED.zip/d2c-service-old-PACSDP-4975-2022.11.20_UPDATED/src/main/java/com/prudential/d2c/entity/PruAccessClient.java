package com.prudential.d2c.entity;

import java.util.List;

import com.prudential.d2c.entity.micro.ClientInfo;

public class PruAccessClient {
	private String sourceSystemCode;
	private String clientNumber;
	private String productType;
	private String reservedField;
	private List<ClientInfo> clientList;
	
	public String getSourceSystemCode() {
		return sourceSystemCode;
	}
	public void setSourceSystemCode(String sourceSystemCode) {
		this.sourceSystemCode = sourceSystemCode;
	}
	public String getClientNumber() {
		return clientNumber;
	}
	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getReservedField() {
		return reservedField;
	}
	public void setReservedField(String reservedField) {
		this.reservedField = reservedField;
	}
	public List<ClientInfo> getClientList() {
		return clientList;
	}
	public void setClientList(List<ClientInfo> clientList) {
		this.clientList = clientList;
	}
	
}
