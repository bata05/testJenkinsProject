package com.prudential.d2c.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.prudential.d2c.entity.micro.payload.QuestionDetail;

@JsonIgnoreProperties(ignoreUnknown = true)
public class QuestionnaireAnswer {
	private QuestionDetail question;
	private AnswerBody answer;
	private QuestionDetail parent;

	public QuestionDetail getQuestion() {
		return question;
	}

	public AnswerBody getAnswer() {
		return answer;
	}

	public void setQuestion(QuestionDetail question) {
		this.question = question;
	}

	public void setAnswer(AnswerBody answer) {
		this.answer = answer;
	}

	public QuestionDetail getParent() {
		return parent;
	}

	public void setParent(QuestionDetail parent) {
		this.parent = parent;
	}
  
}
