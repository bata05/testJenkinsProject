/**
 * 
 */
package com.prudential.d2c.entity;

/**
 * @author rprasad017
 *
 */
public class QuestionnaireDetails {

	private Question question;
	private Answer answer;

	/**
	 * @return the question
	 */
	public Question getQuestion() {
		return question;
	}

	/**
	 * @param question the question to set
	 */
	public void setQuestion(Question question) {
		this.question = question;
	}

	/**
	 * @return the answer
	 */
	public Answer getAnswer() {
		return answer;
	}

	/**
	 * @param answer the answer to set
	 */
	public void setAnswer(Answer answer) {
		this.answer = answer;
	}

	public static class Question {

		private String code;
		private String cat;
		private String description;
		private int sequence;
		private String details;
		/**
		 * @return the code
		 */
		public String getCode() {
			return code;
		}
		/**
		 * @param code the code to set
		 */
		public void setCode(String code) {
			this.code = code;
		}
		/**
		 * @return the cat
		 */
		public String getCat() {
			return cat;
		}
		/**
		 * @param cat the cat to set
		 */
		public void setCat(String cat) {
			this.cat = cat;
		}
		/**
		 * @return the description
		 */
		public String getDescription() {
			return description;
		}
		/**
		 * @param description the description to set
		 */
		public void setDescription(String description) {
			this.description = description;
		}
		/**
		 * @return the sequence
		 */
		public int getSequence() {
			return sequence;
		}
		/**
		 * @param sequence the sequence to set
		 */
		public void setSequence(int sequence) {
			this.sequence = sequence;
		}
		/**
		 * @return the details
		 */
		public String getDetails() {
			return details;
		}
		/**
		 * @param details the details to set
		 */
		public void setDetails(String details) {
			this.details = details;
		}
		
	}

	public static class Answer {
		private String value;
		private String label;
		/**
		 * @return the value
		 */
		public String getValue() {
			return value;
		}
		/**
		 * @param value the value to set
		 */
		public void setValue(String value) {
			this.value = value;
		}
		/**
		 * @return the label
		 */
		public String getLabel() {
			return label;
		}
		/**
		 * @param label the label to set
		 */
		public void setLabel(String label) {
			this.label = label;
		}
	}
}
