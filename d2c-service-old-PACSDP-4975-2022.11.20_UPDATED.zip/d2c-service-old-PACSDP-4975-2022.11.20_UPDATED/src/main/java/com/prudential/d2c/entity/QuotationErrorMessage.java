package com.prudential.d2c.entity;

import org.apache.commons.lang.builder.ToStringBuilder;

public class QuotationErrorMessage {
	
	private String messageCode;
	private String messageDesc;
	private String messageType;
	private String locale;
	/**
	 * @return the messageCode
	 */
	public String getMessageCode() {
		return messageCode;
	}
	/**
	 * @param messageCode the messageCode to set
	 */
	public void setMessageCode(String messageCode) {
		this.messageCode = messageCode;
	}
	/**
	 * @return the messageDesc
	 */
	public String getMessageDesc() {
		return messageDesc;
	}
	/**
	 * @param messageDesc the messageDesc to set
	 */
	public void setMessageDesc(String messageDesc) {
		this.messageDesc = messageDesc;
	}
	/**
	 * @return the messageType
	 */
	public String getMessageType() {
		return messageType;
	}
	/**
	 * @param messageType the messageType to set
	 */
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}
	/**
	 * @return the locale
	 */
	public String getLocale() {
		return locale;
	}
	/**
	 * @param locale the locale to set
	 */
	public void setLocale(String locale) {
		this.locale = locale;
	}
	
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
	

}
