package com.prudential.d2c.entity;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.prudential.d2c.entity.dto.QuotationBenefit;

@JsonIgnoreProperties(ignoreUnknown = true)
public class QuotationPlan {
	
	private String planName;
	private String sumAssured;
	private String mainValue;
	private String discountedMainValue;
	private String mainValue2;
	private List<QuotationBenefit> benefits;
	/**
	 * @return the planName
	 */
	public String getPlanName() {
		return planName;
	}
	/**
	 * @param planName the planName to set
	 */
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	/**
	 * @return the sumAssured
	 */
	public String getSumAssured() {
		return sumAssured;
	}
	/**
	 * @param sumAssured the sumAssured to set
	 */
	public void setSumAssured(String sumAssured) {
		this.sumAssured = sumAssured;
	}
	/**
	 * @return the benefits
	 */
	public List<QuotationBenefit> getBenefits() {
		return benefits;
	}
	/**
	 * @param benefits the benefits to set
	 */
	public void setBenefits(List<QuotationBenefit> benefits) {
		this.benefits = benefits;
	}
	/**
	 * @return the mainValue
	 */
	public String getMainValue() {
		return mainValue;
	}
	/**
	 * @param mainValue the mainValue to set
	 */
	public void setMainValue(String mainValue) {
		this.mainValue = mainValue;
	}

	/*
	* @return the discountedMainValue
	 */
	public String getDiscountedMainValue() {
		return discountedMainValue;
	}

	/*
	* @param discountedMainValue the discountedMainValue to set
	 */
	public void setDiscountedMainValue(String discountedMainValue) {
		this.discountedMainValue = discountedMainValue;
	}

	/**
	 * @return the mainValue2
	 */
	public String getMainValue2() {
		return mainValue2;
	}
	/**
	 * @param mainValue2 the mainValue2 to set
	 */
	public void setMainValue2(String mainValue2) {
		this.mainValue2 = mainValue2;
	}
	
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
	
	

}
