package com.prudential.d2c.entity;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class QuotationPlanResult {
	
	private QuotationPlan quotationRA;
	private List<QuotationPlan> quotationFCPAList;
	/**
	 * @return the quotationRA
	 */
	public QuotationPlan getQuotationRA() {
		return quotationRA;
	}
	/**
	 * @param quotationRA the quotationRA to set
	 */
	public void setQuotationRA(QuotationPlan quotationRA) {
		this.quotationRA = quotationRA;
	}
	/**
	 * @return the quotationFCPAList
	 */
	public List<QuotationPlan> getQuotationFCPAList() {
		return quotationFCPAList;
	}
	/**
	 * @param quotationFCPAList the quotationFCPAList to set
	 */
	public void setQuotationFCPAList(List<QuotationPlan> quotationFCPAList) {
		this.quotationFCPAList = quotationFCPAList;
	}

	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
	


}
