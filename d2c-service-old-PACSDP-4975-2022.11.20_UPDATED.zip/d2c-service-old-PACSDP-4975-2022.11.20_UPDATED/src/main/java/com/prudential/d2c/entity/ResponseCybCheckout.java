package com.prudential.d2c.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Response object of transaction status check.
 * 
 */
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ResponseCybCheckout {
    // transaction status
    private String tranStatus;

    // decision returned by cybersource, sample ACCEPT/REJECT/ERROR
    private String decision;

    // transaction amount
    private String debitAmount;

    // payment type, token or authentication
    private String paymentType;

    // approval code
    private String approvalCode;

    // response code from issuing bank
    private String bankRespCode;

    // BIN number of credit card, like 400000XXXXXX0002
    private String ccNumber;

    // credit card expired date, 02-2022
    private String expiryDate;

    // merchant id
    private String mercId;
    
    // reason code
    private String reasonCode;
    
    private String isPayerAuthSetup;
    
    //challenge or step up required (friction flow), sample: true/false
    private String isChallengeReq;

    private String paResStatus;
    
    private String authTransId;
    
    private String isPayerAuthValidateReq;
}
