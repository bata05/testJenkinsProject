package com.prudential.d2c.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * OBJECT of response for signature generation.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ResponseCybSignature {

    // transaction uuid
    private String transactionUuid;

    // signature generated time
    private String signedDateTime;

    private String signature;

    private String accessKey;
    private String profileId;

    // check out page URL, it's DP's URL
    private String cybCheckoutUrl;

    public ResponseCybSignature(String signature, String transactionUuid, String signedDateTime, String accessKey,
            String profileId, String cybCheckoutUrl) {
        super();
        this.signature = signature;
        this.transactionUuid = transactionUuid;
        this.signedDateTime = signedDateTime;
        this.accessKey = accessKey;
        this.profileId = profileId;
        this.cybCheckoutUrl = cybCheckoutUrl;
    }

    /**
     * @return the transactionUuid
     */
    public String getTransactionUuid() {
        return transactionUuid;
    }

    /**
     * @param transactionUuid
     *            the transactionUuid to set
     */
    public void setTransactionUuid(String transactionUuid) {
        this.transactionUuid = transactionUuid;
    }

    /**
     * @return the signedDateTime
     */
    public String getSignedDateTime() {
        return signedDateTime;
    }

    /**
     * @param signedDateTime
     *            the signedDateTime to set
     */
    public void setSignedDateTime(String signedDateTime) {
        this.signedDateTime = signedDateTime;
    }

    /**
     * @return the signature
     */
    public String getSignature() {
        return signature;
    }

    /**
     * @param signature
     *            the signature to set
     */
    public void setSignature(String signature) {
        this.signature = signature;
    }

    /**
     * @return the accessKey
     */
    public String getAccessKey() {
        return accessKey;
    }

    /**
     * @param accessKey
     *            the accessKey to set
     */
    public void setAccessKey(String accessKey) {
        this.accessKey = accessKey;
    }

    /**
     * @return the profileId
     */
    public String getProfileId() {
        return profileId;
    }

    /**
     * @param profileId
     *            the profileId to set
     */
    public void setProfileId(String profileId) {
        this.profileId = profileId;
    }

    /**
     * @return the cybCheckoutUrl
     */
    public String getCybCheckoutUrl() {
        return cybCheckoutUrl;
    }

    /**
     * @param cybCheckoutUrl
     *            the cybCheckoutUrl to set
     */
    public void setCybCheckoutUrl(String cybCheckoutUrl) {
        this.cybCheckoutUrl = cybCheckoutUrl;
    }

    /* (non-Javadoc)
    * @see java.lang.Object#toString()
    */
    @Override
    public String toString() {
        return "ResponseCybSignature [transactionUuid=" + transactionUuid + ", signedDateTime=" + signedDateTime
                + ", signature=" + signature + ", accessKey=" + accessKey + ", profileId=" + profileId
                + ", cybCheckoutUrl=" + cybCheckoutUrl + "]";
    }
}
