package com.prudential.d2c.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SuccessStatus {
	private boolean success = true;
	private String message = "";
	private String excuteStatus;
	private String errorCode;

	public boolean getSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	/**
	 * @return the excuteStatus
	 */
	public String getExcuteStatus() {
		return excuteStatus;
	}
	/**
	 * @param excuteStatus the excuteStatus to set
	 */
	public void setExcuteStatus(String excuteStatus) {
		this.excuteStatus = excuteStatus;
	}


	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
}
