package com.prudential.d2c.entity;

public class TermOption {
	private String optCode;
	private String optDescp;
	private String optValue;
	
	public String getOptCode() {
		return optCode;
	}
	public void setOptCode(String optCode) {
		this.optCode = optCode;
	}
	public String getOptDescp() {
		return optDescp;
	}
	public void setOptDescp(String optDescp) {
		this.optDescp = optDescp;
	}
	public String getOptValue() {
		return optValue;
	}
	public void setOptValue(String optValue) {
		this.optValue = optValue;
	}
	
	
}
