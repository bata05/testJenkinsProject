package com.prudential.d2c.entity;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class TransactionLogin{
	private String username;
	private String password;
    private String randomKey;
    
    private String clientNumber;
    private String transactionId;
    private String otp;
    private String timeForCheckOTP;
    private String custId;
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}

	public String getUsername() {
		return username;
	}



	public String getPassword() {
		return password;
	}



	public String getRandomKey() {
		return randomKey;
	}



	public void setUsername(String username) {
		this.username = username;
	}



	public void setPassword(String password) {
		this.password = password;
	}



	public void setRandomKey(String randomKey) {
		this.randomKey = randomKey;
	}



	public String getClientNumber() {
		return clientNumber;
	}



	public String getTransactionId() {
		return transactionId;
	}



	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}



	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}



	public String getOtp() {
		return otp;
	}



	public void setOtp(String otp) {
		this.otp = otp;
	}



	public String getTimeForCheckOTP() {
		return timeForCheckOTP;
	}



	public void setTimeForCheckOTP(String timeForCheckOTP) {
		this.timeForCheckOTP = timeForCheckOTP;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}
}
