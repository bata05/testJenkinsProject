package com.prudential.d2c.entity;

public class ValidatedClient {
	private String transactionId;
	private String clientName;
	private String mobile;
	private String jwt;
	private boolean allowNewCustomer;
	
	private boolean mobileValid;
	
	public boolean getMobileValid() {
		return mobileValid;
	}

	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getJwt() {
		return jwt;
	}

	public void setJwt(String jwt) {
		this.jwt = jwt;
	}

	public void setMobileValid(boolean mobileValid) {
		this.mobileValid = mobileValid;
	}

	public boolean isAllowNewCustomer() {
		return allowNewCustomer;
	}

	public void setAllowNewCustomer(boolean allowNewCustomer) {
		this.allowNewCustomer = allowNewCustomer;
	}
	
	
}
