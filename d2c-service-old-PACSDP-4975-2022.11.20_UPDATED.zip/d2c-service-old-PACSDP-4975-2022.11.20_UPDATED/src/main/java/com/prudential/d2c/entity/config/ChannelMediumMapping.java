package com.prudential.d2c.entity.config;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "CHANNEL_MEDIUM_MAPPING")
@JsonIgnoreProperties(ignoreUnknown = true)
@EntityListeners(AuditingEntityListener.class)
public class ChannelMediumMapping {
	
	@Id
	@Column(name = "CHANNEL_MEDIUM_MAPPING_ID", nullable = false)
	private int channelMediumId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CHANNEL_ID", insertable = false, updatable = false)
	private Channels channel;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "COMM_MEDIUM_ID", insertable = false, updatable = false)
	private CommunicationMedium medium;

	@Column(name = "DELETE_IND", nullable = false)
	private Integer deleteInd;

	@Column(name = "CREATED_DATE", nullable = false)
	@CreatedDate
	private String createdDate;

	@Column(name = "CREATED_BY", nullable = false)
	private String createdBy;

	@Column(name = "MODIFIED_DATE", nullable = false)
	@LastModifiedDate
	private Date modifiedDate;

	@Column(name = "MODIFIED_BY", nullable = false)
	private String modifiedBy;

	public int getChannelMediumId() {
		return channelMediumId;
	}

	public void setChannelMediumId(int channelMediumId) {
		this.channelMediumId = channelMediumId;
	}

	public Channels getChannel() {
		return channel;
	}

	public void setChannel(Channels channel) {
		this.channel = channel;
	}

	public CommunicationMedium getMedium() {
		return medium;
	}

	public void setMedium(CommunicationMedium medium) {
		this.medium = medium;
	}

	public Integer getDeleteInd() {
		return deleteInd;
	}

	public void setDeleteInd(Integer deleteInd) {
		this.deleteInd = deleteInd;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	@Override
	public String toString() {
		return "ChannelMediumMapping [channelMediumId=" + channelMediumId + ", channel=" + channel + ", medium="
				+ medium + ", deleteInd=" + deleteInd + ", createdDate=" + createdDate + ", createdBy=" + createdBy
				+ ", modifiedDate=" + modifiedDate + ", modifiedBy=" + modifiedBy + "]";
	}
}
