package com.prudential.d2c.entity.config;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "CHANNEL_TYPE")
@JsonIgnoreProperties(ignoreUnknown = true)
@EntityListeners(AuditingEntityListener.class)
public class ChannelType {

	@Id
	@Column(name = "CHANNEL_TYPE_ID", nullable = false)
	private Integer channelTypeId;

	@Column(name = "CHANNEL_TYPE_NAME", nullable = false)
	private String channelTypeName;

	@Column(name = "CHANNEL_TYPE_CODE", nullable = false)
	private String channelTypeCode;

	@Column(name = "CREATED_DATE", nullable = false)
	@CreatedDate
	private String createdDate;

	@Column(name = "CREATED_BY", nullable = false)
	private String createdBy;

	@Column(name = "MODIFIED_DATE", nullable = false)
	@LastModifiedDate
	private Date modifiedDate;

	@Column(name = "MODIFIED_BY", nullable = false)
	private String modifiedBy;

	public Integer getSourceId() {
		return channelTypeId;
	}

	public void setSourceId(Integer sourceId) {
		this.channelTypeId = sourceId;
	}

	public String getSourceName() {
		return channelTypeName;
	}

	public void setSourceName(String sourceName) {
		this.channelTypeName = sourceName;
	}

	public String getSourceCode() {
		return channelTypeCode;
	}

	public void setSourceCode(String sourceCode) {
		this.channelTypeCode = sourceCode;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
}
