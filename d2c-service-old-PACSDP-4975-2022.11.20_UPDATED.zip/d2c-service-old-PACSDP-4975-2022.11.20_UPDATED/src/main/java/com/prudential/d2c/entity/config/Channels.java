package com.prudential.d2c.entity.config;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;
import java.util.Set;

@Entity
@Table(name = "CHANNELS")
@JsonIgnoreProperties(ignoreUnknown = true)
@EntityListeners(AuditingEntityListener.class)
public class Channels {

	@Id
	@Column(name = "CHANNEL_ID", nullable = false)
	private Integer channelId;

	@Column(name = "CHANNEL_NAME", nullable = false)
	private String channelName;

	@Column(name = "CHANNEL_CODE", nullable = false)
	private String channelCode;

	@Column(name = "CREATED_DATE", nullable = false)
	@CreatedDate
	private String createdDate;

	@Column(name = "CREATED_BY", nullable = false)
	private String createdBy;

	@Column(name = "MODIFIED_DATE", nullable = false)
	@LastModifiedDate
	private Date modifiedDate;

	@Column(name = "MODIFIED_BY", nullable = false)
	private String modifiedBy;

	@OneToMany(mappedBy = "channels", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Set<ChannelProductMapping> channelProductMappingSet;
	
	@OneToMany(mappedBy = "channel", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Set<ChannelMediumMapping> channelMediumMappingSet;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CHANNEL_TYPE_ID", insertable = false, updatable = false)
	private ChannelType channelType;

	public Set<ChannelProductMapping> getChannelProductMappingSet() {
		return channelProductMappingSet;
	}

	public void setChannelProductMappingSet(Set<ChannelProductMapping> channelProductMappingSet) {
		this.channelProductMappingSet = channelProductMappingSet;
	}

	public Integer getChannelId() {
		return channelId;
	}

	public void setChannelId(Integer channelId) {
		this.channelId = channelId;
	}

	public String getChannelName() {
		return channelName;
	}

	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Set<ChannelMediumMapping> getChannelMediumMappingSet() {
		return channelMediumMappingSet;
	}

	public void setChannelMediumMappingSet(Set<ChannelMediumMapping> channelMediumMappingSet) {
		this.channelMediumMappingSet = channelMediumMappingSet;
	}

	public ChannelType getChannelType() {
		return channelType;
	}

	public void setChannelType(ChannelType channelType) {
		this.channelType = channelType;
	}
}
