package com.prudential.d2c.entity.config;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="COMMUNICATION_MEDIUM")
@JsonIgnoreProperties(ignoreUnknown = true)
@EntityListeners(AuditingEntityListener.class)
public class CommunicationMedium {
	
	@Id
	@Column(name = "COMM_MEDIUM_ID", nullable = false)
	private Integer mediumId;

	@Column(name = "COMM_MEDIUM_NAME", nullable = false)
	private String mediumName;

	@Column(name = "COMM_MEDIUM_CODE", nullable = false)
	private String mediumCode;

	@Column(name = "CREATED_DATE", nullable = false)
	@CreatedDate
	private String createdDate;

	@Column(name = "CREATED_BY", nullable = false)
	private String createdBy;

	@Column(name = "MODIFIED_DATE", nullable = false)
	@LastModifiedDate
	private Date modifiedDate;

	@Column(name = "MODIFIED_BY", nullable = false)
	private String modifiedBy;
	
	@OneToMany(mappedBy = "medium", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Set<ChannelMediumMapping> channelMediumMappingSet;

	public Integer getMediumId() {
		return mediumId;
	}

	public void setMediumId(Integer mediumId) {
		this.mediumId = mediumId;
	}

	public String getMediumName() {
		return mediumName;
	}

	public void setMediumName(String mediumName) {
		this.mediumName = mediumName;
	}

	public String getMediumCode() {
		return mediumCode;
	}

	public void setMediumCode(String mediumCode) {
		this.mediumCode = mediumCode;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Set<ChannelMediumMapping> getChannelMediumMappingSet() {
		return channelMediumMappingSet;
	}

	public void setChannelMediumMappingSet(Set<ChannelMediumMapping> channelMediumMappingSet) {
		this.channelMediumMappingSet = channelMediumMappingSet;
	}
}
