package com.prudential.d2c.entity.config;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "MYINFO_MAPPING")
@JsonIgnoreProperties(ignoreUnknown = true)
@EntityListeners(AuditingEntityListener.class)
public class MyInfoMapping {

	@Id
	@Column(name = "CODE", nullable = false)
	private String code;

	@Column(name = "LA_DESC", nullable = false)
	private String desc;

	@Column(name = "MYINFO_CODE", nullable = false)
	private String myInfoCode;

	@Column(name = "MYINFO_DESC", nullable = false)
	private String MyInfoDesc;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getMyInfoCode() {
		return myInfoCode;
	}

	public void setMyInfoCode(String myInfoCode) {
		this.myInfoCode = myInfoCode;
	}

	public String getMyInfoDesc() {
		return MyInfoDesc;
	}

	public void setMyInfoDesc(String myInfoDesc) {
		MyInfoDesc = myInfoDesc;
	}

}
