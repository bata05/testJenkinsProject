package com.prudential.d2c.entity.config;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "PASS_TYPE_MAPPING")
@JsonIgnoreProperties(ignoreUnknown = true)
@EntityListeners(AuditingEntityListener.class)
public class PassTypeMapping {

	@Id
	@Column(name = "CODE", nullable = false)
	private String code;

	@Column(name = "DESCRIPTION", nullable = false)
	private String description;
	
	@Column(name = "LA_DESC", nullable = false)
	private String la_desc;

	@Column(name = "DP_CODE_PASS_TYPE", nullable = false)
	private int dpCode;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getLaDesc() {
		return la_desc;
	}

	public void setLaDesc(String la_desc) {
		this.la_desc = la_desc;
	}

	public int getDpCode() {
		return dpCode;
	}

	public void setDpCode(int dpCode) {
		this.dpCode = dpCode;
	}
}
