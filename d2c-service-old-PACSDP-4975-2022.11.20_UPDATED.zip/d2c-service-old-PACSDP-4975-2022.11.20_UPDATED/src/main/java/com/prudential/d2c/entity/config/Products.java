package com.prudential.d2c.entity.config;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="PRODUCTS")
@JsonIgnoreProperties(ignoreUnknown = true)
@EntityListeners(AuditingEntityListener.class)
public class Products {

   @Id
   @Column(name ="PRODUCT_ID", nullable = false)
   private Integer productId;

   @Column(name ="PRODUCT_NAME", nullable = false)
   private String productName;

    @Column(name ="PRODUCT_CODE", nullable = false)
    private String productCode;

    @Column(name ="CREATED_DATE", nullable = false)
    @CreatedDate
    private String createdDate;

    @Column(name ="CREATED_BY", nullable = false)
    private String createdBy;

    @Column(name="MODIFIED_DATE", nullable = false)
    @LastModifiedDate
    private Date modifiedDate;

    @Column(name="MODIFIED_BY", nullable = false)
    private String modifiedBy;

    @OneToMany(mappedBy = "products", cascade = CascadeType.ALL,fetch = FetchType.LAZY)
    private Set<ChannelProductMapping> channelProductMappingSet;

    public Set<ChannelProductMapping> getChannelProductMappingSet() {
        return channelProductMappingSet;
    }

    public void setChannelProductMappingSet(Set<ChannelProductMapping> channelProductMappingSet) {
        this.channelProductMappingSet = channelProductMappingSet;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }
}
