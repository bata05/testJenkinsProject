package com.prudential.d2c.entity.config;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

@Entity
@Table(name = "PRODUCTS_CONFIG", uniqueConstraints = @UniqueConstraint(columnNames = {"SQS_PRODUCT_CODE", "D2C_PRODUCT_ID"}))
@JsonIgnoreProperties(ignoreUnknown = true)
@EntityListeners(AuditingEntityListener.class)
public class ProductsConfig {

    @Id
    @Column(name = "PROD_CONFIG_ID", nullable = false)
    private Integer id;

    @Column(name = "SQS_PRODUCT_CODE", nullable = false)
    private String sqsProductCode;

    @Column(name = "SQS_DOC_ID")
    private String sqsDocId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "D2C_PRODUCT_ID", referencedColumnName = "PRODUCT_ID", nullable = false)
    private Products d2cProduct;

    @Column(name = "MIN_PREMIUM")
    private Double minPremium;

    @Column(name = "MAX_PREMIUM")
    private Double maxPremium;

    @Column(name = "MIN_SUM_ASSURED")
    private Double minSumAssured;

    @Column(name = "MAX_SUM_ASSURED")
    private Double maxSumAssured;

    @Column(name = "MIN_AGE")
    private Integer minAge;

    @Column(name = "MAX_AGE")
    private Integer maxAge;

    @Column(name ="IS_ENABLED_NEW")
    private boolean isEnbledForNew;

    @Column(name ="IS_ENABLED_EXISTING")
    private boolean isEnabledForExisting;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSqsProductCode() {
        return sqsProductCode;
    }

    public void setSqsProductCode(String sqsProductCode) {
        this.sqsProductCode = sqsProductCode;
    }

    public String getSqsDocId() {
        return sqsDocId;
    }

    public void setSqsDocId(String sqsDocId) {
        this.sqsDocId = sqsDocId;
    }

    public Products getD2cProduct() {
        return d2cProduct;
    }

    public void setD2cProduct(Products d2cProduct) {
        this.d2cProduct = d2cProduct;
    }

    public Double getMinPremium() {
        return minPremium;
    }

    public void setMinPremium(Double minPremium) {
        this.minPremium = minPremium;
    }

    public Double getMaxPremium() {
        return maxPremium;
    }

    public void setMaxPremium(Double maxPremium) {
        this.maxPremium = maxPremium;
    }

    public Double getMinSumAssured() {
        return minSumAssured;
    }

    public void setMinSumAssured(Double minSumAssured) {
        this.minSumAssured = minSumAssured;
    }

    public Double getMaxSumAssured() {
        return maxSumAssured;
    }

    public void setMaxSumAssured(Double maxSumAssured) {
        this.maxSumAssured = maxSumAssured;
    }

    public Integer getMinAge() {
        return minAge;
    }

    public void setMinAge(Integer minAge) {
        this.minAge = minAge;
    }

    public Integer getMaxAge() {
        return maxAge;
    }

    public void setMaxAge(Integer maxAge) {
        this.maxAge = maxAge;
    }

    public boolean isEnbledForNew() {
        return isEnbledForNew;
    }

    public void setEnbledForNew(boolean enbledForNew) {
        isEnbledForNew = enbledForNew;
    }

    public boolean isEnabledForExisting() {
        return isEnabledForExisting;
    }

    public void setEnabledForExisting(boolean enabledForExisting) {
        isEnabledForExisting = enabledForExisting;
    }

    @Override
    public String toString() {
        return "PRODUCTS_CONFIG {" +
                "sqsProductCode= '" + sqsProductCode + '\'' +
            //    ", d2cProduct= '" + d2cProduct.getProductCode() + '\'' +
                ", minPremium= '" + minPremium + '\'' +
                ", maxPremium= '" + maxPremium + '\'' +
                ", minSumAssured= '" + minSumAssured + '\'' +
                ", maxSumAssured= '" + maxSumAssured + '\'' +
                ", minAge=' " + minAge + '\'' +
                ", maxAge=' " + maxAge + '\'' +
                ", isEnbledForNew=' " + isEnbledForNew + '\'' +
                ", isEnabledForExisting=' " + isEnabledForExisting + '\'' +
                '}';
    }
}
