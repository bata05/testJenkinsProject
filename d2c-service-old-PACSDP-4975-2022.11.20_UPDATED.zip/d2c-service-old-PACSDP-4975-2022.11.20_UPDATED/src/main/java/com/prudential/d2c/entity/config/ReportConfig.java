package com.prudential.d2c.entity.config;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "REPORT_CHANNEL_CONFIG")
@JsonIgnoreProperties(ignoreUnknown = true)
@EntityListeners(AuditingEntityListener.class)
public class ReportConfig {

	@Id
	@Column(name = "CHANNEL_CODE", nullable = false)
	private String channelCode;

	@Column(name = "CHANNEL_DESCRIPTION", nullable = false)
	private String channelDescription;

	@Column(name = "CREATED_DATE", nullable = false)
	@CreatedDate
	private String createdDate;

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getChannelDescription() {
		return channelDescription;
	}

	public void setChannelDescription(String channelDescription) {
		this.channelDescription = channelDescription;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	@Override
	public String toString() {
		return "ReportConfig [channelCode=" + channelCode + ", channelDescription=" + channelDescription
				+ ", createdDate=" + createdDate + "]";
	}

}
