package com.prudential.d2c.entity.dto;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * DTO that mapping to the table APPLICATION_CYB_DATA, all are transaction data.
 * 
 */
@Entity
@Table(name = "APPLICATION_CYB_DATA")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@EntityListeners(AuditingEntityListener.class)
public class ApplicationCybData {
    // e-reference number
    @Id
    @Column(name = "eref_no", nullable = false)
    private String erefNo;

    // transaction status
    @Column(name = "trans_status")
    private String transStatus;

    // merchant id
    @Column(name = "merchant_id")
    private String merchantId;

    // credit card onus flag, onUs: UOB, offUs: non-UOB
    @Column(name = "on_us")
    private String onUs;

    // decision of cybersource response : ACCEPT|REJECT|ERROR|CANCEL
    @Column(name = "decision")
    private String decision;

    // Decision reason code: 100/102/475
    @Column(name = "reason_code")
    private String reasonCode;

    // signature: JGWLzMPs3x61syRvWs3GRjT9PC5UhWDO8gKuchZFsXo=
    @Column(name = "signature")
    private String signature;

    // BIN number of credit number: 400000XXXXXX0002
    @Column(name = "card_number")
    private String cardNumber;

    // credit card expired date: 02-2022
    @Column(name = "card_expiry_date")
    private String cardExpiryDate;

    // card type: VISA:001 MASTERCARD:002
    @Column(name = "card_type")
    private String cardType;

    @Column(name = "amount")
    private BigDecimal amount;

    // currency: SGD|USD
    @Column(name = "currency")
    private String currency;

    @Column(name = "locale")
    private String locale;

    // payment method: card
    @Column(name = "payment_method")
    private String paymentMethod;

    // payment token generated at cybersource, need to remove it from DB once transaction finished or failed.
    @Column(name = "payment_token")
    private String paymentToken;

    // transaction reference number
    @Column(name = "reference_number")
    private String referenceNumber;

    // transaction type: create_payment_token
    @Column(name = "transaction_type")
    private String transactionType;

    @Column(name = "transaction_uuid")
    private String transactionUuid;

    // transaction id of 3DS enrollment check response
    @Column(name = "payerauthenrollreply_xid")
    private String payerAuthEnrollReplyXid;

    @Column(name = "bank_approval_code")
    private String bankApprovalCode;

    @Column(name = "bank_response_code")
    private String bankResponseCode;

    // Issuing bank's authentication URL, return once the credit card is enrolled in cybersource.
    @Column(name = "acs_url")
    @Lob
    private String acsUrl;

    // payment authentication request. Generated at the step of 3DS enrollment check
    @Column(name = "pareq")
    @Lob
    private String paReq;

    @Column(name = "create_date")
    @CreatedDate
    private Date createData;

    @Column(name = "update_date")
    @LastModifiedDate
    private Date updateDate;

    @Column(name = "custom_id")
    private String customId;
    
    @Column(name = "is_payer_auth_setup")
    private String isPayerAuthSetup;
    
    @Column(name = "ddc_url")
    @Lob
    private String ddcUrl;
    
    @Column(name = "pa_setup_reply_access_token")
    @Lob
    private String authSetupReplyAccessToken;
    
    @Column(name = "reference_id")
    private String referenceID;
    
    @Column(name = "step_up_url")
    @Lob
    private String stepUpUrl;

    @Column(name = "authentication_TransactionID")
    private String authenticationTransactionID;
    
    @Column(name = "commerce_indicator")
    private String commerceIndicator;
    
    @Column(name = "eci_raw")
    private String eciRaw;
    
    @Column(name = "eci")
    private String eci;
  
    @Column(name = "billto_firstname")
    private String billToFirstname;
    
    @Column(name = "billto_lastname")
    private String billToLastname;
    
    @Column(name = "billto_email")
    private String billToEmail;
    
    @Column(name = "billto_street1")
    private String billToStreet1;
    
    @Column(name = "billto_city")
    private String billToCity;
    
    @Column(name = "billto_country")
    private String billToCountry;

    @Column(name = "pa_enroll_reply_access_token")
    @Lob
    private String authEnrollReplyAccessToken;
    
    @Column(name = "is_challenge_req")
    private String authEnrollReplyChallengeRequired;
    
    @Column(name = "specification_version")
    private String authEnrollReplySpecificationVersion;
   
    @Column(name = "ds_transaction_id")
    private String authEnrollReplyDirectoryServerTransactionID;
    
    @Column(name = "ucaf_collection_indicator")
    private String authEnrollReplyUcafCollectionIndicator;
    
    @Column(name = "veres_enrolled")
    private String veresEnrolled;
    
    @Column(name = "three_ds_server_txnid")
    private String threeDSServerTransactionID;
    
    @Column(name = "authenrollreply_acs_txnid")
    private String authEnrollReplyAcsTransactionID;
    
    @Column(name = "authenrollreply_authresult")
    private String authEnrollReplyAuthenticationResult;
    
    @Column(name = "authenrollreply_cavv")
    private String authEnrollReplyCavv;
    
    @Column(name = "authenrollreply_paresStatus")
    private String authEnrollReplyParesStatus;
    
    @Column(name = "authenrollreply_cardbin")
    private String authEnrollReplyCardBin;
    
    @Column(name = "authenrollreply_cardtypename")
    private String authEnrollReplyCardTypeName;
    
    @Column(name = "pa_validate_reply_cavv")
    private String authValidateReplyCavv;
    
    @Column(name = "ucaf_authentication_data")
    private String authValidateReplyUcafAuthenticationData;
    
    @Column(name = "pa_res_status")
    private String paResStatus;
    
    @Column(name = "is_payer_auth_validate_req")
    private String isPayerAuthValidateReq;
    
}
