package com.prudential.d2c.entity.dto;

import java.sql.Blob;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="APPLICATION_DATA")
@JsonIgnoreProperties(ignoreUnknown = true)
@EntityListeners(AuditingEntityListener.class)
public class ApplicationData {

	  @Id
	  @Column(name ="eref_no", nullable = false)
	  private String erefNo;
	  @Column(name ="proposal_data", nullable = true)
	  @Lob
	  private Blob proposal;
	  @Column(name ="pay_request", nullable = true)
	  private String payRequest;
	  @Column(name ="pay_response", nullable = true)
	  private String payResponse;
	  @Column(name ="tm_status", nullable = true)
	  private String tmStatus;
	  @Column(name ="tm_mcode", nullable = true)
	  private String tmMcode;
	  @Column(name ="tm_refno", nullable = true)
	  private String tmRefno;
	  @Column(name ="tm_ccnum", nullable = true)
	  private String tmCCNum;
	  @Column(name ="tm_debitamt", nullable = true)
	  private String tmDebitAmt;
	  @Column(name ="tm_paymenttype", nullable = true)
	  private String tmPaymentType;
	  @Column(name ="tm_approvalcode", nullable = true)
	  private String tmApprovalCode;
	  @Column(name ="tm_bankrespcode", nullable = true)
	  private String tmBankRespCode;
	  @Column(name ="tm_expirydate", nullable = true)
	  private String tmExpiryDate;
	  @Column(name ="esub_status", nullable = true)
	  private String esubStatus;
	  
	  @Column(name ="create_date")
	  @CreatedDate
	  private Date createDate;
	  
	  @Column(name ="update_date")
	  @LastModifiedDate
	  private Date updateDate;// happen when 1.save payrequest / 2.save payresponse / 3.save esub
	  
	  @Column(name ="custom_id", nullable = true)
	  private String customId;
	  

	/**
	 * @return the erefNo
	 */
	public String getErefNo() {
		return erefNo;
	}
	/**
	 * @param erefNo the erefNo to set
	 */
	public void setErefNo(String erefNo) {
		this.erefNo = erefNo;
	}
	/**
	 * @return the proposal
	 */
	public Blob getProposal() {
		return proposal;
	}
	/**
	 * @param proposal the proposal to set
	 */
	public void setProposal(Blob proposal) {
		this.proposal = proposal;
	}
	/**
	 * @return the payRequest
	 */
	public String getPayRequest() {
		return payRequest;
	}
	/**
	 * @param payRequest the payRequest to set
	 */
	public void setPayRequest(String payRequest) {
		this.payRequest = payRequest;
	}
	/**
	 * @return the payResponse
	 */
	public String getPayResponse() {
		return payResponse;
	}
	/**
	 * @param payResponse the payResponse to set
	 */
	public void setPayResponse(String payResponse) {
		this.payResponse = payResponse;
	}
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
	public String getTmStatus() {
		return tmStatus;
	}
	public void setTmStatus(String tmStatus) {
		this.tmStatus = tmStatus;
	}
	public String getTmMcode() {
		return tmMcode;
	}
	public void setTmMcode(String tmMcode) {
		this.tmMcode = tmMcode;
	}
	public String getTmRefno() {
		return tmRefno;
	}
	public void setTmRefno(String tmRefno) {
		this.tmRefno = tmRefno;
	}
	public String getTmCCNum() {
		return tmCCNum;
	}
	public void setTmCCNum(String tmCCNum) {
		this.tmCCNum = tmCCNum;
	}
	/**
	 * @return the tmDebitAmt
	 */
	public String getTmDebitAmt() {
		return tmDebitAmt;
	}
	/**
	 * @param tmDebitAmt the tmDebitAmt to set
	 */
	public void setTmDebitAmt(String tmDebitAmt) {
		this.tmDebitAmt = tmDebitAmt;
	}
	/**
	 * @return the tmPaymentType
	 */
	public String getTmPaymentType() {
		return tmPaymentType;
	}
	/**
	 * @param tmPaymentType the tmPaymentType to set
	 */
	public void setTmPaymentType(String tmPaymentType) {
		this.tmPaymentType = tmPaymentType;
	}
	/**
	 * @return the tmApprovalCode
	 */
	public String getTmApprovalCode() {
		return tmApprovalCode;
	}
	/**
	 * @param tmApprovalCode the tmApprovalCode to set
	 */
	public void setTmApprovalCode(String tmApprovalCode) {
		this.tmApprovalCode = tmApprovalCode;
	}
	/**
	 * @return the tmBankRespCode
	 */
	public String getTmBankRespCode() {
		return tmBankRespCode;
	}
	/**
	 * @param tmBankRespCode the tmBankRespCode to set
	 */
	public void setTmBankRespCode(String tmBankRespCode) {
		this.tmBankRespCode = tmBankRespCode;
	}
	/**
	 * @return the esubStatus
	 */
	public String getEsubStatus() {
		return esubStatus;
	}
	/**
	 * @param esubStatus the esubStatus to set
	 */
	public void setEsubStatus(String esubStatus) {
		this.esubStatus = esubStatus;
	}
	/**
	 * @return the tmExpiryDate
	 */
	public String getTmExpiryDate() {
		return tmExpiryDate;
	}
	/**
	 * @param tmExpiryDate the tmExpiryDate to set
	 */
	public void setTmExpiryDate(String tmExpiryDate) {
		this.tmExpiryDate = tmExpiryDate;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	public String getCustomId() {
		return customId;
	}
	public void setCustomId(String customId) {
		this.customId = customId;
	}

}
