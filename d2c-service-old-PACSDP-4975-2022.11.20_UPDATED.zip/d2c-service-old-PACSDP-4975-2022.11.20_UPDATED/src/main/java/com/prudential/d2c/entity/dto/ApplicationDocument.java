package com.prudential.d2c.entity.dto;

import java.sql.Blob;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.prudential.d2c.utils.BlobJsonDeserializer;
import com.prudential.d2c.utils.BlobJsonSerializer;


@Entity
@Table(name="CUSTOMER_APP_DOCUMENT")
@JsonIgnoreProperties(ignoreUnknown = true)
@EntityListeners(AuditingEntityListener.class)
public class ApplicationDocument {

	@Id
	@Column(name = "EREF_NO", nullable = false)
	private String erefNo;

	@Column(name = "CUSTOM_ID", nullable = false)
	private String customId;

	@Column(name = "PROPOSAL_DOCUMENT")
	@Lob
	@Basic(fetch = FetchType.LAZY)
	@JsonSerialize(using = BlobJsonSerializer.class)
	@JsonDeserialize(using = BlobJsonDeserializer.class)
	private Blob proposalDocument;

	@Column(name = "PI_DOCUMENT")
	@Lob
	@Basic(fetch = FetchType.LAZY)
	@JsonSerialize(using = BlobJsonSerializer.class)
	@JsonDeserialize(using = BlobJsonDeserializer.class)
	private Blob piDocument;

	@Column(name = "MYINFO_DOCUMENT")
	@Lob
	@Basic(fetch = FetchType.LAZY)
	@JsonSerialize(using = BlobJsonSerializer.class)
	@JsonDeserialize(using = BlobJsonDeserializer.class)
	private Blob myInfoDocument;
	
	@Column(name = "CREATED_DATE", nullable = false)
	@CreatedDate
	private Date createdDate;

	public String getErefNo() {
		return erefNo;
	}

	public void setErefNo(String erefNo) {
		this.erefNo = erefNo;
	}

	public String getCustomId() {
		return customId;
	}

	public void setCustomId(String customId) {
		this.customId = customId;
	}

	public Blob getProposalDocument() {
		return proposalDocument;
	}

	public void setProposalDocument(Blob proposalDocument) {
		this.proposalDocument = proposalDocument;
	}

	public Blob getPiDocument() {
		return piDocument;
	}

	public void setPiDocument(Blob piDocument) {
		this.piDocument = piDocument;
	}

	public Blob getMyInfoDocument() {
		return myInfoDocument;
	}

	public void setMyInfoDocument(Blob myInfoDocument) {
		this.myInfoDocument = myInfoDocument;
	}
	
	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	@Override
	public String toString() {
		return "ApplicationDocument [erefNo=" + erefNo + ", customId=" + customId + ", proposalDocument="
				+ proposalDocument + ", piDocument=" + piDocument + "MyInfoDocument=" + myInfoDocument
				+ ", createdDate=" + createdDate + "]";
	}


}
