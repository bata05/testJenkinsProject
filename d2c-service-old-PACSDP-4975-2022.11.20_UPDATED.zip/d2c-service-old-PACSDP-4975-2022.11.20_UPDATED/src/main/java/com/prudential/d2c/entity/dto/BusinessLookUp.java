package com.prudential.d2c.entity.dto;

import lombok.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name = "LA_BIZ_SRC_LOOKUP")
@Data @AllArgsConstructor @NoArgsConstructor
@Builder
public class BusinessLookUp {

  @Column(name = "ID_NO")
  private @Id Integer id;
  @Column(name = "CHANNEL_ID", nullable = false)
  private @NonNull Integer channelId;
  @Column(name = "ACTION", nullable = false)
  private @NonNull String action;
  @Column(name = "BIZ_SOURCE", nullable = false)
  private @NonNull String businessSource;
  @Column(name = "BIZ_SUB_SOURCE", nullable = false)
  private @NonNull String businessSubSource;
  @Column(name = "CREATED_DATE", nullable = false)
  private Date createDate;
  @Column(name = "CREATED_BY", nullable = false)
  private @NonNull String createBy;
  @Column(name = "MODIFIED_DATE", nullable = false)
  private Date modifiedDate;
  @Column(name = "MODIFIED_BY", nullable = false)
  private @NonNull String modifiedBy;
}

