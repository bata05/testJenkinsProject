package com.prudential.d2c.entity.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Version;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@EqualsAndHashCode
@ToString
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@NoArgsConstructor(access = AccessLevel.PACKAGE)
@Entity
@Table(name = "CAMPAIGN_LOOKUP")
public class CampaignLookup {
	
    @Version
    private Integer version;

    @Id
    @Column(name = "ID")
    private String id;

    @Column(name = "CHANNEL", nullable = false)
    private String channel;

    @Column(name = "SUB_CHANNEL", nullable = true)
    private String subChannel;

    @Column(name = "PROD_CODE", nullable = false)
    private String prodCode;

    @Column(name = "CAMPAIGN_ID", nullable = false)
    private String campaignId;

    @Column(name = "CAMPAIGN_NAME", nullable = false)
    private String campaignName;
    
    @Column(name = "CAMPAIGN_GUID", nullable = false)
    private String campaignGuid;

    @Column(name = "START_DATE", nullable = false)
    private Date startDate;

    @Column(name = "END_DATE", nullable = false)
    private Date endDate;
    
    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CREATED_TIME")
    private Date createdTime;

    @Column(name = "UPDATED_BY")
    private String updatedBy;

    @Column(name = "UPDATED_TIME")
    private Date updatedTime;

}
