package com.prudential.d2c.entity.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.prudential.d2c.utils.BlobJsonDeserializer;
import com.prudential.d2c.utils.BlobJsonSerializer;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.sql.Blob;
import java.util.Date;


@Entity
@Table(name = "CHANNEL_API_AUDIT")
@SequenceGenerator(name = "CHANNEL_API_AUDIT_SEQ", sequenceName = "CHANNEL_API_AUDIT_SEQ", allocationSize = 1)
@EntityListeners(AuditingEntityListener.class)
public class ChannelAPIAudit {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CHANNEL_API_AUDIT_SEQ")
    @Column(name = "ID", nullable = false)
    private Integer id;

    @Column(name = "TRANSACTION_ID")
    private String transactionID;

    @Column(name = "DP_CUSTOM_ID", nullable = false)
    private String dpCustomId;

    @Column(name = "REQUEST", nullable = false)
    @Lob
    @Basic(fetch = FetchType.LAZY)
    @JsonSerialize(using = BlobJsonSerializer.class)
    @JsonDeserialize(using = BlobJsonDeserializer.class)
    private Blob request;

    @Column(name = "RESPONSE")
    @Lob
    @Basic(fetch = FetchType.LAZY)
    @JsonSerialize(using = BlobJsonSerializer.class)
    @JsonDeserialize(using = BlobJsonDeserializer.class)
    private Blob response;

    @Column(name = "CREATED_DATE", nullable = false)
    @CreatedDate
    private Date createDate;

    @Column(name = "UPDATED_DATE")
    @LastModifiedDate
    private Date updatedDate;

    @Column(name = "API_TYPE", nullable = false)
    private String apiType;

    @Column(name = "API_STATUS")
    private String apiStatus;

    public ChannelAPIAudit() {
    }

    public ChannelAPIAudit(String apiType) {
        this.apiType = apiType;
    }
    public ChannelAPIAudit(String transactionID, String dpCustomId, Blob request, String apiType) {
        this.createDate = new Date();
        this.transactionID = transactionID;
        this.dpCustomId = dpCustomId;
        this.request = request;
        this.apiType = apiType;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTransactionID() {
        return transactionID;
    }

    public void setTransactionID(String transactionID) {
        this.transactionID = transactionID;
    }

    public String getDpCustomId() {
        return dpCustomId;
    }

    public void setDpCustomId(String dpCustomId) {
        this.dpCustomId = dpCustomId;
    }

    public Blob getRequest() {
        return request;
    }

    public void setRequest(Blob request) {
        this.request = request;
    }

    public Blob getResponse() {
        return response;
    }

    public void setResponse(Blob response) {
        this.response = response;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getApiType() {
        return apiType;
    }

    public void setApiType(String apiType) {
        this.apiType = apiType;
    }

    public String getApiStatus() {
        return apiStatus;
    }

    public void setApiStatus(String apiStatus) {
        this.apiStatus = apiStatus;
    }
}
