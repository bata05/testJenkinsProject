package com.prudential.d2c.entity.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.prudential.d2c.utils.BlobJsonDeserializer;
import com.prudential.d2c.utils.BlobJsonSerializer;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Blob;
import java.util.Date;

@Entity
@Table(name = "CHANNEL_API_CUST_APPLICATION")
@SequenceGenerator(name = "CHANNEL_API_CUST_APP_SEQ", sequenceName = "CHANNEL_API_CUST_APP_SEQ", allocationSize = 1)
@EntityListeners(AuditingEntityListener.class)
public class ChannelAPICustomerApplication {

    public enum ChannelAPICusAppStatus {
        VALIDATION_ERROR,
        VALIDATION_SUCCESS,
        SUBMISSION_INIT,
        FC_ASSIGN_SUCCESS,
        FC_ASSIGN_ERROR,
        PROPOSAL_GEN_SUCCESS,
        PROPOSAL_GEN_ERROR,
        SUBMISSION_SUCCESS,
        SUBMISSION_ERROR,
        PROCESSING_ERROR
    }

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CHANNEL_API_CUST_APP_SEQ")
    @Column(name = "ID", nullable = false)
    private Integer id;

    @Column(name = "TRANSACTION_ID", nullable = false)
    private String transactionID;

    @Column(name = "DP_CUSTOM_ID", nullable = false)
    private String dpCustomId;

    @Column(name = "PARTNER_EREF")
    private String partnerEref;

    @Column(name="WORK_PASS")
    private String workPass;

    @ManyToOne(fetch = FetchType.LAZY,cascade = {CascadeType.MERGE})
    @JoinColumn(name = "OCCUPATION_CODE")
    private Occupation occupation;

    @Column(name = "INDUSTRY")
    private String industry;

    @Column(name = "EMPLOYER_NAME")
    private String employerName;

    @Column(name = "DESIGNATION")
    private String designation;

    @Column(name = "QUESTIONNAIRE", updatable = false)
    @Lob
    @Basic(fetch = FetchType.LAZY)
    @JsonSerialize(using = BlobJsonSerializer.class)
    @JsonDeserialize(using = BlobJsonDeserializer.class)
    private Blob questionnaire;

    @Column(name = "PAYMENT_MODE")
    private String paymentMode;

    @Column(name = "PREMIUM_AMOUNT")
    private BigDecimal premiumAmount;

    @Column(name = "PAYMENT_METHOD")
    private String paymentMethod;

    @Column(name = "DP_EREF")
    private String erefNo;

    @Column(name = "AGENT_CODE")
    private String agentCode;

    @Column(name ="MAIL_SAME_RESIDENTIAL", nullable = true)
    private boolean mailSameAsResidential;

    @Column(name ="IS_EXISTING_CLIENT", nullable = true)
    private boolean isExistingClient;

    @Column( name = "APPLICATION_STATUS")
    @Enumerated(EnumType.ORDINAL)
    private ChannelAPICusAppStatus applicationStatus;

    @Column(name ="SERVER_HOST_NAME")
    private String serverHostName;

    @Column(name = "CREATED_DATE", nullable = false)
    @CreatedDate
    private Date createDate;

    @Column(name = "UPDATED_DATE")
    @LastModifiedDate
    private Date updatedDate;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTransactionID() {
        return transactionID;
    }

    public void setTransactionID(String transactionID) {
        this.transactionID = transactionID;
    }

    public String getDpCustomId() {
        return dpCustomId;
    }

    public void setDpCustomId(String dpCustomId) {
        this.dpCustomId = dpCustomId;
    }

    public String getPartnerEref() {
        return partnerEref;
    }

    public void setPartnerEref(String partnerEref) {
        this.partnerEref = partnerEref;
    }

    public String getWorkPass() {
        return workPass;
    }

    public void setWorkPass(String workPass) {
        this.workPass = workPass;
    }

    public Occupation getOccupation() {
        return occupation;
    }

    public void setOccupation(Occupation occupation) {
        this.occupation = occupation;
    }

    public String getIndustry() {
        return industry;
    }

    public void setIndustry(String industry) {
        this.industry = industry;
    }

    public String getEmployerName() {
        return employerName;
    }

    public void setEmployerName(String employerName) {
        this.employerName = employerName;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public Blob getQuestionnaire() {
        return questionnaire;
    }

    public void setQuestionnaire(Blob questionnaire) {
        this.questionnaire = questionnaire;
    }

    public String getPaymentMode() {
        return paymentMode;
    }

    public void setPaymentMode(String paymentMode) {
        this.paymentMode = paymentMode;
    }

    public BigDecimal getPremiumAmount() {
        return premiumAmount;
    }

    public void setPremiumAmount(BigDecimal premiumAmount) {
        this.premiumAmount = premiumAmount;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getErefNo() { return erefNo; }

    public void setErefNo(String erefNo) { this.erefNo = erefNo; }

    public String getAgentCode() { return agentCode; }

    public void setAgentCode(String agentCode) { this.agentCode = agentCode; }

    public boolean isMailSameAsResidential() { return mailSameAsResidential; }

    public void setMailSameAsResidential(boolean mailSameAsResidential) { this.mailSameAsResidential = mailSameAsResidential; }

    public ChannelAPICusAppStatus getApplicationStatus() {
        return applicationStatus;
    }

    public void setApplicationStatus(ChannelAPICusAppStatus applicationStatus) {
        this.applicationStatus = applicationStatus;
    }

    public String getServerHostName() {
        return serverHostName;
    }

    public void setServerHostName(String serverHostName) {
        this.serverHostName = serverHostName;
    }

    public boolean isExistingClient() { return isExistingClient; }

    public void setExistingClient(boolean existingClient) { isExistingClient = existingClient; }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }
}
