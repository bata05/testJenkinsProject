package com.prudential.d2c.entity.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;


@Entity
@Table(name = "CHANNEL_API_MAIL")
@SequenceGenerator(name = "CHANNEL_API_MAIL_SEQ", sequenceName = "CHANNEL_API_MAIL_SEQ", allocationSize = 1)
@EntityListeners(AuditingEntityListener.class)
public class ChannelAPIMail {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CHANNEL_API_MAIL_SEQ")
    @Column(name = "ID", nullable = false)
    private Integer id;

    @Column(name = "TRANSACTION_ID", nullable = false)
    private String transactionID;

    @Column(name = "DP_CUSTOM_ID", nullable = false)
    private String dpCustomId;

    @Column(name = "MAIL_TYPE", nullable = false)
    private String mailType;

    @Column(name = "STATUS", nullable = false)
    private String status;

    @Column(name = "CREATED_DATE", nullable = false)
    @CreatedDate
    private Date createDate;

    @Column(name = "UPDATED_DATE")
    @LastModifiedDate
    private Date updatedDate;

    public ChannelAPIMail(String mailType) {
        this.createDate = new Date();
        this.mailType = mailType;
        this.status = "INITIATED";
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTransactionID() {
        return transactionID;
    }

    public void setTransactionID(String transactionID) {
        this.transactionID = transactionID;
    }

    public String getDpCustomId() {
        return dpCustomId;
    }

    public void setDpCustomId(String dpCustomId) {
        this.dpCustomId = dpCustomId;
    }

    public String getMailType() {
        return mailType;
    }

    public void setMailType(String mailType) {
        this.mailType = mailType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

}
