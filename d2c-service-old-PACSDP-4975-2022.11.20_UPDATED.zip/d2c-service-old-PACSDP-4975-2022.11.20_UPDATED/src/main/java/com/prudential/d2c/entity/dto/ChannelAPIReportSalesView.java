package com.prudential.d2c.entity.dto;

import org.hibernate.annotations.Immutable;

import javax.persistence.*;
import java.util.Date;

@Table(name = "VIEW_REP_CHANNEL_API_SALES")
@Entity
@Immutable
public class ChannelAPIReportSalesView {

    @Id
    @Column(name = "DP_CUSTOM_ID")
    private String customId;

    @Column(name = "TRANS_ID")
    private String transactionId;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "DATE_CREATED")
    private Date createDate;

    @Column(name = "CHANNEL")
    private String channel;

    @Column(name = "NAME")
    private String name;

    @Column(name = "EMAIL")
    private String email;

    @Column(name = "MOBILE")
    private String mobile;

    @Column(name = "NRIC_SUFFIX")
    private String nricSuffix;

    @Column(name = "DOB")
    private String dob;

    @Column(name = "GENDER")
    private String gender;

    @Column(name = "NATIONALITY")
    private String nationality;

    @Column(name = "PROD_NAME")
    private String productName;

    @Column(name = "APPLICATION_DATE")
    private String applicationDate;

    @Column(name = "PROPOSAL_NO")
    private String proposalNo;

    @Column(name = "PRU_EREF")
    private String erefNo;

    @Column(name = "PARTNER_EREF")
    private String channelERefNo;

    @Column(name = "PREMIUM_AMOUNT")
    private Double premiumAmount;

    @Column(name = "CLIENT_NO")
    private String clientNo;

    @Column(name = "AGENT_CODE")
    private String agentCode;

    @Column(name = "AGENT_NAME")
    private String agentName;

    @Column(name = "AGENT_CONTACT")
    private String agentContact;

    @Column(name = "AGENT_EMAIL")
    private String agentEmail;

    public String getCustomId() {
        return customId;
    }

    public void setCustomId(String customId) {
        this.customId = customId;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getNricSuffix() {
        return nricSuffix;
    }

    public void setNricSuffix(String nricSuffix) {
        this.nricSuffix = nricSuffix;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getApplicationDate() {
        return applicationDate;
    }

    public void setApplicationDate(String applicationDate) {
        this.applicationDate = applicationDate;
    }

    public String getProposalNo() {
        return proposalNo;
    }

    public void setProposalNo(String proposalNo) {
        this.proposalNo = proposalNo;
    }

    public String getErefNo() {
        return erefNo;
    }

    public void setErefNo(String erefNo) {
        this.erefNo = erefNo;
    }

    public String getChannelERefNo() {
        return channelERefNo;
    }

    public void setChannelERefNo(String channelERefNo) {
        this.channelERefNo = channelERefNo;
    }

    public Double getPremiumAmount() {
        return premiumAmount;
    }

    public void setPremiumAmount(Double premiumAmount) {
        this.premiumAmount = premiumAmount;
    }

    public String getClientNo() {
        return clientNo;
    }

    public void setClientNo(String clientNo) {
        this.clientNo = clientNo;
    }

    public String getAgentCode() {
        return agentCode;
    }

    public void setAgentCode(String agentCode) {
        this.agentCode = agentCode;
    }

    public String getAgentName() {
        return agentName;
    }

    public void setAgentName(String agentName) {
        this.agentName = agentName;
    }

    public String getAgentContact() {
        return agentContact;
    }

    public void setAgentContact(String agentContact) {
        this.agentContact = agentContact;
    }

    public String getAgentEmail() {
        return agentEmail;
    }

    public void setAgentEmail(String agentEmail) {
        this.agentEmail = agentEmail;
    }
}
