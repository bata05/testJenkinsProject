package com.prudential.d2c.entity.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="CONFIGURE_PROPERTIES")
@JsonIgnoreProperties(ignoreUnknown = true)
public class ConfigureProperties {
	
	/* list:
	 * SERVICE_EMAIL: for get Help center
	 * BACKUP_MAIL: for esub exception 
	 * */
	@Id
	@Column(name ="CON_NAME", nullable = false)
    private String conName ;

	@Column(name ="CON_VALUE", nullable = false)
    private String  conValue;
	

	
	public void setConName(String conName) {
		this.conName = conName;
	}
	public String getConName() {
		return conName;
	}
	public String getConValue() {
		return conValue;
	}
	public void setConValue(String conValue) {
		this.conValue = conValue;
	}

}
