package com.prudential.d2c.entity.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="COUNTRY_IDD")
@JsonIgnoreProperties(ignoreUnknown = true)
public class CountryIDD implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 3274393051556382889L;

	@Id
	@Column(name="COUNTRY", nullable=false)
	private String country;
	
	@Column(name="CODE", nullable=false)
	private String code;
	
	@Column(name="ISO_CODE", nullable=false)
	private String isoCode;
	
	@Column(name="IDD", nullable=false)
	private int idd;

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @return the iso_code
	 */
	public String getIsoCode() {
		return isoCode;
	}

	/**
	 * @param iso_code the iso_code to set
	 */
	public void setIsoCode(String isoCode) {
		this.isoCode = isoCode;
	}

	/**
	 * @return the idd
	 */
	public int getIdd() {
		return idd;
	}

	/**
	 * @param idd the idd to set
	 */
	public void setIdd(int idd) {
		this.idd = idd;
	}
	
	
	
}
