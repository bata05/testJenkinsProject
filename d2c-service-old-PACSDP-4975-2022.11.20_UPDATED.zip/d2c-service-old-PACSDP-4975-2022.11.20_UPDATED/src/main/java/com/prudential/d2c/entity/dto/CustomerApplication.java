package com.prudential.d2c.entity.dto;

import java.sql.Blob;
import java.util.Set;

import javax.persistence.*;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.prudential.d2c.entity.micro.payload.MicroSelectedProducts;
import com.prudential.d2c.utils.BlobJsonDeserializer;
import com.prudential.d2c.utils.BlobJsonSerializer;
import org.springframework.util.StringUtils;

@Entity
@Table(name = "CUSTOMER_APPLICATION")
@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomerApplication {
    @Id
    @Column(name = "custom_id", nullable = false)
    private String customId;
    
    @Column(name = "product_type", nullable = false)
    private String productType;

    @Column(name = "sur_name")
    private String surName;
    
    @Column(name = "given_name")
    private String givenName;

    @Column(name = "nric_fin")
    private String nricFin;
    
    @Column(name = "mobile_phone")
    private String mobilePhone;

    @Column(name = "CLIENT_NUMBER")
    private String clientNumber;

    @Column(name = "GENDER")
    private String gender;
    
    @Column(name = "DATE_OF_BIRTH")
    private String dob;
    
    @Column(name = "NATIONALITY")
    private String nationality;

    @Column(name = "COUNTRY_OF_BIRTH")
    private String countryOfBirth;

    @Column(name = "RESIDENCY_STATUS")
    private String residencyStatus;

    @Column(name = "RESIDENTIAL_COUNTRY")
    private String residentialCountry;
    
    @Column(name = "RESIDENTIAL_POSTAL_CODE")
    private String residentialPostalCode;
    
    @Column(name = "RESIDENTIAL_BLOCK_NO")
    private String residentialBlockNo;

    @Column(name = "RESIDENTIAL_BUILDING_NAME")
    private String residentialBuildingName;
    
    @Column(name = "RESIDENTIAL_STREET_NAME")
    private String residentialStreetName;
    
    @Column(name = "RESIDENTIAL_UNIT_NO")
    private String residentialUnitNo;

    @Column(name = "MAILING_POSTAL_CODE")
    private String mailingPostalCode;
    
    @Column(name = "MAILING_BLOCK_NO")
    private String mailingBlockNo;
    
    @Column(name = "MAILING_BUILDING_NAME")
    private String mailingBuildingName;
    
    @Column(name = "MAILING_STREET_NAME")
    private String mailingStreetName;
    
    @Column(name = "MAILING_UNIT_NO")
    private String mailingUnitNo;

    @Column(name = "MAILING_COUNTRY")
    private String mailingCountry;
    
    @Column(name = "CUSTOMER_EMAIL")
    private String customerEmail;

    @Column(name = "Request_Financial_Consultant")
    private Boolean requestFinancialConsultant;

    @Column(name = "ANNUAL_INCOME")
    private String annualIncome;

    @Column(name = "HEIGHT")
    private String height;
    
    @Column(name = "WEIGHT")
    private String weight;

    @JsonIgnore
    @Column(name = "CREATE_DATE")
    private String createDate;

    @Column(name = "QMAY_QUESTIONNAIRES")
    @Lob
    @Basic(fetch = FetchType.LAZY)
    @JsonSerialize(using = BlobJsonSerializer.class)
    @JsonDeserialize(using = BlobJsonDeserializer.class)
    private Blob qmayQuestionnaires;

    @Column(name = "QPS_QUESTIONNAIRES")
    @Lob
    @Basic(fetch = FetchType.LAZY)
    @JsonSerialize(using = BlobJsonSerializer.class)
    @JsonDeserialize(using = BlobJsonDeserializer.class)
    private Blob qpsQuestionnaires;

    @JsonIgnore
    @Column(name = "STEP_STATUS")
    private String stepStatus;

    @Column(name = "CAMPAIGN_ID")
    private String campaignId;

    @Column(name = "TRACKING_ID")
    private String trackingId;

    @Column(name = "CHANNEL")
    private String channel;

    @Column(name = "MARKETING_CONSENT")
    private String marketConsent;

    @Column(name = "BIZ_SRC_LOOKUP_ID")
    private Integer laBizSrcLookupId;

    @Column(name = "ENTRY_TYPE")
    private String entryType;

    @Column(name = "POLICY_NO")
    private String policyNo;

    @Column(name = "BUSINESS_SRC")
    private String businessSource;

    @Column(name = "BUSINESS_SUB_SRC")
    private String businessSubSource;

    @Column(name = "PS_SIO")
    private String psSIO;

    @Transient
    private boolean agentChange;

    @Transient
    private String productName;

    @Transient
    private boolean startListener;

    @Transient
    private MicroSelectedProducts selectedProducts;

    @Transient
    private String phoneCountryCode;

    @Transient
    private String phoneIDD;

    @Transient
    private String abandCId;//when ET page goes to PTV ,will start a new policy , abandon the old one
    @OneToMany(mappedBy = "customerApplication", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private Set<MailList> mailLists;

    @SuppressWarnings("unused")
	private MicroSelectedProducts getSelectedProducts() {
        return selectedProducts;
    }


    public void setSelectedProducts(MicroSelectedProducts selectedProducts) {
        this.selectedProducts = selectedProducts;
    }


    public String getCustomId() {
        return customId;
    }


    public String getProductType() {
        return productType;
    }


    public String getSurName() {
        return surName;
    }


    public String getGivenName() {
        return givenName;
    }


    public String getMobilePhone() {
        return mobilePhone;
    }


    public String getGender() {
        return gender;
    }


    public String getDob() {
        return dob;
    }


    public String getCountryOfBirth() {
        return countryOfBirth;
    }


    public String getNationality() {
        return nationality;
    }


    public String getResidencyStatus() {
        return residencyStatus;
    }


    public String getResidentialPostalCode() {
        return residentialPostalCode;
    }


    public String getResidentialBlockNo() {
        return residentialBlockNo;
    }


    public String getResidentialBuildingName() {
        return residentialBuildingName;
    }


    public String getResidentialStreetName() {
        return residentialStreetName;
    }


    public String getResidentialUnitNo() {
        return residentialUnitNo;
    }


    public String getMailingPostalCode() {
        return mailingPostalCode;
    }


    public String getMailingBlockNo() {
        return mailingBlockNo;
    }


    public String getMailingBuildingName() {
        return mailingBuildingName;
    }


    public String getMailingStreetName() {
        return mailingStreetName;
    }


    public String getMailingUnitNo() {
        return mailingUnitNo;
    }


    public String getMailingCountry() {
        return mailingCountry;
    }


    public String getCustomerEmail() {
        return customerEmail;
    }


    public String getAnnualIncome() {
        return annualIncome;
    }


    public String getHeight() {
        return height;
    }


    public String getWeight() {
        return weight;
    }


    public String getCreateDate() {
        return createDate;
    }


    public void setCustomId(String customId) {
        this.customId = customId;
    }


    public void setProductType(String productType) {
        this.productType = productType;
    }


    public void setSurName(String surName) {
        this.surName = surName;
    }


    public void setGivenName(String givenName) {
        this.givenName = givenName;
    }


    public void setMobilePhone(String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }


    public void setGender(String gender) {
        this.gender = gender;
    }


    public void setDob(String dob) {
        this.dob = dob;
    }


    public void setCountryOfBirth(String countryOfBirth) {
        this.countryOfBirth = countryOfBirth;
    }


    public void setNationality(String nationality) {
        this.nationality = nationality;
    }


    public void setResidencyStatus(String residencyStatus) {
        this.residencyStatus = residencyStatus;
    }


    public void setResidentialPostalCode(String residentialPostalCode) {
        this.residentialPostalCode = residentialPostalCode;
    }


    public void setResidentialBlockNo(String residentialBlockNo) {
        this.residentialBlockNo = residentialBlockNo;
    }


    public void setResidentialBuildingName(String residentialBuildingName) {
        this.residentialBuildingName = residentialBuildingName;
    }


    public void setResidentialStreetName(String residentialStreetName) {
        this.residentialStreetName = residentialStreetName;
    }


    public void setResidentialUnitNo(String residentialUnitNo) {
        this.residentialUnitNo = residentialUnitNo;
    }


    public void setMailingPostalCode(String mailingPostalCode) {
        this.mailingPostalCode = mailingPostalCode;
    }


    public void setMailingBlockNo(String mailingBlockNo) {
        this.mailingBlockNo = mailingBlockNo;
    }


    public void setMailingBuildingName(String mailingBuildingName) {
        this.mailingBuildingName = mailingBuildingName;
    }


    public void setMailingStreetName(String mailingStreetName) {
        this.mailingStreetName = mailingStreetName;
    }


    public void setMailingUnitNo(String mailingUnitNo) {
        this.mailingUnitNo = mailingUnitNo;
    }


    public void setMailingCountry(String mailingCountry) {
        this.mailingCountry = mailingCountry;
    }


    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }


    public void setAnnualIncome(String annualIncome) {
        this.annualIncome = annualIncome;
    }


    public void setHeight(String height) {
        this.height = height;
    }


    public void setWeight(String weight) {
        this.weight = weight;
    }


    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public Blob getQmayQuestionnaires() {
        return qmayQuestionnaires;
    }


    public Blob getQpsQuestionnaires() {
        return qpsQuestionnaires;
    }


    public void setQmayQuestionnaires(Blob qmayQuestionnaires) {
        this.qmayQuestionnaires = qmayQuestionnaires;
    }


    public void setQpsQuestionnaires(Blob qpsQuestionnaires) {
        this.qpsQuestionnaires = qpsQuestionnaires;
    }

    public String getStepStatus() {
        return stepStatus;
    }


    public void setStepStatus(String stepStatus) {
        this.stepStatus = stepStatus;
    }


    public String getResidentialCountry() {
        return residentialCountry;
    }


    public void setResidentialCountry(String residentialCountry) {
        this.residentialCountry = residentialCountry;
    }


    public String getClientNumber() {
        return clientNumber;
    }


    public void setClientNumber(String clientNumber) {
        this.clientNumber = clientNumber;
    }


    public String getCampaignId() {
        return campaignId;
    }


    public String getTrackingId() {
        return trackingId;
    }


    public void setCampaignId(String campaignId) {
        this.campaignId = campaignId;
    }


    public void setTrackingId(String trackingId) {
        this.trackingId = trackingId;
    }


    public Boolean getRequestFinancialConsultant() {
        return requestFinancialConsultant;
    }


    public void setRequestFinancialConsultant(Boolean requestFinancialConsultant) {
        this.requestFinancialConsultant = requestFinancialConsultant;
    }


    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public boolean getAgentChange() {
        return agentChange;
    }


    public void setAgentChange(boolean agentChange) {
        this.agentChange = agentChange;
    }


    public boolean isStartListener() {
        return startListener;
    }


    public void setStartListener(boolean startListener) {
        this.startListener = startListener;
    }

    public String getNricFin() {
        return nricFin;
    }


    public void setNricFin(String nricFin) {
        this.nricFin = nricFin;
    }


    public String getAbandCId() {
        return abandCId;
    }


    public void setAbandCId(String abandCId) {
        this.abandCId = abandCId;
    }


    public String getProductName() {
        return productName;
    }


    public void setProductName(String productName) {
        this.productName = productName;
    }


    public Set<MailList> getMailLists() {
        return mailLists;
    }


    public void setMailLists(Set<MailList> mailLists) {
        this.mailLists = mailLists;
    }


    @Override
    public String toString()
    {

        Object fieldExcludedObject = ReflectionToStringBuilder.toStringExclude(this, "nricFin");
        return ToStringBuilder.reflectionToString(fieldExcludedObject);
    }


    public String getMarketConsent() {
        return marketConsent;
    }


    public void setMarketConsent(String marketConsent) {
        this.marketConsent = marketConsent;
    }

    public String getEntryType() {
        return entryType;
    }

    public void setEntryType(String entryType) {
        this.entryType = entryType;
    }

    public Integer getLaBizSrcLookupId() {
        return laBizSrcLookupId;
    }

    public void setLaBizSrcLookupId(Integer laBizSrcLookupId) {
        this.laBizSrcLookupId = laBizSrcLookupId;
    }

    public String getPolicyNo() {
        return policyNo;
    }

    public void setPolicyNo(String policyNo) {
        this.policyNo = policyNo;
    }

    public String getBusinessSource() {
        return businessSource;
    }


    public void setBusinessSource(String businessSource) {
        this.businessSource = businessSource;
    }


    public String getBusinessSubSource() {
        return businessSubSource;
    }


    public void setBusinessSubSource(String businessSubSource) {
        this.businessSubSource = businessSubSource;
    }

    @SuppressWarnings("deprecation")
	public String getCustomerName() {
        return ((StringUtils.isEmpty(this.surName) ? "" : this.surName) + " " + (StringUtils.isEmpty(this.givenName) ? "" : this.givenName));
    }

    public String getPhoneCountryCode() {
        return phoneCountryCode;
    }

    public void setPhoneCountryCode(String phoneCountryCode) {
        this.phoneCountryCode = phoneCountryCode;
    }

    public String getPhoneIDD() {
        return phoneIDD;
    }

    public void setPhoneIDD(String phoneIDD) {
        this.phoneIDD = phoneIDD;
    }

    public String getPsSIO() {
        return psSIO;
    }

    public void setPsSIO(String psSIO) {
        this.psSIO = psSIO;
    }
}
