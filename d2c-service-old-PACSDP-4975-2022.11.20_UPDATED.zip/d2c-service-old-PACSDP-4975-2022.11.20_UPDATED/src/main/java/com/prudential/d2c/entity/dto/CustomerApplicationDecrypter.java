package com.prudential.d2c.entity.dto;


import com.prudential.d2c.common.ConfigProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import static com.prudential.d2c.utils.DecryptionUtil.*;
import static java.util.Optional.of;
import static java.util.Optional.ofNullable;


@Component
public class CustomerApplicationDecrypter implements Converter<CustomerApplication, CustomerApplication> {

    static private ConfigProperties configProperties;

    @Autowired
    public void init(ConfigProperties configProperties) {
        CustomerApplicationDecrypter.configProperties = configProperties;
    }

    @Override
    public CustomerApplication convert(CustomerApplication customerApplication) {
        customerApplication.setGivenName(validateAndDecrypt(customerApplication.getGivenName()));
        customerApplication.setSurName(validateAndDecrypt(customerApplication.getSurName()));
        customerApplication.setNricFin(validateAndDecrypt(customerApplication.getNricFin()));
        customerApplication.setCustomerEmail(validateAndDecrypt(customerApplication.getCustomerEmail()));
        customerApplication.setMobilePhone(validateAndDecrypt(customerApplication.getMobilePhone()));
        customerApplication.setResidentialBlockNo(validateAndDecrypt(customerApplication.getResidentialBlockNo()));
        customerApplication.setResidentialCountry(validateAndDecrypt(customerApplication.getResidentialCountry()));
        customerApplication.setResidentialBuildingName(validateAndDecrypt(customerApplication.getResidentialBuildingName()));
        customerApplication.setResidentialPostalCode(validateAndDecrypt(customerApplication.getResidentialPostalCode()));
        customerApplication.setResidentialStreetName(validateAndDecrypt(customerApplication.getResidentialStreetName()));
        customerApplication.setResidentialUnitNo(validateAndDecrypt(customerApplication.getResidentialUnitNo()));
        customerApplication.setMailingBlockNo(validateAndDecrypt(customerApplication.getMailingBlockNo()));
        customerApplication.setMailingBuildingName(validateAndDecrypt(customerApplication.getMailingBuildingName()));
        customerApplication.setMailingStreetName(validateAndDecrypt(customerApplication.getMailingStreetName()));
        customerApplication.setMailingPostalCode(validateAndDecrypt(customerApplication.getMailingPostalCode()));
        customerApplication.setMailingUnitNo(validateAndDecrypt(customerApplication.getMailingUnitNo()));
        customerApplication.setMailingCountry(validateAndDecrypt(customerApplication.getMailingCountry()));
        customerApplication.setNationality(validateAndDecrypt(customerApplication.getNationality()));
        customerApplication.setPhoneCountryCode(validateAndDecrypt(customerApplication.getPhoneCountryCode()));
        customerApplication.setPhoneIDD(validateAndDecrypt(customerApplication.getPhoneIDD()));
        return customerApplication;
    }


    @SuppressWarnings("deprecation")
	@Cacheable(cacheNames = "CUSTOMER_APP_INFO_DECRYPTED", key = "#value")
    public String validateAndDecrypt(String value) {
        return ofNullable(value)
                .filter(v -> !StringUtils.isEmpty(v))
                .map(s -> of(s).filter(r -> r.length() > 200)
                        .map(this::decrypt)
                        .orElseThrow(IllegalArgumentException::new))
                .orElse("");

    }

    public String decrypt(String val){
        return decryption(val,configProperties);
    }


}
