package com.prudential.d2c.entity.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.prudential.d2c.utils.BlobJsonDeserializer;
import com.prudential.d2c.utils.BlobJsonSerializer;

import lombok.Getter;
import lombok.Setter;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

import java.math.BigDecimal;
import java.sql.Blob;
import java.util.Date;


@Entity
@Table(name = "DE_API_AUDIT")
@SequenceGenerator(name = "DE_API_AUDIT_SEQ", sequenceName = "DE_API_AUDIT_SEQ", allocationSize = 1)
@EntityListeners(AuditingEntityListener.class)
@Getter
@Setter
public class DigitalEndowmentAPIAudit {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DE_API_AUDIT_SEQ")
    @Column(name = "ID", nullable = false)
    private Integer id;

    @Column(name = "TRANSACTION_ID")
    private String transactionID;
    
    @Column(name = "PAYMENT_TRANSACTION_ID")
    private String paymentTransactionID;
    
    @Column(name = "EREF_NO")
    private String ereferenceNo;

    @Column(name = "DP_CUSTOM_ID", nullable = false)
    private String dpCustomID;

    @Column(name = "REQUEST", nullable = false, updatable = false)
    @Lob
    @Basic(fetch = FetchType.LAZY)
    @JsonSerialize(using = BlobJsonSerializer.class)
    @JsonDeserialize(using = BlobJsonDeserializer.class)
    private Blob request;

    @Column(name = "RESPONSE")
    @Lob
    @Basic(fetch = FetchType.LAZY)
    @JsonSerialize(using = BlobJsonSerializer.class)
    @JsonDeserialize(using = BlobJsonDeserializer.class)
    private Blob response;
    
    @Column(name = "EXECUTION_TIME", nullable = false)
    private BigDecimal executionTime;

    @Column(name = "CREATED_DATE", nullable = false)
    @CreatedDate
    private Date createDate;

    @Column(name = "UPDATED_DATE")
    @LastModifiedDate
    private Date updatedDate;

    @Column(name = "API_TYPE", nullable = false)
    private String apiType;

    @Column(name = "API_STATUS")
    private String apiStatus;
    
    @Column(name = "FC_CODE")
    private String fcCode;
    
    @Column(name = "CHANNEL")
    private String channel;
    
    @Column(name = "SINGLE_PREMIUM")
    private Double singlePremium;
    
    @Column(name = "PREMIUM_ACCUMULATION")
    private Double premiumAccumulation;
    
    @Column(name = "CREDIT_DATE")
    private String creditDate;
    
    @Column(name = "CREDIT_TIME")
    private String creditTime;
    
    @Column(name = "ESUB_STATUS")
    private String esubStatus;
    
    @Column(name = "TRANCHE_ID")
    private Integer trancheId;
    
    @Column(name = "PRUPAY_RETRY")
    private int prupayRetryCount;
    
    @Column(name = "TRANCHE_RETRY")
    private int trancheRetryCount;
    
    @Column(name = "QUOTATION_RETRY")
    private int quotationRetryCount;
    
    @Column(name = "PROPOSAL_RETRY")
    private int proposalRetryCount;

    public DigitalEndowmentAPIAudit() {
    }

    public DigitalEndowmentAPIAudit(String apiType) {
        this.apiType = apiType;
    }
    
    public DigitalEndowmentAPIAudit(String transactionID, String dpCustomID, Blob request, String apiType) {
        this.createDate = new Date();
        this.transactionID = transactionID;
        this.dpCustomID = dpCustomID;
        this.request = request;
        this.apiType = apiType;
    }

   
}
