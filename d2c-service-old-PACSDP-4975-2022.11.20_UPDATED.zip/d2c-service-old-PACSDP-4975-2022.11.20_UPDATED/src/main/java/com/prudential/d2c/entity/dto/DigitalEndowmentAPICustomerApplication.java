package com.prudential.d2c.entity.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.prudential.d2c.utils.BlobJsonDeserializer;
import com.prudential.d2c.utils.BlobJsonSerializer;

import lombok.Getter;
import lombok.Setter;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Blob;
import java.util.Date;

@Entity
@Table(name = "DE_API_CUST_APPLICATION")
@SequenceGenerator(name = "DE_API_CUST_APP_SEQ", sequenceName = "DE_API_CUST_APP_SEQ", allocationSize = 1)
@EntityListeners(AuditingEntityListener.class)
@Getter
@Setter
public class DigitalEndowmentAPICustomerApplication {

    public enum DigitalEndowmentAPICusAppStatus {
        VALIDATION_ERROR,
        VALIDATION_SUCCESS,
        SUBMISSION_INIT,
        PROPOSAL_GEN_SUCCESS,
        PROPOSAL_GEN_ERROR,
        SUBMISSION_SUCCESS,
        SUBMISSION_ERROR,
        PROCESSING_ERROR,
        TRANCHE_ERROR,
        AUDIT_ERROR
    }

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DE_API_CUST_APP_SEQ")
    @Column(name = "ID", nullable = false)
    private Integer id;

    @Column(name = "TRANSACTION_ID", nullable = false)
    private String transactionID;

    @Column(name = "DP_CUSTOM_ID", nullable = false)
    private String dpCustomID;
    
    @Column(name = "E_REF_NO")
    private String erefNo;
   
    @Column(name = "NATIONALITY")
    private String nationality;
     
    @Column(name="WORK_PASS")
    private String workPass;
    
    @Column(name="PASS_STATUS")
    private String passStatus;
    
    @Column(name="PASS_EXPIRY_DATE")
    private String passExpiryDate;
    
    @Column(name="PASS_TYPE")
    private String passType;
       
    @Column(name = "EMPLOYER_NAME")
    private String employerName;
    
    @ManyToOne(fetch = FetchType.LAZY,cascade = {CascadeType.MERGE})
    @JoinColumn(name = "OCCUPATION_CODE")
    private Occupation occupation;

    @Column(name = "INDUSTRY")
    private String businessIndustry;

    @Column(name = "OTHER_INDUSTRY")
    private String otherIndustry;
    
    @Column(name = "DESIGNATION")
    private String designation;
    
    @Column(name="YEARS_OF_WORKING")
    private Integer yearsOfWorking;
    
    @Column(name = "REQUEST", updatable = false)
    @Lob
    @Basic(fetch = FetchType.LAZY)
    @JsonSerialize(using = BlobJsonSerializer.class)
    @JsonDeserialize(using = BlobJsonDeserializer.class)
    private Blob request;

    @Column(name = "QUESTIONNAIRE", updatable = false)
    @Lob
    @Basic(fetch = FetchType.LAZY)
    @JsonSerialize(using = BlobJsonSerializer.class)
    @JsonDeserialize(using = BlobJsonDeserializer.class)
    private Blob questionnaire;

    @Column(name = "PAYMENT_MODE")
    private String paymentMode;

    @Column(name = "PREMIUM_AMOUNT")
    private BigDecimal premiumAmount;

    @Column(name = "PAYMENT_METHOD")
    private String paymentMethod;
    
    @Column(name = "AGENT_CODE")
    private String agentCode;
    
    @Column(name = "BANK_REFERRAL_CODE")
    private String bankReferralCode;
    
    @Column(name = "BANK_REFERRAL_MOBILE_NUMBER")
    private String bankReferralMobileNumber;
    
    @Column(name = "PSA_LSA_AGENT_CODE")
    private String psaLsaAgentCode;

    @Column(name ="MAIL_SAME_RESIDENTIAL", nullable = true)
    private boolean mailSameAsResidential;

    @Column(name ="IS_EXISTING_CLIENT", nullable = true)
    private boolean isExistingClient;

    @Column( name = "APPLICATION_STATUS")
    @Enumerated(EnumType.ORDINAL)
    private DigitalEndowmentAPICusAppStatus applicationStatus;

    @Column(name ="SERVER_HOST_NAME")
    private String serverHostName;

    @Column(name = "CREATED_DATE", nullable = false)
    @CreatedDate
    private Date createDate;

    @Column(name = "UPDATED_DATE")
    @LastModifiedDate
    private Date updatedDate;
    
    

}
