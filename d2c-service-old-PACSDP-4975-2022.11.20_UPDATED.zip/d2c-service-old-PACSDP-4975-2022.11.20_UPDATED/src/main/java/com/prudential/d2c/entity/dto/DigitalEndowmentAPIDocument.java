package com.prudential.d2c.entity.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.prudential.d2c.utils.BlobJsonDeserializer;
import com.prudential.d2c.utils.BlobJsonSerializer;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.sql.Blob;
import java.util.Date;


@Entity
@Table(name = "DE_API_DOC")
@SequenceGenerator(name = "DE_API_DOC_SEQ", sequenceName = "DE_API_DOC_SEQ", allocationSize = 1)
@EntityListeners(AuditingEntityListener.class)
public class DigitalEndowmentAPIDocument {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DE_API_DOC_SEQ")
    @Column(name = "ID", nullable = false)
    private Integer id;

    @Column(name = "TRANSACTION_ID")
    private String transactionID;

    @Column(name = "DP_CUSTOM_ID", nullable = false)
    private String dpCustomID;

    @Column(name = "PROPOSAL_NO")
    private String proposalNo;

    @Column(name = "QUOTATION_DOC", updatable = false)
    @Lob
    @Basic(fetch = FetchType.LAZY)
    @JsonSerialize(using = BlobJsonSerializer.class)
    @JsonDeserialize(using = BlobJsonDeserializer.class)
    private Blob quotationDoc;
    
    @Column(name = "PROPOSAL_DOC")
    @Lob
    @Basic(fetch = FetchType.LAZY)
    @JsonSerialize(using = BlobJsonSerializer.class)
    @JsonDeserialize(using = BlobJsonDeserializer.class)
    private Blob proposalDoc;
    
    @Column(name = "MYINFO_DOC")
    @Lob
    @Basic(fetch = FetchType.LAZY)
    @JsonSerialize(using = BlobJsonSerializer.class)
    @JsonDeserialize(using = BlobJsonDeserializer.class)
    private Blob myInfoDoc;
    
    @Column(name = "POA_DOC", updatable = false)
    @Lob
    @Basic(fetch = FetchType.LAZY)
    @JsonSerialize(using = BlobJsonSerializer.class)
    @JsonDeserialize(using = BlobJsonDeserializer.class)
    private Blob proofOfAddressDoc;

    @Column(name = "CREATED_DATE", nullable = false)
    @CreatedDate
    private Date createDate;

    @Column(name = "UPDATED_DATE")
    @LastModifiedDate
    private Date updatedDate;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTransactionID() {
        return transactionID;
    }

    public void setTransactionID(String transactionID) {
        this.transactionID = transactionID;
    }

    public String getDpCustomID() {
        return dpCustomID;
    }

    public void setDpCustomID(String dpCustomID) {
        this.dpCustomID = dpCustomID;
    }

    public String getProposalNo() {
        return proposalNo;
    }

    public void setProposalNo(String proposalNo) {
        this.proposalNo = proposalNo;
    }

    public Blob getQuotationDoc() {
        return quotationDoc;
    }

    public void setQuotationDoc(Blob quotationDoc) {
        this.quotationDoc = quotationDoc;
    }

    public Blob getProposalDoc() {
        return proposalDoc;
    }

    public void setProposalDoc(Blob proposalDoc) {
        this.proposalDoc = proposalDoc;
    }

	public Blob getMyInfoDoc() {
		return myInfoDoc;
	}

	public void setMyInfoDoc(Blob myInfoDoc) {
		this.myInfoDoc = myInfoDoc;
	}
	
	public Blob getProofOfAddressDoc() {
		return proofOfAddressDoc;
	}

	public void setProofOfAddressDoc(Blob proofOfAddressDoc) {
		this.proofOfAddressDoc = proofOfAddressDoc;
	}

	public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }
}
