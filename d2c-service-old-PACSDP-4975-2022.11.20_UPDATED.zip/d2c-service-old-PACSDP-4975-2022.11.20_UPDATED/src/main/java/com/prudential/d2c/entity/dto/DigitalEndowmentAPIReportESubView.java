package com.prudential.d2c.entity.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

import lombok.Getter;
import lombok.Setter;

@Table(name = "VIEW_REP_DE_API_ESUB")
@Entity
@Immutable
@Setter
@Getter
public class DigitalEndowmentAPIReportESubView {

	@Id
    @Column(name = "AUDIT_ID")
    private Integer auditId;
	
    @Column(name = "CONTRACT_TYPE")
    private String contractType;

    @Column(name = "BUSINESS_SOURCE")
    private String businessSource;

    @Column(name = "FC_CODE")
    private String fcCode;
    
    @Column(name = "EREFERENCE_NUMBER")
    private String ereferenceNumber;

    @Column(name = "SINGLE_PREMIUM")
    private String singlePremium;

    @Column(name = "CREDIT_DATE")
    private String creditDate;

    @Column(name = "CREDIT_TIME")
    private String creditTime;

    @Column(name = "TRANSACTION_STATUS")
    private String transactionStatus;

    @Column(name = "CURRENT_TOTAL_PREM")
    private String currentTotalPrem;

    @Column(name = "TRANCHE_LIMIT")
    private String trancheLimit;

   
}
