package com.prudential.d2c.entity.dto;

import org.hibernate.annotations.Immutable;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Table(name = "VIEW_REP_DE_API_SALES")
@Entity
@Immutable
@Setter
@Getter
public class DigitalEndowmentAPIReportSalesView {

    @Id
    @Column(name = "DP_CUSTOM_ID")
    private String customId;

    @Column(name = "TRANS_ID")
    private String transactionId;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "DATE_CREATED")
    private Date createDate;

    @Column(name = "CHANNEL")
    private String channel;
    
    @Column(name = "SOURCE")
    private String source;

    @Column(name = "NAME")
    private String name;

    @Column(name = "EMAIL")
    private String email;

    @Column(name = "MOBILE")
    private String mobile;

    @Column(name = "NRIC_SUFFIX")
    private String nricSuffix;

    @Column(name = "DOB")
    private String dob;

    @Column(name = "GENDER")
    private String gender;

    @Column(name = "NATIONALITY")
    private String nationality;
    
    @Column(name = "PROD_CODE")
    private String productCode;

    @Column(name = "PROD_NAME")
    private String productName;
    
    @Column(name = "CAMPAIGN_ID")
    private String campaignId;
    
    @Column(name = "EXISTING_CUSTOMER")
    private String existingCustomer;
    
    @Column(name = "APPLICATION_DATE")
    private String applicationDate;

    @Column(name = "PROPOSAL_NO")
    private String proposalNo;

    @Column(name = "EREF_NO")
    private String erefNo;
    
    @Column(name = "PAYMENT_METHOD")
    private String paymentMethod;

    @Column(name = "PREMIUM_AMOUNT")
    private Double premiumAmount;

    @Column(name = "CLIENT_NO")
    private String clientNo;

    @Column(name = "AGENT_CODE")
    private String agentCode;

    @Column(name = "AGENT_NAME")
    private String agentName;

    @Column(name = "AGENT_CONTACT")
    private String agentContact;

    @Column(name = "AGENT_EMAIL")
    private String agentEmail;
    
    @Column(name = "PSA_LSA_AGENT_CODE")
    private String psaLsaAgentCode;
    
    @Column(name = "REFERRAL_AGENT_CODE")
    private String referralAgentCode;
    
    @Column(name = "MARKETING_CONSENT")
    private String marketingConsent;

}
