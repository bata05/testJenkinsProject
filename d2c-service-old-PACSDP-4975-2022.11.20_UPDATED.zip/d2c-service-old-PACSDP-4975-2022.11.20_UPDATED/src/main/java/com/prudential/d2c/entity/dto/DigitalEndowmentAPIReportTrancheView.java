package com.prudential.d2c.entity.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

import lombok.Getter;
import lombok.Setter;

@Table(name = "VIEW_REP_DE_API_TRANCHE")
@Entity
@Immutable
@Setter
@Getter
public class DigitalEndowmentAPIReportTrancheView {

	@Id
    @Column(name = "TRANCHE_ID")
    private Integer trancheId;
	
    @Column(name = "CONTRACT_TYPE")
    private String contractType;

    @Column(name = "CHANNEL")
    private String channel;

    @Column(name = "MAXIMUM_TOTAL_SINGLE_PREMIUM")
    private String maximumTotalSinglePremium;
    
    @Column(name = "CURRENT_TOTAL_SINGLE_PREMIUM")
    private String currentTotalSinglePremium;
   
}
