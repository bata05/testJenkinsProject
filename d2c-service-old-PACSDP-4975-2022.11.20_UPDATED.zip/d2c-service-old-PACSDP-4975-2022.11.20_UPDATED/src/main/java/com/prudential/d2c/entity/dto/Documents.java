package com.prudential.d2c.entity.dto;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import java.sql.Blob;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.prudential.d2c.utils.BlobJsonDeserializer;
import com.prudential.d2c.utils.BlobJsonSerializer;

@Entity
@Table(name = "DOCUMENTS")
@JsonIgnoreProperties(ignoreUnknown = true)
public class Documents {
	@Id
	@Column(name = "custom_id", nullable = false)
	private String customId;
	@Column(name = "product_type", nullable = false)
	private String productType;
	@Column(name = "file1")
	@Lob
	@Basic(fetch = FetchType.LAZY) 
	@JsonSerialize(using=BlobJsonSerializer.class)
	@JsonDeserialize(using=BlobJsonDeserializer.class)
	private Blob file1;
	
	@Column(name = "md5_1")
	private String md51;
	@Column(name = "file2")
	@Lob
	@Basic(fetch = FetchType.LAZY) 
	@JsonSerialize(using=BlobJsonSerializer.class)
	@JsonDeserialize(using=BlobJsonDeserializer.class)
	private Blob file2;
	@Column(name = "md5_2")
	private String md52;

	@Column(name = "file3")
	@Lob
	@Basic(fetch = FetchType.LAZY) 
	@JsonSerialize(using=BlobJsonSerializer.class)
	@JsonDeserialize(using=BlobJsonDeserializer.class)
	private Blob file3;
	@Column(name = "md5_3")
	private String md53;

	@Column(name = "file4")
	@Lob
	@Basic(fetch = FetchType.LAZY) 
	@JsonSerialize(using=BlobJsonSerializer.class)
	@JsonDeserialize(using=BlobJsonDeserializer.class)
	private Blob file4;
	@Column(name = "md5_4")
	private String md54;

	@Column(name = "file5")
	@Lob
	@Basic(fetch = FetchType.LAZY) 
	@JsonSerialize(using=BlobJsonSerializer.class)
	@JsonDeserialize(using=BlobJsonDeserializer.class)
	private Blob file5;
	@Column(name = "md5_5")
	private String md55;

	@Column(name = "file6")
	@Lob
	@Basic(fetch = FetchType.LAZY) 
	@JsonSerialize(using=BlobJsonSerializer.class)
	@JsonDeserialize(using=BlobJsonDeserializer.class)
	private Blob file6;
	@Column(name = "md5_6")
	private String md56;

	@Column(name = "file7")
	@Lob
	@Basic(fetch = FetchType.LAZY) 
	@JsonSerialize(using=BlobJsonSerializer.class)
	@JsonDeserialize(using=BlobJsonDeserializer.class)
	private Blob file7;
	@Column(name = "md5_7")
	private String md57;

	@Column(name = "file8")
	@Lob
	@Basic(fetch = FetchType.LAZY)
	@JsonSerialize(using=BlobJsonSerializer.class)
	@JsonDeserialize(using=BlobJsonDeserializer.class)
	private Blob file8;
	@Column(name = "md5_8")
	private String md58;

	@Column(name = "file9")
	@Lob
	@Basic(fetch = FetchType.LAZY) 
	@JsonSerialize(using=BlobJsonSerializer.class)
	@JsonDeserialize(using=BlobJsonDeserializer.class)
	private Blob file9;
	@Column(name = "md5_9")
	private String md59;

	@Column(name = "file10")
	@Lob
	@Basic(fetch = FetchType.LAZY) 
	@JsonSerialize(using=BlobJsonSerializer.class)
	@JsonDeserialize(using=BlobJsonDeserializer.class)
	private Blob file10;
	@Column(name = "md5_10")
	private String md510;
	
	@JsonIgnore
	@Column(name ="CREATE_DATE")
	private String createDate;

    public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}


	public String getCustomId() {
		return customId;
	}

	public void setCustomId(String customId) {
		this.customId = customId;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public Blob getFile1() {
		return file1;
	}

	public void setFile1(Blob file1) {
		this.file1 = file1;
	}

	public String getMd51() {
		return md51;
	}

	public void setMd51(String md51) {
		this.md51 = md51;
	}

	public Blob getFile2() {
		return file2;
	}

	public void setFile2(Blob file2) {
		this.file2 = file2;
	}

	public String getMd52() {
		return md52;
	}

	public void setMd52(String md52) {
		this.md52 = md52;
	}

	public Blob getFile3() {
		return file3;
	}

	public void setFile3(Blob file3) {
		this.file3 = file3;
	}

	public String getMd53() {
		return md53;
	}

	public void setMd53(String md53) {
		this.md53 = md53;
	}

	public Blob getFile4() {
		return file4;
	}

	public void setFile4(Blob file4) {
		this.file4 = file4;
	}

	public String getMd54() {
		return md54;
	}

	public void setMd54(String md54) {
		this.md54 = md54;
	}

	public Blob getFile5() {
		return file5;
	}

	public void setFile5(Blob file5) {
		this.file5 = file5;
	}

	public String getMd55() {
		return md55;
	}

	public void setMd55(String md55) {
		this.md55 = md55;
	}

	public Blob getFile6() {
		return file6;
	}

	public void setFile6(Blob file6) {
		this.file6 = file6;
	}

	public String getMd56() {
		return md56;
	}

	public void setMd56(String md56) {
		this.md56 = md56;
	}

	public Blob getFile7() {
		return file7;
	}

	public void setFile7(Blob file7) {
		this.file7 = file7;
	}

	public String getMd57() {
		return md57;
	}

	public void setMd57(String md57) {
		this.md57 = md57;
	}

	public Blob getFile8() {
		return file8;
	}

	public void setFile8(Blob file8) {
		this.file8 = file8;
	}

	public String getMd58() {
		return md58;
	}

	public void setMd58(String md58) {
		this.md58 = md58;
	}

	public Blob getFile9() {
		return file9;
	}

	public void setFile9(Blob file9) {
		this.file9 = file9;
	}

	public String getMd59() {
		return md59;
	}

	public void setMd59(String md59) {
		this.md59 = md59;
	}

	public Blob getFile10() {
		return file10;
	}

	public void setFile10(Blob file10) {
		this.file10 = file10;
	}

	public String getMd510() {
		return md510;
	}

	public void setMd510(String md510) {
		this.md510 = md510;
	}

	

}
