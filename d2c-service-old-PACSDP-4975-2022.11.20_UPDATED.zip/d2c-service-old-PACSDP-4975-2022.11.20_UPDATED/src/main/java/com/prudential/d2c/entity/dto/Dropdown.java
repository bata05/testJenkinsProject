package com.prudential.d2c.entity.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="DROPDOWNLIST")
@JsonIgnoreProperties(ignoreUnknown = true)
@IdClass(DropdownPK.class)
public class Dropdown implements Serializable  {
	  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	  @Id
	  @Column(name ="dropdownlist_value", nullable = true)
	  private String value;

	  @Column(name ="dropdownlist_option", nullable = true)
	  private String option;
	  @Id
	  @Column(name ="code", nullable = true)
	  private String code;
	  
	  @Column(name ="sequence", nullable = true)
	  private Integer sequence;
	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}
	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}
	/**
	 * @return the option
	 */
	public String getOption() {
		return option;
	}
	/**
	 * @param option the option to set
	 */
	public void setOption(String option) {
		this.option = option;
	}
	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}
	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}
	

	public Integer getSequence() {
		return sequence;
	}
	public void setSequence(Integer sequence) {
		this.sequence = sequence;
	}
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
	
}
