package com.prudential.d2c.entity.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.apache.commons.lang.builder.ToStringBuilder;

@Entity
@Table(name="EXCEPTION_DATA")
public class ExceptionData {
	
	@Id 
	@SequenceGenerator(name="exceptionid", sequenceName="exceptionid", allocationSize = 1)
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="exceptionid") 
	@Column(name="exception_id",nullable=false)
	  private Integer id;
	
	@Column(name ="exception_request", nullable = true)
	  private String requestURL;
	  @Column(name ="exception_message", nullable = false)
	  private String message;
	  @Column(name ="exception_date", nullable = true)
	  private Date date;
	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * @param message the message to set
	 */
    public void setMessage(String message) {
        if (message.length() >= 2000)
            this.message = message.substring(0, 1999);
        else
            this.message = message;
    }

    /**
	 * @return the date
	 */
	public Date getDate() {
		return date;
	}
	/**
	 * @param date the date to set
	 */
	public void setDate(Date date) {
		this.date = date;
	}
	/**
	 * @return the requestURL
	 */
	public String getRequestURL() {
		return requestURL;
	}
	/**
	 * @param requestURL the requestURL to set
	 */
	public void setRequestURL(String requestURL) {
		this.requestURL = requestURL;
	}
	
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
	

}
