package com.prudential.d2c.entity.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "FAILED_QUESTIONNAIRE_DETAILS")
@SequenceGenerator(name = "FAILED_QUESTIONNAIRE_SEQ", sequenceName = "FAILED_QUESTIONNAIRE_SEQ", allocationSize = 1)
@JsonIgnoreProperties(ignoreUnknown = true)
public class FailedQuestionnaireDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "FAILED_QUESTIONNAIRE_SEQ")
    @Column(name = "id", nullable = false)
    private Long id;

    @Column(name = "custom_id", nullable = false)
    private String customId;

    @Column(name = "product_code", nullable = false)
    private String productCode;

    @Column(name = "questionnaire_id")
    private String questionnaireId;

    @Column(name = "question")
    private String question;

    @Column(name = "parent_question_id")
    private String parentQuestionId;

    @Column(name = "selected_answer")
    private String selectedAnswer;

    @JsonIgnore
    @Column(name = "CREATED_DATE")
    private Date createdDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCustomId() {
        return customId;
    }

    public void setCustomId(String customId) {
        this.customId = customId;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getQuestionnaireId() {
        return questionnaireId;
    }

    public void setQuestionnaireId(String questionnaireId) {
        this.questionnaireId = questionnaireId;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }


    public String getParentQuestionId() {
        return parentQuestionId;
    }

    public void setParentQuestionId(String parentQuestionId) {
        this.parentQuestionId = parentQuestionId;
    }

    public String getSelectedAnswer() {
        return selectedAnswer;
    }

    public void setSelectedAnswer(String selectedAnswer) {
        this.selectedAnswer = selectedAnswer;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    @Override
    public String toString() {
        return "FailedQuestionnaireDetails{" +
                "id='" + id + '\'' +
                ", customId='" + customId + '\'' +
                ", productCode='" + productCode + '\'' +
                ", questionnaireId='" + questionnaireId + '\'' +
                ", question='" + question + '\'' +
                ", parentQuestionId='" + parentQuestionId + '\'' +
                ", selectedAnswer='" + selectedAnswer + '\'' +
                ", createdDate=" + createdDate +
                '}';
    }
}
