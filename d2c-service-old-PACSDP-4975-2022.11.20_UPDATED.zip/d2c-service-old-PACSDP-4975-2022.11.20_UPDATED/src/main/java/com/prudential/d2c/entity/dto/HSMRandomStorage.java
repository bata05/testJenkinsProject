package com.prudential.d2c.entity.dto;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name="HSM_RANDOM_STORAGE")
@JsonIgnoreProperties(ignoreUnknown = true)
public class HSMRandomStorage {
    @Id
    @Column(name ="RANDOM_KEY", nullable = false)
    private String randomKey ;
    @Column(name ="CREATE_DATE", nullable = false)
    private Date createDate;
    @Column(name ="EXPIRED", nullable = false)
    private char expired;


    public String getRandomKey() {
        return randomKey;
    }

    public void setRandomKey(String randomKey) {
        this.randomKey = randomKey;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public char getExpired() {
        return expired;
    }

    public void setExpired(char expired) {
        this.expired = expired;
    }
}
