package com.prudential.d2c.entity.dto;

import lombok.*;
import javax.persistence.*;


import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "LEADS")
public class Leads {
    @Version
    private Integer version;

    @Id
    @Column(name = "ID")
    private String id;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CREATED_TIME")
    private Date createdTime;

    @Column(name = "CHANNEL")
    private String channel;

    @Column(name = "SUB_CHANNEL")
    private String subChannel;

    @Column(name = "NAME")
    private String name;

    @Column(name = "SURNAME")
    private String surName;

    @Column(name = "NRIC_FIN")
    private String nricFin;

    @Column(name = "DOB")
    private String dob;

    @Column(name = "GENDER")
    private String gender;

    @Column(name = "NATIONALITY")
    private String nationality;

    @Column(name = "PROD_CODE")
    private String productCode;

    @Column(name = "PROD_NAME")
    private String productName;

    @Column(name = "CAMPAIGN_ID")
    private String campaignId;

    @Column(name = "NEW_EXT_CUST")
    private String newExtCust;

    @Column(name = "CLIENT_NUMBER")
    private String clientNumber;

    @Column(name = "AGENT_CODE")
    private String agentCode;

    @Column(name = "LSA_AGENT")
    private String lsaAgent;

    @Column(name = "REFERRAL_CODE")
    private String referralCode;

    @Column(name = "REASON")
    private String reason;

    @Column(name = "EMAIL")
    private String email;

    @Column(name = "CONTACT_NUMBER")
    private String contactNumber;

    @Column(name = "PREFERRED_CONTACT_DAY")
    private String preferredContactDay;

    @Column(name = "PREFERRED_CONTACT_TIME")
    private String preferredContactTime;

    @Column(name = "IS_MC_TRIGGERED")
    private boolean isMcTriggered;

    @Column(name = "TRANSACTION_ID")
    private String transactionId;

    @Column(name ="STATUS_CODE", nullable = false)
    private int statusCode;

    @Column(name ="REQUEST_SERVICE_MESSAGE_ID")
    private String requestServiceMessageId;

    @Column(name ="SEND_DATE", nullable = true)
    private Date sendDate;
}
