package com.prudential.d2c.entity.dto;

import org.hibernate.annotations.Immutable;

import javax.persistence.*;
import java.util.Date;

@Table(name = "VIEW_REP_D2C_LEADS_ASSIGNMENT")
@Entity
@Immutable
public class LeadsAssignmentView {

    @Id
    @Column(name = "CUSTOM_ID")
    private String customId;

    @Column(name = "CHANNEL")
    private String channel;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATE_DATE")
    private Date createDate;

    @Column(name = "AGENT_CHANNEL_CODE")
    private String agentChannelCode;

    @Column(name = "SOURCE")
    private String source;

    @Column(name = "CUST_NAME")
    private String customerName;

    @Column(name = "EMAIL")
    private String email;

    @Column(name = "CONTACT_NUMBER")
    private String contactNumber;

    @Column(name = "NRIC_SUFFIX")
    private String nricSuffix;

    @Column(name = "DOB")
    private String dob;

    @Column(name = "GENDER")
    private String gender;

    @Column(name = "NATIONALITY")
    private String nationality;

    @Column(name = "PROD_CODE")
    private String prodCode;

    @Column(name = "PROD_NAME")
    private String prodName;

    @Column(name = "CAMPAIGN_ID")
    private String campaignId;

    @Column(name = "EXISTING_CUSTOMER")
    private String existingCustomer;

    @Column(name = "APPLICATION_DATE")
    private String applicationDate;

    @Column(name = "PREF_CONTACT")
    private String preferedContact;

    @Column(name = "REMARKS")
    private String remarks;

    @Column(name = "CLIENT_NUMBER")
    private String clientNumber;

    @Column(name = "AGENT_CODE")
    private String agentCode;

    @Column(name = "QUERY_STATUS")
    private String queryStatus;

    @Column(name = "SUB_BUSSINES_SOURCE")
    private String subBusinessSource;

    public String getCustomId() {
        return customId;
    }

    public void setCustomId(String customId) {
        this.customId = customId;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getAgentChannelCode() {
        return agentChannelCode;
    }

    public void setAgentChannelCode(String agentChannelCode) {
        this.agentChannelCode = agentChannelCode;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getNricSuffix() {
        return nricSuffix;
    }

    public void setNricSuffix(String nricSuffix) {
        this.nricSuffix = nricSuffix;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public String getProdCode() {
        return prodCode;
    }

    public void setProdCode(String prodCode) {
        this.prodCode = prodCode;
    }

    public String getProdName() {
        return prodName;
    }

    public void setProdName(String prodName) {
        this.prodName = prodName;
    }

    public String getCampaignId() {
        return campaignId;
    }

    public void setCampaignId(String campaignId) {
        this.campaignId = campaignId;
    }

    public String getExistingCustomer() {
        return existingCustomer;
    }

    public void setExistingCustomer(String existingCustomer) {
        this.existingCustomer = existingCustomer;
    }

    public String getApplicationDate() {
        return applicationDate;
    }

    public void setApplicationDate(String applicationDate) {
        this.applicationDate = applicationDate;
    }

    public String getPreferedContact() {
        return preferedContact;
    }

    public void setPreferedContact(String preferedContact) {
        this.preferedContact = preferedContact;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getClientNumber() {
        return clientNumber;
    }

    public void setClientNumber(String clientNumber) {
        this.clientNumber = clientNumber;
    }

    public String getAgentCode() {
        return agentCode;
    }

    public void setAgentCode(String agentCode) {
        this.agentCode = agentCode;
    }

    public String getQueryStatus() {
        return queryStatus;
    }

    public void setQueryStatus(String queryStatus) {
        this.queryStatus = queryStatus;
    }

    public String getSubBusinessSource() {
        return subBusinessSource;
    }

    public void setSubBusinessSource(String subBusinessSource) {
        this.subBusinessSource = subBusinessSource;
    }
}
