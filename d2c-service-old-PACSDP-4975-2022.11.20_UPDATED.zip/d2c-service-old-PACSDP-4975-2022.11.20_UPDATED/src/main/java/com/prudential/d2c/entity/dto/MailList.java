package com.prudential.d2c.entity.dto;

import java.sql.Blob;
import java.util.Date;
import java.util.Objects;
import java.util.UUID;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.prudential.d2c.entity.micro.payload.MicroSelectedProducts;

/**
 *This class is used for email data saving and receiving data from front end,and preparing data before calling agent API 
 *
 */
@Entity
@Table(name="MAIL_LIST")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MailList {
	
	@Id
	@Column(name ="mail_id", nullable = false)
	private String mailId;
	
	@Column(name ="status_code", nullable = false)
	private int statusCode;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name ="create_date", nullable = false)
	private Date createDate;
	
	@Column(name ="given_name", nullable = true)
	private String givenName;
	
	@Column(name ="sur_name", nullable = true)
	private String surName;

    @Column(name ="agent_code", nullable = true)
	private String agentCode;

    @Column(name ="agent_name", nullable = true)
	private String agentName;
	
	@Column(name ="agent_mail", nullable = true)
	private String agentMail;
	
	@Column(name ="agent_mobile", nullable = true)
	private String agentMobile;
	
	@Column(name ="product_name", nullable = false)
	private String productName;
	
	@Column(name ="eref_no", nullable = true)
	private String erefNo;
	
	@Column(name ="stage", nullable = true)
	private String stage;
	
	@Column(name ="phone_no", nullable = true)
	private String mobilePhone;
	
	@Column(name ="age", nullable = true)
	private String age;
	
	@Column(name ="occupation", nullable = true)
	private String occupation;
	
	@Column(name ="nationality", nullable = true)
	private String nationality;

	@Column(name = "residency_status", nullable = true)
	private String residencyStatus;

	@Transient
	private String nationalityName;
	
	@Column(name ="mail_type", nullable = true)
	private String mailType;
	
	@Column(name ="mail_address", nullable = true)
	private String customerEmail;
	
	@Column(name ="is_existing_client", nullable = true)
	private boolean isExistingClient;
	
	@Column(name ="send_date", nullable = true)
	private Date sendDate;

	@Column(name ="nric", nullable = true)
	private String nricFin;

	@Column(name ="nric_suffix", nullable = true)
	private String nricSuffix;
	
	@Column(name = "FILE_LIST")
	@Lob
	@Basic(fetch = FetchType.LAZY) 
	private Blob fileList;
	
	@Column(name ="CUSTOM_ID", nullable = false)
	private String customId;

	@Column(name ="GENDER")
	private String gender;
	@Column(name ="DOB")
	private String dob;
	@Column(name ="HELP_DESCRIPTION")
	private String helpDescription;
	@Column(name ="CONTACT_DAY")
	private String contactDay;
	@Column(name ="CONTACT_TIME")
	private String contactTime;

	@Column(name ="POLICY_NUMBER")
	private String policyNumber;

	@Column(name ="PAYMENT_TYPE")
	private String paymentType;
	
	@Column(name ="REQUEST_SERVICE_MESSAGE_ID")
	private String requestServiceMessageId;
	
	@Column(name ="SERVER_HOST_NAME",nullable = true)
	private String serverHostName;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CUSTOM_ID",insertable = false, updatable = false)
	private CustomerApplication customerApplication;
	
	@Column(name ="AGENT_CHANNEL_CODE")
	private String agentChannelCode;

	@Column(name = "ASSIGN_TO_POOL", nullable = true)
	private String assignedToPool;

	@Column(name = "SERVICING_AGENT_CODE", nullable = true)
	private String saAgentCode;

	@Column(name = "REFERRAL_AGENT_CODE", nullable = true)
	private String referralAgentCode;

	@Column(name = "PHONE_COUNTRY_CODE", nullable = true)
	private String phoneCountryCode;

	@Column(name = "PHONE_IDD", nullable = true)
	private String phoneIDD;

	@Column(name = "IP_ADDRESS", nullable = true)
	private String ipAddress;

	@Column(name = "TYPE_OF_ASSIGNMENT", nullable = true)
	private String typeOfAssignment;

	@Transient
	private String clientNumber;
	
	@Transient
	private String campaignId;
	
	@Transient
	private String productType;

	@Transient
	private String preferredAgentMobile;

	@Transient
	private Boolean assignedAgent;

	@Transient
	private MicroSelectedProducts selectedProducts;
	
    @Transient
    private String channel;

    @Transient
    private boolean isSaleCompleted;
    
	public MailList(String clientNumber,String productType,String channel ,String mailType,String customId,int statusCode,String productName, String campaignId) {
        super();
        this.clientNumber = clientNumber;
        this.productType = productType;
        this.mailType = mailType;
        this.channel = channel;
        this.customId = customId;
        this.statusCode = statusCode;
        this.productName = productName;
        this.campaignId = campaignId;
    }
	public String getMobilePhone() {
        return mobilePhone;
    }

    public void setMobilePhone(String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    public String getCustomerEmail() {
        return customerEmail;
    }

    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }

    public String getNricFin() {
        return nricFin;
    }

    public void setNricFin(String nricFin) {
        this.nricFin = nricFin;
    }

	public String getNricSuffix() {
		return nricSuffix;
	}

	public void setNricSuffix(String nricSuffix) {
		this.nricSuffix = nricSuffix;
	}

    public String getCampaignId() {
		return campaignId;
	}

	public void setCampaignId(String campaignId) {
		this.campaignId = campaignId;
	}
	public String getClientNumber() {
		return clientNumber;
	}

	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}

	/**
	 * @return the mailId
	 */
	public String getMailId() {
		return mailId;
	}

	/**
	 * @param mailId the mailId to set
	 */
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}



	/**
	 * @return the statusCode
	 */
	public int getStatusCode() {
		return statusCode;
	}

	/**
	 * @param statusCode the statusCode to set
	 */
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}


	/**
	 * @return the createDate
	 */
	public Date getCreateDate() {
		return createDate;
	}

	/**
	 * @param createDate the createDate to set
	 */
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	/**
	 * @return the givenName
	 */
	public String getGivenName() {
		return givenName;
	}

	/**
	 * @param givenName the givenName to set
	 */
	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}

	/**
	 * @return the surName
	 */
	public String getSurName() {
		return surName;
	}

	/**
	 * @param surName the surName to set
	 */
	public void setSurName(String surName) {
		this.surName = surName;
	}

	/**
	 * @return the agentName
	 */
	public String getAgentName() {
		return agentName;
	}

	/**
	 * @param agentName the agentName to set
	 */
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	/**
	 * @return the agentMail
	 */
	public String getAgentMail() {
		return agentMail;
	}

	/**
	 * @param agentMail the agentMail to set
	 */
	public void setAgentMail(String agentMail) {
		this.agentMail = agentMail;
	}

	/**
	 * @return the agentMobile
	 */
	public String getAgentMobile() {
		return agentMobile;
	}

	/**
	 * @param agentMobile the agentMobile to set
	 */
	public void setAgentMobile(String agentMobile) {
		this.agentMobile = agentMobile;
	}

	/**
	 * @return the productName
	 */
	public String getProductName() {
		return productName;
	}

	/**
	 * @param productName the productName to set
	 */
	public void setProductName(String productName) {
		this.productName = productName;
	}

	/**
	 * @return the erefNo
	 */
	public String getErefNo() {
		return erefNo;
	}

	/**
	 * @param erefNo the erefNo to set
	 */
	public void setErefNo(String erefNo) {
		this.erefNo = erefNo;
	}

	/**
	 * @return the stage
	 */
	public String getStage() {
		return stage;
	}

	/**
	 * @param stage the stage to set
	 */
	public void setStage(String stage) {
		this.stage = stage;
	}

	/**
	 * @return the age
	 */
	public String getAge() {
		return age;
	}

	/**
	 * @param age the age to set
	 */
	public void setAge(String age) {
		this.age = age;
	}

	/**
	 * @return the occupation
	 */
	public String getOccupation() {
		return occupation;
	}

	/**
	 * @param occupation the occupation to set
	 */
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	/**
	 * @return the nationality
	 */
	public String getNationality() {
		return nationality;
	}

	/**
	 * @param nationality the nationality to set
	 */
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	/**
	 * @return the residencyStatus
	 */
	public String getResidencyStatus() {
		return residencyStatus;
	}

	/**
	 * @param residencyStatus the residencyStatus to set
	 */
	public void setResidencyStatus(String residencyStatus) {
		this.residencyStatus = residencyStatus;
	}

	/**
	 * @return the mailType
	 */
	public String getMailType() {
		return mailType;
	}

	/**
	 * @param mailType the mailType to set
	 */
	public void setMailType(String mailType) {
		this.mailType = mailType;
	}


	
	/**
	 * @return the sendDate
	 */
	public Date getSendDate() {
		return sendDate;
	}

	/**
	 * @param sendDate the sendDate to set
	 */
	public void setSendDate(Date sendDate) {
		this.sendDate = sendDate;
	}


	public Blob getFileList() {
		return fileList;
	}

	public void setFileList(Blob fileList) {
		this.fileList = fileList;
	}

	public String getCustomId() {
		return customId;
	}

	public void setCustomId(String customId) {
		this.customId = customId;
	}

	public String getGender() {
		return gender;
	}

	public String getDob() {
		return dob;
	}

	public String getHelpDescription() {
		return helpDescription;
	}

	public String getContactDay() {
		return contactDay;
	}

	public String getContactTime() {
		return contactTime;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}
	public void setHelpDescription(String helpDescription) {
		this.helpDescription = helpDescription;
	}

	public void setContactDay(String contactDay) {
		this.contactDay = contactDay;
	}

	public void setContactTime(String contactTime) {
		this.contactTime = contactTime;
	}

	public MailList(String erefNo,int statusCode,String customId) {
		super();
		this.mailId =UUID.randomUUID().toString();
		this.statusCode = statusCode;
		this.createDate = new Date();
		this.erefNo = erefNo;
		this.customId = customId;
	}

	public MailList() {

	}

	public boolean getIsExistingClient() {
		return isExistingClient;
	}

	public void setIsExistingClient(boolean isExistingClient) {
		this.isExistingClient = isExistingClient;
	}

	public String getPaymentType() {
		return paymentType;
	}


	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getRequestServiceMessageId() {
		return requestServiceMessageId;
	}

	public void setRequestServiceMessageId(String requestServiceMessageId) {
		this.requestServiceMessageId = requestServiceMessageId;
	}

	public String getAgentCode() {
		return agentCode;
	}

	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public MicroSelectedProducts getSelectedProducts() {
		return selectedProducts;
	}

	public void setSelectedProducts(MicroSelectedProducts selectedProducts) {
		this.selectedProducts = selectedProducts;
	}

	public String getNationalityName() {
		return nationalityName;
	}

	public void setNationalityName(String nationalityName) {
		this.nationalityName = nationalityName;
	}

	public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }
    public String getServerHostName() {
        return serverHostName;
    }
    public void setServerHostName(String serverHostName) {
        this.serverHostName = serverHostName;
    }
 
    public CustomerApplication getCustomerApplication() {
        return customerApplication;
    }
    public void setCustomerApplication(CustomerApplication customerApplication) {
        this.customerApplication = customerApplication;
    }

	public boolean isSaleCompleted() {
		return isSaleCompleted;
	}

	public void setSaleCompleted(boolean saleCompleted) {
		isSaleCompleted = saleCompleted;
	}
	
	public String getAgentChannelCode() { return agentChannelCode; }
	
	public void setAgentChannelCode(String agentChannelCode) { this.agentChannelCode = agentChannelCode; }

	public String getAssignedToPool() {
		return assignedToPool;
	}

	public void setAssignedToPool(String assignedToPool) {
		this.assignedToPool = assignedToPool;
	}

	public String getSaAgentCode() {
		return saAgentCode;
	}

	public void setSaAgentCode(String saAgentCode) {
		this.saAgentCode = saAgentCode;
	}

	public String getReferralAgentCode() {
		return referralAgentCode;
	}

	public void setReferralAgentCode(String referralAgentCode) {
		this.referralAgentCode = referralAgentCode;
	}

	public String getPhoneCountryCode() {
		return phoneCountryCode;
	}

	public void setPhoneCountryCode(String phoneCountryCode) {
		this.phoneCountryCode = phoneCountryCode;
	}

	public String getPhoneIDD() {
		return phoneIDD;
	}

	public void setPhoneIDD(String phoneIDD) {
		this.phoneIDD = phoneIDD;
	}

	public String getIPAddress() {
		return ipAddress;
	}

	public void setIPAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public String getTypeOfAssignment() { return typeOfAssignment; }

	public void setTypeOfAssignment(String typeOfAssignment) { this.typeOfAssignment = typeOfAssignment; }

  public String getPreferredAgentMobile() {
    return preferredAgentMobile;
  }

  public void setPreferredAgentMobile(String preferredAgentMobile) {
    this.preferredAgentMobile = preferredAgentMobile;
  }

	public Boolean isAssignedAgent() {
		return assignedAgent;
	}

	public void setAssignedAgent(Boolean assignedAgent) {
		this.assignedAgent = assignedAgent;
	}

	@Override
	public String toString() {
		return "MailList{" +
					   "mailId='" + mailId + '\'' +
					   ", statusCode=" + statusCode +
					   ", createDate=" + createDate +
					   ", givenName='" + givenName + '\'' +
					   ", surName='" + surName + '\'' +
					   ", agentCode='" + agentCode + '\'' +
					   ", agentName='" + agentName + '\'' +
					   ", agentMail='" + agentMail + '\'' +
					   ", agentMobile='" + agentMobile + '\'' +
					   ", productName='" + productName + '\'' +
					   ", erefNo='" + erefNo + '\'' +
					   ", stage='" + stage + '\'' +
					   ", mobilePhone='" + mobilePhone + '\'' +
					   ", age='" + age + '\'' +
					   ", occupation='" + occupation + '\'' +
					   ", nationality='" + nationality + '\'' +
					   ", nationalityName='" + nationalityName + '\'' +
					   ", mailType='" + mailType + '\'' +
					   ", customerEmail='" + customerEmail + '\'' +
					   ", isExistingClient=" + isExistingClient +
					   ", sendDate=" + sendDate +
					   ", nricFin='" + nricFin + '\'' +
					   ", fileList=" + fileList +
					   ", customId='" + customId + '\'' +
					   ", gender='" + gender + '\'' +
					   ", dob='" + dob + '\'' +
					   ", helpDescription='" + helpDescription + '\'' +
					   ", contactDay='" + contactDay + '\'' +
					   ", contactTime='" + contactTime + '\'' +
					   ", policyNumber='" + policyNumber + '\'' +
					   ", paymentType='" + paymentType + '\'' +
					   ", requestServiceMessageId='" + requestServiceMessageId + '\'' +
					   ", serverHostName='" + serverHostName + '\'' +
					   ", agentChannelCode='" + agentChannelCode + '\'' +
					   ", clientNumber='" + clientNumber + '\'' +
					   ", campaignId='" + campaignId + '\'' +
					   ", productType='" + productType + '\'' +
					   ", channel='" + channel + '\'' +
					   ", isSaleCompleted=" + isSaleCompleted +
						 ", ipAddress=" + ipAddress +
						 ", typeOfAssignment=" + typeOfAssignment +
             ", preferredAgentMobile=" + preferredAgentMobile +
             '}';
	}
	
	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof MailList))
			return false;
		MailList mailList = (MailList) o;
		return getStatusCode() == mailList.getStatusCode() &&
					   isExistingClient == mailList.isExistingClient &&
					   isSaleCompleted() == mailList.isSaleCompleted() &&
					   Objects.equals(getMailId(), mailList.getMailId()) &&
					   Objects.equals(getCreateDate(), mailList.getCreateDate()) &&
					   Objects.equals(getGivenName(), mailList.getGivenName()) &&
					   Objects.equals(getSurName(), mailList.getSurName()) &&
					   Objects.equals(getAgentCode(), mailList.getAgentCode()) &&
					   Objects.equals(getAgentName(), mailList.getAgentName()) &&
					   Objects.equals(getAgentMail(), mailList.getAgentMail()) &&
					   Objects.equals(getAgentMobile(), mailList.getAgentMobile()) &&
					   Objects.equals(getProductName(), mailList.getProductName()) &&
					   Objects.equals(getErefNo(), mailList.getErefNo()) &&
					   Objects.equals(getStage(), mailList.getStage()) &&
					   Objects.equals(getMobilePhone(), mailList.getMobilePhone()) &&
					   Objects.equals(getAge(), mailList.getAge()) &&
					   Objects.equals(getOccupation(), mailList.getOccupation()) &&
					   Objects.equals(getNationality(), mailList.getNationality()) &&
					   Objects.equals(getNationalityName(), mailList.getNationalityName()) &&
					   Objects.equals(getResidencyStatus(), mailList.getResidencyStatus()) &&
					   Objects.equals(getMailType(), mailList.getMailType()) &&
					   Objects.equals(getCustomerEmail(), mailList.getCustomerEmail()) &&
					   Objects.equals(getSendDate(), mailList.getSendDate()) &&
					   Objects.equals(getNricFin(), mailList.getNricFin()) &&
				       Objects.equals(getNricSuffix(), mailList.getNricSuffix()) &&
					   Objects.equals(getFileList(), mailList.getFileList()) &&
					   Objects.equals(getCustomId(), mailList.getCustomId()) &&
					   Objects.equals(getGender(), mailList.getGender()) &&
					   Objects.equals(getDob(), mailList.getDob()) &&
					   Objects.equals(getHelpDescription(), mailList.getHelpDescription()) &&
					   Objects.equals(getContactDay(), mailList.getContactDay()) &&
					   Objects.equals(getContactTime(), mailList.getContactTime()) &&
					   Objects.equals(getPolicyNumber(), mailList.getPolicyNumber()) &&
					   Objects.equals(getPaymentType(), mailList.getPaymentType()) &&
					   Objects.equals(getRequestServiceMessageId(), mailList.getRequestServiceMessageId()) &&
					   Objects.equals(getServerHostName(), mailList.getServerHostName()) &&
					   Objects.equals(getCustomerApplication(), mailList.getCustomerApplication()) &&
					   Objects.equals(getAgentChannelCode(), mailList.getAgentChannelCode()) &&
					   Objects.equals(getClientNumber(), mailList.getClientNumber()) &&
					   Objects.equals(getCampaignId(), mailList.getCampaignId()) &&
					   Objects.equals(getProductType(), mailList.getProductType()) &&
					   Objects.equals(getSelectedProducts(), mailList.getSelectedProducts()) &&
						 Objects.equals(getIPAddress(), mailList.getIPAddress()) &&
						 Objects.equals(getTypeOfAssignment(), mailList.getTypeOfAssignment()) &&
					   Objects.equals(getChannel(), mailList.getChannel());
	}
	
	@Override
	public int hashCode() {
		
		return Objects.hash(getMailId(), getStatusCode(), getCreateDate(), getGivenName(), getSurName(), getAgentCode(), getAgentName(), getAgentMail(), getAgentMobile(), getProductName(), getErefNo(), getStage(), getMobilePhone(), getAge(), getOccupation(), getNationality(), getNationalityName(), getResidencyStatus(), getMailType(), getCustomerEmail(), isExistingClient, getSendDate(), getNricFin(), getNricSuffix(), getFileList(), getCustomId(), getGender(), getDob(), getHelpDescription(), getContactDay(), getContactTime(), getPolicyNumber(), getPaymentType(), getRequestServiceMessageId(), getServerHostName(), getCustomerApplication(), getAgentChannelCode(), getClientNumber(), getCampaignId(), getProductType(), getSelectedProducts(), getChannel(), isSaleCompleted(), getIPAddress(), getTypeOfAssignment());
	}
}
