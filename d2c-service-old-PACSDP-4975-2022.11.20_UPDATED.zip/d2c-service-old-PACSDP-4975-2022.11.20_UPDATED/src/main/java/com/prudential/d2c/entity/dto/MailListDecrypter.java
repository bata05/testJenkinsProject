package com.prudential.d2c.entity.dto;

import com.prudential.d2c.common.ConfigProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import static com.prudential.d2c.utils.DecryptionUtil.decryption;
import static java.util.Optional.of;
import static java.util.Optional.ofNullable;

@Component
public class MailListDecrypter implements Converter<MailList, MailList> {

    static private ConfigProperties configProperties;

    @Autowired
    public void init(ConfigProperties configProperties) {
        MailListDecrypter.configProperties = configProperties;
    }

    @Override
    public MailList convert(MailList mailList) {
        mailList.setGivenName(validateAndDecrypt(mailList.getGivenName()));
        mailList.setSurName(validateAndDecrypt(mailList.getSurName()));
        mailList.setNricFin(validateAndDecrypt(mailList.getNricFin()));
        mailList.setNricSuffix(validateAndDecrypt(mailList.getNricSuffix()));
        mailList.setMobilePhone(validateAndDecrypt(mailList.getMobilePhone()));
        mailList.setPhoneCountryCode(validateAndDecrypt(mailList.getPhoneCountryCode()));
        mailList.setPhoneIDD(validateAndDecrypt(mailList.getPhoneIDD()));
        mailList.setCustomerEmail(validateAndDecrypt(mailList.getCustomerEmail()));
        return mailList;
    }



    @SuppressWarnings("deprecation")
	@Cacheable(cacheNames = "CUSTOMER_APP_INFO_DECRYPTED", key = "#value")
    public String validateAndDecrypt(String value) {

        return ofNullable(value)
                .filter(v -> !StringUtils.isEmpty(v))
                .map(s -> of(s).filter(r -> r.length() > 200)
                        .map(this::decrypt)
                        .orElseThrow(IllegalArgumentException::new))
                .orElse("");

    }

    public String decrypt(String val){
        return decryption(val,configProperties);
    }
}
