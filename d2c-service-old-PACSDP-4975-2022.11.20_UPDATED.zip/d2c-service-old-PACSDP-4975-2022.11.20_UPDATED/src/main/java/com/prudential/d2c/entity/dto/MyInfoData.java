package com.prudential.d2c.entity.dto;

import java.util.Date;

import javax.persistence.*;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name = "MYINFO_DATA")
@SequenceGenerator(name = "MYINFO_DATA_SEQ", sequenceName = "MYINFO_DATA_SEQ", allocationSize = 1)
@EntityListeners(AuditingEntityListener.class)
public class MyInfoData {

	@Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "MYINFO_DATA_SEQ")
    @Column(name = "ID", nullable = false)
    private Integer id;
	
	@Column(name = "EREF_NO", nullable = false)
    private String eref;

    @Column(name = "UINFIN")
    private String uinfin;
    
    @Column(name = "NRIC_SUFFIX")
    private String nricSuffix;
    
	@Column(name = "NAME")
    private String name;

    @Column(name = "SEX")
    private String sex;
    
    @Column(name = "NATIONALITY")
    private String nationality;

    @Column(name = "DOB")
    private String dob;
    
    @Column(name = "EMAIL")
    private String email;

    @Column(name = "MOBILE_NO")
    private String mobileNo;

    @Column(name = "REG_ADD")
    private String regAdd;
    
    @Column(name = "PASS_TYPE")
    private String passType;
    
    @Column(name = "PASS_EXPIRY_DATE")
    private String passExpiryDate;
    
    @Column(name = "PASS_STATUS")
    private String passStatus;

    @Column(name = "RESIDENTIAL_STATUS")
    private String residentialStatus;
    
    @Column(name = "INDICATOR")
    private String indicator;
    
    @Column(name = "STATUS")
    private String status;
    
    @Column(name = "TRANS_DATE")
    private String transDate;

    @Column(name = "CREATED_DATE", nullable = false)
    @CreatedDate
    private Date createDate;

    @Column(name = "UPDATED_DATE")
    @LastModifiedDate
    private Date updatedDate;
    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
    
	public String getEref() {
		return eref;
	}

	public void setEref(String eref) {
		this.eref = eref;
	}

	public String getUinfin() {
		return uinfin;
	}

	public void setUinfin(String uinfin) {
		this.uinfin = uinfin;
	}
	
	public String getNricSuffix() {
		return nricSuffix;
	}
	
	public void setNricSuffix(String nricSuffix) {
		this.nricSuffix = nricSuffix;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getRegAdd() {
		return regAdd;
	}

	public void setRegAdd(String regAdd) {
		this.regAdd = regAdd;
	}

	public String getPassType() {
		return passType;
	}

	public void setPassType(String passType) {
		this.passType = passType;
	}

	public String getPassExpiryDate() {
		return passExpiryDate;
	}

	public void setPassExpiryDate(String passExpiryDate) {
		this.passExpiryDate = passExpiryDate;
	}

	public String getPassStatus() {
		return passStatus;
	}

	public void setPassStatus(String passStatus) {
		this.passStatus = passStatus;
	}

	public String getResidentialStatus() {
		return residentialStatus;
	}

	public void setResidentialStatus(String residentialStatus) {
		this.residentialStatus = residentialStatus;
	}
	
	public String getIndicator() {
		return indicator;
	}

	public void setIndicator(String indicator) {
		this.indicator = indicator;
	}
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTransDate() {
		return transDate;
	}

	public void setTransDate(String transDate) {
		this.transDate = transDate;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
}