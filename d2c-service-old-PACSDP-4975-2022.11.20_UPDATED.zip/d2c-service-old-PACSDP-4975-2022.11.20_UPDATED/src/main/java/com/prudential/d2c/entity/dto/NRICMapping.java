package com.prudential.d2c.entity.dto;

import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;


import javax.persistence.*;
import javax.transaction.Transactional;
import java.util.Date;

@Transactional
@Entity
@Builder @Data @AllArgsConstructor @NoArgsConstructor
@Table(name="NRIC_CUSTOMID_MAPPING")
@EntityListeners(AuditingEntityListener.class)
public class NRICMapping {

    @Column(name ="CUSTOM_ID", nullable = false, unique = true)
    private @NonNull @Id String customId;

    @Column(name ="NRIC_FIN", nullable = false)
    private @NonNull String nricFin;

    @CreatedDate
    @Column(name="CREATED_DATE", nullable = false)
    private Date createdDate;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CUSTOM_ID",insertable = false, updatable = false)
    private CustomerApplication customerApplication;
}
