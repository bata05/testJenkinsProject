package com.prudential.d2c.entity.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.prudential.d2c.entity.NeedsAnalysisRequest;
import com.prudential.d2c.utils.BlobJsonDeserializer;
import com.prudential.d2c.utils.BlobJsonSerializer;
import com.prudential.d2c.utils.D2CUtils;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.sql.Blob;

@Entity
@Table(name="NEEDS_ANALYSIS")
@JsonIgnoreProperties(ignoreUnknown = true)
@EntityListeners(AuditingEntityListener.class)
public class NeedsAnalysis {

  @Id
  @Column(name ="custom_id", nullable = false)
  private String customId;
  @Column(name ="needs_payload", nullable = false)
  @Lob
  @Basic(fetch = FetchType.LAZY)
  @JsonSerialize(using = BlobJsonSerializer.class)
  @JsonDeserialize(using = BlobJsonDeserializer.class)
  private Blob needsPayload;
  @Column(name ="monthly_budget", nullable = true)
  private double monthlyBudget;
  @Column(name ="recommended_product_payload", nullable = true)
  @Lob
  @Basic(fetch = FetchType.LAZY)
  @JsonSerialize(using = BlobJsonSerializer.class)
  @JsonDeserialize(using = BlobJsonDeserializer.class)
  private Blob recommendedProductPayload;

  public NeedsAnalysis() {
  }

  public NeedsAnalysis(NeedsAnalysisRequest needsAnalysisRequest) {
    this.customId = needsAnalysisRequest.getCustomId();
    this.monthlyBudget = needsAnalysisRequest.getMonthlyBudget();
    if (needsAnalysisRequest.getRecommendedProductPayload() != null) {
      this.recommendedProductPayload = D2CUtils.getJsonBlob(needsAnalysisRequest.getRecommendedProductPayload());
    }
    if (needsAnalysisRequest.getNeedsAnalysisPayload() != null) {
      this.needsPayload = D2CUtils.getJsonBlob(needsAnalysisRequest.getNeedsAnalysisPayload());
    }
  }

  public String getCustomId() {
    return customId;
  }

  public void setCustomId(String customId) {
    this.customId = customId;
  }

  public Blob getNeedsPayload() {
    return needsPayload;
  }

  public void setNeedsPayload(Blob needsPayload) {
    this.needsPayload = needsPayload;
  }

  public double getMonthlyBudget() {
    return monthlyBudget;
  }

  public void setMonthlyBudget(double monthlyBudget) {
    this.monthlyBudget = monthlyBudget;
  }

  public Blob getRecommendedProductPayload() {
    return recommendedProductPayload;
  }

  public void setRecommendedProductPayload(Blob recommendedProductPayload) {
    this.recommendedProductPayload = recommendedProductPayload;
  }
}
