package com.prudential.d2c.entity.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="OCCUPATION")
@JsonIgnoreProperties(ignoreUnknown = true)
public class Occupation {
	
	@Id
	  @Column(name ="code", nullable = false)
	  private String code;
	
	@Column(name ="class", nullable = false)
	  private String classOccupation;
	@Column(name ="description", nullable = false)
	  private String description;
	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}
	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @return the classOccupation
	 */
	public String getClassOccupation() {
		return classOccupation;
	}
	/**
	 * @param classOccupation the classOccupation to set
	 */
	public void setClassOccupation(String classOccupation) {
		this.classOccupation = classOccupation;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
	

}
