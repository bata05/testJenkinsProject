package com.prudential.d2c.entity.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name="PGP_ORDERS")
public class PgpOrders {
	@Id
	@Column(name ="custom_id", nullable = false)
    private String customId;
	@Column(name ="CURRENCY", nullable = false)
	private String currency;
	@Column(name ="CHANNEL", nullable = false)
    private String channel;
	@Column(name ="AMOUNT")
    private String amount;
	@Column(name ="EREF_NO")
    private String erefNo;
	public String getCurrency() {
		return currency;
	}
	public String getAmount() {
		return amount;
	}
	public String getCustomId() {
		return customId;
	}
	public String getChannel() {
		return channel;
	}
	public String getErefNo() {
		return erefNo;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public void setCustomId(String customId) {
		this.customId = customId;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public void setErefNo(String erefNo) {
		this.erefNo = erefNo;
	}
   
}
