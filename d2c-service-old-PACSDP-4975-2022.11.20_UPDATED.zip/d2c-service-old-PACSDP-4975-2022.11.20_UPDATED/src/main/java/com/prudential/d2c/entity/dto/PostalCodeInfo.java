package com.prudential.d2c.entity.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang.builder.ToStringBuilder;

@Entity
@Table(name = "POSTAL_CODE")
public class PostalCodeInfo {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "postalcode", nullable = false)
    private String postalCode;

    @Column(name = "streetname", nullable = true)
    private String streetName;

    @Column(name = "serviceno", nullable = true)
    private String serviceNo;

    @Column(name = "buildingname", nullable = true)
    private String buildingName;

    @Column(name = "blockno", nullable = true)
    private String blockNo;

    @Column(name = "addresstype", nullable = true)
    private String addressType;



    public String getStreetName() {
        return streetName == null ? "" : streetName;
    }

    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    public String getServiceNo() {
        return serviceNo == null ? "" : serviceNo;
    }

    public void setServiceNo(String serviceNo) {
        this.serviceNo = serviceNo;
    }

    public String getBuildingName() {
        return buildingName == null ? "" : buildingName;
    }

    public void setBuildingName(String buildingName) {
        this.buildingName = buildingName;
    }

    public String getBlockNo() {
        return blockNo == null ? "" : blockNo;
    }

    public void setBlockNo(String blockNo) {
        this.blockNo = blockNo;
    }

    public String getAddressType() {
        return addressType;
    }

    public void setAddressType(String addressType) {
        this.addressType = addressType;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

}
