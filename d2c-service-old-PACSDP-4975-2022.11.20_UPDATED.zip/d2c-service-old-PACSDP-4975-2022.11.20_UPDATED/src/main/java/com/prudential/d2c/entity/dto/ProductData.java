package com.prudential.d2c.entity.dto;


public class ProductData {

    String productCodes;
    String productNames;
    String componentCodes;
    String componentNames;
    private double totalPremium;

    public String getProductCodes() {
        return productCodes;
    }

    public void setProductCodes(String productCodes) {
        this.productCodes = productCodes;
    }

    public String getProductNames() {
        return productNames;
    }

    public void setProductNames(String productNames) {
        this.productNames = productNames;
    }

    public String getComponentCodes() {
        return componentCodes;
    }

    public void setComponentCodes(String componentCodes) {
        this.componentCodes = componentCodes;
    }

    public String getComponentNames() {
        return componentNames;
    }

    public void setComponentNames(String componentNames) {
        this.componentNames = componentNames;
    }

    public double getTotalPremium() {
        return totalPremium;
    }

    public void setTotalPremium(double totalPremium) {
        this.totalPremium = totalPremium;
    }
}
