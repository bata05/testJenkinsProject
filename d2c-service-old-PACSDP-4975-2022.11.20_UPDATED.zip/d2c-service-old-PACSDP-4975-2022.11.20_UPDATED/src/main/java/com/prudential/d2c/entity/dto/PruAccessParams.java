package com.prudential.d2c.entity.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name="PRUACCESS_PARAMS")
@JsonIgnoreProperties(ignoreUnknown = true)
public class PruAccessParams {
    @Id
    @Column(name ="UNIQUE_ID", nullable = false)
    private String uniqueID ;
    @Column(name ="PARAM1", nullable = false)
    private String param1;
    @Column(name ="PARAM2", nullable = false)
    private String param2;
    @Column(name ="CREATE_DATE", nullable = false)
    private Date createDate;
    @Column(name ="EXPIRED", nullable = false)
    private char expired;

    public String getUniqueID() {
        return uniqueID;
    }

    public void setUniqueID(String uniqueID) {
        this.uniqueID = uniqueID;
    }

    public String getParam1() {
        return param1;
    }

    public void setParam1(String param1) {
        this.param1 = param1;
    }

    public String getParam2() {
        return param2;
    }

    public void setParam2(String param2) {
        this.param2 = param2;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public char getExpired() {
        return expired;
    }

    public void setExpired(char expired) {
        this.expired = expired;
    }
}
