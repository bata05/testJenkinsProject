package com.prudential.d2c.entity.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="MOBILE_COUNTRY_MAPPING")
@JsonIgnoreProperties(ignoreUnknown = true)
public class PruforceCountryCode implements Serializable{

	private static final long serialVersionUID = 6146700055490963940L;

	@Id
    @Column(name="COUNTRY_NAME", nullable=false)
    private String country;

    @Column(name="CODE_NUMBER", nullable=false)
    private String codeNumber;

    @Column(name="COUNTRY_CODE", nullable=false)
    private String countryCode;

    @Column(name="REGION_CODE", nullable=false)
    private String regionCode;

    /**
     * @return the country
     */
    public String getCountry() {
        return country;
    }

    /**
     * @return the code number
     */
    public String getCodeNumber() {
        return codeNumber;
    }

    /**
     * @return the country code
     */
    public String getCountryCode() {
        return countryCode;
    }

    /**
     * @return the country code
     */
    public String getRegionCode() {
        return regionCode;
    }
}
