package com.prudential.d2c.entity.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang.builder.ToStringBuilder;


@Entity
@Table(name="QUOTATION")
public class Quotation {

	@Id @GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name ="quotation_id", nullable = false)
	  private Integer id;

	  @Column(name ="quotation_class", nullable = true)
	  private String occupationClass;
	  
	  @Column(name ="quotation_sum", nullable = true)
	  private String sumAssured;
	  
	  @Column(name ="quotation_main", nullable = true)
	  private String mainValue;
	  
	  @Column(name ="quotation_main2", nullable = true)
	  private String mainValue2;
	  
	  @Column(name ="quotation_plan", nullable = true)
	  private String plan;
	  
	  @Column(name ="quotation_type", nullable = true)
	  private String type;
	  
	  @Column(name ="quotation_age_start", nullable = true)
	  private Integer firstAge;
	  
	  @Column(name ="quotation_age_end", nullable = true)
	  private Integer lastAge;
	  
	  @Column(name ="quotation_residency", nullable = true)
	  private String residency;


	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the occupationClass
	 */
	public String getOccupationClass() {
		return occupationClass;
	}

	/**
	 * @param occupationClass the occupationClass to set
	 */
	public void setOccupationClass(String occupationClass) {
		this.occupationClass = occupationClass;
	}

	/**
	 * @return the sumAssured
	 */
	public String getSumAssured() {
		return sumAssured;
	}

	/**
	 * @param sumAssured the sumAssured to set
	 */
	public void setSumAssured(String sumAssured) {
		this.sumAssured = sumAssured;
	}

	/**
	 * @return the mainValue
	 */
	public String getMainValue() {
		return mainValue;
	}

	/**
	 * @param mainValue the mainValue to set
	 */
	public void setMainValue(String mainValue) {
		this.mainValue = mainValue;
	}

	/**
	 * @return the mainValue2
	 */
	public String getMainValue2() {
		return mainValue2;
	}

	/**
	 * @param mainValue2 the mainValue2 to set
	 */
	public void setMainValue2(String mainValue2) {
		this.mainValue2 = mainValue2;
	}

	/**
	 * @return the plan
	 */
	public String getPlan() {
		return plan;
	}

	/**
	 * @param plan the plan to set
	 */
	public void setPlan(String plan) {
		this.plan = plan;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}



	/**
	 * @return the firstAge
	 */
	public Integer getFirstAge() {
		return firstAge;
	}

	/**
	 * @param firstAge the firstAge to set
	 */
	public void setFirstAge(Integer firstAge) {
		this.firstAge = firstAge;
	}

	/**
	 * @return the lastAge
	 */
	public Integer getLastAge() {
		return lastAge;
	}

	/**
	 * @param lastAge the lastAge to set
	 */
	public void setLastAge(Integer lastAge) {
		this.lastAge = lastAge;
	}

	/**
	 * @return the residency
	 */
	public String getResidency() {
		return residency;
	}

	/**
	 * @param residency the residency to set
	 */
	public void setResidency(String residency) {
		this.residency = residency;
	}

	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
	
	
 
}
