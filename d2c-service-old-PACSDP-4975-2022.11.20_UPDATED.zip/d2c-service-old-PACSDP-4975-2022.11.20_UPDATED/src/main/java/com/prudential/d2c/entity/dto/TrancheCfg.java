package com.prudential.d2c.entity.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "TRANCHE_CFG")
@SequenceGenerator(name = "TRANCHE_CFG_SEQ", sequenceName = "TRANCHE_CFG_SEQ", allocationSize = 1)
@EntityListeners(AuditingEntityListener.class)
@Getter
@Setter
public class TrancheCfg {
	
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TRANCHE_CFG_SEQ")
    @Column(name = "ID", nullable = false)
    private Integer id;

    @Column(name = "COV_GRP_CODE", nullable = false)
    private String covGrpCode;

    @Column(name = "COMPONENT_CODE", nullable = false)
    private String componentCode;
    
    @Column(name = "CHANNEL_CODE", nullable = false)
    private String channelCode;
    
    @Column(name = "TRANCHE_GROUP")
    private String trancheGroup;
   
    @Column(name = "SUBMITTED_CUMULATIVE_TOTAL")
    private Double submittedCumulativeTotal;
    
    @Column(name = "START_DATE", nullable = false)
    private Date startDate;

    @Column(name = "END_DATE", nullable = false)
    private Date endDate;
     
    @Column(name = "CREATED_DATE", nullable = false)
    @CreatedDate
    private Date createDate;

    @Column(name = "UPDATED_DATE")
    @LastModifiedDate
    private Date updatedDate;
    
    @Column(name = "STATUS")
    private String status;
    

}
