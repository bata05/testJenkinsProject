package com.prudential.d2c.entity.dto;

import java.sql.Blob;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.prudential.d2c.utils.BlobJsonDeserializer;
import com.prudential.d2c.utils.BlobJsonSerializer;


@Entity
@Table(name = "TRANS_CUST_APPLICATION")
@EntityListeners(AuditingEntityListener.class)
public class TransactionalCustomerApplication {

    @Id
    @SequenceGenerator(name = "tranCustAppSeq", sequenceName = "CUSTAPPINDEX", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "tranCustAppSeq")
    @Column(name = "ID_NO", nullable = false)
    private Integer idNo;

    @Column(name = "CUSTOM_ID", nullable = false)
    private String custId;

    @Column(name = "PRODUCT_OBJ")
    @Lob
    @Basic(fetch = FetchType.LAZY)
    @JsonSerialize(using = BlobJsonSerializer.class)
    @JsonDeserialize(using = BlobJsonDeserializer.class)
    private Blob productObj;

    @Column(name = "CLIENT_OBJ")
    @Lob
    @Basic(fetch = FetchType.LAZY)
    @JsonSerialize(using = BlobJsonSerializer.class)
    @JsonDeserialize(using = BlobJsonDeserializer.class)
    private Blob clientObj;

    @Column(name = "COMPUTE_OBJ")
    @Lob
    @Basic(fetch = FetchType.LAZY)
    @JsonSerialize(using = BlobJsonSerializer.class)
    @JsonDeserialize(using = BlobJsonDeserializer.class)
    private Blob computeObj;

    @Column(name = "COMPUTE_ALL_OBJ")
    @Lob
    @Basic(fetch = FetchType.LAZY)
    @JsonSerialize(using = BlobJsonSerializer.class)
    @JsonDeserialize(using = BlobJsonDeserializer.class)
    private Blob computeAllObj;

    @Column(name = "PROD_CODE")
    private String productCodes;

    @Column(name = "PROD_DES")
    private String productNames;

    @Column(name = "COMP_CODE")
    private String componentCodes;

    @Column(name = "COMP_DES")
    private String cetComponentNames;

    @Column(name = "TOT_PREMIUM")
    private Double totalPremium;

    @Column(name = "CREATED_DATE")
    @CreatedDate
    private Date createDate;

    public Integer getIdNo() {
        return idNo;
    }

    public void setIdNo(Integer idNo) {
        this.idNo = idNo;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getCustId() {
        return custId;
    }

    public void setCustId(String custId) {
        this.custId = custId;
    }

    public Blob getProductObj() {
        return productObj;
    }

    public void setProductObj(Blob productObj) {
        this.productObj = productObj;
    }

    public Blob getClientObj() {
        return clientObj;
    }

    public void setClientObj(Blob clientObj) {
        this.clientObj = clientObj;
    }

    public Blob getComputeObj() {
        return computeObj;
    }

    public void setComputeObj(Blob computeObj) {
        this.computeObj = computeObj;
    }

    public Blob getComputeAllObj() {
        return computeAllObj;
    }

    public void setComputeAllObj(Blob computeAllObj) {
        this.computeAllObj = computeAllObj;
    }

    public String getProductCodes() {
        return productCodes;
    }

    public void setProductCodes(String productCodes) {
        this.productCodes = productCodes;
    }

    public String getProductNames() {
        return productNames;
    }

    public void setProductNames(String productNames) {
        this.productNames = productNames;
    }

    public String getComponentCodes() {
        return componentCodes;
    }

    public void setComponentCodes(String componentCodes) {
        this.componentCodes = componentCodes;
    }

    public String getCetComponentNames() {
        return cetComponentNames;
    }

    public void setCetComponentNames(String cetComponentNames) {
        this.cetComponentNames = cetComponentNames;
    }

    public Double getTotalPremium() {
        return totalPremium;
    }

    public void setTotalPremium(Double totalPremium) {
        this.totalPremium = totalPremium;
    }

}
