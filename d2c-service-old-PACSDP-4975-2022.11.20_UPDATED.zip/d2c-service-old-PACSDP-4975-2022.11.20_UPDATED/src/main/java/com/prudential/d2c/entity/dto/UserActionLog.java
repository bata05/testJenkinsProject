package com.prudential.d2c.entity.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name = "USER_ACTION_LOG")
public class UserActionLog implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "actionid", sequenceName = "actionid", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "actionid")
    @Column(name = "ACTION_ID", nullable = false)
    private Long actionId;

    @Column(name = "TRANSACTION_ID", nullable = false)
    private String transactionId;

    @Column(name = "CLIENT_NUMBER")
    private String clientNumber;

    @Column(name = "PRODUCT_TYPE")
    private String productType;

    @Column(name = "ACTION_NAME")
    private String actionName;

    @Column(name = "ACTION_TIME")
    private Date actionTime;

    /**
     * @return the actionId
     */
    public Long getActionId() {
        return actionId;
    }

    /**
     * @param actionId the actionId to set
     */
    public void setActionId(Long actionId) {
        this.actionId = actionId;
    }

    /**
     * @return the transactionId
     */
    public String getTransactionId() {
        return transactionId;
    }

    /**
     * @param transactionId the transactionId to set
     */
    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    /**
     * @return the clientNumber
     */
    public String getClientNumber() {
        return clientNumber;
    }

    /**
     * @param clientNumber the clientNumber to set
     */
    public void setClientNumber(String clientNumber) {
        this.clientNumber = clientNumber;
    }

    /**
     * @return the productType
     */
    public String getProductType() {
        return productType;
    }

    /**
     * @param productType the productType to set
     */
    public void setProductType(String productType) {
        this.productType = productType;
    }

    /**
     * @return the actionName
     */
    public String getActionName() {
        return actionName;
    }

    /**
     * @param actionName the actionName to set
     */
    public void setActionName(String actionName) {
        this.actionName = actionName;
    }

    /**
     * @return the actionTime
     */
    public Date getActionTime() {
        return actionTime;
    }

    /**
     * @param date the actionTime to set
     */
    public void setActionTime(Date date) {
        this.actionTime = date;
    }


}
