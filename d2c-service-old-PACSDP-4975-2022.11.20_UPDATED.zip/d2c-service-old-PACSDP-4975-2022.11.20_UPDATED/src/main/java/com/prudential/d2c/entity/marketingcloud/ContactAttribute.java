package com.prudential.d2c.entity.marketingcloud;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ContactAttribute {
	private String name;
	private List<ContactItem> items;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<ContactItem> getItems() {
		return items;
	}
	public void setItems(List<ContactItem> items) {
		this.items = items;
	}
	
	
}
