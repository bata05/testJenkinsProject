package com.prudential.d2c.entity.marketingcloud;

import java.util.List;

public class ContactItem {
	private List<ContactValue> values;

	public List<ContactValue> getValues() {
		return values;
	}

	public void setValues(List<ContactValue> values) {
		this.values = values;
	}
	
}
