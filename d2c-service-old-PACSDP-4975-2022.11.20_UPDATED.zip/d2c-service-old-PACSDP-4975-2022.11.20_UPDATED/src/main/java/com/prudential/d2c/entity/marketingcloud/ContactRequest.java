package com.prudential.d2c.entity.marketingcloud;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ContactRequest {
	private String contactKey;
	private List<ContactAttribute> attributeSets;
	
	public String getContactKey() {
		return contactKey;
	}
	public void setContactKey(String contactKey) {
		this.contactKey = contactKey;
	}
	public List<ContactAttribute> getAttributeSets() {
		return attributeSets;
	}
	public void setAttributeSets(List<ContactAttribute> attributeSets) {
		this.attributeSets = attributeSets;
	}
	
	
}
