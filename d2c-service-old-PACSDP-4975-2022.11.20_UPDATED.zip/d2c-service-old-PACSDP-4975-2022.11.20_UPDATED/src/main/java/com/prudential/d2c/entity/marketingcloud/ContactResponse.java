package com.prudential.d2c.entity.marketingcloud;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ContactResponse {
	private String operationStatus;
	private int rowsAffected;
	private String contactKey;
	private int contactID;
	private int contactTypeID;
	private boolean isNewContactKey;
	private String requestServiceMessageID;
	private String responseDateTime;
	private boolean hasErrors;
	private String[] resultMessages;
	private String serviceMessageID;
	/**
	 * @return the operationStatus
	 */
	public String getOperationStatus() {
		return operationStatus;
	}
	/**
	 * @param operationStatus the operationStatus to set
	 */
	public void setOperationStatus(String operationStatus) {
		this.operationStatus = operationStatus;
	}
	/**
	 * @return the rowsAffected
	 */
	public int getRowsAffected() {
		return rowsAffected;
	}
	/**
	 * @param rowsAffected the rowsAffected to set
	 */
	public void setRowsAffected(int rowsAffected) {
		this.rowsAffected = rowsAffected;
	}
	/**
	 * @return the contactKey
	 */
	public String getContactKey() {
		return contactKey;
	}
	/**
	 * @param contactKey the contactKey to set
	 */
	public void setContactKey(String contactKey) {
		this.contactKey = contactKey;
	}
	/**
	 * @return the contactID
	 */
	public int getContactID() {
		return contactID;
	}
	/**
	 * @param contactID the contactID to set
	 */
	public void setContactID(int contactID) {
		this.contactID = contactID;
	}
	/**
	 * @return the contactTypeID
	 */
	public int getContactTypeID() {
		return contactTypeID;
	}
	/**
	 * @param contactTypeID the contactTypeID to set
	 */
	public void setContactTypeID(int contactTypeID) {
		this.contactTypeID = contactTypeID;
	}
	/**
	 * @return the isNewContactKey
	 */
	public boolean isNewContactKey() {
		return isNewContactKey;
	}
	/**
	 * @param isNewContactKey the isNewContactKey to set
	 */
	public void setNewContactKey(boolean isNewContactKey) {
		this.isNewContactKey = isNewContactKey;
	}
	/**
	 * @return the requestServiceMessageID
	 */
	public String getRequestServiceMessageID() {
		return requestServiceMessageID;
	}
	/**
	 * @param requestServiceMessageID the requestServiceMessageID to set
	 */
	public void setRequestServiceMessageID(String requestServiceMessageID) {
		this.requestServiceMessageID = requestServiceMessageID;
	}
	/**
	 * @return the responseDateTime
	 */
	public String getResponseDateTime() {
		return responseDateTime;
	}
	/**
	 * @param responseDateTime the responseDateTime to set
	 */
	public void setResponseDateTime(String responseDateTime) {
		this.responseDateTime = responseDateTime;
	}
	/**
	 * @return the hasErrors
	 */
	public boolean isHasErrors() {
		return hasErrors;
	}
	/**
	 * @param hasErrors the hasErrors to set
	 */
	public void setHasErrors(boolean hasErrors) {
		this.hasErrors = hasErrors;
	}
	/**
	 * @return the resultMessages
	 */
	public String[] getResultMessages() {
		return resultMessages;
	}
	/**
	 * @param resultMessages the resultMessages to set
	 */
	public void setResultMessages(String[] resultMessages) {
		this.resultMessages = resultMessages;
	}
	/**
	 * @return the serviceMessageID
	 */
	public String getServiceMessageID() {
		return serviceMessageID;
	}
	/**
	 * @param serviceMessageID the serviceMessageID to set
	 */
	public void setServiceMessageID(String serviceMessageID) {
		this.serviceMessageID = serviceMessageID;
	}
	
	
}
