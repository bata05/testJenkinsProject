package com.prudential.d2c.entity.marketingcloud;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
/**
 * Object of request data send to sales force.
 * 
 * Coding style is not followed for some properties in this POJO since below reason:
 * The third party service salesforce only accepts the name with style they used.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class EventData {
	private String txtGender;
	private String txtLastName;
	private String txtFirstName;
	private String txtNRIC;
	private String txtDob;
	private String txtMobileNumber;
	private String txtCountryCode;
	private String txtNext;
	private String isAssignConsultant;
	private String txtNationality;
	private String QMAY001;
	
	private String QMAY003A;
	private String QMAY003B;
	private String QMAY003C;
	
	private String QMAY004;
	private String txtResidentialPostalCode;
	private String txtMailingPostalCode;
	private String txtResidentialBlockNo;
	private String txtResidentialStreet;
	private String txtResidentialBuilding;
	private String txtResidentialUnitNo;
	private String QMAY010;
	private String QMAY011;
	private String txtMailingBlockNo;
	private String txtMailingStreet;
	private String txtMailingBuilding;
	private String txtMailingUnitNo;
	private String txtMailingCountry;
	private String txtEmail;
	private String QMAY018;
	
	private String QMAY019;
	private String QMAY01901;
	private String QMAY01902;
	private String QMAY01903;
	private String QMAY01904;
	
	private String QMAY021;
	private String QMAY02101;
	private String QMAY0210101;
	private String QMAY0210102;
	private String QMAY0210103;
	private String QMAY0210104;
	private String QMAY0210105;
	private String QMAY0210106;
	private String QMAY02102;
	private String QMAY02103;
	private String QMAY02104;
	private String QMAY02105;
	private String QMAY02106;
	private String QMAY02107;
	private String QMAY02108;
	private String QMAY02109;
	private String QMAY02110;
	
	private String txtAnnualIncome;
	
	private String QMAY023;
	private String QMAY02301;
	private String QMAY02302;
	private String QMAY02303;
	private String QMAY02304;
	
	private String QMAY024;
	private String QMAY025;
	private String QMAY026;
	
	private String QMAY027;
	private String QMAY02701;
	private String QMAY02702;
	private String QMAY02703;
	private String QMAY02704;
	private String QMAY02705;
	private String QMAY02706;
	private String QMAY02707;
	private String QMAY02708;
	private String QMAY02709;
	
	private String QMAY028;
	private String QMAY029;
	private String QMAY030;
	
	private String QMAY031;
	private String QMAY03101;
	private String QMAY03102;
	private String QMAY03103;
	private String QMAY03104;
	
	private String QMAY032;
	private String QMAY03201;
	private String QMAY03202;
	private String QMAY03203;
	private String QMAY03204;
	private String QMAY03205;
	private String QMAY03206;
	private String QMAY0320601;
	
	private String QMAY033;
	private String QMAY03301;
	private String QMAY03302;
	private String QMAY03303;
	private String QMAY03304;
	private String QMAY03305;
	private String QMAY03306;
	private String QMAY03307;
	
	private String QMAY034;
	
	private String txtHeight;
	private String txtWeight;
	
	private String QPS003;
	private String QPS00301;
	private String QPS00302;
	private String QPS00303;
	
	private String QPS004;
	private String QPS00401;
	private String QPS00402;
	private String QPS00403;
	private String QPS00404;
	private String QPS00405;
	private String QPS00406;
	private String QPS00407;
	
	private String QPS005;
	private String QPS00501;
	private String QPS00502;
	
	private String QPS006;
	private String QPS00601;
	
	private String QPS007;
	private String QPS00701;
	private String QPS00702;
	private String QPS00703;
	
	private String QPS008;
	
	private String QPS009;
	private String QPS00901;
	private String QPS00902;
	private String QPS00903;
	private String QPS00904;
	private String QPS00905;
	
	private String QPS010;
	private String QPS01001;
	private String QPS01002;
	private String QPS01003;
	private String QPS01004;
	private String QPS01005;
	private String QPS01006;
	
	private String QPS011;
	private String QPS01101;
	private String QPS01102;
	private String QPS01103;
	private String QPS01104;
	private String QPS01105;
	private String QPS01106;
	private String QPS01107;
	private String QPS01108;
	private String QPS01109;
	private String QPS01110;
	
	private String QPS013;
	private String QPS01301;
	private String QPS01302;
	
	private String txtBirthDefect;
	
	private String QPS016;
	private String QPS017;
	private String QPS018;
	private String QPS019;
	
	private String QPS020;
	private String QPS02001;
	private String QPS02002;
	private String QPS02003;
	private String QPS02004;
	private String QPS02005;
	private String QPS02006;
	
	private String QPS021;
	private String QPS02101;
	private String QPS02102;
	private String QPS02103;
	private String QPS02104;
	
	private String QPS022;
	private String QPS023;
	private String QPS024;
	
	private String txtPayMethod;
	private String isReadBenefit;
	private String marketingConsent;
	private String txtClientID;
	private String txtProductName;
	private String txtRider;
	private String txtLastServAgent;
	private String txtCallbackGetHelp;
	private String txtHelpDescription;
	private String txtSaveAndReturnLink;
	private String txtAppID;
	private String txtCampaignID;
	private String txtDPSource;
	private String txtTimeStampAbandonedCartRequest;
	private String txtQueryStatus;
	private String txtAttributeStatus;
	private String txtOpportunityID;
	private String txtProspectOrExistingCust;
	private String txtResidencyStatus;
	private String txtLastServAgentName;
	private String txtLastServAgentMobile;
	private String txtLastServAgentEmail;
	private String txtOpportunityDescription;
	private String txtOpportunityDescriptionAboutYou;
	private String txtOpportunityDescriptionMoreAboutYou;
	private String txtOpportunityDescriptionHnL;
	private String txtEntrySource;
	private String txtPassType;
	private String txtPreferredcontacttime;
	private String txtPreferredcontactday;
	private String txtReasonforLeadGen;
	private String txtNRICSuffix;
	private String txtApplicationDateTime;
	private String txtAssigntoPOOLIndicator;
	//this field is used to extract passType from qmayQuestions
	//as extraction compares the question code
	@JsonIgnore
	private String qmay_passType;
	// Pass agent assignment decision
	private String typeOfAssignment;

	public String getTxtEntrySource() {
		return txtEntrySource;
	}

	public void setTxtEntrySource(String txtEntrySource) {
		this.txtEntrySource = txtEntrySource;
	}

	public String getTxtGender() {
		return txtGender;
	}
	public void setTxtGender(String txtGender) {
		this.txtGender = txtGender;
	}
	public String getTxtLastName() {
		return txtLastName;
	}
	public void setTxtLastName(String txtLastName) {
		this.txtLastName = txtLastName;
	}
	public String getTxtFirstName() {
		return txtFirstName;
	}
	public void setTxtFirstName(String txtFirstName) {
		this.txtFirstName = txtFirstName;
	}
	public String getTxtNRIC() {
		return txtNRIC;
	}
	public void setTxtNRIC(String txtNRIC) {
		this.txtNRIC = txtNRIC;
	}
	public String getTxtDob() {
		return txtDob;
	}
	public void setTxtDob(String txtDob) {
		this.txtDob = txtDob;
	}
	public String getTxtMobileNumber() {
		return txtMobileNumber;
	}
	public void setTxtMobileNumber(String txtMobileNumber) {
		this.txtMobileNumber = txtMobileNumber;
	}
    public String getTxtCountryCode () {
        return txtCountryCode ;
    }
    public void setTxtCountryCode (String txtCountryCode) {
        this.txtCountryCode = txtCountryCode;
    }
	public String getTxtNext() {
		return txtNext;
	}
	public void setTxtNext(String txtNext) {
		this.txtNext = txtNext;
	}
	public String getIsAssignConsultant() {
		return isAssignConsultant;
	}
	public void setIsAssignConsultant(String isAssignConsultant) {
		this.isAssignConsultant = isAssignConsultant;
	}
	public String getTxtNationality() {
		return txtNationality;
	}
	public void setTxtNationality(String txtNationality) {
		this.txtNationality = txtNationality;
	}
	public String getQMAY001() {
		return QMAY001;
	}
	public void setQMAY001(String qMAY001) {
		QMAY001 = qMAY001;
	}
	public String getQMAY003A() {
		return QMAY003A;
	}
	public void setQMAY003A(String qMAY003A) {
		QMAY003A = qMAY003A;
	}
	public String getQMAY003B() {
		return QMAY003B;
	}
	public void setQMAY003B(String qMAY003B) {
		QMAY003B = qMAY003B;
	}
	public String getQMAY003C() {
		return QMAY003C;
	}
	public void setQMAY003C(String qMAY003C) {
		QMAY003C = qMAY003C;
	}
	public String getQMAY004() {
		return QMAY004;
	}
	public void setQMAY004(String qMAY004) {
		QMAY004 = qMAY004;
	}
	public String getTxtResidentialPostalCode() {
		return txtResidentialPostalCode;
	}
	public void setTxtResidentialPostalCode(String txtResidentialPostalCode) {
		this.txtResidentialPostalCode = txtResidentialPostalCode;
	}
	public String getTxtMailingPostalCode() {
		return txtMailingPostalCode;
	}
	public void setTxtMailingPostalCode(String txtMailingPostalCode) {
		this.txtMailingPostalCode = txtMailingPostalCode;
	}
	public String getTxtResidentialBlockNo() {
		return txtResidentialBlockNo;
	}
	public void setTxtResidentialBlockNo(String txtResidentialBlockNo) {
		this.txtResidentialBlockNo = txtResidentialBlockNo;
	}
	public String getTxtResidentialStreet() {
		return txtResidentialStreet;
	}
	public void setTxtResidentialStreet(String txtResidentialStreet) {
		this.txtResidentialStreet = txtResidentialStreet;
	}
	public String getTxtResidentialBuilding() {
		return txtResidentialBuilding;
	}
	public void setTxtResidentialBuilding(String txtResidentialBuilding) {
		this.txtResidentialBuilding = txtResidentialBuilding;
	}
	public String getTxtResidentialUnitNo() {
		return txtResidentialUnitNo;
	}
	public void setTxtResidentialUnitNo(String txtResidentialUnitNo) {
		this.txtResidentialUnitNo = txtResidentialUnitNo;
	}
	public String getQMAY010() {
		return QMAY010;
	}
	public void setQMAY010(String qMAY010) {
		QMAY010 = qMAY010;
	}
	public String getQMAY011() {
		return QMAY011;
	}
	public void setQMAY011(String qMAY011) {
		QMAY011 = qMAY011;
	}
	public String getTxtMailingBlockNo() {
		return txtMailingBlockNo;
	}
	public void setTxtMailingBlockNo(String txtMailingBlockNo) {
		this.txtMailingBlockNo = txtMailingBlockNo;
	}
	public String getTxtMailingStreet() {
		return txtMailingStreet;
	}
	public void setTxtMailingStreet(String txtMailingStreet) {
		this.txtMailingStreet = txtMailingStreet;
	}
	public String getTxtMailingBuilding() {
		return txtMailingBuilding;
	}
	public void setTxtMailingBuilding(String txtMailingBuilding) {
		this.txtMailingBuilding = txtMailingBuilding;
	}
	public String getTxtMailingUnitNo() {
		return txtMailingUnitNo;
	}
	public void setTxtMailingUnitNo(String txtMailingUnitNo) {
		this.txtMailingUnitNo = txtMailingUnitNo;
	}
	public String getTxtMailingCountry() {
		return txtMailingCountry;
	}
	public void setTxtMailingCountry(String txtMailingCountry) {
		this.txtMailingCountry = txtMailingCountry;
	}
	public String getTxtEmail() {
		return txtEmail;
	}
	public void setTxtEmail(String txtEmail) {
		this.txtEmail = txtEmail;
	}
	public String getQMAY018() {
		return QMAY018;
	}
	public void setQMAY018(String qMAY018) {
		QMAY018 = qMAY018;
	}
	public String getQMAY019() {
		return QMAY019;
	}
	public void setQMAY019(String qMAY019) {
		QMAY019 = qMAY019;
	}
	public String getQMAY01901() {
		return QMAY01901;
	}
	public void setQMAY01901(String qMAY01901) {
		QMAY01901 = qMAY01901;
	}
	public String getQMAY01902() {
		return QMAY01902;
	}
	public void setQMAY01902(String qMAY01902) {
		QMAY01902 = qMAY01902;
	}
	public String getQMAY01903() {
		return QMAY01903;
	}
	public void setQMAY01903(String qMAY01903) {
		QMAY01903 = qMAY01903;
	}
	public String getQMAY01904() {
		return QMAY01904;
	}
	public void setQMAY01904(String qMAY01904) {
		QMAY01904 = qMAY01904;
	}
	public String getQMAY021() {
		return QMAY021;
	}
	public void setQMAY021(String qMAY021) {
		QMAY021 = qMAY021;
	}
	public String getQMAY02101() {
		return QMAY02101;
	}
	public void setQMAY02101(String qMAY02101) {
		QMAY02101 = qMAY02101;
	}
	public String getQMAY0210101() {
		return QMAY0210101;
	}
	public void setQMAY0210101(String qMAY0210101) {
		QMAY0210101 = qMAY0210101;
	}
	public String getQMAY0210102() {
		return QMAY0210102;
	}
	public void setQMAY0210102(String qMAY0210102) {
		QMAY0210102 = qMAY0210102;
	}
	public String getQMAY0210103() {
		return QMAY0210103;
	}
	public void setQMAY0210103(String qMAY0210103) {
		QMAY0210103 = qMAY0210103;
	}
	public String getQMAY0210104() {
		return QMAY0210104;
	}
	public void setQMAY0210104(String qMAY0210104) {
		QMAY0210104 = qMAY0210104;
	}
	public String getQMAY0210105() {
		return QMAY0210105;
	}
	public void setQMAY0210105(String qMAY0210105) {
		QMAY0210105 = qMAY0210105;
	}
	public String getQMAY0210106() {
		return QMAY0210106;
	}
	public void setQMAY0210106(String qMAY0210106) {
		QMAY0210106 = qMAY0210106;
	}
	public String getQMAY02102() {
		return QMAY02102;
	}
	public void setQMAY02102(String qMAY02102) {
		QMAY02102 = qMAY02102;
	}
	public String getQMAY02103() {
		return QMAY02103;
	}
	public void setQMAY02103(String qMAY02103) {
		QMAY02103 = qMAY02103;
	}
	public String getQMAY02104() {
		return QMAY02104;
	}
	public void setQMAY02104(String qMAY02104) {
		QMAY02104 = qMAY02104;
	}
	public String getQMAY02105() {
		return QMAY02105;
	}
	public void setQMAY02105(String qMAY02105) {
		QMAY02105 = qMAY02105;
	}
	public String getQMAY02106() {
		return QMAY02106;
	}
	public void setQMAY02106(String qMAY02106) {
		QMAY02106 = qMAY02106;
	}
	public String getQMAY02107() {
		return QMAY02107;
	}
	public void setQMAY02107(String qMAY02107) {
		QMAY02107 = qMAY02107;
	}
	public String getQMAY02108() {
		return QMAY02108;
	}
	public void setQMAY02108(String qMAY02108) {
		QMAY02108 = qMAY02108;
	}
	public String getQMAY02109() {
		return QMAY02109;
	}
	public void setQMAY02109(String qMAY02109) {
		QMAY02109 = qMAY02109;
	}
	public String getQMAY02110() {
		return QMAY02110;
	}
	public void setQMAY02110(String qMAY02110) {
		QMAY02110 = qMAY02110;
	}
	public String getTxtAnnualIncome() {
		return txtAnnualIncome;
	}
	public void setTxtAnnualIncome(String txtAnnualIncome) {
		this.txtAnnualIncome = txtAnnualIncome;
	}
	public String getQMAY023() {
		return QMAY023;
	}
	public void setQMAY023(String qMAY023) {
		QMAY023 = qMAY023;
	}
	public String getQMAY02301() {
		return QMAY02301;
	}
	public void setQMAY02301(String qMAY02301) {
		QMAY02301 = qMAY02301;
	}
	public String getQMAY02302() {
		return QMAY02302;
	}
	public void setQMAY02302(String qMAY02302) {
		QMAY02302 = qMAY02302;
	}
	public String getQMAY02303() {
		return QMAY02303;
	}
	public void setQMAY02303(String qMAY02303) {
		QMAY02303 = qMAY02303;
	}
	public String getQMAY02304() {
		return QMAY02304;
	}
	public void setQMAY02304(String qMAY02304) {
		QMAY02304 = qMAY02304;
	}
	public String getQMAY024() {
		return QMAY024;
	}
	public void setQMAY024(String qMAY024) {
		QMAY024 = qMAY024;
	}
	public String getQMAY025() {
		return QMAY025;
	}
	public void setQMAY025(String qMAY025) {
		QMAY025 = qMAY025;
	}
	public String getQMAY026() {
		return QMAY026;
	}
	public void setQMAY026(String qMAY026) {
		QMAY026 = qMAY026;
	}
	public String getQMAY027() {
		return QMAY027;
	}
	public void setQMAY027(String qMAY027) {
		QMAY027 = qMAY027;
	}
	public String getQMAY02701() {
		return QMAY02701;
	}
	public void setQMAY02701(String qMAY02701) {
		QMAY02701 = qMAY02701;
	}
	public String getQMAY02702() {
		return QMAY02702;
	}
	public void setQMAY02702(String qMAY02702) {
		QMAY02702 = qMAY02702;
	}
	public String getQMAY02703() {
		return QMAY02703;
	}
	public void setQMAY02703(String qMAY02703) {
		QMAY02703 = qMAY02703;
	}
	public String getQMAY02704() {
		return QMAY02704;
	}
	public void setQMAY02704(String qMAY02704) {
		QMAY02704 = qMAY02704;
	}
	public String getQMAY02705() {
		return QMAY02705;
	}
	public void setQMAY02705(String qMAY02705) {
		QMAY02705 = qMAY02705;
	}
	public String getQMAY02706() {
		return QMAY02706;
	}
	public void setQMAY02706(String qMAY02706) {
		QMAY02706 = qMAY02706;
	}
	public String getQMAY02707() {
		return QMAY02707;
	}
	public void setQMAY02707(String qMAY02707) {
		QMAY02707 = qMAY02707;
	}
	public String getQMAY02708() {
		return QMAY02708;
	}
	public void setQMAY02708(String qMAY02708) {
		QMAY02708 = qMAY02708;
	}
	public String getQMAY02709() {
		return QMAY02709;
	}
	public void setQMAY02709(String qMAY02709) {
		QMAY02709 = qMAY02709;
	}
	public String getQMAY028() {
		return QMAY028;
	}
	public void setQMAY028(String qMAY028) {
		QMAY028 = qMAY028;
	}
	public String getQMAY029() {
		return QMAY029;
	}
	public void setQMAY029(String qMAY029) {
		QMAY029 = qMAY029;
	}
	public String getQMAY030() {
		return QMAY030;
	}
	public void setQMAY030(String qMAY030) {
		QMAY030 = qMAY030;
	}
	public String getQMAY031() {
		return QMAY031;
	}
	public void setQMAY031(String qMAY031) {
		QMAY031 = qMAY031;
	}
	public String getQMAY03101() {
		return QMAY03101;
	}
	public void setQMAY03101(String qMAY03101) {
		QMAY03101 = qMAY03101;
	}
	public String getQMAY03102() {
		return QMAY03102;
	}
	public void setQMAY03102(String qMAY03102) {
		QMAY03102 = qMAY03102;
	}
	public String getQMAY03103() {
		return QMAY03103;
	}
	public void setQMAY03103(String qMAY03103) {
		QMAY03103 = qMAY03103;
	}
	public String getQMAY03104() {
		return QMAY03104;
	}
	public void setQMAY03104(String qMAY03104) {
		QMAY03104 = qMAY03104;
	}
	public String getQMAY032() {
		return QMAY032;
	}
	public void setQMAY032(String qMAY032) {
		QMAY032 = qMAY032;
	}
	public String getQMAY03201() {
		return QMAY03201;
	}
	public void setQMAY03201(String qMAY03201) {
		QMAY03201 = qMAY03201;
	}
	public String getQMAY03202() {
		return QMAY03202;
	}
	public void setQMAY03202(String qMAY03202) {
		QMAY03202 = qMAY03202;
	}
	public String getQMAY03203() {
		return QMAY03203;
	}
	public void setQMAY03203(String qMAY03203) {
		QMAY03203 = qMAY03203;
	}
	public String getQMAY03204() {
		return QMAY03204;
	}
	public void setQMAY03204(String qMAY03204) {
		QMAY03204 = qMAY03204;
	}
	public String getQMAY03205() {
		return QMAY03205;
	}
	public void setQMAY03205(String qMAY03205) {
		QMAY03205 = qMAY03205;
	}
	public String getQMAY03206() {
		return QMAY03206;
	}
	public void setQMAY03206(String qMAY03206) {
		QMAY03206 = qMAY03206;
	}
	public String getQMAY0320601() {
		return QMAY0320601;
	}
	public void setQMAY0320601(String qMAY0320601) {
		QMAY0320601 = qMAY0320601;
	}
	public String getQMAY033() {
		return QMAY033;
	}
	public void setQMAY033(String qMAY033) {
		QMAY033 = qMAY033;
	}
	public String getQMAY03301() {
		return QMAY03301;
	}
	public void setQMAY03301(String qMAY03301) {
		QMAY03301 = qMAY03301;
	}
	public String getQMAY03302() {
		return QMAY03302;
	}
	public void setQMAY03302(String qMAY03302) {
		QMAY03302 = qMAY03302;
	}
	public String getQMAY03303() {
		return QMAY03303;
	}
	public void setQMAY03303(String qMAY03303) {
		QMAY03303 = qMAY03303;
	}
	public String getQMAY03304() {
		return QMAY03304;
	}
	public void setQMAY03304(String qMAY03304) {
		QMAY03304 = qMAY03304;
	}
	public String getQMAY03305() {
		return QMAY03305;
	}
	public void setQMAY03305(String qMAY03305) {
		QMAY03305 = qMAY03305;
	}
	public String getQMAY03306() {
		return QMAY03306;
	}
	public void setQMAY03306(String qMAY03306) {
		QMAY03306 = qMAY03306;
	}
	public String getQMAY03307() {
		return QMAY03307;
	}
	public void setQMAY03307(String qMAY03307) {
		QMAY03307 = qMAY03307;
	}
	public String getQMAY034() {
		return QMAY034;
	}
	public void setQMAY034(String qMAY034) {
		QMAY034 = qMAY034;
	}
	public String getTxtHeight() {
		return txtHeight;
	}
	public void setTxtHeight(String txtHeight) {
		this.txtHeight = txtHeight;
	}
	public String getTxtWeight() {
		return txtWeight;
	}
	public void setTxtWeight(String txtWeight) {
		this.txtWeight = txtWeight;
	}
	public String getQPS003() {
		return QPS003;
	}
	public void setQPS003(String qPS003) {
		QPS003 = qPS003;
	}
	public String getQPS00301() {
		return QPS00301;
	}
	public void setQPS00301(String qPS00301) {
		QPS00301 = qPS00301;
	}
	public String getQPS00302() {
		return QPS00302;
	}
	public void setQPS00302(String qPS00302) {
		QPS00302 = qPS00302;
	}
	public String getQPS00303() {
		return QPS00303;
	}
	public void setQPS00303(String qPS00303) {
		QPS00303 = qPS00303;
	}
	public String getQPS004() {
		return QPS004;
	}
	public void setQPS004(String qPS004) {
		QPS004 = qPS004;
	}
	public String getQPS00401() {
		return QPS00401;
	}
	public void setQPS00401(String qPS00401) {
		QPS00401 = qPS00401;
	}
	public String getQPS00402() {
		return QPS00402;
	}
	public void setQPS00402(String qPS00402) {
		QPS00402 = qPS00402;
	}
	public String getQPS00403() {
		return QPS00403;
	}
	public void setQPS00403(String qPS00403) {
		QPS00403 = qPS00403;
	}
	public String getQPS00404() {
		return QPS00404;
	}
	public void setQPS00404(String qPS00404) {
		QPS00404 = qPS00404;
	}
	public String getQPS00405() {
		return QPS00405;
	}
	public void setQPS00405(String qPS00405) {
		QPS00405 = qPS00405;
	}
	public String getQPS00406() {
		return QPS00406;
	}
	public void setQPS00406(String qPS00406) {
		QPS00406 = qPS00406;
	}
	public String getQPS00407() {
		return QPS00407;
	}
	public void setQPS00407(String qPS00407) {
		QPS00407 = qPS00407;
	}
	public String getQPS005() {
		return QPS005;
	}
	public void setQPS005(String qPS005) {
		QPS005 = qPS005;
	}
	public String getQPS00501() {
		return QPS00501;
	}
	public void setQPS00501(String qPS00501) {
		QPS00501 = qPS00501;
	}
	public String getQPS00502() {
		return QPS00502;
	}
	public void setQPS00502(String qPS00502) {
		QPS00502 = qPS00502;
	}
	public String getQPS006() {
		return QPS006;
	}
	public void setQPS006(String qPS006) {
		QPS006 = qPS006;
	}
	public String getQPS00601() {
		return QPS00601;
	}
	public void setQPS00601(String qPS00601) {
		QPS00601 = qPS00601;
	}
	public String getQPS007() {
		return QPS007;
	}
	public void setQPS007(String qPS007) {
		QPS007 = qPS007;
	}
	public String getQPS00701() {
		return QPS00701;
	}
	public void setQPS00701(String qPS00701) {
		QPS00701 = qPS00701;
	}
	public String getQPS00702() {
		return QPS00702;
	}
	public void setQPS00702(String qPS00702) {
		QPS00702 = qPS00702;
	}
	public String getQPS00703() {
		return QPS00703;
	}
	public void setQPS00703(String qPS00703) {
		QPS00703 = qPS00703;
	}
	public String getQPS008() {
		return QPS008;
	}
	public void setQPS008(String qPS008) {
		QPS008 = qPS008;
	}
	public String getQPS009() {
		return QPS009;
	}
	public void setQPS009(String qPS009) {
		QPS009 = qPS009;
	}
	public String getQPS00901() {
		return QPS00901;
	}
	public void setQPS00901(String qPS00901) {
		QPS00901 = qPS00901;
	}
	public String getQPS00902() {
		return QPS00902;
	}
	public void setQPS00902(String qPS00902) {
		QPS00902 = qPS00902;
	}
	public String getQPS00903() {
		return QPS00903;
	}
	public void setQPS00903(String qPS00903) {
		QPS00903 = qPS00903;
	}
	public String getQPS00904() {
		return QPS00904;
	}
	public void setQPS00904(String qPS00904) {
		QPS00904 = qPS00904;
	}
	public String getQPS00905() {
		return QPS00905;
	}
	public void setQPS00905(String qPS00905) {
		QPS00905 = qPS00905;
	}
	public String getQPS010() {
		return QPS010;
	}
	public void setQPS010(String qPS010) {
		QPS010 = qPS010;
	}
	public String getQPS01001() {
		return QPS01001;
	}
	public void setQPS01001(String qPS01001) {
		QPS01001 = qPS01001;
	}
	public String getQPS01002() {
		return QPS01002;
	}
	public void setQPS01002(String qPS01002) {
		QPS01002 = qPS01002;
	}
	public String getQPS01003() {
		return QPS01003;
	}
	public void setQPS01003(String qPS01003) {
		QPS01003 = qPS01003;
	}
	public String getQPS01004() {
		return QPS01004;
	}
	public void setQPS01004(String qPS01004) {
		QPS01004 = qPS01004;
	}
	public String getQPS01005() {
		return QPS01005;
	}
	public void setQPS01005(String qPS01005) {
		QPS01005 = qPS01005;
	}
	public String getQPS01006() {
		return QPS01006;
	}
	public void setQPS01006(String qPS01006) {
		QPS01006 = qPS01006;
	}
	public String getQPS011() {
		return QPS011;
	}
	public void setQPS011(String qPS011) {
		QPS011 = qPS011;
	}
	public String getQPS01101() {
		return QPS01101;
	}
	public void setQPS01101(String qPS01101) {
		QPS01101 = qPS01101;
	}
	public String getQPS01102() {
		return QPS01102;
	}
	public void setQPS01102(String qPS01102) {
		QPS01102 = qPS01102;
	}
	public String getQPS01103() {
		return QPS01103;
	}
	public void setQPS01103(String qPS01103) {
		QPS01103 = qPS01103;
	}
	public String getQPS01104() {
		return QPS01104;
	}
	public void setQPS01104(String qPS01104) {
		QPS01104 = qPS01104;
	}
	public String getQPS01105() {
		return QPS01105;
	}
	public void setQPS01105(String qPS01105) {
		QPS01105 = qPS01105;
	}
	public String getQPS01106() {
		return QPS01106;
	}
	public void setQPS01106(String qPS01106) {
		QPS01106 = qPS01106;
	}
	public String getQPS01107() {
		return QPS01107;
	}
	public void setQPS01107(String qPS01107) {
		QPS01107 = qPS01107;
	}
	public String getQPS01108() {
		return QPS01108;
	}
	public void setQPS01108(String qPS01108) {
		QPS01108 = qPS01108;
	}
	public String getQPS01109() {
		return QPS01109;
	}
	public void setQPS01109(String qPS01109) {
		QPS01109 = qPS01109;
	}
	public String getQPS01110() {
		return QPS01110;
	}
	public void setQPS01110(String qPS01110) {
		QPS01110 = qPS01110;
	}
	public String getQPS013() {
		return QPS013;
	}
	public void setQPS013(String qPS013) {
		QPS013 = qPS013;
	}
	public String getQPS01301() {
		return QPS01301;
	}
	public void setQPS01301(String qPS01301) {
		QPS01301 = qPS01301;
	}
	public String getQPS01302() {
		return QPS01302;
	}
	public void setQPS01302(String qPS01302) {
		QPS01302 = qPS01302;
	}
	public String getTxtBirthDefect() {
		return txtBirthDefect;
	}
	public void setTxtBirthDefect(String txtBirthDefect) {
		this.txtBirthDefect = txtBirthDefect;
	}
	public String getQPS016() {
		return QPS016;
	}
	public void setQPS016(String qPS016) {
		QPS016 = qPS016;
	}
	public String getQPS017() {
		return QPS017;
	}
	public void setQPS017(String qPS017) {
		QPS017 = qPS017;
	}
	public String getQPS018() {
		return QPS018;
	}
	public void setQPS018(String qPS018) {
		QPS018 = qPS018;
	}
	public String getQPS019() {
		return QPS019;
	}
	public void setQPS019(String qPS019) {
		QPS019 = qPS019;
	}
	public String getQPS020() {
		return QPS020;
	}
	public void setQPS020(String qPS020) {
		QPS020 = qPS020;
	}
	public String getQPS02001() {
		return QPS02001;
	}
	public void setQPS02001(String qPS02001) {
		QPS02001 = qPS02001;
	}
	public String getQPS02002() {
		return QPS02002;
	}
	public void setQPS02002(String qPS02002) {
		QPS02002 = qPS02002;
	}
	public String getQPS02003() {
		return QPS02003;
	}
	public void setQPS02003(String qPS02003) {
		QPS02003 = qPS02003;
	}
	public String getQPS02004() {
		return QPS02004;
	}
	public void setQPS02004(String qPS02004) {
		QPS02004 = qPS02004;
	}
	public String getQPS02005() {
		return QPS02005;
	}
	public void setQPS02005(String qPS02005) {
		QPS02005 = qPS02005;
	}
	public String getQPS02006() {
		return QPS02006;
	}
	public void setQPS02006(String qPS02006) {
		QPS02006 = qPS02006;
	}
	public String getQPS021() {
		return QPS021;
	}
	public void setQPS021(String qPS021) {
		QPS021 = qPS021;
	}
	public String getQPS02101() {
		return QPS02101;
	}
	public void setQPS02101(String qPS02101) {
		QPS02101 = qPS02101;
	}
	public String getQPS02102() {
		return QPS02102;
	}
	public void setQPS02102(String qPS02102) {
		QPS02102 = qPS02102;
	}
	public String getQPS02103() {
		return QPS02103;
	}
	public void setQPS02103(String qPS02103) {
		QPS02103 = qPS02103;
	}
	public String getQPS02104() {
		return QPS02104;
	}
	public void setQPS02104(String qPS02104) {
		QPS02104 = qPS02104;
	}
	public String getQPS022() {
		return QPS022;
	}
	public void setQPS022(String qPS022) {
		QPS022 = qPS022;
	}
	public String getQPS023() {
		return QPS023;
	}
	public void setQPS023(String qPS023) {
		QPS023 = qPS023;
	}
	public String getQPS024() {
		return QPS024;
	}
	public void setQPS024(String qPS024) {
		QPS024 = qPS024;
	}
	public String getTxtPayMethod() {
		return txtPayMethod;
	}
	public void setTxtPayMethod(String txtPayMethod) {
		this.txtPayMethod = txtPayMethod;
	}
	public String getIsReadBenefit() {
		return isReadBenefit;
	}
	public void setIsReadBenefit(String isReadBenefit) {
		this.isReadBenefit = isReadBenefit;
	}
	public String getMarketingConsent() {
		return marketingConsent;
	}
	public void setMarketingConsent(String marketingConsent) {
		this.marketingConsent = marketingConsent;
	}
	public String getTxtClientID() {
		return txtClientID;
	}
	public void setTxtClientID(String txtClientID) {
		this.txtClientID = txtClientID;
	}
	public String getTxtProductName() {
		return txtProductName;
	}
	public void setTxtProductName(String txtProductName) {
		this.txtProductName = txtProductName;
	}
	public String getTxtRider() {
		return txtRider;
	}
	public void setTxtRider(String txtRider) {
		this.txtRider = txtRider;
	}
	public String getTxtLastServAgent() {
		return txtLastServAgent;
	}
	public void setTxtLastServAgent(String txtLastServAgent) {
		this.txtLastServAgent = txtLastServAgent;
	}
	public String getTxtCallbackGetHelp() {
		return txtCallbackGetHelp;
	}
	public void setTxtCallbackGetHelp(String txtCallbackGetHelp) {
		this.txtCallbackGetHelp = txtCallbackGetHelp;
	}
	public String getTxtHelpDescription() {
		return txtHelpDescription;
	}
	public void setTxtHelpDescription(String txtHelpDescription) {
		this.txtHelpDescription = txtHelpDescription;
	}
	public String getTxtSaveAndReturnLink() {
		return txtSaveAndReturnLink;
	}
	public void setTxtSaveAndReturnLink(String txtSaveAndReturnLink) {
		this.txtSaveAndReturnLink = txtSaveAndReturnLink;
	}
	public String getTxtAppID() {
		return txtAppID;
	}
	public void setTxtAppID(String txtAppID) {
		this.txtAppID = txtAppID;
	}
	public String getTxtCampaignID() {
		return txtCampaignID;
	}
	public void setTxtCampaignID(String txtCampaignID) {
		this.txtCampaignID = txtCampaignID;
	}
	public String getTxtDPSource() {
		return txtDPSource;
	}
	public void setTxtDPSource(String txtDPSource) {
		this.txtDPSource = txtDPSource;
	}
	public String getTxtTimeStampAbandonedCartRequest() {
		return txtTimeStampAbandonedCartRequest;
	}
	public void setTxtTimeStampAbandonedCartRequest(String txtTimeStampAbandonedCartRequest) {
		this.txtTimeStampAbandonedCartRequest = txtTimeStampAbandonedCartRequest;
	}
	public String getTxtQueryStatus() {
		return txtQueryStatus;
	}
	public void setTxtQueryStatus(String txtQueryStatus) {
		this.txtQueryStatus = txtQueryStatus;
	}
	public String getTxtAttributeStatus() {
		return txtAttributeStatus;
	}
	public void setTxtAttributeStatus(String txtAttributeStatus) {
		this.txtAttributeStatus = txtAttributeStatus;
	}
	public String getTxtOpportunityID() {
		return txtOpportunityID;
	}
	public void setTxtOpportunityID(String txtOpportunityID) {
		this.txtOpportunityID = txtOpportunityID;
	}
	public String getTxtProspectOrExistingCust() {
		return txtProspectOrExistingCust;
	}
	public void setTxtProspectOrExistingCust(String txtProspectOrExistingCust) {
		this.txtProspectOrExistingCust = txtProspectOrExistingCust;
	}
	public String getTxtResidencyStatus() {
		return txtResidencyStatus;
	}
	public void setTxtResidencyStatus(String txtResidencyStatus) {
		this.txtResidencyStatus = txtResidencyStatus;
	}
	public String getTxtLastServAgentName() {
		return txtLastServAgentName;
	}
	public void setTxtLastServAgentName(String txtLastServAgentName) {
		this.txtLastServAgentName = txtLastServAgentName;
	}
	public String getTxtLastServAgentMobile() {
		return txtLastServAgentMobile;
	}
	public void setTxtLastServAgentMobile(String txtLastServAgentMobile) {
		this.txtLastServAgentMobile = txtLastServAgentMobile;
	}
	public String getTxtLastServAgentEmail() {
		return txtLastServAgentEmail;
	}
	public void setTxtLastServAgentEmail(String txtLastServAgentEmail) {
		this.txtLastServAgentEmail = txtLastServAgentEmail;
	}
	public String getTxtOpportunityDescription() {
		return txtOpportunityDescription;
	}
	public void setTxtOpportunityDescription(String txtOpportunityDescription) {
		this.txtOpportunityDescription = txtOpportunityDescription;
	}
	public String getTxtOpportunityDescriptionAboutYou() {
		return txtOpportunityDescriptionAboutYou;
	}
	public void setTxtOpportunityDescriptionAboutYou(String txtOpportunityDescriptionAboutYou) {
		this.txtOpportunityDescriptionAboutYou = txtOpportunityDescriptionAboutYou;
	}
	public String getTxtOpportunityDescriptionMoreAboutYou() {
		return txtOpportunityDescriptionMoreAboutYou;
	}
	public void setTxtOpportunityDescriptionMoreAboutYou(String txtOpportunityDescriptionMoreAboutYou) {
		this.txtOpportunityDescriptionMoreAboutYou = txtOpportunityDescriptionMoreAboutYou;
	}
	public String getTxtOpportunityDescriptionHnL() {
		return txtOpportunityDescriptionHnL;
	}
	public void setTxtOpportunityDescriptionHnL(String txtOpportunityDescriptionHnL) {
		this.txtOpportunityDescriptionHnL = txtOpportunityDescriptionHnL;
	}
	public String getTxtPassType() {
		return txtPassType;
	}
	public void setTxtPassType(String txtPassType) {
		this.txtPassType = txtPassType;
	}
	public String getTxtPreferredcontacttime() {
		return txtPreferredcontacttime;
	}
	public void setTxtPreferredcontacttime(String txtPreferredcontacttime) {
		this.txtPreferredcontacttime = txtPreferredcontacttime;
	}
	public String getTxtPreferredcontactday() {
		return txtPreferredcontactday;
	}
	public void setTxtPreferredcontactday(String txtPreferredcontactday) {
		this.txtPreferredcontactday = txtPreferredcontactday;
	}
	public String getTxtReasonforLeadGen() {
		return txtReasonforLeadGen;
	}
	public void setTxtReasonforLeadGen(String txtReasonforLeadGen) {
		this.txtReasonforLeadGen = txtReasonforLeadGen;
	}
	public String getTxtNRICSuffix() {
		return txtNRICSuffix;
	}
	public void setTxtNRICSuffix(String txtNRICSuffix) {
		this.txtNRICSuffix = txtNRICSuffix;
	}
	public String getTxtApplicationDateTime() {
		return txtApplicationDateTime;
	}
	public void setTxtApplicationDateTime(String txtApplicationDateTime) {
		this.txtApplicationDateTime = txtApplicationDateTime;
	}
	public String getTxtAssigntoPOOLIndicator() {
		return txtAssigntoPOOLIndicator;
	}
	public void setTxtAssigntoPOOLIndicator(String txtAssigntoPOOLIndicator) {
		this.txtAssigntoPOOLIndicator = txtAssigntoPOOLIndicator;
	}
	@JsonIgnore
	public String getQmay_passType() {
		return qmay_passType;
	}
	public void setQmay_passType(String qmay_passType) {
		this.txtPassType = qmay_passType;
		this.qmay_passType = qmay_passType;

	}

	public String getTypeOfAssignment() {
		return typeOfAssignment;
	}

	public void setTypeOfAssignment(String typeOfAssignment) {
		this.typeOfAssignment = typeOfAssignment;
	}

	@Override
	public String toString() {
		return "EventData { " +
				"txtResidencyStatus = '" + txtResidencyStatus + '\'' +
				", txtDob=" + txtDob +
				", txtPassType=" + txtPassType +
				", txtNationality='" + txtNationality + '\'' +
				", txtProspectOrExistingCust='" + txtProspectOrExistingCust + '\'' +
				", txtNRIC='" + txtNRIC + '\'' +
				", txtPreferredcontacttime='" + txtPreferredcontacttime + '\'' +
				", txtPreferredcontactday='" + txtPreferredcontactday + '\'' +
				", txtFirstName[GVNName]='" + txtFirstName + '\'' +
				", txtLastName[Surname]='" + txtLastName + '\'' +
				", txtEmail='" + txtEmail + '\'' +
				", txtMobileNumber='" + txtMobileNumber + '\'' +
				", txtGender='" + txtGender + '\'' +
				", txtPayMethod='" + txtPayMethod + '\'' +
				", txtReasonforLeadGen='" + txtReasonforLeadGen + '\'' +
				", txtNRICSuffix='" + txtNRICSuffix + '\'' +
				", txtAnnualIncome='" + txtAnnualIncome + '\'' +
				", txtHeight='" + txtHeight + '\'' +
				", txtWeight='" + txtWeight + '\'' +
				", txtOpportunityDescription[Coverage]=" + txtOpportunityDescription +
				", txtProductName=" + txtProductName +
				", txtQueryStatus='" + txtQueryStatus + '\'' +
				", txtDPSource=" + txtDPSource +
				", txtApplicationDateTime='" + txtApplicationDateTime + '\'' +
				", txtLastServAgent='" + txtLastServAgent + '\'' +
				", txtAssigntoPOOLIndicator='" + txtAssigntoPOOLIndicator + '\'' +
				", typeOfAssignment='" + typeOfAssignment + '\'' +
				'}';
	}
}
