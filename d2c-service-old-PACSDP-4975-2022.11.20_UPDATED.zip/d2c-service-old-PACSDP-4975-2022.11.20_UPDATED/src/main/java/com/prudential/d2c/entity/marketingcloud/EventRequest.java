package com.prudential.d2c.entity.marketingcloud;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class EventRequest {
	private String ContactKey;
	private String EventDefinitionKey;
	private boolean EstablishContactKey;
	private EventData data;
	
	public String getContactKey() {
		return ContactKey;
	}
	public void setContactKey(String contactKey) {
		ContactKey = contactKey;
	}
	public String getEventDefinitionKey() {
		return EventDefinitionKey;
	}
	public void setEventDefinitionKey(String eventDefinitionKey) {
		EventDefinitionKey = eventDefinitionKey;
	}
	public boolean isEstablishContactKey() {
		return EstablishContactKey;
	}
	public void setEstablishContactKey(boolean establishContactKey) {
		EstablishContactKey = establishContactKey;
	}
	public EventData getData() {
		return data;
	}
	public void setData(EventData data) {
		this.data = data;
	}
	
	
}
