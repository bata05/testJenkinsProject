package com.prudential.d2c.entity.marketingcloud;

public class EventResponse {
	private String eventInstanceId;

	public String getEventInstanceId() {
		return eventInstanceId;
	}

	public void setEventInstanceId(String eventInstanceId) {
		this.eventInstanceId = eventInstanceId;
	}
	
}
