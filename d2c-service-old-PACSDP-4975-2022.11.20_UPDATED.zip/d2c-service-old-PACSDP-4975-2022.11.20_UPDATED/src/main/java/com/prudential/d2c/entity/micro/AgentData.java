package com.prudential.d2c.entity.micro;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AgentData {
	
	private String agentCode;
	private String businessName;
	private String businessSource;
	private String agentType;
	private String emailAddress;
	private String mobileNumber;
	private String masRepNumber;
	private String businessSubSource;


    //new add
	private String channel;
	private String subChannel;
	
	private String category;
	private String agentChannelCode;

	private boolean assignedFromPool;
	
	public AgentData (){
		this.agentCode = "d2c";
	}
    
    public AgentData(String agentCode, String businessName, String emailAddress, String mobileNumber) {
        super();
        this.agentCode = agentCode;
        this.businessName = businessName;
        this.emailAddress = emailAddress;
        this.mobileNumber = mobileNumber;
    }
	/**
	 * @return the agentCode
	 */
	public String getAgentCode() {
		return agentCode;
	}
	/**
	 * @param agentCode the agentCode to set
	 */
	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}

	/**
	 * @return the businessName
	 */
	public String getBusinessName() {
		return businessName;
	}
	/**
	 * @param businessName the businessName to set
	 */
	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}
	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}
	/**
	 * @param emailAddress the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress) {
		if(emailAddress != null){
			this.emailAddress = emailAddress;
		}else{
			this.emailAddress = "########";
		}
	}
	
	
	public String getBusinessSource() {
		return businessSource;
	}

	public void setBusinessSource(String businessSource) {
		this.businessSource = businessSource;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		if(mobileNumber != null){
			this.mobileNumber = mobileNumber;
		}else{
			this.mobileNumber = "########";
		}
		
	}

	public String getMasRepNumber() {
		return masRepNumber;
	}

	public void setMasRepNumber(String masRepNumber) {
		this.masRepNumber = masRepNumber;
	}

	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}

	/**
	 * @return the agentType
	 */
	public String getAgentType() {
		return agentType;
	}

	/**
	 * @param agentType the agentType to set
	 */
	public void setAgentType(String agentType) {
		this.agentType = agentType;
	}

	public String getChannel() {
		return channel;
	}

	public String getSubChannel() {
		return subChannel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public void setSubChannel(String subChannel) {
		this.subChannel = subChannel;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getBusinessSubSource() {
		return businessSubSource;
	}

	public void setBusinessSubSource(String businessSubSource) {
		this.businessSubSource = businessSubSource;
	}
	
	public String getAgentChannelCode() { return agentChannelCode; }
	
	public void setAgentChannelCode(String agentChannelCode) { this.agentChannelCode = agentChannelCode; }

	public boolean isAssignedFromPool() {
		return assignedFromPool;
	}

	public void setAssignedFromPool(boolean assignedFromPool) {
		this.assignedFromPool = assignedFromPool;
	}

	@JsonIgnore
	public String getAssignedToPoolIndicator() {
		return assignedFromPool ? "Y" : "N";
	}
}
