package com.prudential.d2c.entity.micro;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AgentDataCriteria {

    private String saAgentCode;

    private boolean existingClient;

    private String clientNumber;

    public String getSaAgentCode() {
        return saAgentCode;
    }

    public void setSaAgentCode(String saAgentCode) {
        this.saAgentCode = saAgentCode;
    }

    public boolean isExistingClient() {
        return existingClient;
    }

    public void setExistingClient(boolean existingClient) {
        this.existingClient = existingClient;
    }

    public String getClientNumber() {
        return clientNumber;
    }

    public void setClientNumber(String clientNumber) {
        this.clientNumber = clientNumber;
    }
}
