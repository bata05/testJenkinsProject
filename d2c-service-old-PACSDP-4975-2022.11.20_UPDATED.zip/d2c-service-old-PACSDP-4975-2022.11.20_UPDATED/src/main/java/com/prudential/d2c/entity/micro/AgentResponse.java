package com.prudential.d2c.entity.micro;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AgentResponse {
	//remove after new agent API comes to live
	boolean isExistingClient;
	
	private AgentData lastServicingAgent;
	
	private AgentData newAgent;
	
	private AgentData defaultAgent;

	/**
	 * @return the newAgent
	 */
	public AgentData getNewAgent() {
		return newAgent;
	}

	/**
	 * @param newAgent the newAgent to set
	 */
	public void setNewAgent(AgentData newAgent) {
		this.newAgent = newAgent;
	}

	/**
	 * @return the defaultAgent
	 */
	public AgentData getDefaultAgent() {
		return defaultAgent;
	}

	/**
	 * @param defaultAgent the defaultAgent to set
	 */
	public void setDefaultAgent(AgentData defaultAgent) {
		this.defaultAgent = defaultAgent;
	}
	
	public boolean getIsExistingClient() {
		return isExistingClient;
	}

	public void setIsExistingClient(boolean isExistingClient) {
		this.isExistingClient = isExistingClient;
	}

	public AgentData getLastServicingAgent() {
		return lastServicingAgent;
	}

	public void setLastServicingAgent(AgentData lastServicingAgent) {
		this.lastServicingAgent = lastServicingAgent;
	}

	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}

}
