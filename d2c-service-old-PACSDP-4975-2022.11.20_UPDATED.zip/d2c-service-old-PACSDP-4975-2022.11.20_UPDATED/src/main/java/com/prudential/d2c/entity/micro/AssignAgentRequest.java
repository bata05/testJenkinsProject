package com.prudential.d2c.entity.micro;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.prudential.d2c.entity.micro.payload.MicroSelectedProducts;

/**
 * This entity is used for data preparation when any logic to fetch agent info
 *
 */
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class AssignAgentRequest {

    // use this value to fetch agent info
    private String customId;
    // to call agent API required
    // i.e. for getHelp scenario to fetch agentInfo
    private String clientNumber;
    private String nric;
    private String dob;
    private String gender;
    private String nationality;
    // i.e. PA, PS
    private String proType;
    // i.e. SCB
    private String channelType;

    private String policyNumber;

    private String age;
    private MicroSelectedProducts selectedProducts;
    private String isSaleCompleted;
    // for PDPC
    private String mobileNo;
    private String emailId;
    private String nricSuffix;

    private String referralAgentCode;

    private String preferredAgentMobile;

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getNricSuffix() {
        return nricSuffix;
    }

    public void setNricSuffix(String nricSuffix) {
        this.nricSuffix = nricSuffix;
    }


    public String getChannelType() {
        return channelType;
    }

    public void setChannelType(String channelType) {
        this.channelType = channelType;
    }

    public MicroSelectedProducts getSelectedProducts() {
        return selectedProducts;
    }

    public void setSelectedProducts(MicroSelectedProducts selectedProducts) {
        this.selectedProducts = selectedProducts;
    }

    public String getPolicyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String getCustomId() {
        return customId;
    }

    public void setCustomId(String customId) {
        this.customId = customId;
    }

    public String getClientNumber() {
        return clientNumber;
    }

    public void setClientNumber(String clientNumber) {
        this.clientNumber = clientNumber;
    }

    public String getNric() {
        return nric;
    }

    public void setNric(String nric) {
        this.nric = nric;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public String getProType() {
        return proType;
    }

    public void setProType(String proType) {
        this.proType = proType;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getIsSaleCompleted() {
        return isSaleCompleted;
    }

    public void setIsSaleCompleted(String isSaleCompleted) {
        this.isSaleCompleted = isSaleCompleted;
    }

    public String getReferralAgentCode() {
        return referralAgentCode;
    }

    public void setReferralAgentCode(String referralAgentCode) {
        this.referralAgentCode = referralAgentCode;
    }

  public String getPreferredAgentMobile() {
    return preferredAgentMobile;
  }

  public void setPreferredAgentMobile(String preferredAgentMobile) {
    this.preferredAgentMobile = preferredAgentMobile;
  }

  @Override
    public String toString() {
        return "AssignAgentRequest{" +
                "customId='" + customId + '\'' +
                ", clientNumber='" + clientNumber + '\'' +
                ", dob='" + dob + '\'' +
                ", gender='" + gender + '\'' +
                ", nationality='" + nationality + '\'' +
                ", proType='" + proType + '\'' +
                ", channelType='" + channelType + '\'' +
                ", policyNumber='" + policyNumber + '\'' +
                ", age='" + age + '\'' +
                ", selectedProducts=" + selectedProducts +
                ", isSaleCompleted='" + isSaleCompleted + '\'' +
                ", mobileNo='" + mobileNo + '\'' +
                ", emailId='" + emailId + '\'' +
                ", nricSuffix='" + nricSuffix + '\'' +
                ", referralAgentCode='" + referralAgentCode + '\'' +
                ", preferredAgentMobile='" + preferredAgentMobile + '\'' +
                '}';
    }
}
