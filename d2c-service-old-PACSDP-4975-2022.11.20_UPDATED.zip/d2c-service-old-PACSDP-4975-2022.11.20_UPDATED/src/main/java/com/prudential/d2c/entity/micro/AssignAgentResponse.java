package com.prudential.d2c.entity.micro;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.prudential.d2c.entity.micro.payload.AssignAgentResponsePayload;
@JsonIgnoreProperties(ignoreUnknown = true)
public class AssignAgentResponse {
	private MicroResponseSystem system;
	private AssignAgentResponsePayload payload;
	public AssignAgentResponse(){
		system = new MicroResponseSystem();
		payload = new AssignAgentResponsePayload();
	}
	public MicroResponseSystem getSystem() {
		return system;
	}
	public AssignAgentResponsePayload getPayload() {
		return payload;
	}
	public void setSystem(MicroResponseSystem system) {
		this.system = system;
	}
	public void setPayload(AssignAgentResponsePayload payload) {
		this.payload = payload;
	}
}
