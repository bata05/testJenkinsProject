package com.prudential.d2c.entity.micro;

import com.prudential.d2c.entity.micro.payload.AuthPayload;

public class AuthRequest {
  private MicroRequestSystem system;
  private AuthPayload payload;
  

public MicroRequestSystem getSystem() {
	if(this.system==null){
		this.system = new MicroRequestSystem();
	}
	return system;
}


public AuthPayload getPayload() {
	if(this.payload==null){
		this.payload = new AuthPayload();
	}
	return  payload;
}


public void setSystem(MicroRequestSystem system) {
	this.system = system;
}


public void setPayload(AuthPayload payload) {
	this.payload = payload;
}



}
