package com.prudential.d2c.entity.micro;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
@Builder
public class ChannelAPIAppSubmissionResponse extends ChannelAPIBasePayLoad {
    private ChannelAPIApplicationStatus applicationStatus;
}
