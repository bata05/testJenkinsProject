package com.prudential.d2c.entity.micro;

import com.fasterxml.jackson.annotation.*;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonPropertyOrder({ "transactionId", "dpTransactionId", "partnerEref", "proposalNumber", "errors" })
@JsonAutoDetect(fieldVisibility=JsonAutoDetect.Visibility.ANY, getterVisibility=JsonAutoDetect.Visibility.NONE,
        setterVisibility=JsonAutoDetect.Visibility.NONE, creatorVisibility=JsonAutoDetect.Visibility.NONE)
@Getter
@Setter
@Builder
public class ChannelAPIApplicationStatus {

    @JsonProperty("transactionId")
    private String transactionId;

    @JsonProperty("dpTransactionId")
    private String DPTransactionId;

    @JsonProperty("partnerEref")
    private String partnerEref;

    @JsonProperty("proposalNumber")
    private String proposalNumber;

    @JsonProperty("errors")
    private List<ChannelAPIError> errors;

}
