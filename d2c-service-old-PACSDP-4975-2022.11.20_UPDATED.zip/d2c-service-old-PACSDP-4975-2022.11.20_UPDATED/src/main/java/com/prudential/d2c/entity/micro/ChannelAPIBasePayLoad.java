package com.prudential.d2c.entity.micro;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ChannelAPIBasePayLoad {

    private String transactionId;

    private String dpTransactionId;

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getDpTransactionId() {
        return dpTransactionId;
    }

    public void setDpTransactionId(String dpTransactionId) {
        this.dpTransactionId = dpTransactionId;
    }

}
