package com.prudential.d2c.entity.micro;

public class ChannelAPIErrorResponse {

    private String message;

    private String description;

    public ChannelAPIErrorResponse(String message, String description) {
        this.message = message;
        this.description = description;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
