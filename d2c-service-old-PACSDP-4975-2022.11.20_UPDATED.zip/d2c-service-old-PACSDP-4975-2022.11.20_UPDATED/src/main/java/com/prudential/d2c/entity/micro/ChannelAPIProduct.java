package com.prudential.d2c.entity.micro;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ChannelAPIProduct {

    private String docId;

    private Double sumAssured;
    
    private String paymentMode;
    
    private Double yearlyPremium;

    private Double halfYearlyPremium;

    private Double quarterlyPremium;

    private Double monthlyPremium;

    private Double discount;

    private Double discountedYearlyPremium;

    private Double discountedHalfYearlyPremium;

    private Double discountedQuarterlyPremium;

    private Double discountedMonthlyPremium;
    
    
    public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public String getDocId() {
        return docId;
    }

    public void setDocId(String docId) {
        this.docId = docId;
    }

    public Double getSumAssured() {
        return sumAssured;
    }

    public void setSumAssured(Double sumAssured) {
        this.sumAssured = sumAssured;
    }

    public Double getYearlyPremium() {
        return yearlyPremium;
    }

    public void setYearlyPremium(Double yearlyPremium) {
        this.yearlyPremium = yearlyPremium;
    }

    public Double getHalfYearlyPremium() {
        return halfYearlyPremium;
    }

    public void setHalfYearlyPremium(Double halfYearlyPremium) {
        this.halfYearlyPremium = halfYearlyPremium;
    }

    public Double getQuarterlyPremium() {
        return quarterlyPremium;
    }

    public void setQuarterlyPremium(Double quarterlyPremium) {
        this.quarterlyPremium = quarterlyPremium;
    }

    public Double getMonthlyPremium() {
        return monthlyPremium;
    }

    public void setMonthlyPremium(Double monthlyPremium) {
        this.monthlyPremium = monthlyPremium;
    }

    public Double getDiscount() {
        return discount;
    }

    public void setDiscount(Double discount) {
        this.discount = discount;
    }

    public Double getDiscountedYearlyPremium() {
        return discountedYearlyPremium;
    }

    public void setDiscountedYearlyPremium(Double discountedYearlyPremium) {
        this.discountedYearlyPremium = discountedYearlyPremium;
    }

    public Double getDiscountedHalfYearlyPremium() {
        return discountedHalfYearlyPremium;
    }

    public void setDiscountedHalfYearlyPremium(Double discountedHalfYearlyPremium) {
        this.discountedHalfYearlyPremium = discountedHalfYearlyPremium;
    }

    public Double getDiscountedQuarterlyPremium() {
        return discountedQuarterlyPremium;
    }

    public void setDiscountedQuarterlyPremium(Double discountedQuarterlyPremium) {
        this.discountedQuarterlyPremium = discountedQuarterlyPremium;
    }

    public Double getDiscountedMonthlyPremium() {
        return discountedMonthlyPremium;
    }

    public void setDiscountedMonthlyPremium(Double discountedMonthlyPremium) {
        this.discountedMonthlyPremium = discountedMonthlyPremium;
    }
}
