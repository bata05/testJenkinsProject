package com.prudential.d2c.entity.micro;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ChannelAPIQuestionnaire {

    private String offshoreDeclaration;
    //private String highestEducation;
    private String isBeneficialOwner;
    private ChannelAPIPersonProfile beneficialOwnerProfile;
    private String isPoliticallyExposed;
    private ChannelAPIPersonProfile politicallyExposedProfile;
    private String healthDeclaration;
    private String marketingConsent;
}
