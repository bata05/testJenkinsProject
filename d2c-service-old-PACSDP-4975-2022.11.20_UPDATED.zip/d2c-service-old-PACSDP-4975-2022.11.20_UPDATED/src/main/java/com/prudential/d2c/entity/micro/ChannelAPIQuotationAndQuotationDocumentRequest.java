package com.prudential.d2c.entity.micro;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ChannelAPIQuotationAndQuotationDocumentRequest extends ChannelAPIBasePayLoad {

    private ChannelAPIClientProfile clientProfile;

    private ChannelAPIProduct product;

    public ChannelAPIClientProfile getClientProfile() {
        return clientProfile;
    }

    public void setClientProfile(ChannelAPIClientProfile clientProfile) {
        this.clientProfile = clientProfile;
    }

    public ChannelAPIProduct getProduct() {
        return product;
    }

    public void setProduct(ChannelAPIProduct product) {
        this.product = product;
    }
}
