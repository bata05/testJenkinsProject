package com.prudential.d2c.entity.micro;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ChannelAPIQuotationAndQuotationDocumentResponse extends ChannelAPIBasePayLoad {

    private ChannelAPIClientProfile clientProfile;

    private ChannelAPIProduct product;

    private String quotationPdfToken;

    private List<ChannelAPIError> errors;

    public ChannelAPIClientProfile getClientProfile() {
        return clientProfile;
    }

    public void setClientProfile(ChannelAPIClientProfile clientProfile) {
        this.clientProfile = clientProfile;
    }

    public ChannelAPIProduct getProduct() {
        return product;
    }

    public void setProduct(ChannelAPIProduct product) {
        this.product = product;
    }

    public String getQuotationPdfToken() {
        return quotationPdfToken;
    }

    public void setQuotationPdfToken(String quotationPdfToken) {
        this.quotationPdfToken = quotationPdfToken;
    }

    public List<ChannelAPIError> getErrors() {
        return errors;
    }

    public void setErrors(List<ChannelAPIError> errors) {
        this.errors = errors;
    }
}
