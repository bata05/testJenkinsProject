package com.prudential.d2c.entity.micro;

import java.util.List;

public class ClientErrorContainer {
	private List<ClientError> errors;

	public List<ClientError> getErrors() {
		return errors;
	}
	public void setErrors(List<ClientError> errors) {
		this.errors = errors;
	}
	public String getFirstErrorMessage() {
		String error = null;
		
		if(errors!=null && !errors.isEmpty()){
			error = errors.get(0).getMessage();
		 }
		return error;

	}
}
