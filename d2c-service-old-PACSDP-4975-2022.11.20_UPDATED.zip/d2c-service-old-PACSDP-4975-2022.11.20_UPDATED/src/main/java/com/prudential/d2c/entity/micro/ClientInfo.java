package com.prudential.d2c.entity.micro;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ClientInfo{
	private String clientNumber;
	private String idNumber;
	private String dateOfBirth;
	private String countryOfBirth;
	private String gender;
	private String race;
	private String nationality;
	private String nationalityName;
	private String salutation;
	private String christianName;
	private String firstName;
	private String lastName;
	private String maritalStatus;
	private String emailAddress;
	private String occupation;
	private String occupationClass;
	private String occupationName;
	private String height;
  	private String weight;
  	private String clientType;//none
    private EsubClientContact contact;
    private List<EsubClientAddress> addresses;
    
	public String getClientNumber() {
		return clientNumber;
	}
	public String getIdNumber() {
		return idNumber;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public String getCountryOfBirth() {
		return countryOfBirth;
	}
	public String getGender() {
		return gender;
	}
	public String getRace() {
		return race;
	}
	public String getNationality() {
		return nationality;
	}
	public String getSalutation() {
		return salutation;
	}
	public String getChristianName() {
		return christianName;
	}
	public String getFirstName() {
		return firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public String getMaritalStatus() {
		return maritalStatus;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public String getOccupation() {
		return occupation;
	}
	public String getHeight() {
		return height;
	}
	public String getWeight() {
		return weight;
	}
	public String getClientType() {
		return clientType;
	}
	public EsubClientContact getContact() {
		return contact;
	}
	public List<EsubClientAddress> getAddresses() {
		return addresses;
	}
	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}
	public void setIdNumber(String idNumber) {
		this.idNumber = idNumber;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public void setCountryOfBirth(String countryOfBirth) {
		this.countryOfBirth = countryOfBirth;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public void setRace(String race) {
		this.race = race;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}
	public void setChristianName(String christianName) {
		this.christianName = christianName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	public void setHeight(String height) {
		this.height = height;
	}
	public void setWeight(String weight) {
		this.weight = weight;
	}
	public void setClientType(String clientType) {
		this.clientType = clientType;
	}
	public void setContact(EsubClientContact contact) {
		this.contact = contact;
	}
	public void setAddresses(List<EsubClientAddress> addresses) {
		this.addresses = addresses;
	}
	public String getOccupationClass() {
		return occupationClass;
	}
	public void setOccupationClass(String occupationClass) {
		this.occupationClass = occupationClass;
	}
	public String getNationalityName() {
		return nationalityName;
	}
	public void setNationalityName(String nationalityName) {
		this.nationalityName = nationalityName;
	}
	public String getOccupationName() {
		return occupationName;
	}
	public void setOccupationName(String occupationName) {
		this.occupationName = occupationName;
	}
}
