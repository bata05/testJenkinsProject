package com.prudential.d2c.entity.micro;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@JsonIgnoreProperties(ignoreUnknown = true)
public class ClientPolicyResponse {
    private MicroResponseSystem system;
    private ClientPolicyResponsePayload payload;

    public ClientPolicyResponsePayload getPayload() {
        return payload;
    }
    public void setPayload(ClientPolicyResponsePayload payload) {
        this.payload = payload;
    }
    public MicroResponseSystem getSystem() {
        return system;
    }
    public void setSystem(MicroResponseSystem system) {
        this.system = system;
    }
}
