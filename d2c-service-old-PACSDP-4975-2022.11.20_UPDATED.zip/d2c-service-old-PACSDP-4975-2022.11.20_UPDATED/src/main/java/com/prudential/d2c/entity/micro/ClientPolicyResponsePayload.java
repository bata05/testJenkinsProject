package com.prudential.d2c.entity.micro;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ClientPolicyResponsePayload extends ClientErrorContainer {

    private String transactionId;
    private boolean pruShieldPolicyExist;
    public String getTransactionId() {
        return transactionId;
    }
    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }
    public boolean isPruShieldPolicyExist() {
        return pruShieldPolicyExist;
    }
    public void setPruShieldPolicyExist(boolean pruShieldPolicyExist) {
        this.pruShieldPolicyExist = pruShieldPolicyExist;
    }

}
