package com.prudential.d2c.entity.micro;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.prudential.d2c.entity.micro.payload.ClientResponsePayload;
@JsonIgnoreProperties(ignoreUnknown = true)
public class ClientResponse {
	private MicroResponseSystem system;
	private ClientResponsePayload payload;

	public ClientResponsePayload getPayload() {
		return payload;
	}
	public void setPayload(ClientResponsePayload payload) {
		this.payload = payload;
	}
	public MicroResponseSystem getSystem() {
		return system;
	}
	public void setSystem(MicroResponseSystem system) {
		this.system = system;
	}
	
	
}
