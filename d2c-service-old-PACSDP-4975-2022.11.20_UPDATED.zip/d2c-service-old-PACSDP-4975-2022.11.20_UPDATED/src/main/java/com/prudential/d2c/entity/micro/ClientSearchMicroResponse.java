package com.prudential.d2c.entity.micro;

import com.prudential.d2c.entity.micro.payload.ClientSearchResponsePayload;

public class ClientSearchMicroResponse extends MicroResponse {
	private String transactionId;
	private ClientSearchResponsePayload payload;
	
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public ClientSearchResponsePayload getPayload() {
		return payload;
	}
	public void setPayload(ClientSearchResponsePayload payload) {
		this.payload = payload;
	}
	
	
}
