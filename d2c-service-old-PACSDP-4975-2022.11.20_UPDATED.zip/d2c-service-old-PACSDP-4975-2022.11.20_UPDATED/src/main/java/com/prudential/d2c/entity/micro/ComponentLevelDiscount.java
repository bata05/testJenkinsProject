package com.prudential.d2c.entity.micro;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ComponentLevelDiscount {
    private String componentCode;
    private double discountPercentage;
  
    public ComponentLevelDiscount() {

    }

    public ComponentLevelDiscount(String componentCode, double discountPercentage) {
        this.componentCode = componentCode;
        this.discountPercentage = discountPercentage;
    }

	public String getComponentCode() {
		return componentCode;
	}

	public void setComponentCode(String componentCode) {
		this.componentCode = componentCode;
	}

	public double getDiscountPercentage() {
		return discountPercentage;
	}

	public void setDiscountPercentage(double discountPercentage) {
		this.discountPercentage = discountPercentage;
	}


}
