package com.prudential.d2c.entity.micro;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.prudential.d2c.entity.SuccessStatus;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Compute extends SuccessStatus {

	private ComputeSystem system;
	private Payload payload;


	/**
	 * @return the system
	 */
	public ComputeSystem getSystem() {
		return system;
	}
	/**
	 * @param system the system to set
	 */
	public void setSystem(ComputeSystem system) {
		this.system = system;
	}
	/**
	 * @return the payload
	 */
	public Payload getPayload() {
		return payload;
	}
	/**
	 * @param payload the payload to set
	 */
	public void setPayload(Payload payload) {
		this.payload = payload;
	}
	
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
	

}
