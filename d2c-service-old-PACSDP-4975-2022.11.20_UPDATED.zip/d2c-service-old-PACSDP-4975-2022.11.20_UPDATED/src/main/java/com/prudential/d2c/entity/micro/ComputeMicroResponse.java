package com.prudential.d2c.entity.micro;

import com.prudential.d2c.entity.micro.payload.ComputeResponsePayload;

public class ComputeMicroResponse extends MicroResponse{
	private ComputeResponsePayload payload;

	public ComputeMicroResponse() {
		super();
	}

	public ComputeResponsePayload getPayload() {
		return payload;
	}

	public void setPayload(ComputeResponsePayload payload) {
		this.payload = payload;
	}
	
	
}
