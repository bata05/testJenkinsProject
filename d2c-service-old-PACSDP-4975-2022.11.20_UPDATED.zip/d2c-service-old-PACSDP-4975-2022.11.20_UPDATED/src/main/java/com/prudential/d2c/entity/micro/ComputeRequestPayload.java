package com.prudential.d2c.entity.micro;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.prudential.d2c.entity.Product;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ComputeRequestPayload extends ProductRequestPayload{
	private Boolean generatePDF = false;
	private Boolean generatePIPDF = false;
	private List<Product> selectedSQSProducts;
	private String agentChannelCode ="";
	
	
	public ComputeRequestPayload() {
		super();
	}

	
	public Boolean getGeneratePDF() {
		return generatePDF;
	}


	public void setGeneratePDF(Boolean generatePDF) {
		this.generatePDF = generatePDF;
	}

	public Boolean getGeneratePIPDF() {
		return generatePIPDF;
	}

	public void setGeneratePIPDF(Boolean generatePIPDF) {
		this.generatePIPDF = generatePIPDF;
	}

	public List<Product> getSelectedSQSProducts() {
		return selectedSQSProducts;
	}


	public void setSelectedSQSProducts(List<Product> selectedSQSProducts) {
		this.selectedSQSProducts = selectedSQSProducts;
	}


	public String getAgentChannelCode() {
		return agentChannelCode;
	}


	public void setAgentChannelCode(String agentChannelCode) {
		this.agentChannelCode = agentChannelCode;
	}

	
	
}
