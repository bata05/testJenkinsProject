package com.prudential.d2c.entity.micro;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ComputeSystem {
	
	private String appVersion;
	private String appKey;
	private String clientIP;
	private String appName;
	private String clientUdid;
	private boolean isPayloadEncrypted;
	private String encryptionKey;
	
	//add for computeAll response
	private String status;
	private String apiVersion;
	
	/**
	 * @return the appVersion
	 */
	public String getAppVersion() {
		return appVersion;
	}
	/**
	 * @param appVersion the appVersion to set
	 */
	public void setAppVersion(String appVersion) {
		this.appVersion = appVersion;
	}
	/**
	 * @return the appKey
	 */
	public String getAppKey() {
		return appKey;
	}
	/**
	 * @param appKey the appKey to set
	 */
	public void setAppKey(String appKey) {
		this.appKey = appKey;
	}
	/**
	 * @return the clientIP
	 */
	public String getClientIP() {
		return clientIP;
	}
	/**
	 * @param clientIP the clientIP to set
	 */
	public void setClientIP(String clientIP) {
		this.clientIP = clientIP;
	}
	/**
	 * @return the appName
	 */
	public String getAppName() {
		return appName;
	}
	/**
	 * @param appName the appName to set
	 */
	public void setAppName(String appName) {
		this.appName = appName;
	}
	/**
	 * @return the clientUdid
	 */
	public String getClientUdid() {
		return clientUdid;
	}
	/**
	 * @param clientUdid the clientUdid to set
	 */
	public void setClientUdid(String clientUdid) {
		this.clientUdid = clientUdid;
	}
	/**
	 * @return the isPayloadEncrypted
	 */
	public boolean getIsPayloadEncrypted() {
		return isPayloadEncrypted;
	}
	/**
	 * @param isPayloadEncrypted the isPayloadEncrypted to set
	 */
	public void setIsPayloadEncrypted(boolean isPayloadEncrypted) {
		this.isPayloadEncrypted = isPayloadEncrypted;
	}
	/**
	 * @return the encryptionKey
	 */
	public String getEncryptionKey() {
		return encryptionKey;
	}
	/**
	 * @param encryptionKey the encryptionKey to set
	 */
	public void setEncryptionKey(String encryptionKey) {
		this.encryptionKey = encryptionKey;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the apiVersion
	 */
	public String getApiVersion() {
		return apiVersion;
	}
	/**
	 * @param apiVersion the apiVersion to set
	 */
	public void setApiVersion(String apiVersion) {
		this.apiVersion = apiVersion;
	}

	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
	
}
