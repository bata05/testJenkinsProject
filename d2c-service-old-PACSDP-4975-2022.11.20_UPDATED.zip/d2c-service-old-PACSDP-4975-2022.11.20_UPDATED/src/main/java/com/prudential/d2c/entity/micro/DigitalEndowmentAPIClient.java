package com.prudential.d2c.entity.micro;

import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class DigitalEndowmentAPIClient {
	
	private int clientId;
	private String salutation;
	private String givenName;
	private String christianName;
	private String surname;
	private String dateOfBirth;
	private String gender;
	private String nationality;
	private String nationalitySpr;
	private String nric;
	private String maritalStatus;
	private boolean smoker;
	private String residency;
	private int yearsResideOutside;
	private int daysResideInside;
	private boolean resideOutside5Year;
	private String race;
	private BigDecimal height;
	private BigDecimal weight;
    private String passStatus;
    private String passExpiryDate;
    private String passType;
	private String countryOfBirth;
	private String cpfAccountNo;
	private boolean publicServiceOfficer;
	private boolean staffSelectedCompany;
	private boolean mailSameAsResidential;
	private boolean residentialSameAsProposer;
	private String countryOfStudy;
	private String education;
	private boolean englishSpeaking;

	private int yearsOfWorking; 
	private String occupation;
	private String occupationClass;
	private String employer;
	private String employmentType;
	private String annualIncomeType;
	private double annualBonus;
	private double otherIncome;
	private double annualIncome;
	private String jobDuties;
	private String businessIndustry;
	private String otherIndustry;
	private String otherOccupation;
	private int yearsToSupport;
	private boolean disclose;
	private boolean privateConfidential;
	private boolean personalReason;
	private boolean jointAsset;
	private String discloseOtherReason;
	private boolean accompanied;
	private String trusteeName;
	private String trusteeNric;
	private String trusteeRelationship;
	private String relationship;
	private String fin;
	private int ageNextBirthday;
	private boolean childOwnCpf;
	private boolean filedUsTax;
	private String clientRelationship;
	private DigitalEndowmentAPIClientContact contact;
	private List<DigitalEndowmentAPIClientAddress> addresses;
	private boolean foreigner;
	
	private int previousYearsOfWorking;
	private String previousBusinessIndustry;
	private String previousEmployer;
	private String previousOccupation;
	private BigDecimal previousAnnualIncome;

	private String investmentName;
	private String investmentType;
	private BigDecimal investmentIncomeValue;
	private int monthInvestmentIncomeEarned;
	
	private String saleIncomeName;
	private BigDecimal valueOfSaleIncome;
	private int saleIncomeYear;
	
	private BigDecimal valueOfPolicyProceed;
	private int policyProceedYear;
	private String policyProceedPayer;

	private BigDecimal valueOfInheritance;
	private String gifterName;
	private String gifterRelationship;
	private int gifterYearsOfWorking;
	private String gifterBusinessIndustry;
	private String gifterOccupation;
	private BigDecimal gifterAnnualIncome;
	private String gifterEmployer;
	
	private String providerName;
	private String providerRelationship;
	private int providerYearsOfWorking;
	private String providerBusinessIndustry;
	private String providerOccupation;
	private BigDecimal providerAnnualIncome;
	private String providerEmployer;
	
}
