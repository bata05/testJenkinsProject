package com.prudential.d2c.entity.micro;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class DigitalEndowmentAPIESubPayment {

    private String paymentTransactionId;
    private String paymentSource;
	private double totalPrem;
	private String paymentMode;
	private String paymentModeX;
	private String paymentMethod;
	private String paymentMethodX;
	private String payFor;
	private String cardType;
	private String nameOfCardholder;
	private String cardholderRelToProposer;
	private String cardTypeX;
	private String nameOfCardholderX;
	private String cardholderRelToProposerX;
	private double firstPremAmt;
	private double installPremAmtX;
	private String maturityPolNo;
	private String cpfAccountNoOA;
	private String cpfAccountNoSA;
	private String cpfAccountNoSRS;
	private String cpfAgentBank;
	private String invAccountNo;
	
	//begin not in PS---------------
	private String mercId;
	private String mercRefNo;
	private String currency;
	private double transAmt;
	private String paymentType;
	private String gatewayErrorCode;
	private String gatewayErrorMsg;
	private String approvalCode;
	private String bankRetCode;
	private String creditCardNum;
	private String creditCardExpiration;
	private String respSignature;
	private String eci;
	private String cavv;
	private String xid;
	private String origRefNo;
	private String origPayType;
	private int validFlag;
	private String respTimestamp;
	private String reqTimestamp;
	private String lastModifiedTimestamp;
	private double installPremAmt;
	private double amtPaid;
	private String txnTimestamp;
	private String tydes;
	private String pymtMethod;
	private String instFromDate;
	private String instToDate;
	private String remark;
	private double itemPymtAmt;
	private double premDue;
	private double origPrem;
	//end not in PS------------------
	
	private String maskedCreditCardNum;
	private String creditCardNumX;
	private String maskedCreditCardNumX;
	private String creditCardExpirationX;
    private String recupDate;
	
}
