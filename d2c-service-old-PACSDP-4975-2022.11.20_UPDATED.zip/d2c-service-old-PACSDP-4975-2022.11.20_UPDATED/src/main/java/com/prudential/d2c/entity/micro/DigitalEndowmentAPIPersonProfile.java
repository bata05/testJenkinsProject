package com.prudential.d2c.entity.micro;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class DigitalEndowmentAPIPersonProfile {

    private String name;
    private String nric;
    private String dob;
    private String nationalityCode;
    private String residencyCountryCode;
    private String relationship;
    private String natureOfPublicFunc;
}
