package com.prudential.d2c.entity.micro;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class DigitalEndowmentAPIPruPayAttributes {
	
	public String is_web;
    public String pgTransactionId;
    public String externalMerchantId;
    public String masked_pan;
    public String serviceCode;
    public String webSessionId;
    public String namespace;
    public String paymentSource;
    public Date lastUpdatedTime;
    public String lang;
    public String pgCode;
    public String paymentChannel;
    public String tokenize;
 
}
