package com.prudential.d2c.entity.micro;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class DigitalEndowmentAPIQuestionnaire {

	private String singaporeCitizen;
	private String taxResidentOfSing;
	private String fileTaxInUS;
	private String singTINisNRIC;
    private String locationInSingapore;
    private String notReplacePolicy;
    private String beneficialOwners;
    private String payByYou;
    private String isPoliticallyExposed;
    
    private String highestEducation;
    private String marketingConsent;
    private String englishProficiency;
    
}
