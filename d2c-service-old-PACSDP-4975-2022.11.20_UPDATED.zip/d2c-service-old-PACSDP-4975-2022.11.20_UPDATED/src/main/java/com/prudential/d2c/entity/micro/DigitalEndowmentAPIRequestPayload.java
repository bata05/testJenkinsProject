package com.prudential.d2c.entity.micro;


import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class DigitalEndowmentAPIRequestPayload {
		
	@JsonProperty("transactionId")
	private String transactionId;
	
	@JsonProperty("ereferenceNo")
	private String ereferenceNo;
	
	@JsonProperty("agentCode")
	private String agentCode;
	
	@JsonProperty("agentBizSource")
	private String agentBizSource;
	
	@JsonProperty("agentSubSource")
	private String agentSubSource;
	
	@JsonProperty("bankReferralCode")
	private String bankReferralCode;
	
	@JsonProperty("bankReferralMobileNumber")
	private String bankReferralMobileNumber;
	
	@JsonProperty("agentName")
	private String agentName;
	
	@JsonProperty("agentType")
	private String agentType;
	
	@JsonProperty("agentEmail")
	private String agentEmail;
	
	@JsonProperty("agentMobileNumber")
	private String agentMobileNumber;
	
	@JsonProperty("agentChannelCode")
	private String agentChannelCode;
	
	@JsonProperty("isExistingClient ")
	private Boolean isExistingClient;
	
	@JsonProperty("clientNumber")
	private String clientNumber;
	
	@JsonProperty("saAgentCode")
	private String saAgentCode;
	
	@JsonProperty("clients")
	private List<DigitalEndowmentAPIClient> clients;
	
	@JsonProperty("sqs")
	private SQSProduct sqs;
	
	@JsonProperty("payment")
	private DigitalEndowmentAPIESubPayment payment;
	
	@JsonProperty("forms")
	private List<Form> forms;
	
	@JsonProperty("planDetail")
	private PlanDetail planDetail;
	
	@JsonProperty("document")
	private List<DigitalEndowmentAPIRequestDocument> document;
	
	@JsonProperty("bypassPlanner")
	private Boolean bypassPlanner;
	
	@JsonProperty("srcInd")
	private String srcInd;
	
	@JsonProperty("myInfo")
	private Boolean myInfo;
	
	@JsonProperty("extraPayment")
	private DigitalEndowmentAPIESubPayment extraPayment;
	
	@JsonProperty("questionnaire")
	private DigitalEndowmentAPIQuestionnaire questionnaire;

	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}

}
