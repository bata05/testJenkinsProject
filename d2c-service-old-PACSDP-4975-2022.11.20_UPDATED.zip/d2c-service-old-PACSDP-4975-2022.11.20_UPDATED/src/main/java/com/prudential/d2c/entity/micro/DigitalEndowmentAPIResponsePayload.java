package com.prudential.d2c.entity.micro;


import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonPropertyOrder({ "policy", "responseCode", "responseDesc", "errors" })
public class DigitalEndowmentAPIResponsePayload {

    private List<DigitalEndowmentAPIPolicy> policy;
    private String responseCode;
    private String responseDesc;
    private List <DigitalEndowmentAPIError> errors;
}
