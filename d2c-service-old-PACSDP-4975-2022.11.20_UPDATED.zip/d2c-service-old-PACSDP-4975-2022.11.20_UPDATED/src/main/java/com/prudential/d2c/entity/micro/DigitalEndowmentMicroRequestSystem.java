package com.prudential.d2c.entity.micro;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class DigitalEndowmentMicroRequestSystem {
	
	private String appVersion;
	private String appKey;
	private String clientIP;
	private String clientUdid;
	private String appName;
	private Boolean isPayloadEncrypted;
	private String encryptionKey;
	private String status;
	
}
