package com.prudential.d2c.entity.micro;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Discount {
    private double percentage;
    private int startAge;
    private int endAge;
    
    private List <ComponentLevelDiscount> componentLevelDiscount;

    public Discount() {

    }

    public Discount(double percentage, int startAge, int endAge) {
        this.percentage = percentage;
        this.startAge = startAge;
        this.endAge = endAge;
    }

    public double getPercentage() {
        return percentage;
    }

    public void setPercentage(double percentage) {
        this.percentage = percentage;
    }

    public int getStartAge() {
        return startAge;
    }

    public void setStartAge(int startAge) {
        this.startAge = startAge;
    }

    public int getEndAge() {
        return endAge;
    }

    public void setEndAge(int endAge) {
        this.endAge = endAge;
    }

	public List<ComponentLevelDiscount> getComponentLevelDiscount() {
		return componentLevelDiscount;
	}

	public void setComponentLevelDiscount(List<ComponentLevelDiscount> componentLevelDiscount) {
		this.componentLevelDiscount = componentLevelDiscount;
	}

}
