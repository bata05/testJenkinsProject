package com.prudential.d2c.entity.micro;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.prudential.d2c.service.validator.ValidationFailure;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Error implements ValidationFailure{

    private String messageCode;
    private String messageType;
    private String messageDesc;
    private String locale;
    private String code;
    
    @Override
    public String toString() {
        return "Error{" +
                "messageCode='" + messageCode + '\'' +
                ", messageType='" + messageType + '\'' +
                ", messageDesc='" + messageDesc + '\'' +
                ", locale='" + locale + '\'' +
                '}';
    }
}
