package com.prudential.d2c.entity.micro;

import java.io.Serializable;

import com.prudential.d2c.entity.micro.payload.ErrorMessagesPayload;
public class ErrorMessagesResponse implements Serializable{
	/**
     * 
     */
    private static final long serialVersionUID = 1L;
    private MicroResponseSystem system;
	private ErrorMessagesPayload payload;
	public MicroResponseSystem getSystem() {
		return system;
	}
	public ErrorMessagesPayload getPayload() {
		return payload;
	}
	public void setSystem(MicroResponseSystem system) {
		this.system = system;
	}
	public void setPayload(ErrorMessagesPayload payload) {
		this.payload = payload;
	}
}
