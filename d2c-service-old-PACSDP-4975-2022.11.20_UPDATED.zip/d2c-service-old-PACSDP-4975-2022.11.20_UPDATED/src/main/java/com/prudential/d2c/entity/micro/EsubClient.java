package com.prudential.d2c.entity.micro;

import java.util.List;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class EsubClient {
	
	private int clientId;
	private String salutation;
	private String givenName;
	private String christianName;
	private String surname;
	private String dateOfBirth;
	private String gender;
	private String nationality;
	private String nationalitySpr;
	private String passType;
	private String nric;
	private String maritalStatus;
	private boolean smoker;
	private String residency;
	private int yearsResideOutside;
	private int daysResideInside;
	private boolean resideOutside5Year;
	private String race;
	private double height;
	private double weight;
	private String countryOfBirth;
	private String cpfAccountNo;
	private boolean publicServiceOfficer;
	private boolean staffSelectedCompany;
	private boolean mailSameAsResidential;
	private boolean residentialSameAsProposer;
	private String countryOfStudy;
	private String education;
	private boolean englishSpeaking;
	private String occupation;
	private String occupationClass;
	private String employer;
	private String employmentType;
	private String annualIncomeType;
	private double annualBonus;
	private double otherIncome;
	private double annualIncome;
	private String jobDuties;
	private String businessIndustry;
	private String otherOccupation;
	private int yearsToSupport;
	private boolean disclose;
	private boolean privateConfidential;
	private boolean personalReason;
	private boolean jointAsset;
	private String discloseOtherReason;
	private boolean accompanied;
	private String trusteeName;
	private String trusteeNric;
	private String trusteeRelationship;
	private String relationship;
	private String fin;
	private int ageNextBirthday;
	private boolean childOwnCpf;
	private boolean filedUsTax;
	private String clientRelationship;
	private EsubClientContact contact;
	private List<EsubClientAddress> addresses;
	private boolean foreigner;
	/**
	 * @return the clientId
	 */
	public int getClientId() {
		return clientId;
	}
	/**
	 * @param clientId the clientId to set
	 */
	public void setClientId(int clientId) {
		this.clientId = clientId;
	}
	/**
	 * @return the salutation
	 */
	public String getSalutation() {
		return salutation;
	}
	/**
	 * @param salutation the salutation to set
	 */
	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}
	/**
	 * @return the givenName
	 */
	public String getGivenName() {
		return givenName;
	}
	/**
	 * @param givenName the givenName to set
	 */
	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}
	/**
	 * @return the christianName
	 */
	public String getChristianName() {
		return christianName;
	}
	/**
	 * @param christianName the christianName to set
	 */
	public void setChristianName(String christianName) {
		this.christianName = christianName;
	}
	/**
	 * @return the surname
	 */
	public String getSurname() {
		return surname;
	}
	/**
	 * @param surname the surname to set
	 */
	public void setSurname(String surname) {
		this.surname = surname;
	}
	/**
	 * @return the dateOfBirth
	 */
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	/**
	 * @param dateOfBirth the dateOfBirth to set
	 */
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}
	/**
	 * @param gender the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}
	/**
	 * @return the nationality
	 */
	public String getNationality() {
		return nationality;
	}
	/**
	 * @param nationality the nationality to set
	 */
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	/**
	 * @return the passType
	 */
	public String getPassType() {
		return passType;
	}

	/**
	 * @param passType the passType to set
	 */
	public void setPassType(String passType) {
		this.passType = passType;
	}

	/**
	 * @return the nric
	 */
	public String getNric() {
		return nric;
	}
	/**
	 * @param nric the nric to set
	 */
	public void setNric(String nric) {
		this.nric = nric;
	}
	/**
	 * @return the maritalStatus
	 */
	public String getMaritalStatus() {
		return maritalStatus;
	}
	/**
	 * @param maritalStatus the maritalStatus to set
	 */
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	/**
	 * @return the smoker
	 */
	public boolean isSmoker() {
		return smoker;
	}
	/**
	 * @param smoker the smoker to set
	 */
	public void setSmoker(boolean smoker) {
		this.smoker = smoker;
	}
	/**
	 * @return the residency
	 */
	public String getResidency() {
		return residency;
	}
	/**
	 * @param residency the residency to set
	 */
	public void setResidency(String residency) {
		this.residency = residency;
	}
	/**
	 * @return the yearsResideOutside
	 */
	public int getYearsResideOutside() {
		return yearsResideOutside;
	}
	/**
	 * @param yearsResideOutside the yearsResideOutside to set
	 */
	public void setYearsResideOutside(int yearsResideOutside) {
		this.yearsResideOutside = yearsResideOutside;
	}
	/**
	 * @return the daysResideInside
	 */
	public int getDaysResideInside() {
		return daysResideInside;
	}
	/**
	 * @param daysResideInside the daysResideInside to set
	 */
	public void setDaysResideInside(int daysResideInside) {
		this.daysResideInside = daysResideInside;
	}
	/**
	 * @return the height
	 */
	public double getHeight() {
		return height;
	}
	/**
	 * @param height the height to set
	 */
	public void setHeight(double height) {
		this.height = height;
	}
	/**
	 * @return the weight
	 */
	public double getWeight() {
		return weight;
	}
	/**
	 * @param weight the weight to set
	 */
	public void setWeight(double weight) {
		this.weight = weight;
	}
	/**
	 * @return the countryOfBirth
	 */
	public String getCountryOfBirth() {
		return countryOfBirth;
	}
	/**
	 * @param countryOfBirth the countryOfBirth to set
	 */
	public void setCountryOfBirth(String countryOfBirth) {
		this.countryOfBirth = countryOfBirth;
	}
	/**
	 * @return the education
	 */
	public String getEducation() {
		return education;
	}
	/**
	 * @param education the education to set
	 */
	public void setEducation(String education) {
		this.education = education;
	}
	/**
	 * @return the occupation
	 */
	public String getOccupation() {
		return occupation;
	}
	/**
	 * @param occupation the occupation to set
	 */
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	/**
	 * @return the occupationClass
	 */
	public String getOccupationClass() {
		return occupationClass;
	}
	/**
	 * @param occupationClass the occupationClass to set
	 */
	public void setOccupationClass(String occupationClass) {
		this.occupationClass = occupationClass;
	}
	/**
	 * @return the employer
	 */
	public String getEmployer() {
		return employer;
	}
	/**
	 * @param employer the employer to set
	 */
	public void setEmployer(String employer) {
		this.employer = employer;
	}
	/**
	 * @return the annualIncome
	 */
	public double getAnnualIncome() {
		return annualIncome;
	}
	/**
	 * @param annualIncome the annualIncome to set
	 */
	public void setAnnualIncome(double annualIncome) {
		this.annualIncome = annualIncome;
	}
	/**
	 * @return the jobDuties
	 */
	public String getJobDuties() {
		return jobDuties;
	}
	/**
	 * @param jobDuties the jobDuties to set
	 */
	public void setJobDuties(String jobDuties) {
		this.jobDuties = jobDuties;
	}
	/**
	 * @return the ageNextBirthday
	 */
	public int getAgeNextBirthday() {
		return ageNextBirthday;
	}
	/**
	 * @param ageNextBirthday the ageNextBirthday to set
	 */
	public void setAgeNextBirthday(int ageNextBirthday) {
		this.ageNextBirthday = ageNextBirthday;
	}
	/**
	 * @return the contact
	 */
	public EsubClientContact getContact() {
		return contact;
	}
	/**
	 * @param contact the contact to set
	 */
	public void setContact(EsubClientContact contact) {
		this.contact = contact;
	}
	/**
	 * @return the addresses
	 */
	public List<EsubClientAddress> getAddresses() {
		return addresses;
	}
	/**
	 * @param addresses the addresses to set
	 */
	public void setAddresses(List<EsubClientAddress> addresses) {
		this.addresses = addresses;
	}
	
	/**
	 * @return the cpfAccountNo
	 */
	public String getCpfAccountNo() {
		return cpfAccountNo;
	}
	/**
	 * @param cpfAccountNo the cpfAccountNo to set
	 */
	public void setCpfAccountNo(String cpfAccountNo) {
		this.cpfAccountNo = cpfAccountNo;
	}
	/**
	 * @return the publicServiceOfficer
	 */
	public boolean isPublicServiceOfficer() {
		return publicServiceOfficer;
	}
	/**
	 * @param publicServiceOfficer the publicServiceOfficer to set
	 */
	public void setPublicServiceOfficer(boolean publicServiceOfficer) {
		this.publicServiceOfficer = publicServiceOfficer;
	}
	/**
	 * @return the staffSelectedCompany
	 */
	public boolean isStaffSelectedCompany() {
		return staffSelectedCompany;
	}
	/**
	 * @param staffSelectedCompany the staffSelectedCompany to set
	 */
	public void setStaffSelectedCompany(boolean staffSelectedCompany) {
		this.staffSelectedCompany = staffSelectedCompany;
	}
	/**
	 * @return the mailSameAsResidential
	 */
	public boolean isMailSameAsResidential() {
		return mailSameAsResidential;
	}
	/**
	 * @param mailSameAsResidential the mailSameAsResidential to set
	 */
	public void setMailSameAsResidential(boolean mailSameAsResidential) {
		this.mailSameAsResidential = mailSameAsResidential;
	}
	/**
	 * @return the residentialSameAsProposer
	 */
	public boolean isResidentialSameAsProposer() {
		return residentialSameAsProposer;
	}
	/**
	 * @param residentialSameAsProposer the residentialSameAsProposer to set
	 */
	public void setResidentialSameAsProposer(boolean residentialSameAsProposer) {
		this.residentialSameAsProposer = residentialSameAsProposer;
	}
	/**
	 * @return the countryOfStudy
	 */
	public String getCountryOfStudy() {
		return countryOfStudy;
	}
	/**
	 * @param countryOfStudy the countryOfStudy to set
	 */
	public void setCountryOfStudy(String countryOfStudy) {
		this.countryOfStudy = countryOfStudy;
	}
	/**
	 * @return the englishSpeaking
	 */
	public boolean isEnglishSpeaking() {
		return englishSpeaking;
	}
	/**
	 * @param englishSpeaking the englishSpeaking to set
	 */
	public void setEnglishSpeaking(boolean englishSpeaking) {
		this.englishSpeaking = englishSpeaking;
	}
	/**
	 * @return the employmentType
	 */
	public String getEmploymentType() {
		return employmentType;
	}
	/**
	 * @param employmentType the employmentType to set
	 */
	public void setEmploymentType(String employmentType) {
		this.employmentType = employmentType;
	}
	/**
	 * @return the annualIncomeType
	 */
	public String getAnnualIncomeType() {
		return annualIncomeType;
	}
	/**
	 * @param annualIncomeType the annualIncomeType to set
	 */
	public void setAnnualIncomeType(String annualIncomeType) {
		this.annualIncomeType = annualIncomeType;
	}
	/**
	 * @return the annualBonus
	 */
	public double getAnnualBonus() {
		return annualBonus;
	}
	/**
	 * @param annualBonus the annualBonus to set
	 */
	public void setAnnualBonus(double annualBonus) {
		this.annualBonus = annualBonus;
	}
	/**
	 * @return the otherIncome
	 */
	public double getOtherIncome() {
		return otherIncome;
	}
	/**
	 * @param otherIncome the otherIncome to set
	 */
	public void setOtherIncome(double otherIncome) {
		this.otherIncome = otherIncome;
	}
	/**
	 * @return the businessIndustry
	 */
	public String getBusinessIndustry() {
		return businessIndustry;
	}
	/**
	 * @param businessIndustry the businessIndustry to set
	 */
	public void setBusinessIndustry(String businessIndustry) {
		this.businessIndustry = businessIndustry;
	}
	/**
	 * @return the otherOccupation
	 */
	public String getOtherOccupation() {
		return otherOccupation;
	}
	/**
	 * @param otherOccupation the otherOccupation to set
	 */
	public void setOtherOccupation(String otherOccupation) {
		this.otherOccupation = otherOccupation;
	}
	/**
	 * @return the yearsToSupport
	 */
	public int getYearsToSupport() {
		return yearsToSupport;
	}
	/**
	 * @param yearsToSupport the yearsToSupport to set
	 */
	public void setYearsToSupport(int yearsToSupport) {
		this.yearsToSupport = yearsToSupport;
	}
	/**
	 * @return the clientRelationship
	 */
	public String getClientRelationship() {
		return clientRelationship;
	}
	/**
	 * @param clientRelationship the clientRelationship to set
	 */
	public void setClientRelationship(String clientRelationship) {
		this.clientRelationship = clientRelationship;
	}
	/**
	 * @return the foreigner
	 */
	public boolean isForeigner() {
		return foreigner;
	}
	/**
	 * @param foreigner the foreigner to set
	 */
	public void setForeigner(boolean foreigner) {
		this.foreigner = foreigner;
	}
	@Override
	public String toString()
	{
		Object fieldExcludedObject = ReflectionToStringBuilder.toStringExclude(this, "nric");
		return ToStringBuilder.reflectionToString(fieldExcludedObject);
	}
	/**
	 * @return the race
	 */
	public String getRace() {
		return race;
	}
	/**
	 * @param race the race to set
	 */
	public void setRace(String race) {
		this.race = race;
	}
	/**
	 * @return the disclose
	 */
	public boolean isDisclose() {
		return disclose;
	}
	/**
	 * @param disclose the disclose to set
	 */
	public void setDisclose(boolean disclose) {
		this.disclose = disclose;
	}
	/**
	 * @return the privateConfidential
	 */
	public boolean isPrivateConfidential() {
		return privateConfidential;
	}
	/**
	 * @param privateConfidential the privateConfidential to set
	 */
	public void setPrivateConfidential(boolean privateConfidential) {
		this.privateConfidential = privateConfidential;
	}
	/**
	 * @return the personalReason
	 */
	public boolean isPersonalReason() {
		return personalReason;
	}
	/**
	 * @param personalReason the personalReason to set
	 */
	public void setPersonalReason(boolean personalReason) {
		this.personalReason = personalReason;
	}
	/**
	 * @return the jointAsset
	 */
	public boolean isJointAsset() {
		return jointAsset;
	}
	/**
	 * @param jointAsset the jointAsset to set
	 */
	public void setJointAsset(boolean jointAsset) {
		this.jointAsset = jointAsset;
	}
	/**
	 * @return the discloseOtherReason
	 */
	public String getDiscloseOtherReason() {
		return discloseOtherReason;
	}
	/**
	 * @param discloseOtherReason the discloseOtherReason to set
	 */
	public void setDiscloseOtherReason(String discloseOtherReason) {
		this.discloseOtherReason = discloseOtherReason;
	}
	/**
	 * @return the accompanied
	 */
	public boolean isAccompanied() {
		return accompanied;
	}
	/**
	 * @param accompanied the accompanied to set
	 */
	public void setAccompanied(boolean accompanied) {
		this.accompanied = accompanied;
	}
	/**
	 * @return the trusteeName
	 */
	public String getTrusteeName() {
		return trusteeName;
	}
	/**
	 * @param trusteeName the trusteeName to set
	 */
	public void setTrusteeName(String trusteeName) {
		this.trusteeName = trusteeName;
	}
	/**
	 * @return the trusteeNric
	 */
	public String getTrusteeNric() {
		return trusteeNric;
	}
	/**
	 * @param trusteeNric the trusteeNric to set
	 */
	public void setTrusteeNric(String trusteeNric) {
		this.trusteeNric = trusteeNric;
	}
	/**
	 * @return the trusteeRelationship
	 */
	public String getTrusteeRelationship() {
		return trusteeRelationship;
	}
	/**
	 * @param trusteeRelationship the trusteeRelationship to set
	 */
	public void setTrusteeRelationship(String trusteeRelationship) {
		this.trusteeRelationship = trusteeRelationship;
	}
	/**
	 * @return the relationship
	 */
	public String getRelationship() {
		return relationship;
	}
	/**
	 * @param relationship the relationship to set
	 */
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}
	/**
	 * @return the fin
	 */
	public String getFin() {
		return fin;
	}
	/**
	 * @param fin the fin to set
	 */
	public void setFin(String fin) {
		this.fin = fin;
	}
	/**
	 * @return the childOwnCpf
	 */
	public boolean isChildOwnCpf() {
		return childOwnCpf;
	}
	/**
	 * @param childOwnCpf the childOwnCpf to set
	 */
	public void setChildOwnCpf(boolean childOwnCpf) {
		this.childOwnCpf = childOwnCpf;
	}
	/**
	 * @return the filedUsTax
	 */
	public boolean isFiledUsTax() {
		return filedUsTax;
	}
	/**
	 * @param filedUsTax the filedUsTax to set
	 */
	public void setFiledUsTax(boolean filedUsTax) {
		this.filedUsTax = filedUsTax;
	}
	public boolean isResideOutside5Year() {
		return resideOutside5Year;
	}
	public void setResideOutside5Year(boolean resideOutside5Year) {
		this.resideOutside5Year = resideOutside5Year;
	}
	public String getNationalitySpr() {
		return nationalitySpr;
	}
	public void setNationalitySpr(String nationalitySpr) {
		this.nationalitySpr = nationalitySpr;
	}
	
	
}
