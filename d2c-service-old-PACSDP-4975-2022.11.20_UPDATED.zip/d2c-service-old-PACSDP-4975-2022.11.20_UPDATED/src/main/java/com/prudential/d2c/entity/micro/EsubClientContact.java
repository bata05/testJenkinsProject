package com.prudential.d2c.entity.micro;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class EsubClientContact {
	
	private String homePhoneArea;
	private String officePhoneArea;
	private String mobilePhoneArea;
	private String homePhone;
	private String officePhone;
	private String mobilePhone;
	private String email;
	private String homeContactIDD ;
	private String mobileContactIDD;
	/**
	 * @return the homePhoneArea
	 */
	public String getHomePhoneArea() {
		return homePhoneArea;
	}
	/**
	 * @param homePhoneArea the homePhoneArea to set
	 */
	public void setHomePhoneArea(String homePhoneArea) {
		this.homePhoneArea = homePhoneArea;
	}
	/**
	 * @return the officePhoneArea
	 */
	public String getOfficePhoneArea() {
		return officePhoneArea;
	}
	/**
	 * @param officePhoneArea the officePhoneArea to set
	 */
	public void setOfficePhoneArea(String officePhoneArea) {
		this.officePhoneArea = officePhoneArea;
	}
	/**
	 * @return the mobilePhoneArea
	 */
	public String getMobilePhoneArea() {
		return mobilePhoneArea;
	}
	/**
	 * @param mobilePhoneArea the mobilePhoneArea to set
	 */
	public void setMobilePhoneArea(String mobilePhoneArea) {
		this.mobilePhoneArea = mobilePhoneArea;
	}
	/**
	 * @return the homePhone
	 */
	public String getHomePhone() {
		return homePhone;
	}
	/**
	 * @param homePhone the homePhone to set
	 */
	public void setHomePhone(String homePhone) {
		this.homePhone = homePhone;
	}
	/**
	 * @return the officePhone
	 */
	public String getOfficePhone() {
		return officePhone;
	}
	/**
	 * @param officePhone the officePhone to set
	 */
	public void setOfficePhone(String officePhone) {
		this.officePhone = officePhone;
	}
	/**
	 * @return the mobilePhone
	 */
	public String getMobilePhone() {
		return mobilePhone;
	}
	/**
	 * @param mobilePhone the mobilePhone to set
	 */
	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	public String getHomeContactIDD() {
		return homeContactIDD;
	}

	public void setHomeContactIDD(String homeContactIDD) {
		this.homeContactIDD = homeContactIDD;
	}

	public String getMobileContactIDD() {
		return mobileContactIDD;
	}

	public void setMobileContactIDD(String mobileContactIDD) {
		this.mobileContactIDD = mobileContactIDD;
	}

	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
	
	

}
