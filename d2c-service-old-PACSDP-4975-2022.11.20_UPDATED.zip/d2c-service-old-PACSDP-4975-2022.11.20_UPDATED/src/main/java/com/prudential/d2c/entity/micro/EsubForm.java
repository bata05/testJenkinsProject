package com.prudential.d2c.entity.micro;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class EsubForm {
	
	private List<EsubQuestionnaireForm> questionnaireForms;

	/**
	 * @return the questionnaireForms
	 */
	public List<EsubQuestionnaireForm> getQuestionnaireForms() {
		return questionnaireForms;
	}

	/**
	 * @param questionnaireForms the questionnaireForms to set
	 */
	public void setQuestionnaireForms(List<EsubQuestionnaireForm> questionnaireForms) {
		this.questionnaireForms = questionnaireForms;
	}
	
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
	

}
