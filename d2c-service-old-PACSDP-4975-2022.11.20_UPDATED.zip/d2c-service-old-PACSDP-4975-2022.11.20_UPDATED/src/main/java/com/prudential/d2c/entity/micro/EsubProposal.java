package com.prudential.d2c.entity.micro;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class EsubProposal {
	private String eRefNo;
	private int clientId;
	private EsubProposalPayment payment;
	private List<EsubForm> forms;
	/**
	 * @return the payment
	 */
	public EsubProposalPayment getPayment() {
		return payment;
	}
	/**
	 * @param payment the payment to set
	 */
	public void setPayment(EsubProposalPayment payment) {
		this.payment = payment;
	}
	/**
	 * @return the forms
	 */
	public List<EsubForm> getForms() {
		return forms;
	}
	/**
	 * @param forms the forms to set
	 */
	public void setForms(List<EsubForm> forms) {
		this.forms = forms;
	}
	
	/**
	 * @return the eRefNo
	 */
	public String geteRefNo() {
		return eRefNo;
	}
	/**
	 * @param eRefNo the eRefNo to set
	 */
	public void seteRefNo(String eRefNo) {
		this.eRefNo = eRefNo;
	}
	/**
	 * @return the clientId
	 */
	public int getClientId() {
		return clientId;
	}
	/**
	 * @param clientId the clientId to set
	 */
	public void setClientId(int clientId) {
		this.clientId = clientId;
	}
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
	
	

}
