package com.prudential.d2c.entity.micro;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class EsubProposalPayment {
	
	private String totalPrem;

	/**
	 * @return the totalPrem
	 */
	public String getTotalPrem() {
		return totalPrem;
	}

	/**
	 * @param totalPrem the totalPrem to set
	 */
	public void setTotalPrem(String totalPrem) {
		this.totalPrem = totalPrem;
	}
	
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
	
	

}
