package com.prudential.d2c.entity.micro;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class EsubQuestion extends Question{

	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
	

}
