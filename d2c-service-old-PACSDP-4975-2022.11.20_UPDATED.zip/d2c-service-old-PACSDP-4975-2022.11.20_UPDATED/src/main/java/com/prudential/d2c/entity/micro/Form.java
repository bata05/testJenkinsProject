package com.prudential.d2c.entity.micro;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Form {
	private String categoryCode;
	private List<QuestionnaireForm> questionnaireForms;
	
	/**
	 * @return the categoryCode
	 */
	public String getCategoryCode() {
		return categoryCode;
	}
	/**
	 * @param categoryCode the categoryCode to set
	 */
	public void setCategoryCode(String categoryCode) {
		this.categoryCode = categoryCode;
	}
	/**
	 * @return the questionnaireForms
	 */
	public List<QuestionnaireForm> getQuestionnaireForms() {
		return questionnaireForms;
	}
	/**
	 * @param questionnaireForms the questionnaireForms to set
	 */
	public void setQuestionnaireForms(List<QuestionnaireForm> questionnaireForms) {
		this.questionnaireForms = questionnaireForms;
	}
}
