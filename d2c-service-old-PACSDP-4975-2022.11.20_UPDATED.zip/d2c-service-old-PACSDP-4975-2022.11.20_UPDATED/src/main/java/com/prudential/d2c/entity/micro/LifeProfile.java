package com.prudential.d2c.entity.micro;

import java.util.Date;
import java.util.Objects;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.time.DateUtils;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.prudential.d2c.common.Constants;
import com.prudential.d2c.utils.JsonDateSerializer;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class LifeProfile {


	  private String name;
	  @JsonSerialize(using=JsonDateSerializer.class)
	  @JsonFormat(shape=JsonFormat.Shape.STRING, pattern=Constants.DOBFORMAT)
	  private Date dob;
	  private Integer age;
	  private String gender;
	  private boolean smoker;
	  private String residentStatus;
	  private Integer numberOfLife;
	  private String clientType;
	  private String countryCode;
	  private String nric;
	  private String clientNumber;
	  private String occupationCode;
	  private String occupation;
	  private String nationality;
	
	  private String clientIndicator;
	  private String occupationDesc;
	  private boolean isSmoker;
	  private String pregnancyWeeks;
	  private LifeProfileProposal proposal;
	  private String customID;
	  private Integer premiumTerm;
	  private String channelCode;
	  private String random;

	public String getCustomID() {
		return customID;
	}

	public void setCustomID(String customID) {
		this.customID = customID;
	}

	/**
	 * @return the occupationCode
	 */
	public String getOccupationCode() {
		return occupationCode;
	}
	/**
	 * @param occupationCode the occupationCode to set
	 */
	public void setOccupationCode(String occupationCode) {
		this.occupationCode = occupationCode;
	}
	/**
	 * @return the occupation
	 */
	public String getOccupation() {
		return occupation;
	}
	/**
	 * @param occupation the occupation to set
	 */
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	/**
	 * @return the nationality
	 */
	public String getNationality() {
		return nationality;
	}
	/**
	 * @param nationality the nationality to set
	 */
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the dob
	 */
	public Date getDob() {
		return dob;
	}
	/**
	 * @param dob the dob to set
	 */
	public void setDob(Date dob) {
		this.dob = dob;
	}
	/**
	 * @return the age
	 */
	public Integer getAge() {
		return age;
	}
	/**
	 * @param age the age to set
	 */
	public void setAge(Integer age) {
		this.age = age;
	}
	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}
	/**
	 * @param gender the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	public boolean isSmoker() {
		return smoker;
	}
	public void setSmoker(boolean smoker) {
		this.smoker = smoker;
	}
	/**
	 * @return the residentStatus
	 */
	public String getResidentStatus() {
		return residentStatus;
	}
	/**
	 * @param residentStatus the residentStatus to set
	 */
	public void setResidentStatus(String residentStatus) {
		this.residentStatus = residentStatus;
	}
	/**
	 * @return the numberOfLife
	 */
	public Integer getNumberOfLife() {
		return numberOfLife;
	}
	/**
	 * @param numberOfLife the numberOfLife to set
	 */
	public void setNumberOfLife(Integer numberOfLife) {
		this.numberOfLife = numberOfLife;
	}
	/**
	 * @return the clientType
	 */
	public String getClientType() {
		return clientType;
	}
	/**
	 * @param clientType the clientType to set
	 */
	public void setClientType(String clientType) {
		this.clientType = clientType;
	}
	/**
	 * @return the countryCode
	 */
	public String getCountryCode() {
		return countryCode;
	}
	/**
	 * @param countryCode the countryCode to set
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	/**
	 * @return the nric
	 */
	public String getNric() {
		return nric;
	}
	/**
	 * @param nric the nric to set
	 */
	public void setNric(String nric) {
		this.nric = nric;
	}
	
	/**
	 * @return the clientNumber
	 */
	public String getClientNumber() {
		return clientNumber;
	}
	/**
	 * @param clientNumber the clientNumber to set
	 */
	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}
	/**
	 * @return the proposal
	 */
	public LifeProfileProposal getProposal() {
		return proposal;
	}
	/**
	 * @param proposal the proposal to set
	 */
	public void setProposal(LifeProfileProposal proposal) {
		this.proposal = proposal;
	}
	
	/**
	 * @return the occupationDesc
	 */
	public String getOccupationDesc() {
		return occupationDesc;
	}
	/**
	 * @param occupationDesc the occupationDesc to set
	 */
	public void setOccupationDesc(String occupationDesc) {
		this.occupationDesc = occupationDesc;
	}
	
	public boolean getIsSmoker() {
		return isSmoker;
	}
	public void setIsSmoker(boolean isSmoker) {
		this.isSmoker = isSmoker;
	}
	@Override
	public String toString()
	{
		Object fieldExcludedObject = ReflectionToStringBuilder.toStringExclude(this, "nric");
		return ToStringBuilder.reflectionToString(fieldExcludedObject);
	}
	public String getClientIndicator() {
		return clientIndicator;
	}
	public void setClientIndicator(String clientIndicator) {
		this.clientIndicator = clientIndicator;
	}
	public String getPregnancyWeeks() {
		return pregnancyWeeks;
	}
	public void setPregnancyWeeks(String pregnancyWeeks) {
		this.pregnancyWeeks = pregnancyWeeks;
	}

	public Integer getPremiumTerm() {
		return premiumTerm;
	}

	public void setPremiumTerm(Integer premiumTerm) {
		this.premiumTerm = premiumTerm;
	}

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getRandom() {
		return random;
	}

	public void setRandom(String random) {
		this.random = random;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		LifeProfile that = (LifeProfile) o;
		return smoker == that.smoker &&
				isSmoker == that.isSmoker &&
				DateUtils.isSameDay(dob, that.dob) &&
				Objects.equals(age, that.age) &&
				Objects.equals(gender, that.gender);
				//Objects.equals(occupationCode, that.occupationCode) &&
				//Objects.equals(occupation, that.occupation);
	}

	@Override
	public int hashCode() {
		return Objects.hash(dob, age, gender, smoker, occupationCode, occupation, isSmoker);
	}
}
