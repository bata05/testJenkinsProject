package com.prudential.d2c.entity.micro;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class LifeProfileProposal {
	
	private boolean isMailingAddressSameAsHomeAddress;
	private LifeProfileProposalAddress homeAddress;
	private LifeProfileProposalAddress mailingAddress;
	private LifeProfileProposalContact contact;
	

	
	/**
	 * @return the isMailingAddressSameAsHomeAddress
	 */
	public boolean getIsMailingAddressSameAsHomeAddress() {
		return isMailingAddressSameAsHomeAddress;
	}



	/**
	 * @param isMailingAddressSameAsHomeAddress the isMailingAddressSameAsHomeAddress to set
	 */
	public void setIsMailingAddressSameAsHomeAddress(boolean isMailingAddressSameAsHomeAddress) {
		this.isMailingAddressSameAsHomeAddress = isMailingAddressSameAsHomeAddress;
	}



	/**
	 * @return the homeAddress
	 */
	public LifeProfileProposalAddress getHomeAddress() {
		return homeAddress;
	}



	/**
	 * @param homeAddress the homeAddress to set
	 */
	public void setHomeAddress(LifeProfileProposalAddress homeAddress) {
		this.homeAddress = homeAddress;
	}



	/**
	 * @return the mailingAddress
	 */
	public LifeProfileProposalAddress getMailingAddress() {
		return mailingAddress;
	}



	/**
	 * @param mailingAddress the mailingAddress to set
	 */
	public void setMailingAddress(LifeProfileProposalAddress mailingAddress) {
		this.mailingAddress = mailingAddress;
	}



	/**
	 * @return the contact
	 */
	public LifeProfileProposalContact getContact() {
		return contact;
	}



	/**
	 * @param contact the contact to set
	 */
	public void setContact(LifeProfileProposalContact contact) {
		this.contact = contact;
	}



	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
	
	

}
