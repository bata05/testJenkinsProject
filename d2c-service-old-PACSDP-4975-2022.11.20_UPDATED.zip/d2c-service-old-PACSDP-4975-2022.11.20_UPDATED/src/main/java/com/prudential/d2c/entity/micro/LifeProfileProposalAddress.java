package com.prudential.d2c.entity.micro;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class LifeProfileProposalAddress {
	
	private String houseNo;
	private String street;
	private String unitNo;
	private String building;
	private String city;
	private String postcode;
	private String countryCode;
	

	/**
	 * @return the houseNo
	 */
	public String getHouseNo() {
		return houseNo;
	}



	/**
	 * @param houseNo the houseNo to set
	 */
	public void setHouseNo(String houseNo) {
		this.houseNo = houseNo;
	}



	/**
	 * @return the street
	 */
	public String getStreet() {
		return street;
	}



	/**
	 * @param street the street to set
	 */
	public void setStreet(String street) {
		this.street = street;
	}



	/**
	 * @return the unitNo
	 */
	public String getUnitNo() {
		return unitNo;
	}



	/**
	 * @param unitNo the unitNo to set
	 */
	public void setUnitNo(String unitNo) {
		this.unitNo = unitNo;
	}



	/**
	 * @return the building
	 */
	public String getBuilding() {
		return building;
	}



	/**
	 * @param building the building to set
	 */
	public void setBuilding(String building) {
		this.building = building;
	}



	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}



	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}



	/**
	 * @return the postcode
	 */
	public String getPostcode() {
		return postcode;
	}



	/**
	 * @param postcode the postcode to set
	 */
	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}



	/**
	 * @return the countryCode
	 */
	public String getCountryCode() {
		return countryCode;
	}



	/**
	 * @param countryCode the countryCode to set
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}



	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
	
	

}
