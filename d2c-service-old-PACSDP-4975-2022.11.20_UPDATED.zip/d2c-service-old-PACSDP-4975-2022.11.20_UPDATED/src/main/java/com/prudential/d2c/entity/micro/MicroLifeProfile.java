package com.prudential.d2c.entity.micro;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class MicroLifeProfile {
	private String name;
	
	//can get agentInfo by clientNumer and nric ,or by gender,nric and nationality
	private String gender;
	private String nric;
	private String clientNumber;
	private String nationality;
	private String mobileNo;
	private String emailId;
	private String nricSuffix;
	// @JsonFormat(shape=JsonFormat.Shape.STRING, pattern=Constants.DATE_FORMAT_DDMMYYYY)
	private String dob;
	private String age;
	
	private String countryOfBirth;//for existing client , country of birth is USA then return Unite State question,Or return don't return.
	private String residentStatus;// only for questionnaire
	private boolean existingClient;// only for questionnaire
	private String lastPolicyPurchaseDate;// only for questionnaire
	private boolean hasMyInfoSelected;
	private boolean noMyInfoAdd;


	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getNricSuffix() {
		return nricSuffix;
	}

	public void setNricSuffix(String nricSuffix) {
		this.nricSuffix = nricSuffix;
	}


	public String getGender() {
		return gender;
	}

	/**
	 * @return the clientNumber
	 */
	public String getClientNumber() {
		return clientNumber;
	}

	/**
	 * @param clientNumber the clientNumber to set
	 */
	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}

	public String getNric() {
		return nric;
	}

	public String getNationality() {
		return nationality;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setNric(String nric) {
		this.nric = nric;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}



	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getResidentStatus() {
		return residentStatus;
	}

	public boolean isExistingClient() {
		return existingClient;
	}

	public void setResidentStatus(String residentStatus) {
		this.residentStatus = residentStatus;
	}

	public void setExistingClient(boolean existingClient) {
		this.existingClient = existingClient;
	}

	public String getCountryOfBirth() {
		return countryOfBirth;
	}

	public void setCountryOfBirth(String countryOfBirth) {
		this.countryOfBirth = countryOfBirth;
	}

	public String getLastPolicyPurchaseDate() {
		return lastPolicyPurchaseDate;
	}

	public void setLastPolicyPurchaseDate(String lastPolicyPurchaseDate) {
		this.lastPolicyPurchaseDate = lastPolicyPurchaseDate;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public boolean isHasMyInfoSelected() {
		return hasMyInfoSelected;
	}

	public void setHasMyInfoSelected(boolean hasMyInfoSelected) {
		this.hasMyInfoSelected = hasMyInfoSelected;
	}

	public boolean isNoMyInfoAdd() {
		return noMyInfoAdd;
	}

	public void setNoMyInfoAdd(boolean noMyInfoAdd) {
		this.noMyInfoAdd = noMyInfoAdd;
	}
}
