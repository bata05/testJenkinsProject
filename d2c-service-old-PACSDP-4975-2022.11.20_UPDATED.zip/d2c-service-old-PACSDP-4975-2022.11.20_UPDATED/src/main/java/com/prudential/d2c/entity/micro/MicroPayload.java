package com.prudential.d2c.entity.micro;

import com.prudential.d2c.utils.EncryptedIdsUtil;

public class MicroPayload {
	private String transactionId;

	public MicroPayload(){
		this.transactionId = EncryptedIdsUtil.generateDefaultTransactionId();
	}
	
	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	
}
