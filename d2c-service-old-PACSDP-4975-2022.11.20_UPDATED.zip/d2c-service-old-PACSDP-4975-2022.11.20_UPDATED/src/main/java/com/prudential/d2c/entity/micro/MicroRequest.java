package com.prudential.d2c.entity.micro;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class MicroRequest {
	private MicroRequestSystem system;
	private Object payload;
	
	public MicroRequestSystem getSystem() {
		return system;
	}
	public void setSystem(MicroRequestSystem system) {
		this.system = system;
	}
	public Object getPayload() {
		return payload;
	}
	public void setPayload(Object payload) {
		this.payload = payload;
	}
	public MicroRequest() {
		this.system = new MicroRequestSystem();
		this.payload = new Object();
	}
	
	
}
