package com.prudential.d2c.entity.micro;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.prudential.d2c.common.Constants;
import com.prudential.d2c.utils.EncryptedIdsUtil;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class MicroRequestSystem {
	
	private String appVersion;
	private String appKey;
	private String clientIp;
	private String clientUdid;
	private String appName;
	private Boolean isPayloadEncrypted;
	private String encryptionKey;
	private String status;
	
	public MicroRequestSystem(){
		setAppVersion(Constants.APPVERSION);
		setAppKey(Constants.EMPTY_STRING);
		setClientIp(EncryptedIdsUtil.getServerIP());
		setClientUdid(Constants.CLIENTUDID);
		setAppName(Constants.APPNAME);
		setIsPayloadEncrypted(false);
		setEncryptionKey(Constants.ENCRYPTIONKEY);
		setStatus(Constants.OK_STRING);
	}
	
	public String getAppVersion() {
		return appVersion;
	}
	public void setAppVersion(String appVersion) {
		this.appVersion = appVersion;
	}
	public String getAppKey() {
		return appKey;
	}
	public void setAppKey(String appKey) {
		this.appKey = appKey;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getClientUdid() {
		return clientUdid;
	}
	public void setClientUdid(String clientUdid) {
		this.clientUdid = clientUdid;
	}
	public Boolean getIsPayloadEncrypted() {
		return isPayloadEncrypted;
	}
	public void setIsPayloadEncrypted(Boolean isPayloadEncrypted) {
		this.isPayloadEncrypted = isPayloadEncrypted;
	}
	public String getEncryptionKey() {
		return encryptionKey;
	}
	public void setEncryptionKey(String encryptionKey) {
		this.encryptionKey = encryptionKey;
	}

	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}

	public String getClientIp() {
		return clientIp ;
	}

	public void setClientIp(String clientIp) {
		this.clientIp  = clientIp ;
	}



}
