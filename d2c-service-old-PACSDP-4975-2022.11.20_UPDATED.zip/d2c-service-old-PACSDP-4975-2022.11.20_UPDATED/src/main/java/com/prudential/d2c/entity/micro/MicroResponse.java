package com.prudential.d2c.entity.micro;

public class MicroResponse {
	private MicroResponseSystem system;
	
	public MicroResponseSystem getSystem() {
		return system;
	}
	public void setSystem(MicroResponseSystem system) {
		this.system = system;
	}
	
	
}
