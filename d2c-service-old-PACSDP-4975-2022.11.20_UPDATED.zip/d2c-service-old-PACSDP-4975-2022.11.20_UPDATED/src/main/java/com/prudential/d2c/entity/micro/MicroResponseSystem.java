package com.prudential.d2c.entity.micro;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MicroResponseSystem implements Serializable{

    private static final long serialVersionUID = 1L;
    private String apiVersion;
	private String status;
	
	public MicroResponseSystem(){
		this.setStatus("");
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getApiVersion() {
		return apiVersion;
	}

	public void setApiVersion(String apiVersion) {
		this.apiVersion = apiVersion;
	}
	
}
