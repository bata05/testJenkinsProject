package com.prudential.d2c.entity.micro;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class NeedsAnalysisRecommendedProductPayload {

  public String compoDesc;
  public String compoCode;
  public int yearlyPremium;
  public boolean hasDiscount;
  public int discountedPremium;
  public NeedsAnalysisRecommendedProductPayload recommendedRider;

  public NeedsAnalysisRecommendedProductPayload() {
  }

  public String getCompoDesc() {
    return compoDesc;
  }

  public void setCompoDesc(String compoDesc) {
    this.compoDesc = compoDesc;
  }

  public String getCompoCode() {
    return compoCode;
  }

  public void setCompoCode(String compoCode) {
    this.compoCode = compoCode;
  }

  public int getYearlyPremium() {
    return yearlyPremium;
  }

  public void setYearlyPremium(int yearlyPremium) {
    this.yearlyPremium = yearlyPremium;
  }

  public NeedsAnalysisRecommendedProductPayload getRecommendedRider() {
    return recommendedRider;
  }

  public void setRecommendedRider(NeedsAnalysisRecommendedProductPayload recommendedRider) {
    this.recommendedRider = recommendedRider;
  }

  public boolean isHasDiscount() {
    return hasDiscount;
  }

  public void setHasDiscount(boolean hasDiscount) {
    this.hasDiscount = hasDiscount;
  }

  public int getDiscountedPremium() {
    return discountedPremium;
  }

  public void setDiscountedPremium(int discountedPremium) {
    this.discountedPremium = discountedPremium;
  }

  @Override
  public String toString() {
    return "NeedsAnalysisRecommendedProductPayload{" +
        "compoDesc='" + compoDesc + '\'' +
        ", compoCode='" + compoCode + '\'' +
        ", yearlyPremium=" + yearlyPremium +
        ", hasDiscount=" + hasDiscount +
        ", discountedPremium=" + discountedPremium +
        ", rider=" + recommendedRider +
        '}';
  }
}
