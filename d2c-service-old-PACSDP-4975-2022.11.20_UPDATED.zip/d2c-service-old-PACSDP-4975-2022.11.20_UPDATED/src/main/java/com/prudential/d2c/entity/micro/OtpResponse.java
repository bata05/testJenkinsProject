package com.prudential.d2c.entity.micro;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.prudential.d2c.entity.micro.payload.BasePayload;
@JsonIgnoreProperties(ignoreUnknown = true)
public class OtpResponse {
	private MicroResponseSystem system;
	private BasePayload payload;
	

	public BasePayload getPayload() {
		return payload;
	}
	public void setPayload(BasePayload payload) {
		this.payload = payload;
	}
	public MicroResponseSystem getSystem() {
		return system;
	}
	public void setSystem(MicroResponseSystem system) {
		this.system = system;
	}
	
	
}
