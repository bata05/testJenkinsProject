package com.prudential.d2c.entity.micro;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class OtpVerifyResponse extends OtpResponse {
	
}
