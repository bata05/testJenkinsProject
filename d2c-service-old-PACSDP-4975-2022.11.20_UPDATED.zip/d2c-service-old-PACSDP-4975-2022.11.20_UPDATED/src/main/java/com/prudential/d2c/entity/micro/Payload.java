package com.prudential.d2c.entity.micro;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.prudential.d2c.entity.Policy;
import com.prudential.d2c.entity.QuotationErrorMessage;
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Payload {
		
	private String transactionId;
	
	private boolean generatePDF;
	
	private List<LifeProfile> lifeProfiles;
	
	private List<SelectedSQSProduct> selectedSQSProducts;
	
	//Add for response
	private PdfData pdfData;
	private List<QuotationErrorMessage> errorMessages;
	
	
	//Add for E-Sub
	private String customId;
	private String eReferenceNo;
	private String agentCode;
	private List<PdfFile> files;
	private List<EsubClient> clients;
	private SQSProduct sqs;
	private Proposal proposal;
	private String submissionTime;
	private List<Policy> policies;
	private String agentBizSource;
	
	//add MyInfo Indicator
	private String myInfo;

	//add PS SIO Indicator
	private String psSIO;

	public String getAgentSubSource() {
		return agentSubSource;
	}

	public void setAgentSubSource(String agentSubSource) {
		this.agentSubSource = agentSubSource;
	}

	private String agentSubSource;

	public String getCustomId() { return customId; }

	public void setCustomId(String customId) {
		this.customId = customId;
	}

	/**
	 * @return the proposal
	 */
	public Proposal getProposal() {
		return proposal;
	}

	/**
	 * @param proposal the proposal to set
	 */
	public void setProposal(Proposal proposal) {
		this.proposal = proposal;
	}

	/**
	 * @return the pdfData
	 */
	public PdfData getPdfData() {
		return pdfData;
	}

	/**
	 * @param pdfData the pdfData to set
	 */
	public void setPdfData(PdfData pdfData) {
		this.pdfData = pdfData;
	}

	/**
	 * @return the transactionId
	 */
	public String getTransactionId() {
		return transactionId;
	}

	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	/**
	 * @return the lifeProfiles
	 */
	public List<LifeProfile> getLifeProfiles() {
		return lifeProfiles;
	}

	/**
	 * @param lifeProfiles the lifeProfiles to set
	 */
	public void setLifeProfiles(List<LifeProfile> lifeProfiles) {
		this.lifeProfiles = lifeProfiles;
	}

	/**
	 * @return the selectedSQSProducts
	 */
	public List<SelectedSQSProduct> getSelectedSQSProducts() {
		return selectedSQSProducts;
	}

	/**
	 * @param selectedSQSProducts the selectedSQSProducts to set
	 */
	public void setSelectedSQSProducts(List<SelectedSQSProduct> selectedSQSProducts) {
		this.selectedSQSProducts = selectedSQSProducts;
	}




	/**
	 * @return the generatePDF
	 */
	public boolean isGeneratePDF() {
		return generatePDF;
	}

	/**
	 * @param generatePDF the generatePDF to set
	 */
	public void setGeneratePDF(boolean generatePDF) {
		this.generatePDF = generatePDF;
	}

	/**
	 * @return the errorMessages
	 */
	public List<QuotationErrorMessage> getErrorMessages() {
		return errorMessages;
	}

	/**
	 * @param errorMessages the errorMessages to set
	 */
	public void setErrorMessages(List<QuotationErrorMessage> errorMessages) {
		this.errorMessages = errorMessages;
	}




	/**
	 * @return the eReferenceNo
	 */
	public String geteReferenceNo() {
		return eReferenceNo;
	}

	/**
	 * @param eReferenceNo the eReferenceNo to set
	 */
	public void seteReferenceNo(String eReferenceNo) {
		this.eReferenceNo = eReferenceNo;
	}

	/**
	 * @return the agentCode
	 */
	public String getAgentCode() {
		return agentCode;
	}

	/**
	 * @param agentCode the agentCode to set
	 */
	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}

	/**
	 * @return the files
	 */
	public List<PdfFile> getFiles() {
		return files;
	}

	/**
	 * @param files the files to set
	 */
	public void setFiles(List<PdfFile> files) {
		this.files = files;
	}

	/**
	 * @return the clients
	 */
	public List<EsubClient> getClients() {
		return clients;
	}

	/**
	 * @param clients the clients to set
	 */
	public void setClients(List<EsubClient> clients) {
		this.clients = clients;
	}

	/**
	 * @return the sqs
	 */
	public SQSProduct getSqs() {
		return sqs;
	}

	/**
	 * @param sqs the sqs to set
	 */
	public void setSqs(SQSProduct sqs) {
		this.sqs = sqs;
	}


	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}

	public String getSubmissionTime() {
		return submissionTime;
	}

	public void setSubmissionTime(String submissionTime) {
		this.submissionTime = submissionTime;
	}
	

	public List<Policy> getPolicies() {
		return policies;
	}

	public void setPolicies(List<Policy> policies) {
		this.policies = policies;
	}

	public String getAgentBizSource() {
		return agentBizSource;
	}

	public void setAgentBizSource(String agentBizSource) {
		this.agentBizSource = agentBizSource;
	}
	
	public String getMyInfo() {
		return myInfo;
	}

	public void setMyInfo(String myInfo) {
		this.myInfo = myInfo;
	}

	public String getPsSIO() {
		return psSIO;
	}

	public void setPsSIO(String psSIO) {
		this.psSIO = psSIO;
	}
}
