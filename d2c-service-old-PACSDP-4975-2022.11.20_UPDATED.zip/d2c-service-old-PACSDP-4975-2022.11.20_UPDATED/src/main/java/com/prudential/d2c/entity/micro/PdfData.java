package com.prudential.d2c.entity.micro;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.prudential.d2c.entity.PDFData;

import io.swagger.annotations.ApiModel;
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(value = "PdfData", description = "PdfData")
public class PdfData extends PDFData {
	
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
	
	
}
