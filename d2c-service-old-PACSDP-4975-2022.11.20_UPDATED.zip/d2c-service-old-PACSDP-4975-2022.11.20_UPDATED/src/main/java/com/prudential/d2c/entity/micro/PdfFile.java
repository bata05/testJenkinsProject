package com.prudential.d2c.entity.micro;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class PdfFile {

	/**
	 * PdfFile can be used to handle any file type not only PDF
	 *
	 */
	private String fileType;
	private String fileCategory;
	private String fileName;
	private String md5Checksum;
	private String encryptedData;
	private String rawData;
	private String signDate;
	private int lifeAssuredId;
	
	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}
	/**
	 * @param fileName the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	/**
	 * @return the md5Checksum
	 */
	public String getMd5Checksum() {
		return md5Checksum;
	}
	/**
	 * @param md5Checksum the md5Checksum to set
	 */
	public void setMd5Checksum(String md5Checksum) {
		this.md5Checksum = md5Checksum;
	}


	/**
	 * @return the fileType
	 */
	public String getFileType() {
		return fileType;
	}
	/**
	 * @param fileType the fileType to set
	 */
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	/**
	 * @return the fileCategory
	 */
	public String getFileCategory() {
		return fileCategory;
	}
	/**
	 * @param fileCategory the fileCategory to set
	 */
	public void setFileCategory(String fileCategory) {
		this.fileCategory = fileCategory;
	}
	/**
	 * @return the rawData
	 */
	public String getRawData() {
		return rawData;
	}
	/**
	 * @param rawData the rawData to set
	 */
	public void setRawData(String rawData) {
		this.rawData = rawData;
	}
	/**
	 * @return the signDate
	 */
	public String getSignDate() {
		return signDate;
	}
	/**
	 * @param signDate the signDate to set
	 */
	public void setSignDate(String signDate) {
		this.signDate = signDate;
	}
	/**
	 * @return the lifeAssuredId
	 */
	public int getLifeAssuredId() {
		return lifeAssuredId;
	}
	/**
	 * @param lifeAssuredId the lifeAssuredId to set
	 */
	public void setLifeAssuredId(int lifeAssuredId) {
		this.lifeAssuredId = lifeAssuredId;
	}
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
	/**
	 * @return the encryptedData
	 */
	public String getEncryptedData() {
		return encryptedData;
	}
	/**
	 * @param encryptedData the encryptedData to set
	 */
	public void setEncryptedData(String encryptedData) {
		this.encryptedData = encryptedData;
	}
}
