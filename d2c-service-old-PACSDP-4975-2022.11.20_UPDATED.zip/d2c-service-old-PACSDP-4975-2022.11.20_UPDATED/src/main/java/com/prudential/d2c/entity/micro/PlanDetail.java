package com.prudential.d2c.entity.micro;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class PlanDetail {
	private String policyDocumentDelivery;
	private boolean acknowledgeShieldPlan;
	private boolean acknowledgeMedicalCondition;
	private boolean acknowledgePayHigher;
	private String payoutBankName;
	private String payoutRelToProposer;
	private String payoutAccName;
	private String payoutAccNo;
	private boolean ackOption1;
	private boolean ackOption2;
	private boolean ackOption3;
	private boolean ackOption4;
	private boolean psAckOption1;
	private boolean psAckOption2;
	private boolean psAckOption3;
	private boolean portfolioSolution;
	private boolean directIncomeOption;
	private double payoutAmtDIO;
	
	/**
	 * @return the policyDocumentDelivery
	 */
	public String getPolicyDocumentDelivery() {
		return policyDocumentDelivery;
	}
	/**
	 * @param policyDocumentDelivery the policyDocumentDelivery to set
	 */
	public void setPolicyDocumentDelivery(String policyDocumentDelivery) {
		this.policyDocumentDelivery = policyDocumentDelivery;
	}
	/**
	 * @return the acknowledgeShieldPlan
	 */
	public boolean isAcknowledgeShieldPlan() {
		return acknowledgeShieldPlan;
	}
	/**
	 * @param acknowledgeShieldPlan the acknowledgeShieldPlan to set
	 */
	public void setAcknowledgeShieldPlan(boolean acknowledgeShieldPlan) {
		this.acknowledgeShieldPlan = acknowledgeShieldPlan;
	}
	/**
	 * @return the acknowledgeMedicalCondition
	 */
	public boolean isAcknowledgeMedicalCondition() {
		return acknowledgeMedicalCondition;
	}
	/**
	 * @param acknowledgeMedicalCondition the acknowledgeMedicalCondition to set
	 */
	public void setAcknowledgeMedicalCondition(boolean acknowledgeMedicalCondition) {
		this.acknowledgeMedicalCondition = acknowledgeMedicalCondition;
	}
	/**
	 * @return the acknowledgePayHigher
	 */
	public boolean isAcknowledgePayHigher() {
		return acknowledgePayHigher;
	}
	/**
	 * @param acknowledgePayHigher the acknowledgePayHigher to set
	 */
	public void setAcknowledgePayHigher(boolean acknowledgePayHigher) {
		this.acknowledgePayHigher = acknowledgePayHigher;
	}
	/**
	 * @return the payoutBankName
	 */
	public String getPayoutBankName() {
		return payoutBankName;
	}
	/**
	 * @param payoutBankName the payoutBankName to set
	 */
	public void setPayoutBankName(String payoutBankName) {
		this.payoutBankName = payoutBankName;
	}
	/**
	 * @return the payoutRelToProposer
	 */
	public String getPayoutRelToProposer() {
		return payoutRelToProposer;
	}
	/**
	 * @param payoutRelToProposer the payoutRelToProposer to set
	 */
	public void setPayoutRelToProposer(String payoutRelToProposer) {
		this.payoutRelToProposer = payoutRelToProposer;
	}
	/**
	 * @return the payoutAccName
	 */
	public String getPayoutAccName() {
		return payoutAccName;
	}
	/**
	 * @param payoutAccName the payoutAccName to set
	 */
	public void setPayoutAccName(String payoutAccName) {
		this.payoutAccName = payoutAccName;
	}
	/**
	 * @return the payoutAccNo
	 */
	public String getPayoutAccNo() {
		return payoutAccNo;
	}
	/**
	 * @param payoutAccNo the payoutAccNo to set
	 */
	public void setPayoutAccNo(String payoutAccNo) {
		this.payoutAccNo = payoutAccNo;
	}
	/**
	 * @return the ackOption1
	 */
	public boolean isAckOption1() {
		return ackOption1;
	}
	/**
	 * @param ackOption1 the ackOption1 to set
	 */
	public void setAckOption1(boolean ackOption1) {
		this.ackOption1 = ackOption1;
	}
	/**
	 * @return the ackOption2
	 */
	public boolean isAckOption2() {
		return ackOption2;
	}
	/**
	 * @param ackOption2 the ackOption2 to set
	 */
	public void setAckOption2(boolean ackOption2) {
		this.ackOption2 = ackOption2;
	}
	/**
	 * @return the ackOption3
	 */
	public boolean isAckOption3() {
		return ackOption3;
	}
	/**
	 * @param ackOption3 the ackOption3 to set
	 */
	public void setAckOption3(boolean ackOption3) {
		this.ackOption3 = ackOption3;
	}
	/**
	 * @return the ackOption4
	 */
	public boolean isAckOption4() {
		return ackOption4;
	}
	/**
	 * @param ackOption4 the ackOption4 to set
	 */
	public void setAckOption4(boolean ackOption4) {
		this.ackOption4 = ackOption4;
	}
	/**
	 * @return the psAckOption1
	 */
	public boolean isPsAckOption1() {
		return psAckOption1;
	}
	/**
	 * @param psAckOption1 the psAckOption1 to set
	 */
	public void setPsAckOption1(boolean psAckOption1) {
		this.psAckOption1 = psAckOption1;
	}
	/**
	 * @return the psAckOption2
	 */
	public boolean isPsAckOption2() {
		return psAckOption2;
	}
	/**
	 * @param psAckOption2 the psAckOption2 to set
	 */
	public void setPsAckOption2(boolean psAckOption2) {
		this.psAckOption2 = psAckOption2;
	}
	/**
	 * @return the psAckOption3
	 */
	public boolean isPsAckOption3() {
		return psAckOption3;
	}
	/**
	 * @param psAckOption3 the psAckOption3 to set
	 */
	public void setPsAckOption3(boolean psAckOption3) {
		this.psAckOption3 = psAckOption3;
	}
	/**
	 * @return the portfolioSolution
	 */
	public boolean isPortfolioSolution() {
		return portfolioSolution;
	}
	/**
	 * @param portfolioSolution the portfolioSolution to set
	 */
	public void setPortfolioSolution(boolean portfolioSolution) {
		this.portfolioSolution = portfolioSolution;
	}
	/**
	 * @return the directIncomeOption
	 */
	public boolean isDirectIncomeOption() {
		return directIncomeOption;
	}
	/**
	 * @param directIncomeOption the directIncomeOption to set
	 */
	public void setDirectIncomeOption(boolean directIncomeOption) {
		this.directIncomeOption = directIncomeOption;
	}
	/**
	 * @return the payoutAmtDIO
	 */
	public double getPayoutAmtDIO() {
		return payoutAmtDIO;
	}
	/**
	 * @param payoutAmtDIO the payoutAmtDIO to set
	 */
	public void setPayoutAmtDIO(double payoutAmtDIO) {
		this.payoutAmtDIO = payoutAmtDIO;
	}
}
