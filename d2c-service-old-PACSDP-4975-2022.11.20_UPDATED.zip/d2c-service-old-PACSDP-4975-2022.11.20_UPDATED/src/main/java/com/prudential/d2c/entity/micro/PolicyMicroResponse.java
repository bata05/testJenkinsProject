package com.prudential.d2c.entity.micro;

import java.util.List;

import com.prudential.d2c.entity.Policy;

public class PolicyMicroResponse {
	private MicroResponseSystem system;
	private PolicyResponsePayload payload;
	
	public MicroResponseSystem getSystem() {
		return system;
	}
	public void setSystem(MicroResponseSystem system) {
		this.system = system;
	}
	
	public PolicyResponsePayload getPayload() {
		return payload;
	}
	public void setPayload(PolicyResponsePayload payload) {
		this.payload = payload;
	}
	
	public class PolicyResponsePayload {
		private String transactionId;
		private List<Policy> policies;
		
		public String getTransactionId() {
			return transactionId;
		}
		public void setTransactionId(String transactionId) {
			this.transactionId = transactionId;
		}
		public List<Policy> getPolicies() {
			return policies;
		}
		public void setPolicies(List<Policy> policies) {
			this.policies = policies;
		}
		
	}
	
	
}
