package com.prudential.d2c.entity.micro;

import java.util.List;

import com.prudential.d2c.entity.PolicyBean;

public class PolicyRequestPayload {
	private String transactionId;
	private ClientInfo clientProfile;
	private List<PolicyBean> policies;
	
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public ClientInfo getClientProfile() {
		return clientProfile;
	}
	public void setClientProfile(ClientInfo clientProfile) {
		this.clientProfile = clientProfile;
	}
	public List<PolicyBean> getPolicies() {
		return policies;
	}
	public void setPolicies(List<PolicyBean> policies) {
		this.policies = policies;
	}
		
}
