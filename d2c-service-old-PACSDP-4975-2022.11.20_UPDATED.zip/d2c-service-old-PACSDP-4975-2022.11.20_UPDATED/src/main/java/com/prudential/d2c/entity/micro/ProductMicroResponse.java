package com.prudential.d2c.entity.micro;

import com.prudential.d2c.entity.Product;


public class ProductMicroResponse {
	private MicroResponseSystem system;
	private ProductResponsePayload payload;
	
	public MicroResponseSystem getSystem() {
		return system;
	}
	public void setSystem(MicroResponseSystem system) {
		this.system = system;
	}
	public ProductResponsePayload getPayload() {
		return payload;
	}
	public void setPayload(ProductResponsePayload payload) {
		this.payload = payload;
	}
	
	public class ProductResponsePayload{
		private String transactionId;
		private Product sqsProduct;
		
		public String getTransactionId() {
			return transactionId;
		}
		public void setTransactionId(String transactionId) {
			this.transactionId = transactionId;
		}
		public Product getSqsProduct() {
			return sqsProduct;
		}
		public void setSqsProduct(Product sqsProduct) {
			this.sqsProduct = sqsProduct;
		}
		
		
	}
}
