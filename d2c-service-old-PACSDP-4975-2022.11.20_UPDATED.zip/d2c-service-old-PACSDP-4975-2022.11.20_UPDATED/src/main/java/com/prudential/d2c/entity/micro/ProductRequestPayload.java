package com.prudential.d2c.entity.micro;

import java.util.List;

public class ProductRequestPayload {
	private String transactionId;
	private List<LifeProfile> lifeProfiles;
	private Discount discount;
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public List<LifeProfile> getLifeProfiles() {
		return lifeProfiles;
	}
	public void setLifeProfiles(List<LifeProfile> lifeProfiles) {
		this.lifeProfiles = lifeProfiles;
	}

	public Discount getDiscount() {
		return discount;
	}

	public void setDiscount(Discount discount) {
		this.discount = discount;
	}
}
