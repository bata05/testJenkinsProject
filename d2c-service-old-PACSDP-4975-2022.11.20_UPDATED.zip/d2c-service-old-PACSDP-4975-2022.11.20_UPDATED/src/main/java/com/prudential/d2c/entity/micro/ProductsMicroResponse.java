package com.prudential.d2c.entity.micro;

import java.util.List;

import com.prudential.d2c.entity.ProductList;

public class ProductsMicroResponse {
	private MicroResponseSystem system;
	private ProductsResponsePayload payload;
	
	public MicroResponseSystem getSystem() {
		return system;
	}
	public void setSystem(MicroResponseSystem system) {
		this.system = system;
	}
	public ProductsResponsePayload getPayload() {
		return payload;
	}
	public void setPayload(ProductsResponsePayload payload) {
		this.payload = payload;
	}
	
	public class ProductsResponsePayload {
		private String transactionId;
		private List<ProductList> productList;
		
		public String getTransactionId() {
			return transactionId;
		}
		public void setTransactionId(String transactionId) {
			this.transactionId = transactionId;
		}
		public List<ProductList> getProductList() {
			return productList;
		}
		public void setProductList(List<ProductList> productList) {
			this.productList = productList;
		}
		
		
	}
}
