package com.prudential.d2c.entity.micro;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.prudential.d2c.common.Constants;

/**
 * This entity is used for data preparation when any logic to fetch agent info
 */
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class PromoResponse {

    private boolean isPromoValid;

    @JsonFormat(pattern = Constants.DATEFORMAT, timezone = "Asia/Singapore")
    private Date fromValidityDate;

    @JsonFormat(pattern = Constants.DATEFORMAT, timezone = "Asia/Singapore")
    private Date toValidityDate;

    private Double discountPercentage;

    private Integer startAge;

    private Integer endAge;

    private String promoMsg;

    private boolean isPromoStatic;

    public boolean isPromoValid() {
        return isPromoValid;
    }

    public void setPromoValid(boolean promoValid) {
        isPromoValid = promoValid;
    }

    public Date getFromValidityDate() {
        return fromValidityDate;
    }

    public void setFromValidityDate(Date fromValidityDate) {
        this.fromValidityDate = fromValidityDate;
    }

    public Date getToValidityDate() {
        return toValidityDate;
    }

    public void setToValidityDate(Date toValidityDate) {
        this.toValidityDate = toValidityDate;
    }

    public Double getDiscountPercentage() {
        return discountPercentage;
    }

    public void setDiscountPercentage(Double discountPercentage) {
        this.discountPercentage = discountPercentage;
    }

    public Integer getStartAge() {
        return startAge;
    }

    public void setStartAge(Integer startAge) {
        this.startAge = startAge;
    }

    public Integer getEndAge() {
        return endAge;
    }

    public void setEndAge(Integer endAge) {
        this.endAge = endAge;
    }

    public String getPromoMsg() {
        return promoMsg;
    }

    public void setPromoMsg(String promoMsg) {
        this.promoMsg = promoMsg;
    }

    public boolean isPromoStatic() {
        return isPromoStatic;
    }

    public void setPromoStatic(boolean promoStatic) {
        isPromoStatic = promoStatic;
    }
}
