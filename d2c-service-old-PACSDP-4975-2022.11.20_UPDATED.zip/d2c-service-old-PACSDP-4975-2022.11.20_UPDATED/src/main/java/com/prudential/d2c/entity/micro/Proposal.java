package com.prudential.d2c.entity.micro;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.prudential.d2c.entity.Payment;
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Proposal {
	private String mercRefNo;
	private String companyNo;
	private Payment payment;
	private Payment extraPayment;
	private List<Form> forms;
	private PlanDetail planDetail;
	private String eRefNo;
	private String clientId;
	private boolean pdpa;
	private String srcInd;
	private String proposalNo;
	private String passType;
	
	/**
	 * @return the mercRefNo
	 */
	public String getMercRefNo() {
		return mercRefNo;
	}
	/**
	 * @param mercRefNo the mercRefNo to set
	 */
	public void setMercRefNo(String mercRefNo) {
		this.mercRefNo = mercRefNo;
	}

	/**
	 * @return the companyNo
	 */
	public String getCompanyNo() {
		return companyNo;
	}
	/**
	 * @param companyNo the companyNo to set
	 */
	public void setCompanyNo(String companyNo) {
		this.companyNo = companyNo;
	}
	/**
	 * @return the payment
	 */
	public Payment getPayment() {
		return payment;
	}
	/**
	 * @param payment the payment to set
	 */
	public void setPayment(Payment payment) {
		this.payment = payment;
	}
	/**
	 * @return the forms
	 */
	public List<Form> getForms() {
		return forms;
	}
	/**
	 * @param forms the forms to set
	 */
	public void setForms(List<Form> forms) {
		this.forms = forms;
	}
	/**
	 * @return the planDetail
	 */
	public PlanDetail getPlanDetail() {
		return planDetail;
	}
	/**
	 * @param planDetail the planDetail to set
	 */
	public void setPlanDetail(PlanDetail planDetail) {
		this.planDetail = planDetail;
	}
	/**
	 * @return the eRefNo
	 */
	public String geteRefNo() {
		return eRefNo;
	}
	/**
	 * @param eRefNo the eRefNo to set
	 */
	public void seteRefNo(String eRefNo) {
		this.eRefNo = eRefNo;
	}
	/**
	 * @return the clientId
	 */
	public String getClientId() {
		return clientId;
	}
	/**
	 * @param clientId the clientId to set
	 */
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	/**
	 * @return the pdpa
	 */
	public boolean isPdpa() {
		return pdpa;
	}
	/**
	 * @param pdpa the pdpa to set
	 */
	public void setPdpa(boolean pdpa) {
		this.pdpa = pdpa;
	}
	/**
	 * @return the srcInd
	 */
	public String getSrcInd() {
		return srcInd;
	}
	/**
	 * @param srcInd the srcInd to set
	 */
	public void setSrcInd(String srcInd) {
		this.srcInd = srcInd;
	}

	public Payment getExtraPayment() {
		return extraPayment;
	}

	public void setExtraPayment(Payment extraPayment) {
		this.extraPayment = extraPayment;
	}

	public String getProposalNo() {
		return proposalNo;
	}

	public void setProposalNo(String proposalNo) {
		this.proposalNo = proposalNo;
	}

	public String getPassType() {
		return passType;
	}

	public void setPassType(String passType) {
		this.passType = passType;
	}
}
