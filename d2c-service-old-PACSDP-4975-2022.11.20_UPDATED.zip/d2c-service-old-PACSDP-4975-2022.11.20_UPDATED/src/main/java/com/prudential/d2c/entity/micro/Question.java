package com.prudential.d2c.entity.micro;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Question {
	private String questionCode;
	private String parentQuestionCode;
	private int sequenceNo;
	private int parentSequenceNo;
	private String answerValue;
	
	/**
	 * @return the questionCode
	 */
	public String getQuestionCode() {
		return questionCode;
	}
	/**
	 * @param questionCode the questionCode to set
	 */
	public void setQuestionCode(String questionCode) {
		this.questionCode = questionCode;
	}
	/**
	 * @return the parentQuestionCode
	 */
	public String getParentQuestionCode() {
		return parentQuestionCode;
	}
	/**
	 * @param parentQuestionCode the parentQuestionCode to set
	 */
	public void setParentQuestionCode(String parentQuestionCode) {
		this.parentQuestionCode = parentQuestionCode;
	}
	/**
	 * @return the sequenceNo
	 */
	public int getSequenceNo() {
		return sequenceNo;
	}
	/**
	 * @param sequenceNo the sequenceNo to set
	 */
	public void setSequenceNo(int sequenceNo) {
		this.sequenceNo = sequenceNo;
	}
	/**
	 * @return the parentSequenceNo
	 */
	public int getParentSequenceNo() {
		return parentSequenceNo;
	}
	/**
	 * @param parentSequenceNo the parentSequenceNo to set
	 */
	public void setParentSequenceNo(int parentSequenceNo) {
		this.parentSequenceNo = parentSequenceNo;
	}
	/**
	 * @return the answerValue
	 */
	public String getAnswerValue() {
		return answerValue;
	}
	/**
	 * @param answerValue the answerValue to set
	 */
	public void setAnswerValue(String answerValue) {
		this.answerValue = answerValue;
	}
}
