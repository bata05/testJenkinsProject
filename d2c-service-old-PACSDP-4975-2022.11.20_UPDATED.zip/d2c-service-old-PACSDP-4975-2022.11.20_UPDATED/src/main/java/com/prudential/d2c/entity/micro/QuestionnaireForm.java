package com.prudential.d2c.entity.micro;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class QuestionnaireForm {
	private int lifeAssuredId;
	private List<Question> questions;
	
	/**
	 * @return the lifeAssuredId
	 */
	public int getLifeAssuredId() {
		return lifeAssuredId;
	}
	/**
	 * @param lifeAssuredId the lifeAssuredId to set
	 */
	public void setLifeAssuredId(int lifeAssuredId) {
		this.lifeAssuredId = lifeAssuredId;
	}
	/**
	 * @return the questions
	 */
	public List<Question> getQuestions() {
		return questions;
	}
	/**
	 * @param questions the questions to set
	 */
	public void setQuestions(List<Question> questions) {
		this.questions = questions;
	}
}
