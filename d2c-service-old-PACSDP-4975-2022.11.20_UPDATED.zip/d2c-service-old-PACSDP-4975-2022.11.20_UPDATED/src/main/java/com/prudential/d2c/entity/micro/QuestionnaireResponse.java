package com.prudential.d2c.entity.micro;

import com.prudential.d2c.entity.micro.payload.QuestionnaireResponsePayload;

public class QuestionnaireResponse {
	
	private MicroResponseSystem system;
	private QuestionnaireResponsePayload payload;
	public QuestionnaireResponse(){
		system = new MicroResponseSystem();
		payload = new QuestionnaireResponsePayload();
	}
	public MicroResponseSystem getSystem() {
		return system;
	}
	public QuestionnaireResponsePayload getPayload() {
		return payload;
	}
	public void setSystem(MicroResponseSystem system) {
		this.system = system;
	}
	public void setPayload(QuestionnaireResponsePayload payload) {
		this.payload = payload;
	}
	
}
