package com.prudential.d2c.entity.micro;

import com.prudential.d2c.entity.micro.payload.RsaKeyResponsePayload;

public class RsaKeyResponse {
	private MicroResponseSystem system;
	private RsaKeyResponsePayload payload;
	
	public RsaKeyResponsePayload getPayload() {
		return payload;
	}
	public void setPayload(RsaKeyResponsePayload payload) {
		this.payload = payload;
	}
	public MicroResponseSystem getSystem() {
		return system;
	}
	public void setSystem(MicroResponseSystem system) {
		this.system = system;
	}
	
	
	
}
