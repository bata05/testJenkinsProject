package com.prudential.d2c.entity.micro;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class SQSProduct {
	
	private int sqsId;
	private boolean backdating;
	private String premiumBackDate;	
	private String sqsVersion;
	private String sqsTimestamp;
	private int clientId;
	private String currencyCode;
	private String productCategoryCode;
	private String productCode;
	private String productCurrency;
	private String paymentTypeIndicator;
	private String policyOption;
	private int policyOptionYears;
	private boolean impairedLife;
	private boolean crisisWaiver;
	private boolean earlyCrisisWaiver;
	private List<SQSProductLifeAssured> lifeAssureds;
	private String portfolioNo;
	private int productCategoryId;
	
	/**
	 * @return the productCode
	 */
	public String getProductCode() {
		return productCode;
	}
	/**
	 * @param productCode the productCode to set
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	/**
	 * @return the productCurrency
	 */
	public String getProductCurrency() {
		return productCurrency;
	}
	/**
	 * @param productCurrency the productCurrency to set
	 */
	public void setProductCurrency(String productCurrency) {
		this.productCurrency = productCurrency;
	}
	/**
	 * @return the lifeAssureds
	 */
	public List<SQSProductLifeAssured> getLifeAssureds() {
		return lifeAssureds;
	}
	/**
	 * @param lifeAssureds the lifeAssureds to set
	 */
	public void setLifeAssureds(List<SQSProductLifeAssured> lifeAssureds) {
		this.lifeAssureds = lifeAssureds;
	}
	
	/**
	 * @return the sqsId
	 */
	public int getSqsId() {
		return sqsId;
	}
	/**
	 * @param sqsId the sqsId to set
	 */
	public void setSqsId(int sqsId) {
		this.sqsId = sqsId;
	}
	/**
	 * @return the sqsVersion
	 */
	public String getSqsVersion() {
		return sqsVersion;
	}
	/**
	 * @param sqsVersion the sqsVersion to set
	 */
	public void setSqsVersion(String sqsVersion) {
		this.sqsVersion = sqsVersion;
	}
	/**
	 * @return the sqsTimestamp
	 */
	public String getSqsTimestamp() {
		return sqsTimestamp;
	}
	/**
	 * @param sqsTimestamp the sqsTimestamp to set
	 */
	public void setSqsTimestamp(String sqsTimestamp) {
		this.sqsTimestamp = sqsTimestamp;
	}
	/**
	 * @return the clientId
	 */
	public int getClientId() {
		return clientId;
	}
	/**
	 * @param clientId the clientId to set
	 */
	public void setClientId(int clientId) {
		this.clientId = clientId;
	}
	/**
	 * @return the paymentTypeIndicator
	 */
	public String getPaymentTypeIndicator() {
		return paymentTypeIndicator;
	}
	/**
	 * @param paymentTypeIndicator the paymentTypeIndicator to set
	 */
	public void setPaymentTypeIndicator(String paymentTypeIndicator) {
		this.paymentTypeIndicator = paymentTypeIndicator;
	}
	/**
	 * @return the portfolioNo
	 */
	public String getPortfolioNo() {
		return portfolioNo;
	}
	/**
	 * @param portfolioNo the portfolioNo to set
	 */
	public void setPortfolioNo(String portfolioNo) {
		this.portfolioNo = portfolioNo;
	}
	/**
	 * @return the productCategoryId
	 */
	public int getProductCategoryId() {
		return productCategoryId;
	}
	/**
	 * @param productCategoryId the productCategoryId to set
	 */
	public void setProductCategoryId(int productCategoryId) {
		this.productCategoryId = productCategoryId;
	}
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
	/**
	 * @return the backdating
	 */
	public boolean isBackdating() {
		return backdating;
	}
	/**
	 * @param backdating the backdating to set
	 */
	public void setBackdating(boolean backdating) {
		this.backdating = backdating;
	}
	/**
	 * @return the premiumBackDate
	 */
	public String getPremiumBackDate() {
		return premiumBackDate;
	}
	/**
	 * @param premiumBackDate the premiumBackDate to set
	 */
	public void setPremiumBackDate(String premiumBackDate) {
		this.premiumBackDate = premiumBackDate;
	}
	/**
	 * @return the currencyCode
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}
	/**
	 * @param currencyCode the currencyCode to set
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	/**
	 * @return the productCategoryCode
	 */
	public String getProductCategoryCode() {
		return productCategoryCode;
	}
	/**
	 * @param productCategoryCode the productCategoryCode to set
	 */
	public void setProductCategoryCode(String productCategoryCode) {
		this.productCategoryCode = productCategoryCode;
	}
	/**
	 * @return the policyOption
	 */
	public String getPolicyOption() {
		return policyOption;
	}
	/**
	 * @param policyOption the policyOption to set
	 */
	public void setPolicyOption(String policyOption) {
		this.policyOption = policyOption;
	}
	/**
	 * @return the policyOptionYears
	 */
	public int getPolicyOptionYears() {
		return policyOptionYears;
	}
	/**
	 * @param policyOptionYears the policyOptionYears to set
	 */
	public void setPolicyOptionYears(int policyOptionYears) {
		this.policyOptionYears = policyOptionYears;
	}
	/**
	 * @return the impairedLife
	 */
	public boolean isImpairedLife() {
		return impairedLife;
	}
	/**
	 * @param impairedLife the impairedLife to set
	 */
	public void setImpairedLife(boolean impairedLife) {
		this.impairedLife = impairedLife;
	}
	/**
	 * @return the crisisWaiver
	 */
	public boolean isCrisisWaiver() {
		return crisisWaiver;
	}
	/**
	 * @param crisisWaiver the crisisWaiver to set
	 */
	public void setCrisisWaiver(boolean crisisWaiver) {
		this.crisisWaiver = crisisWaiver;
	}
	/**
	 * @return the earlyCrisisWaiver
	 */
	public boolean isEarlyCrisisWaiver() {
		return earlyCrisisWaiver;
	}
	/**
	 * @param earlyCrisisWaiver the earlyCrisisWaiver to set
	 */
	public void setEarlyCrisisWaiver(boolean earlyCrisisWaiver) {
		this.earlyCrisisWaiver = earlyCrisisWaiver;
	}
}
