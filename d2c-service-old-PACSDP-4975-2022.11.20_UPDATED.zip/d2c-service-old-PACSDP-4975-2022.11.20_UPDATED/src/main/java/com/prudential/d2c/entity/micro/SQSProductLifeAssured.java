package com.prudential.d2c.entity.micro;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class SQSProductLifeAssured {
	
	private int lifeAssuredId;
	private String lifeAssuredType;
	private String clientType;
	private int clientId;
	private int sequenceNo;
	private List<SQSProductPlan> plans;
	private List<SQSProductPlan> extraPlans;
	private List<SQSProductPlan> riders;
	private boolean proposer;
	/**
	 * @return the plans
	 */
	public List<SQSProductPlan> getPlans() {
		return plans;
	}
	/**
	 * @param plans the plans to set
	 */
	public void setPlans(List<SQSProductPlan> plans) {
		this.plans = plans;
	}
	/**
	 * @return the extraPlans
	 */
	public List<SQSProductPlan> getExtraPlans() {
		return extraPlans;
	}
	/**
	 * @param extraPlans the extraPlans to set
	 */
	public void setExtraPlans(List<SQSProductPlan> extraPlans) {
		this.extraPlans = extraPlans;
	}
	/**
	 * @return the riders
	 */
	public List<SQSProductPlan> getRiders() {
		return riders;
	}
	/**
	 * @param riders the riders to set
	 */
	public void setRiders(List<SQSProductPlan> riders) {
		this.riders = riders;
	}
	
	/**
	 * @return the lifeAssuredId
	 */
	public int getLifeAssuredId() {
		return lifeAssuredId;
	}
	/**
	 * @param lifeAssuredId the lifeAssuredId to set
	 */
	public void setLifeAssuredId(int lifeAssuredId) {
		this.lifeAssuredId = lifeAssuredId;
	}
	/**
	 * @return the lifeAssuredType
	 */
	public String getLifeAssuredType() {
		return lifeAssuredType;
	}
	/**
	 * @param lifeAssuredType the lifeAssuredType to set
	 */
	public void setLifeAssuredType(String lifeAssuredType) {
		this.lifeAssuredType = lifeAssuredType;
	}
	/**
	 * @return the clientType
	 */
	public String getClientType() {
		return clientType;
	}
	/**
	 * @param clientType the clientType to set
	 */
	public void setClientType(String clientType) {
		this.clientType = clientType;
	}
	/**
	 * @return the clientId
	 */
	public int getClientId() {
		return clientId;
	}
	/**
	 * @param clientId the clientId to set
	 */
	public void setClientId(int clientId) {
		this.clientId = clientId;
	}
	/**
	 * @return the sequenceNo
	 */
	public int getSequenceNo() {
		return sequenceNo;
	}
	/**
	 * @param sequenceNo the sequenceNo to set
	 */
	public void setSequenceNo(int sequenceNo) {
		this.sequenceNo = sequenceNo;
	}
	/**
	 * @return the proposer
	 */
	public boolean isProposer() {
		return proposer;
	}
	/**
	 * @param proposer the proposer to set
	 */
	public void setProposer(boolean proposer) {
		this.proposer = proposer;
	}
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
	

}
