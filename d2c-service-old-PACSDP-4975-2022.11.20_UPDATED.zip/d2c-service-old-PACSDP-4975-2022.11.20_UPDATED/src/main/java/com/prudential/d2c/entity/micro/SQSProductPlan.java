package com.prudential.d2c.entity.micro;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class SQSProductPlan {
	
	private int planId;
	private String planName;
	private String planType;
	private String planCode;
	private String productCategoryCode;
	private int benefit;
	private int duration;
	private String paymentMethod;
	private String paymentMode;
	private double sumAssured;
	private double premium;
	private double premiumYearly;
	private double premiumHalfYearly;
	private double premiumQuarterly;
	private double premiumMonthly;
	private double discountedPremium;
	private int premiumTerm;
	private int policyTerm;
	private String optionCode;
	private boolean cwAttached;
	private String selectedTermOption;
	private String type;
	private String premiumDueDate;
	
	private double singlePremium;
	
	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
	}
