package com.prudential.d2c.entity.micro;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class SelectedPolicyOption {
	
	private String optCode;
	private String optValue;
	private String optDescp;
	private boolean isOptValueEditable;

	public String getOptCode() {
		return optCode;
	}

	public String getOptValue() {
		return optValue;
	}

	public String getOptDescp() {
		return optDescp;
	}

	public boolean isOptValueEditable() {
		return isOptValueEditable;
	}

	public void setOptCode(String optCode) {
		this.optCode = optCode;
	}

	public void setOptValue(String optValue) {
		this.optValue = optValue;
	}

	public void setOptDescp(String optDescp) {
		this.optDescp = optDescp;
	}

	public void setOptValueEditable(boolean isOptValueEditable) {
		this.isOptValueEditable = isOptValueEditable;
	}

	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
	
}
