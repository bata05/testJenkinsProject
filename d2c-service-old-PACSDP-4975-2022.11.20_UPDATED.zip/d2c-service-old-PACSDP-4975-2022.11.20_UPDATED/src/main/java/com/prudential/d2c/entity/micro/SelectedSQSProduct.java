package com.prudential.d2c.entity.micro;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class SelectedSQSProduct {
	
	public SelectedSQSProduct() {
		super();
		this.isAgeReq = false;
		this.isSmokerReq = false;
		this.isResidentialStatusReq = false;
		this.isOccupReq = false;
		this.isGenderReq = false;
		this.isPaymentModeReq = false;
	}

	private String docId;
	private String prodCode;
	private String prodDesc;
	//for questionnaire
	private String policyType;
	private String topUpSumAssured;
	
	private String paymentMode;
	private String currency;
	private String paymentTypeIndicator;
	private double totalPremium;
	private double totalHalfYearlyPremium;
	private double totalQuarterlyPremium;
	private double totalMonthlyPremium;
	private double totalYearlyPremium;
	
	//assign agent 
	private boolean isAgeReq;
	private boolean isSmokerReq;
	private boolean isResidentialStatusReq;
	private boolean isOccupReq;
	private boolean isGenderReq;
	private boolean isPaymentModeReq;

		
	private List<SelectedSQSProductComponent> components;
	
	private SelectedPolicyOption selectedPolicyOption;
	
	private SelectedSQSProductTables tables;

	/**
	 * @return the docId
	 */
	public String getDocId() {
		return docId;
	}

	/**
	 * @param docId the docId to set
	 */
	public void setDocId(String docId) {
		this.docId = docId;
	}

	/**
	 * @return the prodCode
	 */
	public String getProdCode() {
		return prodCode;
	}

	/**
	 * @param prodCode the prodCode to set
	 */
	public void setProdCode(String prodCode) {
		this.prodCode = prodCode;
	}

	/**
	 * @return the paymentMode
	 */
	public String getPaymentMode() {
		return paymentMode;
	}

	/**
	 * @param paymentMode the paymentMode to set
	 */
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	/**
	 * @return the components
	 */
	public List<SelectedSQSProductComponent> getComponents() {
		return components;
	}

	/**
	 * @param components the components to set
	 */
	public void setComponents(List<SelectedSQSProductComponent> components) {
		this.components = components;
	}

	/**
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}

	/**
	 * @param currency the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}

	/**
	 * @return the totalPremium
	 */
	public double getTotalPremium() {
		return totalPremium;
	}

	/**
	 * @param totalPremium the totalPremium to set
	 */
	public void setTotalPremium(double totalPremium) {
		this.totalPremium = totalPremium;
	}

	/**
	 * @return the totalHalfYearlyPremium
	 */
	public double getTotalHalfYearlyPremium() {
		return totalHalfYearlyPremium;
	}

	/**
	 * @param totalHalfYearlyPremium the totalHalfYearlyPremium to set
	 */
	public void setTotalHalfYearlyPremium(double totalHalfYearlyPremium) {
		this.totalHalfYearlyPremium = totalHalfYearlyPremium;
	}

	/**
	 * @return the totalQuarterlyPremium
	 */
	public double getTotalQuarterlyPremium() {
		return totalQuarterlyPremium;
	}

	/**
	 * @param totalQuarterlyPremium the totalQuarterlyPremium to set
	 */
	public void setTotalQuarterlyPremium(double totalQuarterlyPremium) {
		this.totalQuarterlyPremium = totalQuarterlyPremium;
	}

	/**
	 * @return the totalMonthlyPremium
	 */
	public double getTotalMonthlyPremium() {
		return totalMonthlyPremium;
	}

	/**
	 * @param totalMonthlyPremium the totalMonthlyPremium to set
	 */
	public void setTotalMonthlyPremium(double totalMonthlyPremium) {
		this.totalMonthlyPremium = totalMonthlyPremium;
	}

	/**
	 * @return the totalYearlyPremium
	 */
	public double getTotalYearlyPremium() {
		return totalYearlyPremium;
	}

	/**
	 * @param totalYearlyPremium the totalYearlyPremium to set
	 */
	public void setTotalYearlyPremium(double totalYearlyPremium) {
		this.totalYearlyPremium = totalYearlyPremium;
	}

	/**
	 * @return the selectedPolicyOption
	 */
	public SelectedPolicyOption getSelectedPolicyOption() {
		return selectedPolicyOption;
	}

	/**
	 * @param selectedPolicyOption the selectedPolicyOption to set
	 */
	public void setSelectedPolicyOption(SelectedPolicyOption selectedPolicyOption) {
		this.selectedPolicyOption = selectedPolicyOption;
	}

	/**
	 * @return the tables
	 */
	public SelectedSQSProductTables getTables() {
		return tables;
	}

	/**
	 * @param tables the tables to set
	 */
	public void setTables(SelectedSQSProductTables tables) {
		this.tables = tables;
	}

	/**
	 * @return the prodDesc
	 */
	public String getProdDesc() {
		return prodDesc;
	}

	/**
	 * @param prodDesc the prodDesc to set
	 */
	public void setProdDesc(String prodDesc) {
		this.prodDesc = prodDesc;
	}

	/**
	 * @return the paymentTypeIndicator
	 */
	public String getPaymentTypeIndicator() {
		return paymentTypeIndicator;
	}

	/**
	 * @param paymentTypeIndicator the paymentTypeIndicator to set
	 */
	public void setPaymentTypeIndicator(String paymentTypeIndicator) {
		this.paymentTypeIndicator = paymentTypeIndicator;
	}
	
	public String getPolicyType() {
		return policyType;
	}

	public String getTopUpSumAssured() {
		return topUpSumAssured;
	}

	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}

	public void setTopUpSumAssured(String topUpSumAssured) {
		this.topUpSumAssured = topUpSumAssured;
	}

	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}

	public boolean isAgeReq() {
		return isAgeReq;
	}

	public boolean isSmokerReq() {
		return isSmokerReq;
	}

	public boolean isResidentialStatusReq() {
		return isResidentialStatusReq;
	}

	public boolean isOccupReq() {
		return isOccupReq;
	}

	public boolean isGenderReq() {
		return isGenderReq;
	}

	public boolean isPaymentModeReq() {
		return isPaymentModeReq;
	}

	public void setAgeReq(boolean isAgeReq) {
		this.isAgeReq = isAgeReq;
	}

	public void setSmokerReq(boolean isSmokerReq) {
		this.isSmokerReq = isSmokerReq;
	}

	public void setResidentialStatusReq(boolean isResidentialStatusReq) {
		this.isResidentialStatusReq = isResidentialStatusReq;
	}

	public void setOccupReq(boolean isOccupReq) {
		this.isOccupReq = isOccupReq;
	}

	public void setGenderReq(boolean isGenderReq) {
		this.isGenderReq = isGenderReq;
	}

	public void setPaymentModeReq(boolean isPaymentModeReq) {
		this.isPaymentModeReq = isPaymentModeReq;
	}
	


}
