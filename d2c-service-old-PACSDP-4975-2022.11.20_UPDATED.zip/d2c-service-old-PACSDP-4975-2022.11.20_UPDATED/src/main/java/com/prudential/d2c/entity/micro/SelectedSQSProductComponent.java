package com.prudential.d2c.entity.micro;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class SelectedSQSProductComponent {
	
public SelectedSQSProductComponent() {
		super();
	}

	private String compoCode;
	private boolean isBasic;
	private boolean isRequired;
	private String lifeInsuredType;
	private Integer term;
	private Integer benefitTerm;
	private Integer minPolicyTerm;
	private Integer premiumTerm;
	private Double premium;
	private Double yearlyPremium;
	private Double monthlyPremium;
	private Double sumAssured;
	private String compoDesc;
	private Integer sequence;
	private Double minSumAssured;
	private Double maxSumAssured;
	private String benefitsDesc;
	private String risksDesc;
	private SelectedPolicyOption selectedCompoPlanOption;
	
	
	//for questionnaire
	private String benefitCode;
	private String type;
	private boolean isDefault;
	private Double discountedPremium;
	
	public SelectedSQSProductComponent(String compoCode, boolean isBasic, boolean isRequired, String lifeInsuredType,
			Integer term, Integer benefitTerm,Integer minPolicyTerm, Integer premiumTerm, Double premium, Double yearlyPremium,
			Double sumAssured, String compoDesc,Integer sequence) {

		this.compoCode = compoCode;
		this.isBasic = isBasic;
		this.isRequired = isRequired;
		this.lifeInsuredType = lifeInsuredType;
		this.term = term;
		this.benefitTerm = benefitTerm;
		this.minPolicyTerm = minPolicyTerm;
		this.premiumTerm = premiumTerm;
		this.premium = premium;
		this.yearlyPremium = yearlyPremium;
		this.sumAssured = sumAssured;
		this.compoDesc = compoDesc;
		this.sequence = sequence;
	}

	

	/**
	 * @return the compoCode
	 */
	public String getCompoCode() {
		return compoCode;
	}



	/**
	 * @param compoCode the compoCode to set
	 */
	public void setCompoCode(String compoCode) {
		this.compoCode = compoCode;
	}

	/**
     * @return the basic
     */
    public boolean getIsBasic() {
        return isBasic;
    }



    /**
     * @param basic the basic to set
     */
    public void setIsBasic(boolean isBasic) {
        this.isBasic = isBasic;
    }



    /**
     * @return the required
     */
    public boolean getIsRequired() {
        return isRequired;
    }



    /**
     * @param required the required to set
     */
    public void setIsRequired(boolean isRequired) {
        this.isRequired = isRequired;
    }



    /**
	 * @return the lifeInsuredType
	 */
	public String getLifeInsuredType() {
		return lifeInsuredType;
	}



	/**
	 * @param lifeInsuredType the lifeInsuredType to set
	 */
	public void setLifeInsuredType(String lifeInsuredType) {
		this.lifeInsuredType = lifeInsuredType;
	}



	


	/**
	 * @return the term
	 */
	public Integer getTerm() {
		return term;
	}



	/**
	 * @param term the term to set
	 */
	public void setTerm(Integer term) {
		this.term = term;
	}



	/**
	 * @return the benefitTerm
	 */
	public Integer getBenefitTerm() {
		return benefitTerm;
	}



	/**
	 * @param benefitTerm the benefitTerm to set
	 */
	public void setBenefitTerm(Integer benefitTerm) {
		this.benefitTerm = benefitTerm;
	}



	/**
	 * @return the minPolicyTerm
	 */
	public Integer getMinPolicyTerm() {
		return minPolicyTerm;
	}



	/**
	 * @param minPolicyTerm the minPolicyTerm to set
	 */
	public void setMinPolicyTerm(Integer minPolicyTerm) {
		this.minPolicyTerm = minPolicyTerm;
	}



	/**
	 * @return the premiumTerm
	 */
	public Integer getPremiumTerm() {
		return premiumTerm;
	}



	/**
	 * @param premiumTerm the premiumTerm to set
	 */
	public void setPremiumTerm(Integer premiumTerm) {
		this.premiumTerm = premiumTerm;
	}



	/**
	 * @return the premium
	 */
	public Double getPremium() {
		return premium;
	}



	/**
	 * @param premium the premium to set
	 */
	public void setPremium(Double premium) {
		this.premium = premium;
	}



	/**
	 * @return the yearlyPremium
	 */
	public Double getYearlyPremium() {
		return yearlyPremium;
	}



	/**
	 * @param yearlyPremium the yearlyPremium to set
	 */
	public void setYearlyPremium(Double yearlyPremium) {
		this.yearlyPremium = yearlyPremium;
	}



	/**
	 * @return the monthlyPremium
	 */
	public Double getMonthlyPremium() {
		return monthlyPremium;
	}



	/**
	 * @param monthlyPremium the monthlyPremium to set
	 */
	public void setMonthlyPremium(Double monthlyPremium) {
		this.monthlyPremium = monthlyPremium;
	}



	/**
	 * @return the sumAssured
	 */
	public Double getSumAssured() {
		return sumAssured;
	}



	/**
	 * @param sumAssured the sumAssured to set
	 */
	public void setSumAssured(Double sumAssured) {
		this.sumAssured = sumAssured;
	}



	/**
	 * @return the compoDesc
	 */
	public String getCompoDesc() {
		return compoDesc;
	}



	/**
	 * @param compoDesc the compoDesc to set
	 */
	public void setCompoDesc(String compoDesc) {
		this.compoDesc = compoDesc;
	}



	/**
	 * @return the sequence
	 */
	public Integer getSequence() {
		return sequence;
	}



	/**
	 * @param sequence the sequence to set
	 */
	public void setSequence(Integer sequence) {
		this.sequence = sequence;
	}



	/**
	 * @return the maxSumAssured
	 */
	public Double getMaxSumAssured() {
		return maxSumAssured;
	}



	/**
	 * @param maxSumAssured the maxSumAssured to set
	 */
	public void setMaxSumAssured(Double maxSumAssured) {
		this.maxSumAssured = maxSumAssured;
	}



	/**
	 * @return the benefitsDesc
	 */
	public String getBenefitsDesc() {
		return benefitsDesc;
	}



	/**
	 * @param benefitsDesc the benefitsDesc to set
	 */
	public void setBenefitsDesc(String benefitsDesc) {
		this.benefitsDesc = benefitsDesc;
	}



	/**
	 * @return the risksDesc
	 */
	public String getRisksDesc() {
		return risksDesc;
	}



	/**
	 * @param risksDesc the risksDesc to set
	 */
	public void setRisksDesc(String risksDesc) {
		this.risksDesc = risksDesc;
	}



	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}



	/**
	 * @return the selectedCompoPlanOption
	 */
	public SelectedPolicyOption getSelectedCompoPlanOption() {
		return selectedCompoPlanOption;
	}



	/**
	 * @param selectedCompoPlanOption the selectedCompoPlanOption to set
	 */
	public void setSelectedCompoPlanOption(SelectedPolicyOption selectedCompoPlanOption) {
		this.selectedCompoPlanOption = selectedCompoPlanOption;
	}



	/**
	 * @return the minSumAssured
	 */
	public Double getMinSumAssured() {
		return minSumAssured;
	}



	/**
	 * @param minSumAssured the minSumAssured to set
	 */
	public void setMinSumAssured(Double minSumAssured) {
		this.minSumAssured = minSumAssured;
	}



	public String getBenefitCode() {
		return benefitCode;
	}



	public String getType() {
		return type;
	}

	public boolean isDefault() {
		return isDefault;
	}

	public void setBenefitCode(String benefitCode) {
		this.benefitCode = benefitCode;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setDefault(boolean isDefault) {
		this.isDefault = isDefault;
	}

	public Double getDiscountedPremium() {
		return discountedPremium;
	}

	public void setDiscountedPremium(Double discountedPremium) {
		this.discountedPremium = discountedPremium;
	}
}
