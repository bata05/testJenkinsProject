package com.prudential.d2c.entity.micro;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class SelectedSQSProductTables {
	
	@JsonProperty("MAIN_BENEFIT_TABLE")
	private SelectedSQSProductTable mainBenefitTable;
	
	@JsonProperty("ACCUMULATED_BENEFIT_TABLE")
	private SelectedSQSProductTable accumulatedBenefitTable;
	
	@JsonProperty("RIDER_BENEFIT_TABLE")
	private SelectedSQSProductTable riderBenefitTable;

	@JsonProperty("QUOTE_DETAILS_TABLE")
	private SelectedSQSProductTable quoteDetailsTable;

	/**
	 * @return the mainBenefitTable
	 */
	public SelectedSQSProductTable getMainBenefitTable() {
		return mainBenefitTable;
	}

	/**
	 * @param mainBenefitTable the mainBenefitTable to set
	 */
	public void setMainBenefitTable(SelectedSQSProductTable mainBenefitTable) {
		this.mainBenefitTable = mainBenefitTable;
	}

	/**
	 * @return the accumulatedBenefitTable
	 */
	public SelectedSQSProductTable getAccumulatedBenefitTable() {
		return accumulatedBenefitTable;
	}

	/**
	 * @param accumulatedBenefitTable the accumulatedBenefitTable to set
	 */
	public void setAccumulatedBenefitTable(SelectedSQSProductTable accumulatedBenefitTable) {
		this.accumulatedBenefitTable = accumulatedBenefitTable;
	}
	
	/**
	 * @return the riderBenefitTable
	 */
	public SelectedSQSProductTable getRiderBenefitTable() {
		return riderBenefitTable;
	}

	/**
	 * @param riderBenefitTable the riderBenefitTable to set
	 */
	public void setRiderBenefitTable(SelectedSQSProductTable riderBenefitTable) {
		this.riderBenefitTable = riderBenefitTable;
	}

	public SelectedSQSProductTable getQuoteDetailsTable() {
		return quoteDetailsTable;
	}

	public void setQuoteDetailsTable(SelectedSQSProductTable quoteDetailsTable) {
		this.quoteDetailsTable = quoteDetailsTable;
	}

	@Override
	public String toString()
	{
	  return ToStringBuilder.reflectionToString(this);
	}
	
	

}
