package com.prudential.d2c.entity.micro;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class StoreDocumentRequest {

    private StoreDocumentRequestPayload payload;

    public StoreDocumentRequestPayload getPayload() {
        return payload;
    }

    public void setPayload(StoreDocumentRequestPayload payload) {
        this.payload = payload;
    }
}
