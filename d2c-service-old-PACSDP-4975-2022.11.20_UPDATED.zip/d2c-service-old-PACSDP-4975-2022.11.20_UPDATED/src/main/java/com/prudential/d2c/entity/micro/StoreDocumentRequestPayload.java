package com.prudential.d2c.entity.micro;

public class StoreDocumentRequestPayload {

    private String transactionId;

    private String file;

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getFile() {
        return file;
    }

    public void setFile(String file) {
        this.file = file;
    }
}
