package com.prudential.d2c.entity.micro;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class StoreDocumentResponse {

    private MicroResponseSystem system;

    private String quotationPDFToken;

    public MicroResponseSystem getSystem() {
        return system;
    }

    public void setSystem(MicroResponseSystem system) {
        this.system = system;
    }

    public String getQuotationPDFToken() {
        return quotationPDFToken;
    }

    public void setQuotationPDFToken(String quotationPDFToken) {
        this.quotationPDFToken = quotationPDFToken;
    }
}
