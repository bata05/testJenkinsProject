package com.prudential.d2c.entity.micro;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.io.Serializable;

@JsonIgnoreProperties(ignoreUnknown = true)
public class StoreDocumentResponsePayload implements Serializable {

	private static final long serialVersionUID = -7066957477890086821L;

	private String transactionId;

    private String quotationPdfToken;

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getQuotationPdfToken() {
        return quotationPdfToken;
    }

    public void setQuotationPdfToken(String quotationPdfToken) {
        this.quotationPdfToken = quotationPdfToken;
    }

}
