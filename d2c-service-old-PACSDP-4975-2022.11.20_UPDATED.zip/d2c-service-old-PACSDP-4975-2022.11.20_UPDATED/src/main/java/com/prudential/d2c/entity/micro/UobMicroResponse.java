package com.prudential.d2c.entity.micro;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.prudential.d2c.entity.CardInfo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(value = "UobMicroResponse", description = "UobMicroResponse")
public class UobMicroResponse {

	@ApiModelProperty(required= true, value = "MicroResponseSystem", position = 0)
	private MicroResponseSystem system;

	@ApiModelProperty(required= true, value = "UobPayload", position = 1)
	private UobPayload payload;
	
	public MicroResponseSystem getSystem() {
		return system;
	}
	public void setSystem(MicroResponseSystem system) {
		this.system = system;
	}
	
	public UobPayload getPayload() {
		return payload;
	}
	
	public void setPayload(UobPayload payload) {
		this.payload = payload;
	}
	
	public class UobPayload{
		private CardInfo cardInfo;

		public CardInfo getCardInfo() {
			return cardInfo;
		}

		public void setCardInfo(CardInfo cardInfo) {
			this.cardInfo = cardInfo;
		}
		
	}
}
