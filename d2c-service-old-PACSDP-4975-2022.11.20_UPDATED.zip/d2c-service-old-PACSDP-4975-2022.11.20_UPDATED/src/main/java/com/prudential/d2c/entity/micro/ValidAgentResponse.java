package com.prudential.d2c.entity.micro;

import com.prudential.d2c.entity.GenericResponse;

public class ValidAgentResponse extends GenericResponse {
    private String businessName;
    private String emailAddress;

    public String getBusinessName() {
        return businessName;
    }

    public void setBusinessName(String businessName) {
        this.businessName = businessName;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }
}
