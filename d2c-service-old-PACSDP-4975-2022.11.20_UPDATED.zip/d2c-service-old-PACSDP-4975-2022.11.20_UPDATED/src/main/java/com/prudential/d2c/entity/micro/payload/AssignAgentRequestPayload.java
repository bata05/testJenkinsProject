package com.prudential.d2c.entity.micro.payload;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.prudential.d2c.entity.micro.MicroAgentProfile;
import com.prudential.d2c.entity.micro.MicroLifeProfile;

/**
 * This is used for calling Agent API request payload
 *
 */
@JsonInclude(Include.NON_NULL)
public class AssignAgentRequestPayload {

    private String transactionId;
    private String channel;
    private String subChannel;
    private String policyNumber;
    private MicroLifeProfile clientProfile;
    private MicroSelectedProducts selectedProducts;
    private MicroAgentProfile referralAgentProfile;


    public AssignAgentRequestPayload() {

        clientProfile = new MicroLifeProfile();
        selectedProducts = new MicroSelectedProducts();
        referralAgentProfile = new MicroAgentProfile();
    }
    public MicroLifeProfile getClientProfile() {
        return clientProfile;
    }

    public MicroAgentProfile getReferralAgentProfile() {
        return referralAgentProfile;
    }

    public void setReferralAgentProfile(MicroAgentProfile referralAgentProfile) {
        this.referralAgentProfile = referralAgentProfile;
    }

    public void setClientProfile(MicroLifeProfile clientProfile) {
        this.clientProfile = clientProfile;
    }

    public String getTransactionId() {
        return transactionId;
    }


    public MicroSelectedProducts getSelectedProducts() {
        return selectedProducts;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public void setSelectedProducts(MicroSelectedProducts selectedProducts) {
        this.selectedProducts = selectedProducts;
    }

    public String getPolicyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String getChannel() {
        return channel;
    }

    public String getSubChannel() {
        return subChannel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public void setSubChannel(String subChannel) {
        this.subChannel = subChannel;
    }

    @Override
    public String toString() {
        return "AssignAgentRequestPayload{" +
                "transactionId='" + transactionId + '\'' +
                ", channel='" + channel + '\'' +
                ", subChannel='" + subChannel + '\'' +
                ", policyNumber='" + policyNumber + '\'' +
                ", clientProfile=" + clientProfile +
                ", selectedProducts=" + selectedProducts +
                ", referralAgentProfile=" + referralAgentProfile +
                '}';
    }
}
