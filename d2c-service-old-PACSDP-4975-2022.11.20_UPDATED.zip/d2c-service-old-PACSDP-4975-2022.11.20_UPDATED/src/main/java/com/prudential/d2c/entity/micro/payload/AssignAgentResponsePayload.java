package com.prudential.d2c.entity.micro.payload;

import com.prudential.d2c.entity.micro.AgentData;
import com.prudential.d2c.entity.micro.AgentDataCriteria;
import com.prudential.d2c.entity.micro.ClientErrorContainer;

public class AssignAgentResponsePayload extends ClientErrorContainer {
	
	private String transactionId;

	private AgentData assignedAgent;

	private AgentDataCriteria criteriaDetail;

	private String typeOfAssignment;

	public String getTransactionId() {
		return transactionId;
	}

	public AgentData getAssignedAgent() {
		return assignedAgent;
	}

	public AgentDataCriteria getCriteriaDetail() {
		return criteriaDetail;
	}

	public String getTypeOfAssignment() { return typeOfAssignment; }

	public void setAssignedAgent(AgentData assignedAgent) {
		this.assignedAgent = assignedAgent;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public void setCriteriaDetail(AgentDataCriteria criteriaDetail) {
		this.criteriaDetail = criteriaDetail;
	}

	public void setTypeOfAssignment(String typeOfAssignment) { this.typeOfAssignment = typeOfAssignment; }

}
