package com.prudential.d2c.entity.micro.payload;

public class AuthPayload{
	private String transactionId;
	private String username;
	private String password;
	private String randomKey;
	private String authType;
	private String otp;
	
	public String getTransactionId() {
		return transactionId;
	}
	
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	
	public String getUsername() {
		return username;
	}
	
	public void setUsername(String username) {
		this.username = username;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getRandomKey() {
		return randomKey;
	}
	
	public void setRandomKey(String randomKey) {
		this.randomKey = randomKey;
	}
	public String getAuthType() {
		return authType;
	}
	
	public void setAuthType(String authType) {
		this.authType = authType;
	}
	
	public String getOtp() {
		return otp;
	}
	
	public void setOtp(String otp) {
		this.otp = otp;
	}
	
}
