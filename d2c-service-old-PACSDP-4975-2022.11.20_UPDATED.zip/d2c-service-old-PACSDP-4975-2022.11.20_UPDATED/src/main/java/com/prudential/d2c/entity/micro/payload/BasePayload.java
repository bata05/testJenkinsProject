package com.prudential.d2c.entity.micro.payload;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class BasePayload extends ErrorMessagesPayload {

    private static final long serialVersionUID = 1531915752551452832L;

}
