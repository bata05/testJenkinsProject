package com.prudential.d2c.entity.micro.payload;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@JsonIgnoreProperties(ignoreUnknown = true)
public class ClientPayload extends ErrorMessagesPayload {
    /**
	 * 
	 */
	private static final long serialVersionUID = 3229526903833052456L;
	private String clientNumber;
    
	public String getClientNumber() {
		return clientNumber;
	}
	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}




}
