package com.prudential.d2c.entity.micro.payload;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.prudential.d2c.entity.micro.ClientErrorContainer;
import com.prudential.d2c.entity.micro.ClientInfo;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ClientResponsePayload extends ClientErrorContainer{
	private String transactionId;
	private List<ClientInfo> clientList;
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public List<ClientInfo> getClientList() {
		return clientList;
	}
	public void setClientList(List<ClientInfo> clientList) {
		this.clientList = clientList;
	}
	
	
}
