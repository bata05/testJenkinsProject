package com.prudential.d2c.entity.micro.payload;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.prudential.d2c.entity.micro.LifeProfile;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ClientSearchRequestPayload {
	private String transactionId;
	private Boolean relativeSearch;
	private LifeProfile lifeProfile;
	
	
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public Boolean getRelativeSearch() {
		return relativeSearch;
	}
	public void setRelativeSearch(Boolean relativeSearch) {
		this.relativeSearch = relativeSearch;
	}
	public LifeProfile getLifeProfile() {
		return lifeProfile;
	}
	public void setLifeProfile(LifeProfile lifeProfile) {
		this.lifeProfile = lifeProfile;
	}
	
	
}
