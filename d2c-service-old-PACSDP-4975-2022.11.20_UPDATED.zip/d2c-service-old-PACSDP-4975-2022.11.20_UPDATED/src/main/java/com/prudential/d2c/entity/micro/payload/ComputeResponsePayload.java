package com.prudential.d2c.entity.micro.payload;

import java.util.List;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.prudential.d2c.entity.PDFData;
import com.prudential.d2c.entity.Product;
import com.prudential.d2c.entity.micro.Error;
import com.prudential.d2c.entity.micro.LifeProfile;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ComputeResponsePayload {
	private String transactionId;
	private PDFData pdfData;
	private String erefCode;
	private List<LifeProfile> lifeProfiles;
	private List<Product> selectedSQSProducts;
	private List<String> allowedPaymentMode;
	private Set<Error> errors;
	
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public PDFData getPdfData() {
		return pdfData;
	}
	public void setPdfData(PDFData pdfData) {
		this.pdfData = pdfData;
	}
	public List<LifeProfile> getLifeProfiles() {
		return lifeProfiles;
	}
	public void setLifeProfiles(List<LifeProfile> lifeProfiles) {
		this.lifeProfiles = lifeProfiles;
	}
	public List<Product> getSelectedSQSProducts() {
		return selectedSQSProducts;
	}
	public void setSelectedSQSProducts(List<Product> selectedSQSProducts) {
		this.selectedSQSProducts = selectedSQSProducts;
	}

	public String getErefCode() {
		return erefCode;
	}

	public void setErefCode(String erefCode) {
		this.erefCode = erefCode;
	}

	public Set<Error> getErrors() {
		return errors;
	}

	public void setErrors(Set<Error> errors) {
		this.errors = errors;
	}

	public List<String> getAllowedPaymentMode() {
		return allowedPaymentMode;
	}

	public void setAllowedPaymentMode(List<String> allowedPaymentMode) {
		this.allowedPaymentMode = allowedPaymentMode;
	}
}
