package com.prudential.d2c.entity.micro.payload;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;

public class ErrorMessagesPayload implements Serializable {

    private static final long serialVersionUID = 1L;

    private List<String> errorMessages;

    private String transactionId;

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public List<String> getErrorMessages() {
        return errorMessages;
    }

    public void setErrorMessages(List<String> errorMessages) {
        this.errorMessages = errorMessages;
    }

    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

}
