package com.prudential.d2c.entity.micro.payload;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class MicroSelectedProducts {

	private String docId;
	private String prodCode;
	private List<MicroSelectedProductsComponents> components;
	public String getDocId() {
		return docId;
	}
	public String getProdCode() {
		return prodCode;
	}
	public List<MicroSelectedProductsComponents> getComponents() {
		return components;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	public void setProdCode(String prodCode) {
		this.prodCode = prodCode;
	}
	public void setComponents(List<MicroSelectedProductsComponents> components) {
		this.components = components;
	}

	
}
