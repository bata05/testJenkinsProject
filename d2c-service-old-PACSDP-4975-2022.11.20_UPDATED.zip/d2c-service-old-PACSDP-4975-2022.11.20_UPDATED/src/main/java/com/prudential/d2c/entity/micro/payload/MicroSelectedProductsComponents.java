package com.prudential.d2c.entity.micro.payload;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_NULL)
public class MicroSelectedProductsComponents {
	private String compoCode;
	private String sumAssured;
	//get the API value ,there will be a field in response named isBasic
	private boolean isBasic;
	private String singlePremium;
	private Integer premiumTerm;
	private double premium;

	public String getCompoCode() {
		return compoCode;
	}

	public void setCompoCode(String compoCode) {
		this.compoCode = compoCode;
	}

	public String getSumAssured() {
		return sumAssured;
	}

	public void setSumAssured(String sumAssured) {
		this.sumAssured = sumAssured;
	}

	public boolean getIsBasic() {
		return isBasic;
	}

	public void setIsBasic(boolean isBasic) {
		this.isBasic = isBasic;
	}

	public String getSinglePremium() {
		return singlePremium;
	}

	public void setSinglePremium(String singlePremium) {
		this.singlePremium = singlePremium;
	}

	public Integer getPremiumTerm() {
		return premiumTerm;
	}

	public void setPremiumTerm(Integer premiumTerm) {
		this.premiumTerm = premiumTerm;
	}

	public double getPremium() {
		return premium;
	}

	public void setPremium(double premium) {
		this.premium = premium;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
	
	
}
