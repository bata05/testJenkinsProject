package com.prudential.d2c.entity.micro.payload;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class NeedsAnalysisPayload {

  private boolean skippedNeedsAnalysis;
  private String hospitalType;
  private String roomType;
  private String additionalCoverageType;

  public NeedsAnalysisPayload() {
    this.skippedNeedsAnalysis = false;
    this.hospitalType = null;
    this.roomType = null;
    this.additionalCoverageType = null;
  }

  public boolean isSkippedNeedsAnalysis() {
    return skippedNeedsAnalysis;
  }

  public void setSkippedNeedsAnalysis(boolean skippedNeedsAnalysis) {
    this.skippedNeedsAnalysis = skippedNeedsAnalysis;
  }

  public String getHospitalType() {
    return hospitalType;
  }

  public void setHospitalType(String hospitalType) {
    this.hospitalType = hospitalType;
  }

  public String getRoomType() {
    return roomType;
  }

  public void setRoomType(String roomType) {
    this.roomType = roomType;
  }

  public String getAdditionalCoverageType() {
    return additionalCoverageType;
  }

  public void setAdditionalCoverageType(String additionalCoverageType) {
    this.additionalCoverageType = additionalCoverageType;
  }

  @Override
  public String toString() {
    return "NeedsAnalysisPayload{" +
        "skippedNeedsAnalysis=" + skippedNeedsAnalysis +
        ", hospitalType='" + hospitalType + '\'' +
        ", roomType='" + roomType + '\'' +
        ", additionalCoverageType='" + additionalCoverageType + '\'' +
        '}';
  }
}
