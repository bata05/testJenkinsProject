package com.prudential.d2c.entity.micro.payload;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Option {
	
	private String code;
	private String label;
	private String maxLength;
	private String minLength;
	private String notes;
	private String sequence;
	private String showAdd;
	
	public Option() {
		super();
	}
	public Option(String code, String label, String value,String sequence) {
		super();
		this.code = code;
		this.label = label;
		this.value = value;
		this.sequence= sequence;
	}
	private String value;
	
	public String getCode() {
		return code;
	}
	public String getLabel() {
		return label;
	}
	public String getValue() {
		return value;
	}
	public String getSequence() {
		return sequence;
	}
	public String getShowAdd() {
		return showAdd;
	}
	public String getNotes() {
		return notes;
	}
	public String getMinLength() {
		return minLength;
	}
	public String getMaxLength() {
		return maxLength;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public void setSequence(String sequence) {
		this.sequence = sequence;
	}
	public void setShowAdd(String showAdd) {
		this.showAdd = showAdd;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public void setMinLength(String minLength) {
		this.minLength = minLength;
	}
	public void setMaxLength(String maxLength) {
		this.maxLength = maxLength;
	}
  
}
