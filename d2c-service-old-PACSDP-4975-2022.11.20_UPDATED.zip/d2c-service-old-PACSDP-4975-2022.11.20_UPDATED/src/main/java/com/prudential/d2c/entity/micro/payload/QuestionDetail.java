package com.prudential.d2c.entity.micro.payload;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.prudential.d2c.entity.AnswerBody;
@JsonIgnoreProperties(ignoreUnknown = true)
public class QuestionDetail {
	
	private String after;
	private String description;
	private String validation;
	private String cat;
	private String parent;
	private String depend;
	private int max;
	private String type;
	private String title;
	private String code;
	private String details;
	private List<QuestionDetail> subQuestions;
	private List<Option> answerArray;
	private String questionnaire;
	private String sequence;
	private String required;
	private String warningText;
	private int min;
	
	
	private String order ;//to sort
	private String option;
    
	private AnswerBody answer;
	
	public String getCode() {
		return code;
	}

	public String getParent() {
		return parent;
	}

	public String getCat() {
		return cat;
	}

	public String getDescription() {
		return description;
	}

	public String getSequence() {
		return sequence;
	}

	public String getType() {
		return type;
	}

	public String getValidation() {
		return validation;
	}

	public int getMin() {
		return min;
	}

	public int getMax() {
		return max;
	}

	public String getRequired() {
		return required;
	}

	public String getDepend() {
		return depend;
	}


	public String getTitle() {
		return title;
	}

	public String getQuestionnaire() {
		return questionnaire;
	}

	public String getDetails() {
		return details;
	}


	public String getAfter() {
		return after;
	}

	public List<QuestionDetail> getSubQuestions() {
		return subQuestions;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public void setParent(String parent) {
		this.parent = parent;
	}

	public void setCat(String cat) {
		this.cat = cat;
	}


	public void setDescription(String description) {
		this.description = description;
	}

	public void setSequence(String sequence) {
		this.sequence = sequence;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setValidation(String validation) {
		this.validation = validation;
	}

	public void setMin(int min) {
		this.min = min;
	}

	public void setMax(int max) {
		this.max = max;
	}

	public void setRequired(String required) {
		this.required = required;
	}

	public void setDepend(String depend) {
		this.depend = depend;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setQuestionnaire(String questionnaire) {
		this.questionnaire = questionnaire;
	}

	public void setDetails(String details) {
		this.details = details;
	}


	public void setAfter(String after) {
		this.after = after;
	}


	public void setSubQuestions(List<QuestionDetail> subQuestions) {
		this.subQuestions = subQuestions;
	}

	public String getOption() {
		return option;
	}

	public void setOption(String option) {
		this.option = option;
	}

	public String getOrder() {
		return order;
	}

	public void setOrder(String order) {
		this.order = order;
	}

	public List<Option> getAnswerArray() {
		return answerArray;
	}

	public String getWarningText() {
		return warningText;
	}

	public void setWarningText(String warningText) {
		this.warningText = warningText;
	}

	public void setAnswerArray(List<Option> answerArray) {
		this.answerArray = answerArray;
	}

	public AnswerBody getAnswer() {
		return answer;
	}

	public void setAnswer(AnswerBody answer) {
		this.answer = answer;
	}



  
}
