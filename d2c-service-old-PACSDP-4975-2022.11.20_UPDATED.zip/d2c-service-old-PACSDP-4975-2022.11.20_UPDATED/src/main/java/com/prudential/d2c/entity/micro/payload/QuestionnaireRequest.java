package com.prudential.d2c.entity.micro.payload;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import com.prudential.d2c.entity.micro.PolicyRequestPayload;
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class QuestionnaireRequest extends QuestionnaireRequestPayload {
	
	private PolicyRequestPayload policyRequestPayload;
	
	
    public PolicyRequestPayload getPolicyRequestPayload() {
		return policyRequestPayload;
	}
	public void setPolicyRequestPayload(PolicyRequestPayload policyRequestPayload) {
		this.policyRequestPayload = policyRequestPayload;
	}
}
