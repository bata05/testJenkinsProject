package com.prudential.d2c.entity.micro.payload;

import java.util.List;

import com.prudential.d2c.entity.micro.MicroLifeProfile;

public class QuestionnaireRequestPayload {
	
	private String transactionId;
	private MicroLifeProfile lifeProfile;
	private MicroSelectedProducts selectedProducts;

	private String platform;//"DP"
	private String transactionType;//"NB"
	private String version;//V1
	private List<String> categoryList;
	private String channel;
	public QuestionnaireRequestPayload(){

	}

	public QuestionnaireRequestPayload(String platform, String transactionType, String version) {
		super();
		this.platform = platform;
		this.transactionType = transactionType;
		this.version = version;
	}


	public String getTransactionId() {
		return transactionId;
	}


	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}


	public MicroLifeProfile getLifeProfile() {
		return lifeProfile;
	}
	public void setLifeProfile(MicroLifeProfile lifeProfile) {
		this.lifeProfile = lifeProfile;
	}
	public MicroSelectedProducts getSelectedProducts() {
		return selectedProducts;
	}
	public void setSelectedProducts(MicroSelectedProducts selectedProducts) {
		this.selectedProducts = selectedProducts;
	}
	public String getPlatform() {
		return platform;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public String getVersion() {
		return version;
	}
	public List<String> getCategoryList() {
		return categoryList;
	}
	public void setPlatform(String platform) {
		this.platform = platform;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public void setCategoryList(List<String> categoryList) {
		this.categoryList = categoryList;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	
	
	
}
