package com.prudential.d2c.entity.micro.payload;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.prudential.d2c.entity.micro.ClientErrorContainer;
@JsonIgnoreProperties(ignoreUnknown = true)
public class QuestionnaireResponsePayload extends ClientErrorContainer {
	private String transactionId;
	private List<QuestionDetail> questionnaire;
	
	
	public String getTransactionId() {
		return transactionId;
	}

	public List<QuestionDetail> getQuestionnaire() {
		return questionnaire;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public void setQuestionnaire(List<QuestionDetail> questionnaire) {
		this.questionnaire = questionnaire;
	}
}
