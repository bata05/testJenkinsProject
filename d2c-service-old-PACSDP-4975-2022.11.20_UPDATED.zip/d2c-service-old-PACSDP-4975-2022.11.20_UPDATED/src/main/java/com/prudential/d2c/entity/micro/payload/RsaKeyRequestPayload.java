package com.prudential.d2c.entity.micro.payload;

public class RsaKeyRequestPayload {
	private String transactionId;
	private String authType;
	
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getAuthType() {
		return authType;
	}
	public void setAuthType(String authType) {
		this.authType = authType;
	}
}
