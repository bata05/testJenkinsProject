package com.prudential.d2c.entity.micro.payload;

import com.prudential.d2c.entity.RsaKey;

public class RsaKeyResponsePayload extends RsaKey{
		
}
