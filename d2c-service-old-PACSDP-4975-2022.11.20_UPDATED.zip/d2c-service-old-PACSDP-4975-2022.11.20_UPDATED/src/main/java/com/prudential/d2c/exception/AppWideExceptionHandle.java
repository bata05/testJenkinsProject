package com.prudential.d2c.exception;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.HttpMediaTypeNotAcceptableException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.servlet.ModelAndView;

import com.prudential.d2c.entity.D2CResponse;
import com.prudential.d2c.entity.SuccessStatus;
import com.prudential.d2c.entity.dto.ExceptionData;
import com.prudential.d2c.entity.micro.ChannelAPIErrorResponse;
import com.prudential.d2c.repository.ExceptionDataRepository;
import com.prudential.d2c.service.DPLoggerService;

@ControllerAdvice
public class AppWideExceptionHandle {
    private static final String STATUS_FAILED = "Failed";
    public static final String MSG_ERROR = "Error happened. Please contact the admin.";
    public static final String DEFAULT_ERROR_VIEW = "error";
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    private static final String PARAM_TIMESTAMP = "timestamp";
    private static final String PARAM_MESSAGE = "message";
    private static final String PARAM_STATUS = "status";
    private static final String CHANNEL_API = "channelAPI";

    @Autowired
    private ExceptionDataRepository exceptionDataRepository;

    @Autowired
    private DPLoggerService dpLoggerService;

    /**
     * Handle customized CyberSourcePaymentException
     * 
     * @param request
     *            http request object
     * @param e
     *            exception object
     * @return json object with exception basic information
     */
    @ResponseBody
    @ExceptionHandler(value = {CyberSourcePaymentException.class, D2CException.class})
    public Object handleCyberSourcePaymentException(HttpServletRequest request, Exception e) {
        logger.error(e.getMessage());

        ModelAndView mav = new ModelAndView();
        mav.addObject(PARAM_TIMESTAMP, new Date());
        mav.addObject(DEFAULT_ERROR_VIEW, e);
        mav.addObject(PARAM_MESSAGE, e.getMessage());
        mav.setViewName(DEFAULT_ERROR_VIEW);

        return mav;
    }

    /**
     * Handle customized HttpMediaTypeNotAcceptableException
     *
     * @param request
     *            http request object
     * @param ex
     *            exception object
     * @return json object with exception basic information
     */
    @ResponseStatus(value = HttpStatus.NOT_ACCEPTABLE) // 406
    @ExceptionHandler(HttpMediaTypeNotAcceptableException.class)
    public ModelAndView handleError(HttpServletRequest req, Exception ex) {

        logger.error(ex.getMessage());

        ModelAndView mav = new ModelAndView();
        mav.addObject(PARAM_TIMESTAMP, new Date());
        mav.addObject(DEFAULT_ERROR_VIEW, ex);
        mav.addObject(PARAM_MESSAGE, MSG_ERROR);
        mav.addObject(PARAM_STATUS, 406);
        mav.setViewName(DEFAULT_ERROR_VIEW);

        return mav;
    }

    /**
     * Handle system common exception
     * 
     * @param request
     *            http request object
     * @param e
     *            exception object
     * @return json object with exception basic information
     */
    @ResponseBody
    @ExceptionHandler(Exception.class)
    public Object handleFileNotFound(HttpServletRequest request, Exception e) {
        logger.error("Catch Exception :", e);

        if (StringUtils.contains(request.getRequestURI(), CHANNEL_API)) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }

        ExceptionData eData = new ExceptionData();
        eData.setMessage(MSG_ERROR);
        long millis = System.currentTimeMillis();
        Date date = new Date(millis);
        eData.setDate(date);
        eData.setRequestURL(request.getRequestURI());
        exceptionDataRepository.save(eData);
        SuccessStatus status = new SuccessStatus();
        status.setSuccess(false);
        status.setMessage(MSG_ERROR);
        status.setExcuteStatus(STATUS_FAILED);

        return status;
    }

    /**
     * Handle system common exception
     *
     * @param request
     *            http request object
     * @param e
     *            exception object
     * @return json object with exception basic information
     */
    @ResponseBody
    @ExceptionHandler(D2CConfigException.class)
    public Object handleD2CConfigException(HttpServletRequest request, D2CConfigException e) {
        logger.error("Catch Exception :", e);

        ExceptionData eData = new ExceptionData();
        eData.setMessage(MSG_ERROR);

        long millis = System.currentTimeMillis();
        Date date = new Date(millis);
        eData.setDate(date);
        eData.setRequestURL(request.getRequestURI());
        exceptionDataRepository.save(eData);
        SuccessStatus status = new SuccessStatus();
        status.setSuccess(false);
        status.setMessage(MSG_ERROR);
        status.setExcuteStatus(STATUS_FAILED);
        status.setErrorCode(e.getErrorCode());

        return status;
    }

    /**
     * DPValidationException handler
     * @param request
     * @param exception
     * @return
     */
    @ResponseBody
    @ExceptionHandler(value = {DPValidationException.class})
    public D2CResponse handleValidationException(HttpServletRequest request, DPValidationException exception) {
        logError(exception);
        return D2CResponse.with500ValidationErrors(exception.getErrors());
    }

    @ResponseBody
    @ExceptionHandler(value = {ChannelAPIException.class})
    public ResponseEntity<ChannelAPIErrorResponse> handlechannelAPIException(HttpServletRequest request, ChannelAPIException exception) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
    }

    /**
     * HttpClientErrorException handler
     * @param he
     * @return
     */
    @ResponseBody
    @ExceptionHandler(HttpClientErrorException.class)
    public Object handleHttpClientError(HttpServletRequest request, HttpClientErrorException he) {
        logError(he);
        return D2CResponse.with500ExceptionMessage(he);
    }

    /**
     * Logger
     * @param exception
     */
    protected void logError(Exception exception){
        dpLoggerService.error(exception, logger);
    }
}
