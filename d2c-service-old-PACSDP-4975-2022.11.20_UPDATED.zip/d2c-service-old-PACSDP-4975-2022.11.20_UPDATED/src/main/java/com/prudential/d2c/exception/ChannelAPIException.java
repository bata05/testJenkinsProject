package com.prudential.d2c.exception;


/**
 * Validation exception for DP
 */
public class ChannelAPIException extends Exception {

	private static final long serialVersionUID = -5985283083663371863L;

	public ChannelAPIException(String s) {
        super(s);
    }
}
