package com.prudential.d2c.exception;


/**
 * Customize exception to handle Cyber Source Payment
 *
 */
public class CyberSourcePaymentException extends RuntimeException {

	private static final long serialVersionUID = 7767399358458237176L;
	
	/**
	 * Constructor method with message
	 * @param message
	 * 					exception error message
	 */
	public CyberSourcePaymentException(String message) {
        super(message);
    }
    
	/**
	 * Constructor method with message and throwable object
	 * @param message
	 * 					exception error message
	 * @param t
	 * 					throwable object
	 */
    public CyberSourcePaymentException(String message, Throwable t) {
        super(message, t);
    }
}
