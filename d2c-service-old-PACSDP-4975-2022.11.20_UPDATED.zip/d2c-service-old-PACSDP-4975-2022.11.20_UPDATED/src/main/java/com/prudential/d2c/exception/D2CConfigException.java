package com.prudential.d2c.exception;

/**
 * For common usage of exception
 *
 */
public class D2CConfigException extends RuntimeException {

    private static final long serialVersionUID = -3008978057767316302L;

    private String errorCode;

    /**
     * Constructor method with message
     *
     * @param message
     *            exception error message
     */
    public D2CConfigException(String message) {
        super(message);
    }

    /**
     * Constructor method with message and error code
     * @param message
     * @param errorCode
     */
    public D2CConfigException(String message, String errorCode) {
        super(message);
        this.errorCode = errorCode;
    }

    /**
     * Constructor method with message and throwable object
     *
     * @param message
     *            exception error message
     * @param t
     *            throwable object
     */
    public D2CConfigException(String message, Throwable t) {
        super(message, t);
    }


    /**
     * Constructor method with message and throwable object
     *
     * @param e
     */
    public D2CConfigException(Exception e) {
        super(e);
    }

    public String getErrorCode() {
        return errorCode;
    }
}
