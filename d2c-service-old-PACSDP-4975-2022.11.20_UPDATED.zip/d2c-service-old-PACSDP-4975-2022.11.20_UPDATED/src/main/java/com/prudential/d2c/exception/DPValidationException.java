package com.prudential.d2c.exception;

import java.util.Set;

import com.prudential.d2c.entity.micro.Error;

/**
 * Validation exception for DP
 *
 */
public class DPValidationException extends RuntimeException {

    private static final long serialVersionUID = -3008978057767316304L;

    private Set<Error> errors;

    /**
     * Constructor method with message
     *
     * @param message
     *            exception error message
     */
    public DPValidationException(String message) {
        super(message);
    }

    /**
     * Constructor method with message and throwable object
     *
     * @param message
     *            exception error message
     * @param t
     *            throwable object
     */
    public DPValidationException(String message, Throwable t) {
        super(message, t);
    }


    /**
     * Constructor method with message and throwable object
     *
     * @param e
     */
    public DPValidationException(Exception e) {
        super(e);
    }

    /**
     * Constructor method with message and throwable object
     *
     * @param e
     */
    public DPValidationException(String message, Set<Error> errors) {
        super(message);
        this.errors = errors;
    }

    public Set<Error> getErrors() {
        return errors;
    }
}
