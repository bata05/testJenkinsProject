package com.prudential.d2c.exception;


/**
 * Validation exception for DP
 */
public class DigitalEndowmentAPIException extends Exception {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DigitalEndowmentAPIException(String s) {
        super(s);
    }
}
