package com.prudential.d2c.exception;

public class MyInfoException extends Exception {

	private static final long serialVersionUID = 1L;

	public MyInfoException(String message) {
		super(message);
	}

	public MyInfoException(String message, Throwable t) {
		super(message, t);
	}

	public MyInfoException(Throwable t) {
		super(t);
	}

	public MyInfoException() {
		super();
	}

}
