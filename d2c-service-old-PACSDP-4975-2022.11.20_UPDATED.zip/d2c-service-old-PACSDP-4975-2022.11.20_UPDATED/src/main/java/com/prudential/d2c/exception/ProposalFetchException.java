package com.prudential.d2c.exception;

/**
 * For common usage of exception
 *
 */
public class ProposalFetchException extends RuntimeException {
    private static final long serialVersionUID = -3008978057767316301L;

    /**
     * Constructor method with message
     * 
     * @param message
     *            exception error message
     */
    public ProposalFetchException(String message) {
        super(message);
    }

    /**
     * Constructor method with message and throwable object
     * 
     * @param message
     *            exception error message
     * @param t
     *            throwable object
     */
    public ProposalFetchException(String message, Throwable t) {
        super(message, t);
    }

    
    /**
     * Constructor method with message and throwable object
     * 
     * @param e
     */
    public ProposalFetchException(Exception e) {
        super(e);
    }
}
