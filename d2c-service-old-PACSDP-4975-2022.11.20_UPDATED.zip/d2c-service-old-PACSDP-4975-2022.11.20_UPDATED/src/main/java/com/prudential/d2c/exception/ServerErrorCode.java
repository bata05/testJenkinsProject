package com.prudential.d2c.exception;

public interface ServerErrorCode {

    String SERVER_CONFIG_VALIDATION_FAILURE = "501";
}
