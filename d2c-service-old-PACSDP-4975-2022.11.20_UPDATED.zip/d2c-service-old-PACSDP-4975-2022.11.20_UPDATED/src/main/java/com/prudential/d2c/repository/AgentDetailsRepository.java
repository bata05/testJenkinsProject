package com.prudential.d2c.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.prudential.d2c.entity.AgentDetails;

@Repository
public interface AgentDetailsRepository extends CrudRepository<AgentDetails, String> {
    AgentDetails findOneByCustId(String custId);
}
