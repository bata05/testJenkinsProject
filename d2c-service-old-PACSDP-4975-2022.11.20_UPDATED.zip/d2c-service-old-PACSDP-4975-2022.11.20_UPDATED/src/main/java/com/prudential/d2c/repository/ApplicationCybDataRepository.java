package com.prudential.d2c.repository;

import com.prudential.d2c.entity.dto.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.*;
import org.springframework.data.repository.query.*;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.*;

import java.util.*;

@Repository
public interface ApplicationCybDataRepository extends CrudRepository<ApplicationCybData, String> {

    @Modifying(clearAutomatically = true)
    @Transactional
    @Query("update ApplicationCybData appCybData set appCybData.onUs =:onUs where appCybData.erefNo =:erefNo")
    void updateCybUobStatus(@Param("onUs") String onUs, @Param("erefNo") String erefNo);

    @Modifying(clearAutomatically = true)
    @Transactional
    @Query("update ApplicationCybData appCybData set appCybData.signature =:signature where appCybData.erefNo =:erefNo")
    void updateCybPaymentSignature(@Param("signature") String signature, @Param("erefNo") String erefNo);

    public List<ApplicationCybData> findByPayerAuthEnrollReplyXid(String payerAuthEnrollReplyXid);

    public List<ApplicationCybData> findByAuthenticationTransactionID(String authenticationTransactionID);

    public ApplicationCybData findByCustomId(String customId);
}
