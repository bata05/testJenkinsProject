package com.prudential.d2c.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.prudential.d2c.entity.dto.ApplicationData;

@Repository
public interface ApplicationDataRepository extends CrudRepository<ApplicationData, String> {


	@Modifying(clearAutomatically = true)
	@Transactional
	@Query("update ApplicationData appData set appData.esubStatus =:esubStatus,appData.updateDate = systimestamp where appData.erefNo =:erefNo")
	void updateEsubStatus(@Param("esubStatus") String esubStatus, @Param("erefNo") String erefNo);
	ApplicationData findByCustomId(String customId);

}
