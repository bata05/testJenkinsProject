package com.prudential.d2c.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.prudential.d2c.entity.dto.ApplicationDocument;

@Repository
public interface ApplicationDocumentRepository extends CrudRepository<ApplicationDocument, String> {

	public ApplicationDocument findByErefNoAndCustomId(String erefNo, String customId);

}
