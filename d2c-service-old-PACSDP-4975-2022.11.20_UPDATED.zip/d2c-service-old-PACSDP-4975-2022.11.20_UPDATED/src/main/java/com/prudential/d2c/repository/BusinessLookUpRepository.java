package com.prudential.d2c.repository;

import com.prudential.d2c.entity.dto.BusinessLookUp;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BusinessLookUpRepository extends CrudRepository<BusinessLookUp,Integer> {
  List<BusinessLookUp> findAll();

  List<BusinessLookUp> findByChannelId(Integer channelId);

  @Query("select x from BusinessLookUp x where x.channelId=?1 and x.action=?2")
  BusinessLookUp findByChannelIdAndAction(Integer channelId, String action);

}
