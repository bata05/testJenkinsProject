package com.prudential.d2c.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.prudential.d2c.entity.dto.CampaignLookup;

public interface CampaignLookupRepository extends CrudRepository<CampaignLookup, String> {
    @Query("SELECT c FROM CampaignLookup c WHERE c.channel=:channel and c.subChannel=:subChannel " +
            "and c.startDate <= :today and c.endDate >= :today ")
    public CampaignLookup findByChannels(@Param("channel") String channel, @Param("subChannel") String subChannel, @Param("today") Date today);
    
    public List <CampaignLookup> findByCampaignId(String campaignId);
}
