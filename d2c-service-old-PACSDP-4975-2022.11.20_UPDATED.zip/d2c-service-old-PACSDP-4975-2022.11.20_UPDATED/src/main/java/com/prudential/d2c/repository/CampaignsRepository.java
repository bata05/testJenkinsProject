package com.prudential.d2c.repository;

import com.prudential.d2c.entity.config.Campaigns;
import com.prudential.d2c.entity.config.Channels;
import com.prudential.d2c.entity.config.Products;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CampaignsRepository extends CrudRepository<Campaigns, Integer> {

    public Campaigns findByCampaignId(String campaignId);

    public Campaigns findByCampaignIdAndChannels(String campaignId, Channels channels);

    public Campaigns findByCampaignIdAndAndChannelsAndProducts(String campaignId, Channels channels, Products products);

}
