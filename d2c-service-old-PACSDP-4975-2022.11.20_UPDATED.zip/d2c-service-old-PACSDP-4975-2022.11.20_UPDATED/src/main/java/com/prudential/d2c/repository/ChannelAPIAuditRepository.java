package com.prudential.d2c.repository;

import com.prudential.d2c.entity.dto.ChannelAPIAudit;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ChannelAPIAuditRepository extends CrudRepository<ChannelAPIAudit, String> {

    public List<ChannelAPIAudit> findByTransactionID(String transactionId);

    public List<ChannelAPIAudit> findByTransactionIDAndApiTypeAndApiStatusOrderByCreateDateDesc(String transactionId, String apiType, String apiStatus);

}
