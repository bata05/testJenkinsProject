package com.prudential.d2c.repository;

import com.prudential.d2c.entity.dto.ChannelAPICustomerApplication;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public interface ChannelAPICustomerApplicationRepository extends CrudRepository<ChannelAPICustomerApplication, Integer> {

    public ChannelAPICustomerApplication findByTransactionID(String transactionId);

    List<ChannelAPICustomerApplication> findByApplicationStatusAndServerHostName(ChannelAPICustomerApplication.ChannelAPICusAppStatus applicationStatus, String serverHostName);

    public ChannelAPICustomerApplication findByDpCustomId(String dpCustomId);

}
