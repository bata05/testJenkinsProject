package com.prudential.d2c.repository;

import com.prudential.d2c.entity.dto.ChannelAPIDocument;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ChannelAPIDocumentRepository extends CrudRepository<ChannelAPIDocument, String> {

    public ChannelAPIDocument findByTransactionID(String transactionId);

    public ChannelAPIDocument findByDpCustomId(String dpCustomId);

}
