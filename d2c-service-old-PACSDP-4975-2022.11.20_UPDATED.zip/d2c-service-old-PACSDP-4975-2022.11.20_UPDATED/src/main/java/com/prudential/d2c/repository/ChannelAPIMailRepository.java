package com.prudential.d2c.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.prudential.d2c.entity.dto.ChannelAPIMail;

@Repository
@Transactional
public interface ChannelAPIMailRepository extends CrudRepository<ChannelAPIMail, Integer> {


}
