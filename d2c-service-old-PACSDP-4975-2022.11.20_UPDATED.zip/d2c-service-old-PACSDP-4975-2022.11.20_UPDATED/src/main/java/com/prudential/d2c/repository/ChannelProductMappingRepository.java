package com.prudential.d2c.repository;


import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.prudential.d2c.entity.config.ChannelProductMapping;
import com.prudential.d2c.entity.config.Channels;
import com.prudential.d2c.entity.config.Products;

@Repository
public interface ChannelProductMappingRepository extends CrudRepository<ChannelProductMapping, Integer> {

/*	@Query("select m from ChannelProductMapping m where m.channel.channelCode = :channelCode and m.productId.productCode = :productCode")
    public List<ChannelProductMapping> findByChannelCodeAndProductCode(@Param("channelCode") String channelCode, @Param("productCode") String productCode);*/
	
    public ChannelProductMapping findByChannelsAndProducts(Channels channels, Products products);
    
    @Query("select m from ChannelProductMapping m where m.channels = :channels and m.products = :products and m.aaSubChannel = :aaSubChannel")
    public List<ChannelProductMapping> findByChannelCodeAndProductCodeAndAASubChannel(@Param("channels") Channels channels, @Param("products") Products products,  @Param("aaSubChannel") String aaSubChannel);
	

}
