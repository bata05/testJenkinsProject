package com.prudential.d2c.repository;

import com.prudential.d2c.entity.config.Channels;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ChannelRepository extends CrudRepository<Channels, Integer> {

    public Channels findByChannelName(String channelName);

    public Channels findByChannelCode(String channelCode);

}
