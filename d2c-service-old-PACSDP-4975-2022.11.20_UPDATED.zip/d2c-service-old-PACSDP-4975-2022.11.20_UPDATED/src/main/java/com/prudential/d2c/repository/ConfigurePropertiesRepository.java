package com.prudential.d2c.repository;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.prudential.d2c.entity.dto.ConfigureProperties;

@Repository
public interface ConfigurePropertiesRepository extends CrudRepository<ConfigureProperties, String>{
	
	List<ConfigureProperties> findByConNameIgnoreCaseContaining(String conName);
	
}
