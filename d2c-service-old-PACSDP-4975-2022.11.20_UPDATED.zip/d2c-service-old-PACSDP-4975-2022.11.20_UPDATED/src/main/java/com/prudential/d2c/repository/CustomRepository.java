package com.prudential.d2c.repository;

import java.util.List;
import java.util.Optional;

import com.prudential.d2c.entity.config.ProductsConfig;
import com.prudential.d2c.entity.dto.ChannelAPIReportSalesView;
import com.prudential.d2c.entity.dto.DigitalEndowmentAPIReportESubView;
import com.prudential.d2c.entity.dto.DigitalEndowmentAPIReportSalesView;
import com.prudential.d2c.entity.dto.DigitalEndowmentAPIReportTrancheView;
import com.prudential.d2c.entity.dto.LeadsAssignmentView;

public interface CustomRepository {
    Optional<LeadsAssignmentView> getLeadsdsAssignmentEntryByCustomID(String customId);

    <T> T mergeEntityObject(T entityObj);

    <T> void refreshEntityObject(T entityObj);

    Optional<ProductsConfig> getProductsConfigByCustAppProductType(String productType);

    /**
     * @param customId
     * @return
     */
    Optional<ChannelAPIReportSalesView> getChannelAPIReportSales(String customId);
    
    /**
     * @param customId
     * @return
     */
    Optional<DigitalEndowmentAPIReportSalesView> getDigitalEndowmentAPIReportSales(String customId);
    
    List<DigitalEndowmentAPIReportESubView> getDigitalEndowmentAPIReportESub();
    
    List<DigitalEndowmentAPIReportTrancheView> getDigitalEndowmentAPIReportTranche();
}
