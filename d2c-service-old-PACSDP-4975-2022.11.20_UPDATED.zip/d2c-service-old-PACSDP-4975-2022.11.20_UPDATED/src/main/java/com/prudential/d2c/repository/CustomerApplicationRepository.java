package com.prudential.d2c.repository;

import java.sql.Blob;
import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.prudential.d2c.entity.dto.CustomerApplication;

@Repository
public interface CustomerApplicationRepository extends CrudRepository<CustomerApplication, String> {

    public CustomerApplication findByCustomId(String customId);

    @Modifying(clearAutomatically = true)
    @Transactional
    @Query("update CustomerApplication ca set ca.qpsQuestionnaires =:qpsQuestionnaires,ca.height =:height,ca.weight = :weight ,ca.createDate = :createDate,ca.stepStatus = :stepStatus where ca.customId =:customId and ca.productType = :productType")
    void updateProductSpecificQuestionnaires(@Param("qpsQuestionnaires") Blob qpsQuestionnaires, @Param("height") String height, @Param("weight") String weight, @Param("createDate") String createDate, @Param("stepStatus") String stepStatus, @Param("customId") String customId, @Param("productType") String productType);

    public List<CustomerApplication> findByProductTypeAndChannelAndClientNumberAndCampaignIdAndCreateDateNotNullAndCreateDateAfter(String productType, String channel, String clientNumber, String campaignId, String createDate);

    public List<CustomerApplication> findByProductTypeAndClientNumberAndCampaignId(String productType, String clientNumber, String campaignId);

    @Modifying(clearAutomatically = true)
    @Transactional
    @Query("update CustomerApplication ca set ca.stepStatus = :stepStatus where ca.customId =:customId")
    void updateStepStatus(@Param("stepStatus") String stepStatus, @Param("customId") String customId);

    @Modifying(clearAutomatically = true)
    @Transactional
    @Query("update CustomerApplication ca set ca.marketConsent = :marketConsent where ca.customId =:customId")
    void updateMarketConsent(@Param("marketConsent") String marketConsent, @Param("customId") String customId);

    @Modifying(clearAutomatically = true)
    @Transactional
    @Query("update CustomerApplication ca set ca.laBizSrcLookupId = :laBizSrcLookupId where ca.customId =:customId")
    void updateBusinessLookupId(@Param("laBizSrcLookupId") Integer laBizSrcLookupId, @Param("customId") String customId);

    @Modifying(clearAutomatically = true)
    @Transactional
    @Query("update CustomerApplication ca set ca.stepStatus = :stepStatus, ca.policyNo = :policyNo where ca.customId =:customId")
    void updateStepStatusAndPolicyNo(@Param("stepStatus") String stepStatus,@Param("policyNo") String policyNo,@Param("customId") String customId);

    @Modifying(clearAutomatically = true)
    @Transactional
    @Query("update CustomerApplication ca set ca.businessSource = :businessSource, ca.businessSubSource = :businessSubSource where ca.customId =:customId")
    void updateBSourceAndBSubSource(@Param("businessSource") String laBizSrcLookupId, @Param("businessSubSource") String businessSubSource, @Param("customId") String customId);

    @Modifying(clearAutomatically = true)
    @Transactional
    @Query("update CustomerApplication ca set ca.clientNumber = :clientNumber where ca.customId =:customId")
    void updateClientNumber(@Param("clientNumber") String clientNumber, @Param("customId") String customId);
    
    public List<CustomerApplication> findByNricFin(String nricFin);

}
