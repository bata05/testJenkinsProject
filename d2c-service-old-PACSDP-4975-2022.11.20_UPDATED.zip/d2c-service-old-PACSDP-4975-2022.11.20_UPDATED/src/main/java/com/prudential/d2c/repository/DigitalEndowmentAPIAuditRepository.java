package com.prudential.d2c.repository;

import com.prudential.d2c.entity.dto.DigitalEndowmentAPIAudit;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DigitalEndowmentAPIAuditRepository extends CrudRepository<DigitalEndowmentAPIAudit, String> {

	public DigitalEndowmentAPIAudit findByDpCustomID(String dpCustomID);
	
    public List<DigitalEndowmentAPIAudit> findByTransactionID(String transactionID);
    
    public List<DigitalEndowmentAPIAudit> findByTransactionIDAndApiStatusOrderByCreateDateDesc(String transactionID, String apiStatus);

    public List<DigitalEndowmentAPIAudit> findByTransactionIDAndApiTypeAndApiStatusOrderByCreateDateDesc(String transactionID, String apiType, String apiStatus);

    public List<DigitalEndowmentAPIAudit> findByPaymentTransactionIDAndApiTypeAndApiStatusOrderByCreateDateDesc(String paymentTransactionID, String apiType, String apiStatus);

    public List<DigitalEndowmentAPIAudit> findByEreferenceNoAndApiTypeAndApiStatusOrderByCreateDateDesc(String ereferenceNo, String apiType, String apiStatus);

}
