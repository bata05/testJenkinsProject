package com.prudential.d2c.repository;

import com.prudential.d2c.entity.dto.DigitalEndowmentAPICustomerApplication;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional
public interface DigitalEndowmentAPICustomerApplicationRepository extends CrudRepository<DigitalEndowmentAPICustomerApplication, Integer> {

    public DigitalEndowmentAPICustomerApplication findByTransactionID(String transactionID);

    List <DigitalEndowmentAPICustomerApplication> findFirst30ByApplicationStatusAndServerHostName(DigitalEndowmentAPICustomerApplication.DigitalEndowmentAPICusAppStatus applicationStatus, String serverHostName);

    public DigitalEndowmentAPICustomerApplication findByDpCustomID(String dpCustomID);

}
