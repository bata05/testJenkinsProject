package com.prudential.d2c.repository;

import com.prudential.d2c.entity.dto.DigitalEndowmentAPIDocument;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DigitalEndowmentAPIDocumentRepository extends CrudRepository<DigitalEndowmentAPIDocument, String> {

    public DigitalEndowmentAPIDocument findByTransactionID(String transactionID);

    public DigitalEndowmentAPIDocument findByDpCustomID(String dpCustomID);

}
