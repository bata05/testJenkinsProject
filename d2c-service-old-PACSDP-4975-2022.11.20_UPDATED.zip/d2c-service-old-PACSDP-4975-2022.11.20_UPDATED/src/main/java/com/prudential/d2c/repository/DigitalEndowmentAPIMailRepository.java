package com.prudential.d2c.repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.prudential.d2c.entity.dto.DigitalEndowmentAPIMail;

@Repository
@Transactional
public interface DigitalEndowmentAPIMailRepository extends CrudRepository<DigitalEndowmentAPIMail, Integer> {
	Optional<DigitalEndowmentAPIMail> findByDpCustomIDAndMailTypeAndStatus(String dpCustomID, String mailType, String status);
}
