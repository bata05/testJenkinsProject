package com.prudential.d2c.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.prudential.d2c.entity.dto.Dropdown;

@Repository
public interface DropdownRepository extends CrudRepository<Dropdown, String> {
	
	public List<Dropdown> findByCode(String code);
	public List<Dropdown> findByCodeOrderByOptionAsc(String code);
	public List<Dropdown> findByCodeOrderBySequenceAsc(String code);
	public Dropdown findByValueAndCode(String value,String code);
	List<Dropdown> findByCodeInOrderBySequenceAsc(String[] codeList);
	List<Dropdown> findByCodeInOrderByOptionAsc(String[] codeList);
}
