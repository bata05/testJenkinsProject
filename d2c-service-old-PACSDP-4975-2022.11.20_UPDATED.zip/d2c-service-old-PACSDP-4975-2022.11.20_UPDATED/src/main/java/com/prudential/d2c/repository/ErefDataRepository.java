package com.prudential.d2c.repository;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.prudential.d2c.entity.dto.ErefData;

@Repository

public interface ErefDataRepository extends CrudRepository<ErefData, String> {
}
