package com.prudential.d2c.repository;

import com.prudential.d2c.entity.dto.FailedQuestionnaireDetails;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FailedQuestionnaireRepository extends CrudRepository<FailedQuestionnaireDetails, Long> {

}
