package com.prudential.d2c.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.prudential.d2c.entity.dto.HSMRandomStorage;

@Repository
public interface HSMRandomStorageRepository extends CrudRepository<HSMRandomStorage,String>{
    public HSMRandomStorage findFirstByRandomKey(String randomKey);
}
