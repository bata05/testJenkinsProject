package com.prudential.d2c.repository;


import com.prudential.d2c.entity.dto.Leads;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface LeadsRepository extends CrudRepository<Leads, String> {

	List<Leads> findFirst30ByIsMcTriggeredFalseOrderByCreatedTimeDesc();

	@Modifying(clearAutomatically = true)
	@Transactional
	@Query("update Leads leads set leads.statusCode =:statusCode,leads.requestServiceMessageId=:requestServiceMessageId, leads.sendDate = systimestamp, leads.isMcTriggered = 1 where leads.id= :leadsId")
	void updateMailStatusAndReceivedIdByMailId(@Param("statusCode") int statusCode, @Param("requestServiceMessageId") String requestServiceMessageId, @Param("leadsId") String leadsId);

	@Modifying(clearAutomatically = true)
	@Transactional
	@Query("update Leads leads set leads.statusCode =:statusCode, leads.sendDate = systimestamp, leads.isMcTriggered = 1 where leads.id= :leadsId and leads.statusCode!=3")
	void updateLeadsForCRMException(@Param("statusCode") int statusCode,@Param("leadsId") String leadsId);

}
