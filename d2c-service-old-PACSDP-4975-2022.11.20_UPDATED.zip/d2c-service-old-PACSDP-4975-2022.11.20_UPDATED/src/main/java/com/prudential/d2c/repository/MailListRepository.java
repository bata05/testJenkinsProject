package com.prudential.d2c.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.prudential.d2c.entity.dto.MailList;

@Repository
public interface MailListRepository extends CrudRepository<MailList, String> {
	
	public List<MailList> findByStatusCodeAndServerHostName(Integer status,String serverHostName);

	@Query("select mail from MailList mail where mail.statusCode = :statusCode and mail.serverHostName= :serverHostName " +
				   "and (mail.agentCode NOT IN :agentList OR mail.mailType IN :mailTypeList)")
	public List<MailList> findByStatusCodeServerHostNameInMailTypesOrNotInAgentCodes(@Param("statusCode") int statusCode, @Param("serverHostName") String serverHostName,
																						  @Param("agentList") List<String> agentList, @Param("mailTypeList") List<String> mailTypeList);
	
	public List<MailList> findByStatusCode(Integer status);
	
	
	public List<MailList> findByCustomId(String customId);
	
	public List<MailList> findByCustomIdAndMailType(String customId,String mailType);

	@Modifying(clearAutomatically = true)
	@Transactional
	@Query("update MailList mail set mail.statusCode =:statusCode where mail.customId =:customId and mail.mailType = :mailType")
	void updateMailStatusByMailIdAndCustomId(@Param("statusCode") int statusCode, @Param("customId") String customId,@Param("mailType") String mailType);


	@Modifying(clearAutomatically = true)
	@Transactional
	@Query("update MailList mail set mail.helpDescription =:helpDescription where mail.customId =:customId and mail.mailType = :mailType")
	void updateMailHelpDescriptionByMailIdAndCustomId(@Param("helpDescription") String helpDescription, @Param("customId") String customId,@Param("mailType") String mailType);


	@Modifying(clearAutomatically = true)
	@Transactional
	@Query("update MailList mail set mail.statusCode =:statusCode, mail.stage =:stage where mail.customId =:customId and mail.mailType = :mailType")
	void updateMailStatusAndStageByCustomIdAndMailType(@Param("statusCode") int statusCode, @Param("stage") String stage, @Param("customId") String customId,
			@Param("mailType") String mailType);
	
	@Modifying(clearAutomatically = true)
	@Transactional
	@Query("update MailList mail set mail.statusCode =:statusCode, mail.sendDate = systimestamp where mail.mailId= :mailId")
	void updateMailStatusAndSendDateByMailId(@Param("statusCode") int statusCode,@Param("mailId") String mailId); 
	
	@Modifying(clearAutomatically = true)
	@Transactional
	@Query("update MailList mail set mail.statusCode =:statusCode where mail.mailId= :mailId")
	void updateMailStatusByMailId(@Param("statusCode") int statusCode,@Param("mailId") String mailId);
	
	@Modifying(clearAutomatically = true)
	@Transactional
	@Query("update MailList mail set mail.statusCode =:statusCode, mail.sendDate = systimestamp where mail.mailId= :mailId and mail.statusCode!=3")
	void updateMailListForCRMException(@Param("statusCode") int statusCode,@Param("mailId") String mailId);

	@Modifying(clearAutomatically = true)
	@Transactional
	@Query("update MailList mail set mail.statusCode =:statusCode,mail.requestServiceMessageId=:requestServiceMessageId, mail.sendDate = systimestamp where mail.mailId= :mailId")
	void updateMailStatusAndReceivedIdByMailId(@Param("statusCode") int statusCode, @Param("requestServiceMessageId") String requestServiceMessageId, @Param("mailId") String mailId);

	@Query("select mail from MailList mail where mail.customId =:customId and mail.agentChannelCode IN ('TIED','BANC')")
	public List<MailList> findAgentChannelCodeByCustomeId(@Param("customId") String customId);
}
