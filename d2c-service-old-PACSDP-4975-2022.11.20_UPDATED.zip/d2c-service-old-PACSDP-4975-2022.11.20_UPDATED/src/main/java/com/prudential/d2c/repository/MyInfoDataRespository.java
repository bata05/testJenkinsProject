package com.prudential.d2c.repository;

import com.prudential.d2c.entity.dto.*;
import org.springframework.data.repository.*;
import org.springframework.stereotype.Repository;

@Repository
public interface MyInfoDataRespository extends CrudRepository<MyInfoData, String> {
		
	public MyInfoData findByEref(String eref);
	
	public MyInfoData findTopByUinfinOrderByTransDateDesc(String uinfin);
	
}