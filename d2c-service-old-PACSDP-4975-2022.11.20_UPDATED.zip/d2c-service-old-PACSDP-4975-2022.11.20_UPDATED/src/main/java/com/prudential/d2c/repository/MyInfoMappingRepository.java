package com.prudential.d2c.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.prudential.d2c.entity.config.MyInfoMapping;

@Repository
public interface MyInfoMappingRepository extends CrudRepository<MyInfoMapping, String> {

    public MyInfoMapping findByMyInfoCode(String myInfoCode);

    public MyInfoMapping findByCode(String myInfoCode);
    
}

