package com.prudential.d2c.repository;

import com.prudential.d2c.entity.dto.NRICMapping;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface NRICMappingRepository extends CrudRepository<NRICMapping,String> {
    List<NRICMapping> findAll();

    //@Todo Need to check with time
    @Query("select x from NRICMapping x where x.nricFin= ?1 and x.customerApplication.channel= ?2 and x.customerApplication.productType= ?3 and x.createdDate >= ?4 order by x.createdDate desc")
    List<NRICMapping> findFirst2ByNricChannel(String nric,String channel,String productCode,Date date);
}
