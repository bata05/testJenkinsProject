package com.prudential.d2c.repository;

import com.prudential.d2c.entity.dto.NeedsAnalysis;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface NeedsAnalysisRepository extends CrudRepository<NeedsAnalysis, String> {
}
