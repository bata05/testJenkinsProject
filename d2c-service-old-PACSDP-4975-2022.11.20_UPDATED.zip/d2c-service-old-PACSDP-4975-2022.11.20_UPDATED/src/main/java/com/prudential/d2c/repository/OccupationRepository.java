package com.prudential.d2c.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.prudential.d2c.entity.dto.Occupation;

@Repository
public interface OccupationRepository extends CrudRepository<Occupation, String> {
	
	public List<Occupation> findByClassOccupation(String classOccupation);
	public Occupation findByCode(String code);
}
