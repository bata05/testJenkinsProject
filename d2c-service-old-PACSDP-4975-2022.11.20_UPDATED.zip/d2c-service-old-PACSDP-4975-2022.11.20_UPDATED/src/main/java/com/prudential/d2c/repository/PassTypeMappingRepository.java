package com.prudential.d2c.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.prudential.d2c.entity.config.PassTypeMapping;

@Repository
public interface PassTypeMappingRepository extends CrudRepository<PassTypeMapping, String> {

    public List<PassTypeMapping> findByDescription(String description);

    public List<PassTypeMapping> findByCode(String code);

    public List<PassTypeMapping> findByCodeIgnoreCase(String code);

    public List<PassTypeMapping> findByDpCode(int dpCode);
}

