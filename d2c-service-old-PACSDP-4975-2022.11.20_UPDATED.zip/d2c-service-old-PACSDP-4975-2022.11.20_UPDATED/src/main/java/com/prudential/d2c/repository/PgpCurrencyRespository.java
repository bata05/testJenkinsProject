package com.prudential.d2c.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.prudential.d2c.entity.dto.PgpOrders;

@Repository
public interface PgpCurrencyRespository extends CrudRepository<PgpOrders, String> {
	
	public List<PgpOrders> findByChannelAndCurrency(String channel,String currency);
}
