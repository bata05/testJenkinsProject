package com.prudential.d2c.repository;

import com.prudential.d2c.entity.config.ProductsConfig;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface ProductConfigRepository extends CrudRepository<ProductsConfig, Long> {

    @Transactional(propagation = Propagation.REQUIRED, readOnly = true)
    @Query("select x from ProductsConfig x where x.sqsProductCode=?1")
    ProductsConfig findBySqsProductCode(String sqsProductCode);

    @Transactional(propagation = Propagation.REQUIRED, readOnly = true)
    ProductsConfig findBySqsDocId(String sqsDocId);
}
