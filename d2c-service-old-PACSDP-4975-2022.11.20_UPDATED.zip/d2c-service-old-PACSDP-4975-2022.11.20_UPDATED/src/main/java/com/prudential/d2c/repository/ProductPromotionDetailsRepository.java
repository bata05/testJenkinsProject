package com.prudential.d2c.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.prudential.d2c.entity.config.ProductPromotionDetails;

@Repository
public interface ProductPromotionDetailsRepository extends CrudRepository<ProductPromotionDetails, Integer> {

    @Query(" from ProductPromotionDetails pdp where pdp.productCode = :productCode ")
    public List<ProductPromotionDetails> findByProductDetailsByProductCode(@Param("productCode") String productCode);

}
