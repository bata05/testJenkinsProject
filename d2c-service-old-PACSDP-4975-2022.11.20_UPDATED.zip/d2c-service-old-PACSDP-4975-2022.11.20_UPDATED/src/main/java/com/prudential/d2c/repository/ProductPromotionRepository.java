package com.prudential.d2c.repository;

import com.prudential.d2c.entity.config.ProductPromotion;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface ProductPromotionRepository extends CrudRepository<ProductPromotion, Integer> {

    @Query(" from ProductPromotion pdm where pdm.productCode = :productCode and pdm.fromValidityDate <= :currentDate and pdm.toValidityDate >= :currentDate ")
    public List<ProductPromotion> findByProductValidity(@Param("productCode") String productCode, @Param("currentDate") Date currentDate);

    @Query(" from ProductPromotion pdm where pdm.productCode = :productCode and pdm.channelCode = :channelCode and pdm.fromValidityDate <= :currentDate and pdm.toValidityDate >= :currentDate ")
    public List<ProductPromotion> findByProductandChannelValidity(@Param("productCode") String productCode,@Param("channelCode") String channelCode, @Param("currentDate") Date currentDate);

    @Query(" from ProductPromotion pdm where pdm.productCode = :productCode and ( pdm.channelCode = :channelCode or channelCode = 'ALL' ) and pdm.fromValidityDate <= :currentDate and pdm.toValidityDate >= :currentDate ")
    public List<ProductPromotion> findByProductandChannelWithChannelCodeAll(@Param("productCode") String productCode,@Param("channelCode") String channelCode, @Param("currentDate") Date currentDate);
}
