package com.prudential.d2c.repository;

import com.prudential.d2c.entity.ProductSalesInfo;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductSalesInfoRepository extends CrudRepository<ProductSalesInfo, Long> {

    List<ProductSalesInfo> findByCustomId(String customId);
}
