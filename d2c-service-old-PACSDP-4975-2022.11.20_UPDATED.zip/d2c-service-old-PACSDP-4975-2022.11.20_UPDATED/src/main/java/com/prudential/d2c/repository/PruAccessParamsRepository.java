package com.prudential.d2c.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.prudential.d2c.entity.dto.PruAccessParams;

@Repository
public interface PruAccessParamsRepository extends CrudRepository<PruAccessParams,String> {
    public PruAccessParams findFirstByUniqueID(String uniqueID);
}
