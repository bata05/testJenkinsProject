package com.prudential.d2c.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.prudential.d2c.entity.dto.PruforceCountryCode;

@Repository
public interface PruforceCountryCodeRepository extends CrudRepository<PruforceCountryCode, String> {

    public List<PruforceCountryCode> findByCodeNumberAndRegionCode(String codeNumber, String regionCode);
}
