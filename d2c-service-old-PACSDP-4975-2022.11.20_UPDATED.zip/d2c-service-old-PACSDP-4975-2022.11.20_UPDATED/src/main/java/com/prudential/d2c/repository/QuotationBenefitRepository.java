package com.prudential.d2c.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.prudential.d2c.entity.dto.QuotationBenefit;

@Repository
public interface QuotationBenefitRepository extends CrudRepository<QuotationBenefit, Integer> {
	
	public List<QuotationBenefit> findByPlanAndType(String plan, String type);
}
