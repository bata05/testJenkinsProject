package com.prudential.d2c.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.prudential.d2c.entity.dto.Quotation;

@Repository
public interface QuotationRepository extends CrudRepository<Quotation, Integer> {
		
	public Quotation findByTypeAndOccupationClassAndPlan(String type, String occupationClass, String plan);
	
	public List<Quotation> findByTypeAndOccupationClassAndFirstAgeLessThanEqualAndLastAgeGreaterThanEqualAndResidency(String type, String occupationClass, Integer age1, Integer age2, String residency);
	public List<Quotation> findByTypeAndFirstAgeLessThanEqualAndLastAgeGreaterThanEqualAndResidency(String type, Integer age1, Integer age2, String residency);
	
	public Quotation findByTypeAndOccupationClassAndPlanAndFirstAgeLessThanEqualAndLastAgeGreaterThanEqualAndResidency(String type, String occupationClass, String plan, Integer age1, Integer age2, String residency);

}
