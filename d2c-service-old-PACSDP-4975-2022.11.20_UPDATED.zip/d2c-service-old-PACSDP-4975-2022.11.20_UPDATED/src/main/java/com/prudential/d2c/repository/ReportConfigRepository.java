package com.prudential.d2c.repository;

import com.prudential.d2c.entity.config.ReportConfig;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ReportConfigRepository extends CrudRepository<ReportConfig, String> {

	ReportConfig findByChannelCode(String channelCode);
}
