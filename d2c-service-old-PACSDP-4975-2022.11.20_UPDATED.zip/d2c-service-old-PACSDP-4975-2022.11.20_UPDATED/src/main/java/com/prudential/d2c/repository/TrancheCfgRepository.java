package com.prudential.d2c.repository;

import java.util.Date;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.prudential.d2c.entity.dto.TrancheCfg;

@Repository
public interface TrancheCfgRepository extends CrudRepository<TrancheCfg, Integer> {

    @Query(" from TrancheCfg tc where tc.covGrpCode = :productCode and tc.componentCode = :componentCode and tc.channelCode = :channelCode and tc.startDate <= :currentDate and tc.endDate >= :currentDate and tc.status = :status")
    public TrancheCfg findValidTrancheByProductCodeAndComponentAndChannelAndStatus(@Param("productCode") String productCode,@Param("componentCode") String componentCode,@Param("channelCode") String channelCode, @Param("currentDate") Date currentDate,@Param("status") String status);

}
