package com.prudential.d2c.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.prudential.d2c.entity.dto.UserActionLog;

@Repository
public interface UserActionLogRepository extends CrudRepository<UserActionLog, String> {
	@Query("select count(*) from UserActionLog a where a.clientNumber =:clientNumber and a.actionName = :actionName and a.actionTime > :actionTime")
	public int countByClientNumberActionTime(@Param("clientNumber") String clientNumber, 
										@Param("actionName") String actionName, 
										@Param("actionTime")Date actionTime);

	
	@Query("select a from UserActionLog a where a.clientNumber =:clientNumber and a.actionName = :actionName and a.actionTime > :actionTime order by actionTime DESC")
	public List<UserActionLog> findLatestAction(@Param("clientNumber") String clientNumber, 
										@Param("actionName") String actionName, 
										@Param("actionTime")Date actionTime);


	@Query("select a from UserActionLog a where a.transactionId =:transactionId and a.actionName = :actionName")
	public List<UserActionLog> findActionByTransactionIdAndName(@Param("transactionId") String transactionId,
										@Param("actionName") String actionName);

	@Query("select count(*) from UserActionLog a where a.transactionId =:transactionId and a.actionName = :actionName")
	public int getOTPSubmitCountByTransactionId(@Param("transactionId") String transactionId,
																@Param("actionName") String actionName);
}
