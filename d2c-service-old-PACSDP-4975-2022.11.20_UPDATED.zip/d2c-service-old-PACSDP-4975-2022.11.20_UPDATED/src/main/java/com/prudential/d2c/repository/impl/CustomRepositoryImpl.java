package com.prudential.d2c.repository.impl;

import com.prudential.d2c.entity.config.Products;
import com.prudential.d2c.entity.config.ProductsConfig;
import com.prudential.d2c.entity.dto.ChannelAPIReportSalesView;
import com.prudential.d2c.entity.dto.DigitalEndowmentAPIReportESubView;
import com.prudential.d2c.entity.dto.DigitalEndowmentAPIReportSalesView;
import com.prudential.d2c.entity.dto.DigitalEndowmentAPIReportTrancheView;
import com.prudential.d2c.entity.dto.LeadsAssignmentView;
import com.prudential.d2c.repository.CustomRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Root;

import java.util.List;
import java.util.Optional;

@Repository
@Transactional
public class CustomRepositoryImpl implements CustomRepository {

    @PersistenceContext
    protected EntityManager em;

    @Override
    public Optional<LeadsAssignmentView> getLeadsdsAssignmentEntryByCustomID(String customId) {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<LeadsAssignmentView> cq = cb.createQuery(LeadsAssignmentView.class);
        Root<LeadsAssignmentView> qRoot = cq.from(LeadsAssignmentView.class);
        cq.where(cb.equal(qRoot.get("customId"), customId.trim()));
        cq.orderBy(cb.desc(qRoot.get("createDate")));
        return em.createQuery(cq).getResultList().stream().findFirst();
    }

    @Override
    public <T> T mergeEntityObject(T entityObj) {
        return em.merge(entityObj);
    }

    @Override
    public <T> void refreshEntityObject(T entityObj) {
        em.refresh(entityObj);
    }

    @Override
    public Optional<ProductsConfig> getProductsConfigByCustAppProductType(String productType) {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<ProductsConfig> cq = cb.createQuery(ProductsConfig.class);
        Root<ProductsConfig> qRoot = cq.from(ProductsConfig.class);
        Join<ProductsConfig, Products> productsJoin = qRoot.join("d2cProduct");
        cq.where(cb.equal(productsJoin.get("productCode"), productType.trim()));
        return em.createQuery(cq).getResultList().stream().findFirst();
    }

    @Override
    public Optional<ChannelAPIReportSalesView> getChannelAPIReportSales(String customId) {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<ChannelAPIReportSalesView> cq = cb.createQuery(ChannelAPIReportSalesView.class);
        Root<ChannelAPIReportSalesView> qRoot = cq.from(ChannelAPIReportSalesView.class);
        cq.where(cb.equal(qRoot.get("customId"), customId.trim()));
        return em.createQuery(cq).getResultList().stream().findFirst();
    }

	@Override
	public Optional<DigitalEndowmentAPIReportSalesView> getDigitalEndowmentAPIReportSales(String customId) {
		CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<DigitalEndowmentAPIReportSalesView> cq = cb.createQuery(DigitalEndowmentAPIReportSalesView.class);
        Root<DigitalEndowmentAPIReportSalesView> qRoot = cq.from(DigitalEndowmentAPIReportSalesView.class);
        cq.where(cb.equal(qRoot.get("customId"), customId.trim()));
        return em.createQuery(cq).getResultList().stream().findFirst();
	}
	
	@Override
	public List <DigitalEndowmentAPIReportESubView> getDigitalEndowmentAPIReportESub() {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<DigitalEndowmentAPIReportESubView> cq = cb.createQuery(DigitalEndowmentAPIReportESubView.class);
        Root<DigitalEndowmentAPIReportESubView> rootEntry = cq.from(DigitalEndowmentAPIReportESubView.class);
        CriteriaQuery<DigitalEndowmentAPIReportESubView> all = cq.select(rootEntry);
        TypedQuery<DigitalEndowmentAPIReportESubView> allQuery = em.createQuery(all);
        return allQuery.getResultList();
    }
	
	@Override
	public List <DigitalEndowmentAPIReportTrancheView> getDigitalEndowmentAPIReportTranche() {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<DigitalEndowmentAPIReportTrancheView> cq = cb.createQuery(DigitalEndowmentAPIReportTrancheView.class);
        Root<DigitalEndowmentAPIReportTrancheView> rootEntry = cq.from(DigitalEndowmentAPIReportTrancheView.class);
        CriteriaQuery<DigitalEndowmentAPIReportTrancheView> all = cq.select(rootEntry);
        TypedQuery<DigitalEndowmentAPIReportTrancheView> allQuery = em.createQuery(all);
        return allQuery.getResultList();
		}

}
