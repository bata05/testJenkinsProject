package com.prudential.d2c.security;

import io.jsonwebtoken.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.DatatypeConverter;
import java.security.Key;
import java.util.Date;
import java.util.LinkedHashMap;

@Component
public class JwtProvider {


    @Value("${security.jwt.secret}")
    private String secretkey;

    @Value("${security.jwt.validity}")
    private long ttlMillis;

    SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS256;

    public String createJWT(String customId, String productId, LinkedHashMap<String, String> payload) {

        long nowMillis = System.currentTimeMillis();
        Date now = new Date(nowMillis);

        byte[] apiKeySecretBytes = DatatypeConverter.parseBase64Binary(secretkey);
        Key signingKey = new SecretKeySpec(apiKeySecretBytes, signatureAlgorithm.getJcaName());

        Claims claims = Jwts.claims().setId(customId)
                .setSubject(productId);
        claims.put("payload", payload);


        JwtBuilder builder = Jwts.builder().setIssuedAt(now)
                .setClaims(claims)
                .setIssuer("D2C")
                .compressWith(CompressionCodecs.DEFLATE)
                .signWith(signingKey, signatureAlgorithm);

        if (ttlMillis >= 0) {
            long expMillis = nowMillis + ttlMillis;
            Date exp = new Date(expMillis);
            builder.setExpiration(exp);
        }

        return builder.compact();
    }

    public Claims parseJWT(String token) {

        Claims claims = Jwts.parser()
                .setSigningKey(DatatypeConverter.parseBase64Binary(secretkey))
                .parseClaimsJws(token).getBody();
        return claims;
    }

    public String resolveToken(HttpServletRequest httpServletRequest) {
        String bearerToken = httpServletRequest.getHeader("Authorization");
        if (bearerToken != null && bearerToken.startsWith("Bearer ")) {
            return bearerToken.substring(7, bearerToken.length());
        }
        return null;
    }

    public boolean validateToken(String token) {
        Jwts.parser().setSigningKey((DatatypeConverter.parseBase64Binary(secretkey))).parseClaimsJws(token);
        return true;
    }

    @SuppressWarnings("unchecked")
	public String createJwtWithExisting(String token) {
        Claims claims = parseJWT(token);
        return createJWT(claims.getId(), claims.getSubject(), (LinkedHashMap<String, String>) claims.get("payload"));
    }
}
