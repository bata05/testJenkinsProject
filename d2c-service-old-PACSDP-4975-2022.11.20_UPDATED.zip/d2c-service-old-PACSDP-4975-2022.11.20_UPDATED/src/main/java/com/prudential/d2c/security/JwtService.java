package com.prudential.d2c.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;

@Service
public class JwtService {

    @Autowired
    private JwtProvider jwtProvider;

    public String getJwtCustomId(HttpServletRequest httpServletRequest) {
        String token = jwtProvider.resolveToken(httpServletRequest);
        return jwtProvider.parseJWT(token).getId();
    }
}
