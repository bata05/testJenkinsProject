package com.prudential.d2c.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
public class SecurityConfiguration {


    @Value("${security.jwt.whitelist.entries}")
    String[] whitelistedUrls;

    @Autowired
    private JwtProvider jwtProvider;

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.logout().disable()
        .csrf().disable()
        .formLogin().disable()
        .authorizeRequests()
        .antMatchers("/**").permitAll().and().addFilterBefore(new JwtVerficationFilter(jwtProvider), UsernamePasswordAuthenticationFilter.class)
        .headers()
        .xssProtection()
        .and()
        .contentSecurityPolicy("form-action 'self'");
        http.logout();
        
        return http.build();
    }

    @Bean
    public WebSecurityCustomizer webSecurityCustomizer() {
    	return (web) -> web.ignoring().antMatchers(whitelistedUrls).antMatchers(HttpMethod.OPTIONS, "/**");
    }
}
