package com.prudential.d2c.service;

import com.prudential.d2c.common.ChannelSource;
import com.prudential.d2c.entity.config.ChannelProductMapping;

public interface AgentAssignmentService {

    public ChannelProductMapping getAAChannelSubChannel(String prodCode);

    public ChannelSource getChannel();

    public boolean isSaleCompletionAgentAssignmentCallRequired();
}
