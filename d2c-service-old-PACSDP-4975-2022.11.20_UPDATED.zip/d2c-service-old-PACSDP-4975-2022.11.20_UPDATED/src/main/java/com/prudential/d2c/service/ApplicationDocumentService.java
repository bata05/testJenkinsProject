package com.prudential.d2c.service;

import com.prudential.d2c.entity.dto.ApplicationDocument;
import com.prudential.d2c.entity.micro.Compute;

public interface ApplicationDocumentService {

	void saveApplicationDocuments(Compute compute, ApplicationDocument appDocument);

	ApplicationDocument findByErefNoAndCustomId(String erefNo, String customId);

}
