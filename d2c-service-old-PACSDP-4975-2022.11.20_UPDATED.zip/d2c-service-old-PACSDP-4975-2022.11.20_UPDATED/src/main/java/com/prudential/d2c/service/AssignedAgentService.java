package com.prudential.d2c.service;

import com.prudential.d2c.entity.dto.CustomerApplication;
import com.prudential.d2c.entity.dto.MailList;
import com.prudential.d2c.entity.micro.AgentData;
import com.prudential.d2c.entity.micro.AssignAgentRequest;
import com.prudential.d2c.entity.micro.payload.AssignAgentResponsePayload;
import com.prudential.d2c.entity.micro.payload.ComputeResponsePayload;

/**
 * This class is to get agent info in DB or call agent API or allocate the assigned agent 
 *
 */
public interface AssignedAgentService {

    
    /**
     * get agent info in local DB and return agent code back
     * 
     * @param customId
     *          to get agent based on customId
     * @return String
     */
    String getAgentCodeByCustomId(String customId);
    
    
    /**
     * to get agent info in local DB which has stored it in mail list close browser type
     * 
     * @param customId
     *          to get agent according to customId
     * @return AgentData
     */
    AgentData getAgentByCustomId(String customId);

    /**
     * this method is used to call agent API to get assigned agent group back
     * 
     * @param assignAgentRequest
     *            the prepared data for request,need properties here: nric,clientNumber,gender,nationality,selectedProducts,proType,channelType
     * @return AssignAgentResponsePayload
     *            agent API returned result, the structure is based on what API returns.
     */
    AssignAgentResponsePayload callAssignAgent(AssignAgentRequest assignAgentRequest);

    AgentAssignmentService getAgentAssignmentClass(String channelCode);

    AgentData getSaleCompletionAgent(String customId,ComputeResponsePayload computeResponsePayload);

    MailList getMailListForSale(String customId, CustomerApplication customerApplication,
                                       ComputeResponsePayload computeResponsePayload);

    AgentAssignmentService getPartnerAgentAssignmentService(String channelCode);
    
    /**
     * Get sale completed agent Code by customId.
     * If details present in Agent_Details, fetch agentCode and return.
     * Else, fetch from Mail_List and return.
     *
     * @param customId
     * @return
     */
    String getSaleCompletionAgentCode(String customId);
    
    void saveAgentData(String customId, AgentData agentData);

}
