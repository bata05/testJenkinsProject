package com.prudential.d2c.service;

import com.prudential.d2c.entity.dto.BusinessLookUp;

import java.util.List;

public interface BusinessLookUpService {

	public List<BusinessLookUp> getBusinessLookUpDetails(Integer channel, String action);
	public BusinessLookUp getBusinessLookUpDetailsById(Integer laBizSrcLookupId);
}
