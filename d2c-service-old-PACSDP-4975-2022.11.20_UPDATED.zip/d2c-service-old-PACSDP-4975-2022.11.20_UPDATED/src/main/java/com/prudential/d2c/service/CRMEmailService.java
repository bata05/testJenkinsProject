package com.prudential.d2c.service;

import com.prudential.d2c.entity.dto.MailList;

public interface CRMEmailService {

	public String triggerJourney(MailList mail);
	
}
