package com.prudential.d2c.service;

import com.prudential.d2c.entity.config.Campaigns;
import com.prudential.d2c.exception.D2CConfigException;

public interface CampaignsService {

    public Campaigns validateCampaign(Campaigns campaigns) throws D2CConfigException;
    public Campaigns validateCampaignWithChannel(Campaigns campaigns) throws D2CConfigException;
    public Campaigns validateCampaignsWithChannelAndProduct(Campaigns campaigns) throws D2CConfigException;
}
