package com.prudential.d2c.service;


import java.util.Optional;

import com.prudential.d2c.entity.ChannelAPIDto;
import com.prudential.d2c.entity.config.ProductsConfig;
import com.prudential.d2c.entity.dto.ChannelAPIAudit;
import com.prudential.d2c.entity.micro.ChannelAPIAppSubmissionResponse;
import com.prudential.d2c.entity.micro.ChannelAPIQuotationAndQuotationDocumentResponse;
import com.prudential.d2c.entity.micro.payload.ComputeResponsePayload;

public interface ChannelAPIService {


    /**
     * Quotation Information.
     * <p>
     * <br/>Null If Exception / No Response from downstream
     *
     * @param channelAPIDto
     * @return
     */
    public ChannelAPIQuotationAndQuotationDocumentResponse getQuotation(ChannelAPIDto channelAPIDto);

    /**
     * Quotation Document Information From Front Token
     * <p>
     * <br/>Null If Exception / No Response from downstream
     *
     * @param channelAPIDto
     * @return
     */
    public ChannelAPIQuotationAndQuotationDocumentResponse getQuotationDocument(ChannelAPIDto channelAPIDto);

    /**
     * Fetching DP Transaction ID corresponding to Channel Transaction ID
     *
     * @param transactionId
     * @return
     */
    public String getDPTransactionIDForChannelAPITransaction(String transactionId);

    /**
     * Updating Channel API Request & Response in Audit
     *
     * @param channelAPIDto
     */
    public void updateChannelAPIAudit(ChannelAPIDto channelAPIDto);

    /**
     * Persist Customer Information For Further Product Purchase
     *
     * @param channelAPIDto
     * @param computeResponsePayload
     */
    public void saveCustomerInformation(ChannelAPIDto channelAPIDto, ComputeResponsePayload computeResponsePayload);

    /**
     * Fetching DP ChannelAPIAudit corresponding to Transaction ID, ApiType, ApiStatus
     *
     * @param transactionId
     * @param apiType
     * @param apiStatus
     * @returnChannelAPIAudit
     */
    Optional<ChannelAPIAudit> getChannelAPIAuditForTransactionAndApiTypeAndApiStatus(String transactionId, String apiType, String apiStatus);

    /**
     * Persist Customer Application Information and fetches the policyNumber for the success application
     *
     * @param channelAPIDto
     */
    ChannelAPIAppSubmissionResponse submitCustomerApplication(ChannelAPIDto channelAPIDto);

    /**
     * Persisting Channel API Audit
     *
     * @param channelAPIAudit
     */
    void saveChannelAPIAudit(ChannelAPIAudit channelAPIAudit);

    Optional<ProductsConfig> loadProductsConfigByProductType(String productType);

}