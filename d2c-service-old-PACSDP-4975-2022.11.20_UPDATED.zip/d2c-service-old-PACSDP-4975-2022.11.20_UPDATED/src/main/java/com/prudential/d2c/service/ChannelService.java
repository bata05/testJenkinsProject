package com.prudential.d2c.service;

import com.prudential.d2c.entity.config.Channels;
import com.prudential.d2c.exception.D2CConfigException;

public interface ChannelService {

    public Channels validateChannel(String channelCode) throws D2CConfigException;

    public Channels validateChannelByName(String channelName) throws D2CConfigException;
    
    public Channels validateDEChannelByName(String channelName) throws D2CConfigException;

}
