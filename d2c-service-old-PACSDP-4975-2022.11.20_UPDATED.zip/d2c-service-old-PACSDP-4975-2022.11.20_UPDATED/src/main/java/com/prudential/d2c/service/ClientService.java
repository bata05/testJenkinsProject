package com.prudential.d2c.service;

import java.util.List;

import com.prudential.d2c.entity.micro.*;
import com.prudential.d2c.entity.micro.payload.ClientSearchResponsePayload;

public interface ClientService {

    ClientSearchResponsePayload searchClient(Boolean relativeSearch, LifeProfile lifeProfile);

    ClientResponse getClientInfo(String clientNumber);

    ClientResponse getClientByPolicyNumber(String policyNumber);

    List<ClientInfo> getClientByLifeProfile(LifeProfile lifeProfile, boolean relativeSearch);

    List<ClientInfo> getClientByClientNumber(String clientNumber);

    ClientPolicyResponse checkPolicyByNric(String nric);

}
