package com.prudential.d2c.service;

import com.prudential.d2c.common.ProductComputeValidatorEnum;
import com.prudential.d2c.entity.ComputeBean;
import com.prudential.d2c.entity.dto.CustomerApplication;
import com.prudential.d2c.entity.micro.payload.ComputeResponsePayload;

public interface ComputeRequestValidator {

    public boolean validateComputeAllRequest(ComputeBean computeRequestFromClient, ComputeResponsePayload savedResponse);

    public ProductComputeValidatorEnum getProduct();

    public boolean validateComputeAllRequestFromService(ComputeBean bean, ComputeResponsePayload computeResponsePayload, CustomerApplication customerApplication);

    public boolean validateComputeRequestFromService(ComputeBean bean, ComputeResponsePayload computeResponsePayload);

    public boolean validateProduct(ComputeBean computeRequest);

}
