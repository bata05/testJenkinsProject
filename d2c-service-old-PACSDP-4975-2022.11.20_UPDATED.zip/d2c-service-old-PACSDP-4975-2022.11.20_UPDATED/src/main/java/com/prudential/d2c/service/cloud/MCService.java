package com.prudential.d2c.service.cloud;

import com.prudential.d2c.entity.marketingcloud.ContactRequest;
import com.prudential.d2c.entity.marketingcloud.ContactResponse;
import com.prudential.d2c.entity.marketingcloud.EventRequest;
import com.prudential.d2c.entity.marketingcloud.EventResponse;
import com.prudential.d2c.entity.marketingcloud.MCToken;

public interface MCService {

	public MCToken getAccessToken();

	public ContactResponse contact(String key, ContactRequest request);

	public EventResponse event(String key, EventRequest request);
}
