package com.prudential.d2c.service.cloud.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.prudential.d2c.common.ConfigProperties;
import com.prudential.d2c.entity.marketingcloud.ContactRequest;
import com.prudential.d2c.entity.marketingcloud.ContactResponse;
import com.prudential.d2c.entity.marketingcloud.EventRequest;
import com.prudential.d2c.entity.marketingcloud.EventResponse;
import com.prudential.d2c.entity.marketingcloud.MCApp;
import com.prudential.d2c.entity.marketingcloud.MCToken;
import com.prudential.d2c.exception.D2CException;
import com.prudential.d2c.service.CustomerApplicationService;
import com.prudential.d2c.service.PdfService;
import com.prudential.d2c.service.cloud.MCService;
import com.prudential.d2c.utils.HttpHeadersUtil;
import static com.prudential.d2c.utils.StaticFileUtil.convertObjectToJsonFormat;

@Service
public class MCServiceImpl implements MCService {
	private static final String AUTHORIZATION = "Authorization";

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	public ConfigProperties configProperties;

	@Autowired
	public CustomerApplicationService applicationService;

	@Autowired
	public PdfService pdfService;

	@Autowired
	@Qualifier("mcRestTemplate")
	private RestTemplate mcRestTemplate;

	@Override
	public MCToken getAccessToken() {

		logger.info("Invoking getAccessToken for Marketing Cloud.");
		HttpHeaders headers = HttpHeadersUtil.getHeaders();

		MCApp app = new MCApp();
		app.setClient_id(configProperties.getMcAppClientId());
		app.setClient_secret(configProperties.getMcAppClientSecret());
		app.setGrant_type(configProperties.getMcAppGrantType());

		HttpEntity<MCApp> entityReq = new HttpEntity<>(app, headers);

		logger.debug("Marketing Cloud Request Access Token: {} ", convertObjectToJsonFormat(app));

		MCToken token = new MCToken();

		try {
			token = mcRestTemplate.postForObject(configProperties.getMcAppRequestTokenUrl(), entityReq, MCToken.class);

			logger.debug("Marketing Cloud Access Token Response: {}", convertObjectToJsonFormat(token));

		} catch (Exception e) {
			logger.error("Error while generate token for marketing cloud service API calling.", e);
			throw new D2CException(e);
		}
		return token;

	}

	@Override
	public ContactResponse contact(String key, ContactRequest request) {
		HttpHeaders headers = HttpHeadersUtil.getHeaders();
		headers.add(AUTHORIZATION, key);

		HttpEntity<ContactRequest> entityReq = new HttpEntity<>(request, headers);

		logger.debug("Marketing Cloud Contact Request: {}", convertObjectToJsonFormat(request));

		ContactResponse response = mcRestTemplate.postForObject(configProperties.getMcAppContactsUrl(), entityReq,
				ContactResponse.class);

		logger.debug("Marketing Cloud Contact Response: {}", convertObjectToJsonFormat(response));

		return response;
	}

	@Override
	public EventResponse event(String key, EventRequest request) {
		HttpHeaders headers = HttpHeadersUtil.getHeaders();
		headers.add(AUTHORIZATION, key);

		logger.debug("Marketing Cloud Event Request: {}", convertObjectToJsonFormat(request));

		HttpEntity<EventRequest> entityReq = new HttpEntity<>(request, headers);

		EventResponse response = mcRestTemplate.postForObject(configProperties.getMcAppDataEventsUrl(), entityReq,
				EventResponse.class);
		logger.debug("Marketing Cloud Event Response: {}", response);
		return response;
	}
}
