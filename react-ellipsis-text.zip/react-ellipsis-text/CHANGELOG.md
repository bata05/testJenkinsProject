## Change Log

### Ver 1.2.1
  * Update dependencies with `ncu -u`
  * Add codebeat

### Ver 1.2.0
  * Update dependencies, add core-js@3
  * Change url from georgeosddev to mobilusoss #10

### Ver 1.1.0
  * [Upgraded to separate PropTypes package](https://github.com/mobilusoss/react-ellipsis-text/pull/9)

### Ver 1.0.0
  * Update React from v0.14.x to v15.x
  * Remove `tooltip` option.
  * Change root element from `div` to `span`.

### Ver 0.2.0

  * #3 Support React v0.14.x
  * #2 Publish transpiled ES2015 code
  * Change propType of `tooltip`

### Ver 0.1.0 Initial release
