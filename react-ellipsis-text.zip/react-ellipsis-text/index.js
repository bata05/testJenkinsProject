module.exports = require('./lib/components/EllipsisText');
